import 'package:flutter_test/flutter_test.dart';
import 'package:schola_ecs/app/router.dart';
import 'package:schola_ecs/core/ecs/ecs_seed_data.dart';
import 'package:schola_ecs/core/ecs/schola_ecs_repository.dart';
import 'package:schola_ecs/core/ecs/school_entity.dart';
import 'package:schola_ecs/features/admin_dashboard/domain/syllabus_coverage_system.dart';
import 'package:schola_ecs/features/auth/data/firebase_auth_repository.dart';
import 'package:schola_ecs/features/auth/domain/auth_user.dart';
import 'package:schola_ecs/features/auth/domain/firebase_web_config.dart';
import 'package:schola_ecs/features/class_register/domain/attendance_record.dart';
import 'package:schola_ecs/features/learners/domain/learner.dart';
import 'package:schola_ecs/features/learners/domain/learner_longitudinal_system.dart';
import 'package:schola_ecs/features/lesson_plans/domain/lesson_plan.dart';
import 'package:schola_ecs/features/timetable/domain/timetable_slot.dart';

void main() {
  test('Marking a Lesson Plan taught immediately updates Admin Substrand Coverage', () async {
    final notifier = SchoolEcsNotifier(useFirestore: false);
    final before = SyllabusCoverageSystem.computeSubstrandCoverage(notifier.state)
        .firstWhere((r) => r.substrand.id == 'sub_e1_1');
    expect(before.coveragePercent, 0);

    await notifier.updateLessonPlanStatus('lp_04', LessonStatus.taught, 4);
    final after = SyllabusCoverageSystem.computeSubstrandCoverage(notifier.state)
        .firstWhere((r) => r.substrand.id == 'sub_e1_1');
    expect(after.coveragePercent, 100);
  });

  test('Learner longitudinal report strips staff-only fields for Parents and filters timeframes', () {
    final sinceReg = LearnerLongitudinalSystem.buildReport(
      initialSchoolEcsState,
      'lrn_01',
      PortalRole.parent,
      const LearnerTimeframe(preset: TimeframePreset.sinceRegistration),
    );
    expect(sinceReg, isNotNull);
    expect(sinceReg!.diary.length, 2);
    expect(sinceReg.attendance.first.customFields.containsKey('uniform_compliant'), isFalse);

    final last30 = LearnerLongitudinalSystem.buildReport(
      initialSchoolEcsState,
      'lrn_01',
      PortalRole.parent,
      const LearnerTimeframe(preset: TimeframePreset.last30Days),
    );
    expect(last30!.diary.length, 1);
  });

  test('Admin can create, update, delete dynamic fields and update learner custom fields', () async {
    final notifier = SchoolEcsNotifier(useFirestore: false);
    const created = DynamicFieldDefinition(
      id: 'fld_test_style',
      targetEntityType: EntityType.learner,
      key: 'learning_style',
      label: 'Learning Style',
      fieldType: DynamicFieldType.select,
      options: ['Visual', 'Kinesthetic'],
      visibleTo: [PortalRole.admin, PortalRole.teacher],
      editableBy: [PortalRole.admin],
      description: 'Preferred learning mode',
    );
    await notifier.registerDynamicField(created);
    expect(notifier.state.dynamicFields.any((f) => f.id == 'fld_test_style'), isTrue);

    await notifier.updateDynamicField(
      const DynamicFieldDefinition(
        id: 'fld_test_style',
        targetEntityType: EntityType.learner,
        key: 'learning_style_v2',
        label: 'Learning Style V2',
        fieldType: DynamicFieldType.select,
        options: ['Visual', 'Kinesthetic', 'Auditory'],
        required: true,
        visibleTo: [PortalRole.admin, PortalRole.teacher, PortalRole.parent],
        editableBy: [PortalRole.admin, PortalRole.teacher],
        description: 'Updated learning mode',
      ),
    );
    final updated = notifier.state.dynamicFields.firstWhere((f) => f.id == 'fld_test_style');
    expect(updated.required, isTrue);
    expect(updated.visibleTo.contains(PortalRole.parent), isTrue);

    await notifier.updateLearnerProfile(
      learnerId: 'lrn_01',
      name: 'Zuri Mwangi',
      enrollmentStatus: 'Active',
      parentName: 'Grace Mwangi',
      guardianPhone: '+254 712 401 218',
      internalHealthNote: 'Updated note',
      customFields: const {'learning_style_v2': 'Auditory'},
    );
    final learner = notifier.state.learners.firstWhere((l) => l.id == 'lrn_01');
    expect(learner.customFields['learning_style_v2'], 'Auditory');

    await notifier.archiveDynamicField('fld_test_style');
    final archived = notifier.state.dynamicFields.firstWhere((f) => f.id == 'fld_test_style');
    expect(archived.archived, isTrue);

    await notifier.restoreDynamicField('fld_test_style');
    final restored = notifier.state.dynamicFields.firstWhere((f) => f.id == 'fld_test_style');
    expect(restored.archived, isFalse);
  });

  test('Verified default admin email resolves to admin while unverified/other emails default to parent', () {
    expect(isDefaultAdminEmail('prelanadm@gmail.com'), isTrue);
    expect(isDefaultAdminEmail(' PRELANADM@GMAIL.COM '), isTrue);
    expect(isDefaultAdminEmail('teacher@scholaecs.edu'), isFalse);

    expect(
      resolveBootstrapRole(email: 'prelanadm@gmail.com', emailVerified: true),
      PortalRole.admin,
    );
    expect(
      resolveBootstrapRole(email: 'prelanadm@gmail.com', emailVerified: false),
      PortalRole.parent,
    );
    expect(
      resolveBootstrapRole(email: 'someone@example.com', emailVerified: true),
      PortalRole.parent,
    );
    expect(
      resolveBootstrapRole(
        email: 'teacher@example.com',
        emailVerified: true,
        existingRole: PortalRole.teacher,
      ),
      PortalRole.teacher,
    );
  });

  test('Batch classroom diary broadcast and Mark All Present update all learners in classroom', () async {
    final notifier = SchoolEcsNotifier(useFirestore: false);
    final class5ALearners =
        notifier.state.learners.where((l) => l.classroomId == 'cls_5a').length;

    final diaryCount = await notifier.broadcastClassroomDiary(
      classroomId: 'cls_5a',
      teacherId: 'tch_amara',
      date: '2026-11-25',
      homeworkSummary: 'Complete fractions worksheet #4',
      teacherNote: 'Show working steps.',
      customFields: const {},
    );
    expect(diaryCount, class5ALearners);

    final regCount = await notifier.markClassroomAllPresent(
      classroomId: 'cls_5a',
      teacherId: 'tch_amara',
      date: '2026-11-26',
    );
    expect(regCount, class5ALearners);
    expect(
      notifier.state.attendanceRecords
          .where((r) => r.classroomId == 'cls_5a' && r.date == '2026-11-26')
          .every((r) => r.status == AttendanceStatus.present),
      isTrue,
    );
  });

  test('TimetableConflictValidator detects classroom, teacher, and room conflicts', () async {
    final notifier = SchoolEcsNotifier(useFirestore: false);
    final first = notifier.state.timetableSlots.first;

    final classConflict = await notifier.upsertTimetableSlot(
      TimetableSlotEntity(
        id: 'tt_bad_class',
        classroomId: first.classroomId,
        subjectId: 'sub_eng',
        teacherId: 'tch_david',
        day: first.day,
        period: first.period,
        timeRange: first.timeRange,
        room: 'ALT-99',
      ),
    );
    expect(classConflict, isNotNull);

    final teacherConflict = await notifier.upsertTimetableSlot(
      TimetableSlotEntity(
        id: 'tt_bad_teacher',
        classroomId: 'cls_6b',
        subjectId: first.subjectId,
        teacherId: first.teacherId,
        day: first.day,
        period: first.period,
        timeRange: first.timeRange,
        room: 'ALT-98',
      ),
    );
    expect(teacherConflict, isNotNull);

    final roomConflict = await notifier.upsertTimetableSlot(
      TimetableSlotEntity(
        id: 'tt_bad_room',
        classroomId: 'cls_6b',
        subjectId: 'sub_eng',
        teacherId: 'tch_david',
        day: first.day,
        period: first.period,
        timeRange: first.timeRange,
        room: first.room,
      ),
    );
    expect(roomConflict, isNotNull);

    final validResult = await notifier.upsertTimetableSlot(
      const TimetableSlotEntity(
        id: 'tt_valid_new',
        classroomId: 'cls_5a',
        subjectId: 'sub_sci',
        teacherId: 'tch_david',
        day: 'Fri',
        period: 4,
        timeRange: '11:30 - 12:15',
        room: 'LAB-1',
      ),
    );
    expect(validResult, isNull);
  });

  test('GoRouter evaluatePortalRedirect enforces auth, role guards, and multi-child parent scope', () {
    const teacher = AuthUser(
      uid: 'u_t1',
      email: 't@school.edu',
      displayName: 'Teacher',
      role: PortalRole.teacher,
    );
    const parent = AuthUser(
      uid: 'u_p1',
      email: 'p@school.edu',
      displayName: 'Parent',
      role: PortalRole.parent,
      linkedLearnerIds: ['lrn_01', 'lrn_02'],
    );
    const admin = AuthUser(
      uid: 'u_a1',
      email: 'a@school.edu',
      displayName: 'Admin',
      role: PortalRole.admin,
    );

    expect(
      evaluatePortalRedirect(
        location: '/login',
        firebaseReady: true,
        authLoading: false,
        user: null,
      ),
      isNull,
    );
    expect(
      evaluatePortalRedirect(
        location: '/learners',
        firebaseReady: true,
        authLoading: false,
        user: null,
      ),
      '/login',
    );
    expect(
      evaluatePortalRedirect(
        location: '/login',
        firebaseReady: true,
        authLoading: false,
        user: teacher,
      ),
      '/',
    );
    expect(
      evaluatePortalRedirect(
        location: '/schema',
        firebaseReady: true,
        authLoading: false,
        user: teacher,
      ),
      '/',
    );
    expect(
      evaluatePortalRedirect(
        location: '/parents',
        firebaseReady: true,
        authLoading: false,
        user: teacher,
      ),
      '/',
    );
    expect(
      evaluatePortalRedirect(
        location: '/schemes',
        firebaseReady: true,
        authLoading: false,
        user: parent,
      ),
      '/',
    );
    expect(
      evaluatePortalRedirect(
        location: '/learners/lrn_99',
        firebaseReady: true,
        authLoading: false,
        user: parent,
      ),
      '/learners/lrn_01',
    );
    expect(
      evaluatePortalRedirect(
        location: '/learners/lrn_02',
        firebaseReady: true,
        authLoading: false,
        user: parent,
      ),
      isNull,
    );
    expect(
      evaluatePortalRedirect(
        location: '/classrooms',
        firebaseReady: true,
        authLoading: false,
        user: admin,
      ),
      isNull,
    );
  });

  test('Subject mastery progression and markdown report export summarize longitudinal data', () {
    final progression = LearnerLongitudinalSystem.computeSubjectProgression(
      initialSchoolEcsState,
      'lrn_01',
      '2026-01-10',
      '2026-11-25',
    );
    expect(progression, isNotEmpty);

    final report = LearnerLongitudinalSystem.buildReport(
      initialSchoolEcsState,
      'lrn_01',
      PortalRole.parent,
      const LearnerTimeframe(preset: TimeframePreset.sinceRegistration),
    )!;
    final md = LearnerReportFormatter.toMarkdown(initialSchoolEcsState, report);
    expect(md.contains('# ScholaECS Longitudinal Progress Report'), isTrue);
    expect(md.contains(report.learner.name), isTrue);
  });

  test('Admin Schedule Days CRUD & classroom mapping work with Timetable & Lesson Registry binding', () async {
    final notifier = SchoolEcsNotifier(useFirestore: false);

    // 1. Add Saturday Clinic day mapped only to cls_5a
    final dayErr = await notifier.upsertScheduleDay(
      const ScheduleDayEntity(
        id: 'day_sat',
        code: 'Sat',
        label: 'Saturday Clinic',
        order: 6,
        classroomIds: ['cls_5a'],
        defaultTimeRange: '09:00 - 10:30',
      ),
    );
    expect(dayErr, isNull);
    expect(notifier.scheduleDaysForClassroom('cls_5a').any((d) => d.code == 'Sat'), isTrue);
    expect(notifier.scheduleDaysForClassroom('cls_6b').any((d) => d.code == 'Sat'), isFalse);

    // Toggle cls_6b ON for Sat
    await notifier.toggleDayClassroomMapping('day_sat', 'cls_6b');
    expect(notifier.scheduleDaysForClassroom('cls_6b').any((d) => d.code == 'Sat'), isTrue);

    // 2. Add Classroom mapped to Mon + Sat
    final clsErr = await notifier.upsertClassroom(
      const ClassroomEntity(
        id: 'cls_7a',
        name: 'Grade 7A — Cedar',
        gradeLevel: 'Grade 7',
        roomCode: 'C1-02',
      ),
      mapDayIds: ['day_mon', 'day_sat'],
    );
    expect(clsErr, isNull);
    expect(notifier.scheduleDaysForClassroom('cls_7a').length, 2);

    // 3. Assign unassigned registered lesson lp_05 onto a newly created Sat slot
    final slotErr = await notifier.upsertTimetableSlot(
      const TimetableSlotEntity(
        id: 'tt_sat_clinic',
        classroomId: 'cls_5a',
        subjectId: 'sub_math',
        teacherId: 'tch_david',
        day: 'Sat',
        period: 1,
        timeRange: '09:00 - 10:30',
        room: 'B2-04',
        lessonPlanId: 'lp_05',
      ),
      syncLessonBinding: true,
    );
    expect(slotErr, isNull);
    final boundPlan = notifier.state.lessonPlans.firstWhere((lp) => lp.id == 'lp_05');
    expect(boundPlan.timetableSlotId, 'tt_sat_clinic');

    // 4. Overlapping HH:MM conflict rejected even with a different Period #
    final overlapErr = await notifier.upsertTimetableSlot(
      const TimetableSlotEntity(
        id: 'tt_sat_overlap',
        classroomId: 'cls_6b',
        subjectId: 'sub_eng',
        teacherId: 'tch_david',
        day: 'Sat',
        period: 2,
        timeRange: '09:30 - 10:15',
        room: 'B2-08',
      ),
    );
    expect(overlapErr, isNotNull);

    // 5. Delete schedule day detaches slots cleanly without losing registered lesson
    await notifier.deleteScheduleDay('day_sat');
    expect(notifier.state.timetableSlots.any((s) => s.id == 'tt_sat_clinic'), isFalse);
    final detachedPlan = notifier.state.lessonPlans.firstWhere((lp) => lp.id == 'lp_05');
    expect(detachedPlan.timetableSlotId, isNull);

    // 6. Delete lesson plan clears any slot pointer
    await notifier.assignLessonToTimetableSlot(
      lessonPlanId: 'lp_05',
      timetableSlotId: 'slot_thu_2',
      syncSlotSubjectAndTeacher: true,
    );
    expect(
      notifier.state.timetableSlots.firstWhere((s) => s.id == 'slot_thu_2').lessonPlanId,
      'lp_05',
    );
    await notifier.deleteLessonPlan('lp_05');
    expect(notifier.state.lessonPlans.any((lp) => lp.id == 'lp_05'), isFalse);
    expect(
      notifier.state.timetableSlots.firstWhere((s) => s.id == 'slot_thu_2').lessonPlanId,
      isNull,
    );
  });

  test('parseFirebaseWebConfigSnippet parses both Firebase Console JS and JSON formats', () {
    const jsSnippet = '''
      const firebaseConfig = {
        apiKey: "AIzaSyExampleKey123",
        authDomain: "schola-ecs.firebaseapp.com",
        projectId: "schola-ecs",
        storageBucket: "schola-ecs.firebasestorage.app",
        messagingSenderId: "9988776655",
        appId: "1:9988776655:web:abc123def456",
      };
    ''';
    final parsedJs = parseFirebaseWebConfigSnippet(jsSnippet);
    expect(parsedJs, isNotNull);
    expect(parsedJs!.projectId, 'schola-ecs');
    expect(parsedJs.apiKey, 'AIzaSyExampleKey123');
    expect(parsedJs.effectiveAuthDomain, 'schola-ecs.firebaseapp.com');

    const jsonSnippet =
        '{"apiKey":"AIzaJsonKey","appId":"1:111:web:222","messagingSenderId":"111","projectId":"schola-json"}';
    final parsedJson = parseFirebaseWebConfigSnippet(jsonSnippet);
    expect(parsedJson, isNotNull);
    expect(parsedJson!.effectiveAuthDomain, 'schola-json.firebaseapp.com');
    expect(parseFirebaseWebConfigSnippet('{"apiKey":""}'), isNull);
  });

  test('Class Teacher, two-way Teacher<->Class matrix, Parent rollups, and Who/When Audit Logs track changes', () async {
    final notifier = SchoolEcsNotifier(useFirestore: false);

    // 1. Two-way coverage matrix
    final clsMatrix = SyllabusCoverageSystem.computeClassroomMatrix(notifier.state);
    final grade5A = clsMatrix.firstWhere((c) => c.classroom.id == 'cls_5a');
    expect(grade5A.classTeacher?.id, 'tch_amara');
    expect(grade5A.teacherSlices.any((s) => s.teacher.id == 'tch_amara' && s.isClassTeacher), isTrue);

    final tchMatrix = SyllabusCoverageSystem.computeTeacherMatrix(notifier.state);
    final amara = tchMatrix.firstWhere((t) => t.teacher.id == 'tch_amara');
    expect(amara.homeroomClassrooms.any((c) => c.id == 'cls_5a'), isTrue);
    expect(amara.byClassroom.any((s) => s.classroom.id == 'cls_5a'), isTrue);

    // 2. Parent family summaries group siblings (Zuri & Maya under Grace Mwangi)
    final parents = SyllabusCoverageSystem.computeParentSummaries(notifier.state);
    final grace = parents.firstWhere((p) => p.parentEmail == 'grace.mwangi@family.org');
    expect(grace.children.length, 2);
    expect(grace.classrooms.length, 2);

    // 3. Assigning a new class teacher & teaching a lesson records Who & When audit entries
    final beforeAudits = notifier.state.auditLogs.length;
    await notifier.assignClassTeacher(classroomId: 'cls_5a', teacherId: 'tch_david');
    expect(
      notifier.state.classrooms.firstWhere((c) => c.id == 'cls_5a').classTeacherId,
      'tch_david',
    );
    await notifier.updateLessonPlanStatus(
      'lp_04',
      LessonStatus.taught,
      4,
      taughtByTeacherId: 'tch_david',
    );
    final updatedPlan =
        notifier.state.lessonPlans.firstWhere((lp) => lp.id == 'lp_04');
    expect(updatedPlan.taughtByTeacherId, 'tch_david');
    expect(updatedPlan.taughtAt, isNotNull);
    expect(notifier.state.auditLogs.length, beforeAudits + 2);
    expect(notifier.state.auditLogs.first.action, 'taught');
  });

  test('validateAuthInputs and LocalAuthRegistryNotifier support sign-up & sign-in across admin, teacher, and parent roles', () {
    expect(
      validateAuthInputs(
        isRegister: true,
        email: 'bad-email',
        password: '123',
        confirmPassword: '456',
        displayName: 'A',
      ),
      isNotNull,
    );
    expect(
      validateAuthInputs(
        isRegister: true,
        email: 'new.teacher@scholaecs.edu',
        password: 'Password123',
        confirmPassword: 'Password123',
        displayName: 'Wanjiku Njoroge',
      ),
      isNull,
    );

    final registry = LocalAuthRegistryNotifier();
    final createdTeacher = registry.register(
      email: 'wanjiku@scholaecs.edu',
      password: 'Password123',
      displayName: 'Wanjiku Njoroge',
      role: PortalRole.teacher,
      teacherId: 'tch_amara',
    );
    expect(createdTeacher.role, PortalRole.teacher);
    expect(createdTeacher.teacherId, 'tch_amara');

    final signedIn = registry.signIn('wanjiku@scholaecs.edu', 'Password123');
    expect(signedIn.uid, createdTeacher.uid);

    expect(
      () => registry.signIn('wanjiku@scholaecs.edu', 'WrongPass'),
      throwsFormatException,
    );

    final createdParent = registry.register(
      email: 'parent.new@family.org',
      password: 'Password123',
      displayName: 'Samuel Osei',
      role: PortalRole.parent,
      linkedLearnerIds: const ['lrn_01', 'lrn_04'],
    );
    expect(createdParent.role, PortalRole.parent);
    expect(createdParent.linkedLearnerIds, ['lrn_01', 'lrn_04']);
  });

  test('Schemes of Work Strands connect to specific Classrooms and scope coverage per class', () {
    final coverage = SyllabusCoverageSystem.computeSubstrandCoverage(initialSchoolEcsState);
    final grade5Math = coverage.firstWhere((r) => r.substrand.id == 'sub_m1_1');
    final grade6Math = coverage.firstWhere((r) => r.substrand.id == 'sub_m2_1');

    expect(grade5Math.strand?.classroomId, 'cls_5a');
    expect(grade5Math.classroom?.id, 'cls_5a');
    expect(grade6Math.strand?.classroomId, 'cls_6b');
    expect(grade6Math.classroom?.id, 'cls_6b');
  });

  test('Class Register copyClassroomAttendanceFromDate and Catchment Zone CRUD work cleanly', () async {
    final notifier = SchoolEcsNotifier(useFirestore: false);

    final copyRes = await notifier.copyClassroomAttendanceFromDate(
      classroomId: 'cls_5a',
      teacherId: 'tch_amara',
      toDate: '2026-11-26',
    );
    expect(copyRes.error, isNull);
    expect(copyRes.sourceDate, '2026-11-25');
    expect(copyRes.count, 3);

    final locErr = await notifier.upsertLocation(
      const LocationEntity(
        id: 'loc_lavington',
        name: 'Lavington',
        zone: 'West Route E',
        notes: 'Morning pickup 06:55',
      ),
    );
    expect(locErr, isNull);
    expect(notifier.state.locations.any((l) => l.id == 'loc_lavington'), isTrue);

    await notifier.deleteLocation('loc_kilimani');
    expect(notifier.state.locations.any((l) => l.id == 'loc_kilimani'), isFalse);
    expect(
      notifier.state.learners.firstWhere((l) => l.id == 'lrn_01').locationId,
      isNull,
    );
  });
}
