import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/ecs/ecs_providers.dart';
import '../../../core/ecs/school_entity.dart';
import '../../../core/widgets/action_feedback.dart';
import '../../../core/widgets/admin_ai_briefing_card.dart';
import '../../../core/widgets/analytics_charts.dart';
import '../../../features/assessment_books/domain/assessment_entry.dart';
import '../../../features/auth/data/firebase_auth_repository.dart';
import '../../../features/auth/domain/auth_user.dart';
import '../../../features/learners/domain/learner.dart';
import '../../../features/learners/domain/learner_longitudinal_system.dart';
import '../domain/school_event.dart';

class HomeDashboardPage extends ConsumerStatefulWidget {
  const HomeDashboardPage({super.key});

  @override
  ConsumerState<HomeDashboardPage> createState() => _HomeDashboardPageState();
}

class _HomeDashboardPageState extends ConsumerState<HomeDashboardPage>
    with BusyActionMixin {
  DateTime selectedCalendarDate = DateTime.now();

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(currentUserProvider).valueOrNull;
    final role = user?.role ?? PortalRole.admin;
    final ecsState = ref.watch(schoolEcsProvider);

    final totalLearners = ecsState.learners.length;
    final totalClassrooms = ecsState.classrooms.length;
    final totalTeachers = ecsState.teachers.length;

    // Compute mastery distribution counts for chart
    var exceeding = 0;
    var meeting = 0;
    var approaching = 0;
    var developing = 0;
    for (final a in ecsState.assessments) {
      switch (a.mastery) {
        case MasteryLevel.exceeding:
          exceeding++;
          break;
        case MasteryLevel.meeting:
          meeting++;
          break;
        case MasteryLevel.approaching:
          approaching++;
          break;
        case MasteryLevel.developing:
          developing++;
          break;
      }
    }

    final events = ecsState.schoolEvents;
    final dateStr =
        '${selectedCalendarDate.year}-${selectedCalendarDate.month.toString().padLeft(2, '0')}-${selectedCalendarDate.day.toString().padLeft(2, '0')}';
    final selectedDayEvents =
        events.where((e) => e.date == dateStr).toList();

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Welcome Banner
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF1E3A8A), Color(0xFF2563EB)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.blue.withOpacity(0.15),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                role.label,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            if (ecsState.isLiveSynced)
                              const Row(
                                children: [
                                  Icon(Icons.cloud_done,
                                      color: Color(0xFF34D399), size: 16),
                                  SizedBox(width: 4),
                                  Text(
                                    'Firestore Live Synced',
                                    style: TextStyle(
                                        color: Colors.white70, fontSize: 11),
                                  ),
                                ],
                              ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Text(
                          role == PortalRole.parent
                              ? 'Family & School Calendar'
                              : 'Today at School · ${user?.displayName ?? 'ScholaECS'}',
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          role == PortalRole.parent
                              ? 'Upcoming school events, holidays, and your linked children.'
                              : 'Daily schedule, pending diary sign-offs, and syllabus tracking.',
                          style: const TextStyle(
                            fontSize: 13,
                            color: Colors.white70,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (role == PortalRole.admin)
                    ElevatedButton.icon(
                      onPressed: isBusy ? null : () => _showEventDialog(context, ref, null),
                      icon: const Icon(Icons.add_circle_outline, size: 18),
                      label: const Text('Add School Event'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: const Color(0xFF1E3A8A),
                        elevation: 0,
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFCBD5E1)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Row(
                children: [
                  const Icon(Icons.swap_horiz, color: Color(0xFF2563EB)),
                  const SizedBox(width: 12),
                  const Text(
                    'Active Portal Mode:',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF0F172A),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: PortalRole.values.map((r) {
                        final isSelected = r == role;
                        return ChoiceChip(
                          label: Text(r.label),
                          selected: isSelected,
                          onSelected: (_) {
                            ref.read(demoSessionProvider.notifier).state = AuthUser(
                              uid: 'demo_${r.key}',
                              email: r == PortalRole.admin
                                  ? defaultAdminEmail
                                  : '${r.key}@scholaecs.edu',
                              displayName: r == PortalRole.admin
                                  ? 'Default Admin'
                                  : r.label,
                              role: r,
                              teacherId: 'tch_amara',
                              linkedLearnerIds: r == PortalRole.parent
                                  ? const ['lrn_01', 'lrn_02']
                                  : const ['lrn_01'],
                              emailVerified: true,
                              isDemoMode: true,
                            );
                          },
                          selectedColor: const Color(0xFF2563EB),
                          labelStyle: TextStyle(
                            color: isSelected ? Colors.white : const Color(0xFF1E293B),
                            fontWeight: FontWeight.w600,
                            fontSize: 12,
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            if (role == PortalRole.admin) ...[
              AdminAiBriefingCard(ecsState: ecsState),
              const SizedBox(height: 20),
            ],

            if (role == PortalRole.parent) ...[
              Builder(
                builder: (context) {
                  final linkedChildren = ecsState.learners
                      .where((l) =>
                          user == null ||
                          user.linkedLearnerIds.isEmpty ||
                          user.linkedLearnerIds.contains(l.id))
                      .toList();
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text(
                        'My Children Today',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF0F172A),
                        ),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Attendance, latest scores, and diary entries awaiting your sign-off.',
                        style: TextStyle(fontSize: 13, color: Color(0xFF64748B)),
                      ),
                      const SizedBox(height: 12),
                      if (linkedChildren.isEmpty)
                        Container(
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: const Color(0xFFE2E8F0)),
                          ),
                          child: const Text(
                            'No children are linked to your parent account yet. Contact the school office to link your child.',
                            style: TextStyle(fontSize: 13, color: Color(0xFF475569)),
                          ),
                        )
                      else
                        ...linkedChildren.map((child) {
                          final cls = ecsState.classrooms
                              .where((c) => c.id == child.classroomId)
                              .firstOrNull;
                          final loc = child.locationId == null
                              ? null
                              : ecsState.locations
                                  .where((z) => z.id == child.locationId)
                                  .firstOrNull;
                          final report = LearnerLongitudinalSystem.buildReport(
                            ecsState,
                            child.id,
                            PortalRole.parent,
                            const LearnerTimeframe(
                              preset: TimeframePreset.sinceRegistration,
                            ),
                          );
                          final pendingDiary = ecsState.diaryEntries
                              .where((d) =>
                                  d.learnerId == child.id &&
                                  !d.parentAcknowledged)
                              .toList();

                          return Container(
                            margin: const EdgeInsets.only(bottom: 12),
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: const Color(0xFFE2E8F0)),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Wrap(
                                  alignment: WrapAlignment.spaceBetween,
                                  crossAxisAlignment: WrapCrossAlignment.center,
                                  spacing: 12,
                                  runSpacing: 8,
                                  children: [
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          child.name,
                                          style: const TextStyle(
                                            fontSize: 17,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                        Text(
                                          '${cls?.name ?? child.classroomId}${loc != null ? ' · ${loc.name}' : ''} · Attendance: ${report?.attendanceRate ?? '—'}% · Avg: ${report?.averageScore ?? '—'}%',
                                          style: const TextStyle(
                                            fontSize: 12,
                                            color: Color(0xFF64748B),
                                          ),
                                        ),
                                      ],
                                    ),
                                    FilledButton.tonalIcon(
                                      onPressed: () {
                                        ref
                                            .read(selectedParentLearnerIdProvider
                                                .notifier)
                                            .state = child.id;
                                        context.go('/learners/${child.id}');
                                      },
                                      icon: const Icon(Icons.person_outline, size: 16),
                                      label: const Text("My Child's Details"),
                                    ),
                                  ],
                                ),
                                if (pendingDiary.isNotEmpty) ...[
                                  const Divider(height: 20),
                                  Text(
                                    '${pendingDiary.length} Diary Note${pendingDiary.length == 1 ? '' : 's'} Awaiting Sign-Off',
                                    style: const TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                      color: Color(0xFFB45309),
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  ...pendingDiary.take(2).map(
                                        (entry) => Container(
                                          margin: const EdgeInsets.only(bottom: 6),
                                          padding: const EdgeInsets.all(10),
                                          decoration: BoxDecoration(
                                            color: const Color(0xFFFFFBEB),
                                            borderRadius: BorderRadius.circular(10),
                                            border: Border.all(
                                                color: const Color(0xFFFDE68A)),
                                          ),
                                          child: Row(
                                            children: [
                                              Expanded(
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Text(
                                                      entry.date,
                                                      style: const TextStyle(
                                                        fontSize: 11,
                                                        color: Color(0xFF92400E),
                                                      ),
                                                    ),
                                                    Text(
                                                      entry.homeworkSummary,
                                                      style: const TextStyle(
                                                        fontSize: 13,
                                                        fontWeight: FontWeight.w600,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              const SizedBox(width: 8),
                                              FilledButton(
                                                onPressed: isBusy
                                                    ? null
                                                    : () => runLockedAction(() async {
                                                          await ref
                                                              .read(schoolEcsProvider
                                                                  .notifier)
                                                              .toggleDiaryAcknowledgment(
                                                                  entry.id);
                                                          if (!context.mounted) return;
                                                          showActionSnackBar(
                                                            context,
                                                            kind: ActionFeedbackKind
                                                                .success,
                                                            message:
                                                                'Diary signed off.',
                                                          );
                                                        }),
                                                child: Text(
                                                  isBusy ? 'Saving...' : 'Sign Off',
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                ],
                              ],
                            ),
                          );
                        }),
                    ],
                  );
                },
              ),
              const SizedBox(height: 24),
            ] else ...[
              // Overview KPI Cards (Staff / Admin)
              LayoutBuilder(
                builder: (context, constraints) {
                  final isWide = constraints.maxWidth > 800;
                  return Wrap(
                    spacing: 16,
                    runSpacing: 16,
                    children: [
                      _KpiCard(
                        title: 'Total Learners',
                        value: '$totalLearners Enrolled',
                        icon: Icons.people_outline,
                        color: const Color(0xFF2563EB),
                        width: isWide
                            ? (constraints.maxWidth - 32) / 3
                            : constraints.maxWidth,
                      ),
                      _KpiCard(
                        title: 'Active Classrooms',
                        value: '$totalClassrooms Streams',
                        icon: Icons.class_outlined,
                        color: const Color(0xFF10B981),
                        width: isWide
                            ? (constraints.maxWidth - 32) / 3
                            : constraints.maxWidth,
                      ),
                      _KpiCard(
                        title: 'Faculty Teachers',
                        value: '$totalTeachers Educators',
                        icon: Icons.school_outlined,
                        color: const Color(0xFFF59E0B),
                        width: isWide
                            ? (constraints.maxWidth - 32) / 3
                            : constraints.maxWidth,
                      ),
                    ],
                  );
                },
              ),
              const SizedBox(height: 24),
            ],

            // Middle Section: Calendar & Overview Analytics
            LayoutBuilder(
              builder: (context, constraints) {
                final isWide = constraints.maxWidth > 900;
                final calendarCard = Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFFE2E8F0)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'School Calendar & Holidays',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF0F172A),
                            ),
                          ),
                          Text(
                            dateStr,
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF2563EB),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      CalendarDatePicker(
                        initialDate: selectedCalendarDate,
                        firstDate: DateTime(2025, 1, 1),
                        lastDate: DateTime(2027, 12, 31),
                        onDateChanged: (dt) {
                          setState(() {
                            selectedCalendarDate = dt;
                          });
                        },
                      ),
                      const Divider(height: 24),
                      Text(
                        'Events on $dateStr (${selectedDayEvents.length})',
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                      const SizedBox(height: 8),
                      if (selectedDayEvents.isEmpty)
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 8),
                          child: Text(
                            'No scheduled events or national holidays on this date.',
                            style: TextStyle(
                              fontSize: 12,
                              color: Color(0xFF64748B),
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                        )
                      else
                        ...selectedDayEvents.map(
                          (evt) => Container(
                            margin: const EdgeInsets.only(bottom: 8),
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color:
                                  _getKindColor(evt.kind).withOpacity(0.08),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color:
                                    _getKindColor(evt.kind).withOpacity(0.3),
                              ),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: _getKindColor(evt.kind),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(
                                    _getKindIcon(evt.kind),
                                    color: Colors.white,
                                    size: 16,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              evt.title,
                                              style: const TextStyle(
                                                fontSize: 13,
                                                fontWeight: FontWeight.w700,
                                                color: Color(0xFF0F172A),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            padding:
                                                const EdgeInsets.symmetric(
                                              horizontal: 8,
                                              vertical: 2,
                                            ),
                                            decoration: BoxDecoration(
                                              color: _getKindColor(evt.kind)
                                                  .withOpacity(0.2),
                                              borderRadius:
                                                  BorderRadius.circular(6),
                                            ),
                                            child: Text(
                                              evt.kind.toUpperCase(),
                                              style: TextStyle(
                                                fontSize: 10,
                                                fontWeight: FontWeight.w700,
                                                color:
                                                    _getKindColor(evt.kind),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        evt.description,
                                        style: const TextStyle(
                                          fontSize: 12,
                                          color: Color(0xFF475569),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                if (role == PortalRole.admin) ...[
                                  const SizedBox(width: 8),
                                  IconButton(
                                    icon: const Icon(Icons.edit_outlined,
                                        size: 18),
                                    onPressed: isBusy
                                        ? null
                                        : () => _showEventDialog(context, ref, evt),
                                  ),
                                  IconButton(
                                    icon: const Icon(
                                      Icons.delete_outline,
                                      size: 18,
                                      color: Colors.red,
                                    ),
                                    onPressed: isBusy
                                        ? null
                                        : () => runLockedAction(() async {
                                              await ref
                                                  .read(schoolEcsProvider.notifier)
                                                  .deleteSchoolEvent(evt.id);
                                              if (!context.mounted) return;
                                              showActionSnackBar(
                                                context,
                                                kind: ActionFeedbackKind.info,
                                                message: 'Removed event "${evt.title}".',
                                              );
                                            }),
                                  ),
                                ],
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                );

                final analyticsColumn = Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    MasteryBreakdownChart(
                      exceedingCount: exceeding,
                      meetingCount: meeting,
                      approachingCount: approaching,
                      developingCount: developing,
                    ),
                    const SizedBox(height: 20),
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: const Color(0xFFE2E8F0)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const Text(
                            'Curriculum & Attendance Quick Health',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFF0F172A),
                            ),
                          ),
                          const SizedBox(height: 16),
                          ProgressBarChart(
                            title: 'Syllabus Strands Coverage Progress',
                            value: ecsState.strands.isNotEmpty ? 0.78 : 0.0,
                            label: '78% Complete',
                            color: const Color(0xFF10B981),
                          ),
                          const SizedBox(height: 14),
                          ProgressBarChart(
                            title: 'Average Daily Attendance Rate',
                            value: 0.94,
                            label: '94.2% Present',
                            color: const Color(0xFF2563EB),
                          ),
                          const SizedBox(height: 14),
                          ProgressBarChart(
                            title: 'Teacher Lesson Plan Submissions',
                            value: 0.88,
                            label: '88% Logged',
                            color: const Color(0xFF8B5CF6),
                          ),
                        ],
                      ),
                    ),
                  ],
                );

                if (role == PortalRole.parent) {
                  return calendarCard;
                }

                if (isWide) {
                  return Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(flex: 6, child: calendarCard),
                      const SizedBox(width: 24),
                      Expanded(flex: 5, child: analyticsColumn),
                    ],
                  );
                }

                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    calendarCard,
                    const SizedBox(height: 24),
                    analyticsColumn,
                  ],
                );
              },
            ),
            if (role != PortalRole.parent) ...[
              const SizedBox(height: 32),

              // Quick Access Hub / Navigation Card Grid (Staff / Admin)
              const Text(
                'School Tools & Modules',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF0F172A),
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'Quickly access daily registers, planning, and school administration.',
                style: TextStyle(fontSize: 13, color: Color(0xFF64748B)),
              ),
              const SizedBox(height: 16),

              GridView.count(
                crossAxisCount: MediaQuery.sizeOf(context).width > 1000
                    ? 3
                    : (MediaQuery.sizeOf(context).width > 650 ? 2 : 1),
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                childAspectRatio: 2.2,
                children: [
                  _ModuleCard(
                    title: 'Learners Directory',
                    subtitle: 'Enrollment profiles & catchment zones',
                    icon: Icons.people_outline,
                    color: const Color(0xFF2563EB),
                    onTap: () => context.go('/learners'),
                  ),
                  _ModuleCard(
                    title: 'School Diary',
                    subtitle: 'Daily homework & parent sign-offs',
                    icon: Icons.book_outlined,
                    color: const Color(0xFF10B981),
                    onTap: () => context.go('/diary'),
                  ),
                  _ModuleCard(
                    title: 'Schemes of Work',
                    subtitle: 'Strands, topics & lesson targets',
                    icon: Icons.account_tree_outlined,
                    color: const Color(0xFF8B5CF6),
                    onTap: () => context.go('/schemes'),
                  ),
                  _ModuleCard(
                    title: 'Assessments',
                    subtitle: 'Topic mastery & learner scores',
                    icon: Icons.grading_outlined,
                    color: const Color(0xFFF59E0B),
                    onTap: () => context.go('/assessments'),
                  ),
                  _ModuleCard(
                    title: 'Lesson Plans',
                    subtitle: 'Scheduled lesson notes & reflections',
                    icon: Icons.edit_calendar_outlined,
                    color: const Color(0xFFEC4899),
                    onTap: () => context.go('/lessons'),
                  ),
                  _ModuleCard(
                    title: 'Timetable Hub',
                    subtitle: 'Period schedule & room conflicts',
                    icon: Icons.schedule_outlined,
                    color: const Color(0xFF06B6D4),
                    onTap: () => context.go('/timetable'),
                  ),
                  _ModuleCard(
                    title: 'Class Register',
                    subtitle: 'Attendance roll call & uniform checks',
                    icon: Icons.fact_check_outlined,
                    color: const Color(0xFF3B82F6),
                    onTap: () => context.go('/register'),
                  ),
                  if (role == PortalRole.admin) ...[
                    _ModuleCard(
                      title: 'Coverage & Audit',
                      subtitle: 'Teacher <-> Class matrix, charts & audit log',
                      icon: Icons.analytics_outlined,
                      color: const Color(0xFF6366F1),
                      onTap: () => context.go('/coverage'),
                    ),
                    _ModuleCard(
                      title: 'Parents & Zones',
                      subtitle: 'Guardian households, zones & engagement',
                      icon: Icons.family_restroom_outlined,
                      color: const Color(0xFF0EA5E9),
                      onTap: () => context.go('/parents'),
                    ),
                    _ModuleCard(
                      title: 'Classrooms',
                      subtitle: 'Class teacher, pie/bar/candlestick charts',
                      icon: Icons.class_outlined,
                      color: const Color(0xFF14B8A6),
                      onTap: () => context.go('/classrooms'),
                    ),
                    _ModuleCard(
                      title: 'Custom Fields & Layout',
                      subtitle: 'Custom fields & learner profile sections',
                      icon: Icons.tune_outlined,
                      color: const Color(0xFF64748B),
                      onTap: () => context.go('/schema'),
                    ),
                  ],
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Color _getKindColor(String kind) {
    switch (kind.toLowerCase()) {
      case 'holiday':
        return const Color(0xFF8B5CF6);
      case 'exam':
        return const Color(0xFFEF4444);
      case 'meeting':
        return const Color(0xFFF59E0B);
      case 'sports':
        return const Color(0xFF10B981);
      default:
        return const Color(0xFF2563EB);
    }
  }

  IconData _getKindIcon(String kind) {
    switch (kind.toLowerCase()) {
      case 'holiday':
        return Icons.celebration_outlined;
      case 'exam':
        return Icons.assignment_outlined;
      case 'meeting':
        return Icons.groups_outlined;
      case 'sports':
        return Icons.sports_soccer_outlined;
      default:
        return Icons.event_outlined;
    }
  }

  void _showEventDialog(
      BuildContext context, WidgetRef ref, SchoolEventEntity? existing) {
    final titleController =
        TextEditingController(text: existing?.title ?? '');
    final descController =
        TextEditingController(text: existing?.description ?? '');
    String selectedKind = existing?.kind ?? 'event';
    final dateStr = existing?.date ??
        '${selectedCalendarDate.year}-${selectedCalendarDate.month.toString().padLeft(2, '0')}-${selectedCalendarDate.day.toString().padLeft(2, '0')}';
    var isSubmitting = false;
    String? error;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (modalCtx, setModalState) => AlertDialog(
          title: Text(existing == null ? 'Add School Event' : 'Edit School Event'),
          content: SizedBox(
            width: 400,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  controller: titleController,
                  decoration: const InputDecoration(
                    labelText: 'Event Title *',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: descController,
                  maxLines: 2,
                  decoration: const InputDecoration(
                    labelText: 'Description / Notes',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: selectedKind,
                  decoration: const InputDecoration(
                    labelText: 'Event Kind',
                    border: OutlineInputBorder(),
                  ),
                  items: const [
                    DropdownMenuItem(value: 'event', child: Text('School Event')),
                    DropdownMenuItem(value: 'holiday', child: Text('Holiday / Assembly')),
                    DropdownMenuItem(value: 'exam', child: Text('Examination')),
                    DropdownMenuItem(value: 'meeting', child: Text('Staff Meeting')),
                    DropdownMenuItem(value: 'sports', child: Text('Sports & Athletics')),
                  ],
                  onChanged: isSubmitting
                      ? null
                      : (val) {
                          if (val != null) setModalState(() => selectedKind = val);
                        },
                ),
                const SizedBox(height: 12),
                Text(
                  'Date: $dateStr',
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF2563EB),
                  ),
                ),
                if (error != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    error!,
                    style: const TextStyle(color: Color(0xFFDC2626), fontSize: 12),
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: isSubmitting ? null : () => Navigator.pop(ctx),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: isSubmitting
                  ? null
                  : () async {
                      if (titleController.text.trim().isEmpty) {
                        setModalState(() => error = 'Event title is required.');
                        return;
                      }
                      setModalState(() {
                        error = null;
                        isSubmitting = true;
                      });
                      try {
                        final entity = SchoolEventEntity(
                          id: existing?.id ??
                              'evt_${DateTime.now().millisecondsSinceEpoch}',
                          date: dateStr,
                          title: titleController.text.trim(),
                          description: descController.text.trim(),
                          kind: selectedKind,
                        );
                        await ref
                            .read(schoolEcsProvider.notifier)
                            .upsertSchoolEvent(entity);
                        if (ctx.mounted) Navigator.pop(ctx);
                        if (context.mounted) {
                          showActionSnackBar(
                            context,
                            kind: ActionFeedbackKind.success,
                            message: existing == null
                                ? 'School event "${entity.title}" added.'
                                : 'School event "${entity.title}" updated.',
                          );
                        }
                      } catch (e) {
                        setModalState(() {
                          isSubmitting = false;
                          error = 'Could not save event: $e';
                        });
                      }
                    },
              child: Text(isSubmitting ? 'Saving...' : 'Save Event'),
            ),
          ],
        ),
      ),
    );
  }
}

class _KpiCard extends StatelessWidget {
  const _KpiCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
    required this.width,
  });

  final String title;
  final String value;
  final IconData icon;
  final Color color;
  final double width;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: Color(0xFF64748B),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF0F172A),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ModuleCard extends StatelessWidget {
  const _ModuleCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFE2E8F0)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF0F172A),
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      fontSize: 11,
                      color: Color(0xFF64748B),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios,
                size: 14, color: Color(0xFF94A3B8)),
          ],
        ),
      ),
    );
  }
}
