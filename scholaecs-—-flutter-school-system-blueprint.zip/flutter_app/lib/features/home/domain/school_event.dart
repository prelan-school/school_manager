class SchoolEventEntity {
  const SchoolEventEntity({
    required this.id,
    required this.date, // YYYY-MM-DD
    required this.title,
    required this.description,
    required this.kind, // 'holiday', 'exam', 'event', 'meeting', 'sports'
    this.classroomId, // null if school-wide
  });

  final String id;
  final String date;
  final String title;
  final String description;
  final String kind;
  final String? classroomId;

  SchoolEventEntity copyWith({
    String? date,
    String? title,
    String? description,
    String? kind,
    String? classroomId,
  }) {
    return SchoolEventEntity(
      id: id,
      date: date ?? this.date,
      title: title ?? this.title,
      description: description ?? this.description,
      kind: kind ?? this.kind,
      classroomId: classroomId ?? this.classroomId,
    );
  }

  factory SchoolEventEntity.fromMap(String id, Map<String, dynamic> map) {
    return SchoolEventEntity(
      id: id,
      date: map['date'] as String? ?? '2026-11-28',
      title: map['title'] as String? ?? '',
      description: map['description'] as String? ?? '',
      kind: map['kind'] as String? ?? 'event',
      classroomId: map['classroomId'] as String?,
    );
  }

  Map<String, dynamic> toMap() => {
        'date': date,
        'title': title,
        'description': description,
        'kind': kind,
        'classroomId': classroomId,
      };
}
