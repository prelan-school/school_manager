import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/ecs/ecs_providers.dart';
import '../../../core/ecs/school_entity.dart';
import '../../auth/data/firebase_auth_repository.dart';
import '../domain/scheme_nodes.dart';

class SchemesPage extends ConsumerStatefulWidget {
  const SchemesPage({super.key});

  @override
  ConsumerState<SchemesPage> createState() => _SchemesPageState();
}

class _SchemesPageState extends ConsumerState<SchemesPage> {
  String _selectedClassroomId = 'ALL';
  String _selectedSubjectId = 'ALL';

  Future<void> _showStrandDialog(
    BuildContext context,
    String teacherId, {
    String? initialClassroomId,
  }) async {
    final state = ref.read(schoolEcsProvider);
    if (state.classrooms.isEmpty || state.subjects.isEmpty) return;

    var classroomId = initialClassroomId != null &&
            state.classrooms.any((c) => c.id == initialClassroomId)
        ? initialClassroomId
        : (_selectedClassroomId != 'ALL' &&
                state.classrooms.any((c) => c.id == _selectedClassroomId)
            ? _selectedClassroomId
            : state.classrooms.first.id);
    var subjectId = state.subjects.first.id;
    var term = 'Term 1';
    final codeCtrl = TextEditingController();
    final titleCtrl = TextEditingController();

    await showDialog<void>(
      context: context,
      builder: (dialogCtx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Register Class-Connected Strand'),
          content: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  DropdownButtonFormField<String>(
                    value: classroomId,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Classroom *',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    items: state.classrooms
                        .map(
                          (c) => DropdownMenuItem(
                            value: c.id,
                            child: Text(
                              '${c.name} (${c.gradeLevel})',
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (v) {
                      if (v != null) setDialogState(() => classroomId = v);
                    },
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: subjectId,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Subject *',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    items: state.subjects
                        .map(
                          (s) => DropdownMenuItem(
                            value: s.id,
                            child: Text(s.name, overflow: TextOverflow.ellipsis),
                          ),
                        )
                        .toList(),
                    onChanged: (v) {
                      if (v != null) setDialogState(() => subjectId = v);
                    },
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: codeCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Strand Code * (e.g. STR-6M2)',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: titleCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Strand Title *',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: term,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Term',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    items: const ['Term 1', 'Term 2', 'Term 3']
                        .map(
                          (t) => DropdownMenuItem(
                            value: t,
                            child: Text(t, overflow: TextOverflow.ellipsis),
                          ),
                        )
                        .toList(),
                    onChanged: (v) {
                      if (v != null) setDialogState(() => term = v);
                    },
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogCtx).pop(),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () async {
                if (codeCtrl.text.trim().isEmpty || titleCtrl.text.trim().isEmpty) {
                  return;
                }
                await ref.read(schoolEcsProvider.notifier).addSchemeStrand(
                      SchemeStrandEntity(
                        id: 'str_${DateTime.now().millisecondsSinceEpoch}',
                        classroomId: classroomId,
                        subjectId: subjectId,
                        code: codeCtrl.text.trim(),
                        title: titleCtrl.text.trim(),
                        term: term,
                        createdByTeacherId: teacherId,
                      ),
                    );
                if (dialogCtx.mounted) Navigator.of(dialogCtx).pop();
              },
              child: const Text('Register Strand'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showSubstrandDialog(
    BuildContext context, {
    String? initialStrandId,
    String? initialClassroomId,
  }) async {
    final state = ref.read(schoolEcsProvider);
    if (state.strands.isEmpty) return;

    final seedStrand = initialStrandId != null
        ? state.strands.where((s) => s.id == initialStrandId).firstOrNull
        : null;
    var classroomFilterId = seedStrand?.classroomId ??
        initialClassroomId ??
        (_selectedClassroomId != 'ALL'
            ? _selectedClassroomId
            : state.classrooms.first.id);
    var strandId = seedStrand?.id ??
        state.strands
            .where((s) => s.classroomId == classroomFilterId)
            .firstOrNull
            ?.id ??
        state.strands.first.id;
    final codeCtrl = TextEditingController();
    final titleCtrl = TextEditingController();
    final outcomeCtrl = TextEditingController();
    final lessonsCtrl = TextEditingController(text: '4');

    await showDialog<void>(
      context: context,
      builder: (dialogCtx) => StatefulBuilder(
        builder: (ctx, setDialogState) {
          final matchingStrands = state.strands
              .where((s) => s.classroomId == classroomFilterId)
              .toList();
          if (!matchingStrands.any((s) => s.id == strandId)) {
            strandId = matchingStrands.firstOrNull?.id ?? '';
          }

          return AlertDialog(
            title: const Text('Add Substrand Under Class Strand'),
            content: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DropdownButtonFormField<String>(
                      value: classroomFilterId,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Classroom',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      items: state.classrooms
                          .map(
                            (c) => DropdownMenuItem(
                              value: c.id,
                              child: Text(c.name, overflow: TextOverflow.ellipsis),
                            ),
                          )
                          .toList(),
                      onChanged: (v) {
                        if (v != null) {
                          setDialogState(() {
                            classroomFilterId = v;
                            strandId = state.strands
                                    .where((s) => s.classroomId == v)
                                    .firstOrNull
                                    ?.id ??
                                '';
                          });
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: strandId.isEmpty ? null : strandId,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Parent Strand (Class-Scoped)',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      items: matchingStrands
                          .map(
                            (st) => DropdownMenuItem(
                              value: st.id,
                              child: Text(
                                '${st.code} — ${st.title}',
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (v) {
                        if (v != null) setDialogState(() => strandId = v);
                      },
                    ),
                    if (matchingStrands.isEmpty) ...[
                      const SizedBox(height: 8),
                      const Text(
                        'Register a strand for this classroom first.',
                        style: TextStyle(fontSize: 12, color: Color(0xFFB45309)),
                      ),
                    ],
                    const SizedBox(height: 12),
                    TextField(
                      controller: codeCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Substrand Code *',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: titleCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Substrand Title *',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: outcomeCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Learning Outcome',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: lessonsCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Target Lessons',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogCtx).pop(),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: strandId.isEmpty
                    ? null
                    : () async {
                        if (codeCtrl.text.trim().isEmpty ||
                            titleCtrl.text.trim().isEmpty) {
                          return;
                        }
                        final strand = state.strands.firstWhere((s) => s.id == strandId);
                        await ref.read(schoolEcsProvider.notifier).addSchemeSubstrand(
                              SchemeSubstrandEntity(
                                id: 'sub_${DateTime.now().millisecondsSinceEpoch}',
                                strandId: strand.id,
                                subjectId: strand.subjectId,
                                code: codeCtrl.text.trim(),
                                title: titleCtrl.text.trim(),
                                learningOutcome: outcomeCtrl.text.trim(),
                                targetLessons: int.tryParse(lessonsCtrl.text) ?? 4,
                              ),
                            );
                        if (dialogCtx.mounted) Navigator.of(dialogCtx).pop();
                      },
                child: const Text('Add Substrand'),
              ),
            ],
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(currentUserProvider).valueOrNull;
    final role = user?.role ?? PortalRole.admin;
    final ecs = ref.watch(schoolEcsProvider);
    final canEdit = role == PortalRole.admin || role == PortalRole.teacher;
    final teacherId = user?.teacherId ?? ecs.teachers.firstOrNull?.id ?? 'tch_amara';

    final visibleClassrooms = _selectedClassroomId == 'ALL'
        ? ecs.classrooms
        : ecs.classrooms.where((c) => c.id == _selectedClassroomId).toList();

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Wrap(
          alignment: WrapAlignment.spaceBetween,
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: 12,
          runSpacing: 12,
          children: [
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Schemes of Work Database (Class-Connected)',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                ),
                Text(
                  'Strands and Substrands are organized under specific Classes; Lesson Plans & Assessments inherit their class scheme.',
                  style: TextStyle(fontSize: 13, color: Color(0xFF475569)),
                ),
              ],
            ),
            if (canEdit)
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  OutlinedButton.icon(
                    onPressed: () => _showStrandDialog(context, teacherId),
                    icon: const Icon(Icons.add, size: 16),
                    label: const Text('Register Strand'),
                  ),
                  FilledButton.icon(
                    onPressed: ecs.strands.isEmpty
                        ? null
                        : () => _showSubstrandDialog(
                              context,
                              initialClassroomId: _selectedClassroomId == 'ALL'
                                  ? null
                                  : _selectedClassroomId,
                            ),
                    icon: const Icon(Icons.add, size: 16),
                    label: const Text('Add Substrand'),
                  ),
                ],
              ),
          ],
        ),
        const SizedBox(height: 14),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            ChoiceChip(
              label: Text('All Classes (${ecs.strands.length} strands)'),
              selected: _selectedClassroomId == 'ALL',
              onSelected: (_) => setState(() => _selectedClassroomId = 'ALL'),
            ),
            ...ecs.classrooms.map((cls) {
              final count =
                  ecs.strands.where((st) => st.classroomId == cls.id).length;
              return ChoiceChip(
                label: Text('${cls.name} ($count)'),
                selected: _selectedClassroomId == cls.id,
                onSelected: (_) => setState(() => _selectedClassroomId = cls.id),
              );
            }),
            ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 200),
              child: DropdownButtonFormField<String>(
                value: _selectedSubjectId,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'Subject Filter',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
                items: [
                  const DropdownMenuItem(
                    value: 'ALL',
                    child: Text('All Subjects', overflow: TextOverflow.ellipsis),
                  ),
                  ...ecs.subjects.map(
                    (s) => DropdownMenuItem(
                      value: s.id,
                      child: Text(s.name, overflow: TextOverflow.ellipsis),
                    ),
                  ),
                ],
                onChanged: (v) {
                  if (v != null) setState(() => _selectedSubjectId = v);
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        ...visibleClassrooms.map((classroom) {
          final classTeacher = ecs.teachers
              .where((t) => t.id == classroom.classTeacherId)
              .firstOrNull;
          final classStrands = ecs.strands.where((st) {
            final matchesClass = st.classroomId == classroom.id;
            final matchesSubj =
                _selectedSubjectId == 'ALL' || st.subjectId == _selectedSubjectId;
            return matchesClass && matchesSubj;
          }).toList();

          return Container(
            margin: const EdgeInsets.only(bottom: 18),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFCBD5E1)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  alignment: WrapAlignment.spaceBetween,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  spacing: 12,
                  runSpacing: 8,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${classroom.name} (${classroom.gradeLevel} · Room ${classroom.roomCode})',
                          style: const TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w800,
                            color: Color(0xFF0F172A),
                          ),
                        ),
                        Text(
                          'Class Teacher: ${classTeacher?.name ?? 'Unassigned'} · ${classStrands.length} Strands connected',
                          style: const TextStyle(
                            fontSize: 12,
                            color: Color(0xFF475569),
                          ),
                        ),
                      ],
                    ),
                    if (canEdit)
                      OutlinedButton.icon(
                        onPressed: () => _showStrandDialog(
                          context,
                          teacherId,
                          initialClassroomId: classroom.id,
                        ),
                        icon: const Icon(Icons.add, size: 15),
                        label: Text('Add Strand for ${classroom.gradeLevel}'),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                if (classStrands.isEmpty)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: const Color(0xFFE2E8F0)),
                    ),
                    child: const Text(
                      'No strands registered for this classroom and subject filter yet.',
                      style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                    ),
                  )
                else
                  ...classStrands.map((strand) {
                    final subj = ecs.subjects
                        .where((s) => s.id == strand.subjectId)
                        .firstOrNull;
                    final children = ecs.substrands
                        .where((sub) => sub.strandId == strand.id)
                        .toList();
                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFFE2E8F0)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      '${classroom.gradeLevel} · ${subj?.name ?? ''} · ${strand.term}',
                                      style: const TextStyle(
                                        fontSize: 12,
                                        color: Color(0xFF64748B),
                                      ),
                                    ),
                                    Text(
                                      '${strand.code}: ${strand.title}',
                                      style: const TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              if (canEdit) ...[
                                const SizedBox(width: 8),
                                Flexible(
                                  flex: 0,
                                  child: TextButton(
                                    onPressed: () => _showSubstrandDialog(
                                      context,
                                      initialStrandId: strand.id,
                                      initialClassroomId: classroom.id,
                                    ),
                                    child: const Text('+ Add Substrand'),
                                  ),
                                ),
                              ],
                            ],
                          ),
                          const Divider(height: 18),
                          if (children.isEmpty)
                            const Text(
                              'No substrands added under this strand yet.',
                              style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                            )
                          else
                            ...children.map((sub) {
                              final planCount = ecs.lessonPlans
                                  .where((lp) =>
                                      lp.substrandId == sub.id &&
                                      lp.classroomId == classroom.id)
                                  .length;
                              final assessCount = ecs.assessments
                                  .where((a) => a.substrandId == sub.id)
                                  .length;
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 8),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            '${sub.code}: ${sub.title}',
                                            style: const TextStyle(
                                              fontSize: 13,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                          Text(
                                            sub.learningOutcome,
                                            style: const TextStyle(
                                              fontSize: 12,
                                              color: Color(0xFF475569),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    Flexible(
                                      flex: 0,
                                      child: Text(
                                        '${sub.targetLessons} lessons · $planCount plans · $assessCount assessments',
                                        textAlign: TextAlign.end,
                                        style: const TextStyle(
                                          fontSize: 11,
                                          color: Color(0xFF64748B),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }),
                        ],
                      ),
                    );
                  }),
              ],
            ),
          );
        }),
      ],
    );
  }
}
