import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/ecs/ecs_providers.dart';
import '../../../core/ecs/ecs_seed_data.dart';
import '../../../core/ecs/school_entity.dart';
import '../../../core/widgets/analytics_charts.dart';
import '../../auth/data/firebase_auth_repository.dart';
import '../../timetable/domain/timetable_slot.dart';
import '../domain/lesson_plan.dart';

class LessonPlansPage extends ConsumerStatefulWidget {
  const LessonPlansPage({super.key});

  @override
  ConsumerState<LessonPlansPage> createState() => _LessonPlansPageState();
}

class _LessonPlansPageState extends ConsumerState<LessonPlansPage> {
  String _filterMode = 'all'; // 'all' | 'unassigned'
  String _classroomFilter = 'ALL';

  Future<void> _openLessonDialog({
    required PortalRole role,
    required String defaultTeacherId,
    LessonPlanEntity? existing,
  }) async {
    final ecs = ref.read(schoolEcsProvider);
    if (ecs.substrands.isEmpty || ecs.classrooms.isEmpty || ecs.teachers.isEmpty) {
      return;
    }

    var substrandId = existing?.substrandId ?? ecs.substrands.first.id;
    var classroomId = existing?.classroomId ?? ecs.classrooms.first.id;
    var teacherId = existing?.teacherId ?? defaultTeacherId;
    if (!ecs.teachers.any((t) => t.id == teacherId)) {
      teacherId = ecs.teachers.first.id;
    }
    var slotId = existing?.timetableSlotId ?? '';
    var status = existing?.status ?? LessonStatus.planned;

    final titleCtrl = TextEditingController(text: existing?.title ?? '');
    final dateCtrl = TextEditingController(
      text: existing?.scheduledDate.isNotEmpty == true
          ? existing!.scheduledDate
          : '2026-11-26',
    );
    final deliveredCtrl = TextEditingController(
      text: '${existing?.lessonsDelivered ?? 0}',
    );
    final reflectionCtrl = TextEditingController(
      text: existing?.reflectionNote ?? '',
    );

    await showDialog<void>(
      context: context,
      builder: (dialogCtx) => StatefulBuilder(
        builder: (ctx, setModalState) {
          final classStrandIds = ecs.strands
              .where((st) => st.classroomId == classroomId)
              .map((st) => st.id)
              .toSet();
          final classSubstrands = ecs.substrands
              .where((sub) => classStrandIds.contains(sub.strandId))
              .toList();
          final availableSubstrands =
              classSubstrands.isNotEmpty ? classSubstrands : ecs.substrands;
          if (!availableSubstrands.any((s) => s.id == substrandId) &&
              availableSubstrands.isNotEmpty) {
            substrandId = availableSubstrands.first.id;
          }
          final classSlots = ecs.timetableSlots
              .where((s) => s.classroomId == classroomId)
              .toList();
          if (slotId.isNotEmpty &&
              !classSlots.any((s) => s.id == slotId) &&
              !ecs.timetableSlots.any((s) => s.id == slotId)) {
            slotId = '';
          }

          return AlertDialog(
            title: Text(
              existing == null ? 'Register Lesson Plan' : 'Edit Registered Lesson',
            ),
            content: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 500),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: classroomId,
                            isExpanded: true,
                            decoration: const InputDecoration(
                              labelText: 'Classroom',
                              border: OutlineInputBorder(),
                              isDense: true,
                            ),
                            items: ecs.classrooms
                                .map(
                                  (c) => DropdownMenuItem(
                                    value: c.id,
                                    child: Text(
                                      c.name,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                )
                                .toList(),
                            onChanged: (v) {
                              if (v != null) {
                                setModalState(() {
                                  classroomId = v;
                                  slotId = '';
                                  final nextStrandIds = ecs.strands
                                      .where((st) => st.classroomId == v)
                                      .map((st) => st.id)
                                      .toSet();
                                  final nextSubs = ecs.substrands
                                      .where((sub) =>
                                          nextStrandIds.contains(sub.strandId))
                                      .toList();
                                  if (nextSubs.isNotEmpty) {
                                    substrandId = nextSubs.first.id;
                                  }
                                });
                              }
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: teacherId,
                            isExpanded: true,
                            decoration: const InputDecoration(
                              labelText: 'Assigned Teacher',
                              border: OutlineInputBorder(),
                              isDense: true,
                            ),
                            items: ecs.teachers
                                .map(
                                  (t) => DropdownMenuItem(
                                    value: t.id,
                                    child: Text(
                                      t.name,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                )
                                .toList(),
                            onChanged: role == PortalRole.admin
                                ? (v) {
                                    if (v != null) {
                                      setModalState(() => teacherId = v);
                                    }
                                  }
                                : null,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: substrandId,
                      isExpanded: true,
                      decoration: InputDecoration(
                        labelText: classSubstrands.isNotEmpty
                            ? 'Linked Substrand (Class Scheme)'
                            : 'Linked Substrand (All Classes)',
                        border: const OutlineInputBorder(),
                        isDense: true,
                      ),
                      items: availableSubstrands
                          .map(
                            (s) => DropdownMenuItem(
                              value: s.id,
                              child: Text(
                                '${s.code} — ${s.title}',
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (v) {
                        if (v != null) setModalState(() => substrandId = v);
                      },
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: slotId,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Timetable Slot (optional)',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      items: [
                        const DropdownMenuItem(
                          value: '',
                          child: Text(
                            'Keep Unassigned in Registry',
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        ...classSlots.map((sl) {
                          final subj = ecs.subjects
                              .where((s) => s.id == sl.subjectId)
                              .firstOrNull;
                          return DropdownMenuItem(
                            value: sl.id,
                            child: Text(
                              '${sl.day} P${sl.period} · ${subj?.code ?? ''} (${sl.timeRange}, ${sl.room})',
                              overflow: TextOverflow.ellipsis,
                            ),
                          );
                        }),
                      ],
                      onChanged: (v) {
                        if (v != null) setModalState(() => slotId = v);
                      },
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: titleCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Lesson Focus Title *',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: DropdownButtonFormField<LessonStatus>(
                            value: status,
                            isExpanded: true,
                            decoration: const InputDecoration(
                              labelText: 'Status',
                              border: OutlineInputBorder(),
                              isDense: true,
                            ),
                            items: LessonStatus.values
                                .map(
                                  (st) => DropdownMenuItem(
                                    value: st,
                                    child: Text(
                                      st.label,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                )
                                .toList(),
                            onChanged: (v) {
                              if (v != null) setModalState(() => status = v);
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          flex: 1,
                          child: TextField(
                            controller: deliveredCtrl,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              labelText: 'Periods',
                              border: OutlineInputBorder(),
                              isDense: true,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: dateCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Scheduled Date (YYYY-MM-DD)',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: reflectionCtrl,
                      maxLines: 2,
                      decoration: const InputDecoration(
                        labelText: 'Teaching Reflection / Notes',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogCtx).pop(),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () async {
                  if (titleCtrl.text.trim().isEmpty) return;
                  final sub = ecs.substrands.firstWhere((s) => s.id == substrandId);
                  final payload = LessonPlanEntity(
                    id: existing?.id ?? 'lp_${DateTime.now().millisecondsSinceEpoch}',
                    teacherId: teacherId,
                    classroomId: classroomId,
                    subjectId: sub.subjectId,
                    strandId: sub.strandId,
                    substrandId: sub.id,
                    timetableSlotId: slotId.isEmpty ? null : slotId,
                    title: titleCtrl.text.trim(),
                    scheduledDate: dateCtrl.text.trim().isEmpty
                        ? '2026-11-26'
                        : dateCtrl.text.trim(),
                    lessonsDelivered: int.tryParse(deliveredCtrl.text) ?? 0,
                    status: status,
                    reflectionNote: reflectionCtrl.text.trim(),
                  );
                  if (existing == null) {
                    await ref.read(schoolEcsProvider.notifier).addLessonPlan(payload);
                  } else {
                    await ref.read(schoolEcsProvider.notifier).updateLessonPlan(payload);
                  }
                  if (dialogCtx.mounted) Navigator.of(dialogCtx).pop();
                },
                child: Text(existing == null ? 'Register Lesson' : 'Save Changes'),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _openAssignToTimetableDialog(LessonPlanEntity plan) async {
    final ecs = ref.read(schoolEcsProvider);
    final notifier = ref.read(schoolEcsProvider.notifier);

    var mode = ecs.timetableSlots.isEmpty ? 'create' : 'existing';
    var selectedSlotId = plan.timetableSlotId ?? '';
    if (selectedSlotId.isNotEmpty &&
        !ecs.timetableSlots.any((s) => s.id == selectedSlotId)) {
      selectedSlotId = '';
    }

    var targetClassroomId = plan.classroomId;
    var mappedDays = notifier.scheduleDaysForClassroom(targetClassroomId);
    var dayCode = (mappedDays.isNotEmpty
            ? mappedDays.first.code
            : (ecs.scheduleDays.isNotEmpty ? ecs.scheduleDays.first.code : 'Mon'));
    var period = 1;
    var teacherId = plan.teacherId;
    final classRoomObj = ecs.classrooms
        .where((c) => c.id == targetClassroomId)
        .firstOrNull;
    final timeCtrl = TextEditingController(
      text: mappedDays.isNotEmpty ? mappedDays.first.defaultTimeRange : '08:00 - 08:45',
    );
    final roomCtrl = TextEditingController(text: classRoomObj?.roomCode ?? 'B2-04');
    String? error;

    await showDialog<void>(
      context: context,
      builder: (dialogCtx) => StatefulBuilder(
        builder: (ctx, setModalState) {
          final currentMapped = notifier.scheduleDaysForClassroom(targetClassroomId);
          final availableDays =
              currentMapped.isNotEmpty ? currentMapped : ecs.scheduleDays;

          return AlertDialog(
            title: Text('Assign "${plan.title}" to Timetable'),
            content: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 500),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        ChoiceChip(
                          label: const Text('Bind to Existing Slot'),
                          selected: mode == 'existing',
                          onSelected: (_) => setModalState(() {
                            mode = 'existing';
                            error = null;
                          }),
                        ),
                        ChoiceChip(
                          label: const Text('Create New Slot & Assign'),
                          selected: mode == 'create',
                          onSelected: (_) => setModalState(() {
                            mode = 'create';
                            error = null;
                          }),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    if (mode == 'existing') ...[
                      DropdownButtonFormField<String>(
                        value: selectedSlotId,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'Select Timetable Slot',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                        items: [
                          const DropdownMenuItem(
                            value: '',
                            child: Text(
                              'Unassign (Remove from Timetable)',
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          ...ecs.timetableSlots.map((sl) {
                            final cls = ecs.classrooms
                                .where((c) => c.id == sl.classroomId)
                                .firstOrNull;
                            final subj = ecs.subjects
                                .where((s) => s.id == sl.subjectId)
                                .firstOrNull;
                            final tch = ecs.teachers
                                .where((t) => t.id == sl.teacherId)
                                .firstOrNull;
                            return DropdownMenuItem(
                              value: sl.id,
                              child: Text(
                                '${cls?.name ?? sl.classroomId} · ${sl.day} P${sl.period} (${sl.timeRange}) · ${subj?.code ?? ''} · ${tch?.name ?? ''}',
                                overflow: TextOverflow.ellipsis,
                              ),
                            );
                          }),
                        ],
                        onChanged: (v) {
                          if (v != null) setModalState(() => selectedSlotId = v);
                        },
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Binding updates both the Lesson Plan and Timetable Slot automatically.',
                        style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                      ),
                    ] else ...[
                      DropdownButtonFormField<String>(
                        value: targetClassroomId,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'Classroom',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                        items: ecs.classrooms
                            .map(
                              (c) => DropdownMenuItem(
                                value: c.id,
                                child: Text(
                                  c.name,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            )
                            .toList(),
                        onChanged: (v) {
                          if (v != null) {
                            setModalState(() {
                              targetClassroomId = v;
                              final nextDays = notifier.scheduleDaysForClassroom(v);
                              if (nextDays.isNotEmpty &&
                                  !nextDays.any((d) => d.code == dayCode)) {
                                dayCode = nextDays.first.code;
                                timeCtrl.text = nextDays.first.defaultTimeRange;
                              }
                              final clsObj = ecs.classrooms
                                  .where((c) => c.id == v)
                                  .firstOrNull;
                              if (clsObj != null) {
                                roomCtrl.text = clsObj.roomCode;
                              }
                            });
                          }
                        },
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: availableDays.any((d) => d.code == dayCode)
                                  ? dayCode
                                  : (availableDays.isNotEmpty
                                      ? availableDays.first.code
                                      : 'Mon'),
                              isExpanded: true,
                              decoration: const InputDecoration(
                                labelText: 'Mapped Day',
                                border: OutlineInputBorder(),
                                isDense: true,
                              ),
                              items: availableDays
                                  .map(
                                    (d) => DropdownMenuItem(
                                      value: d.code,
                                      child: Text(
                                        '${d.code} — ${d.label}',
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  )
                                  .toList(),
                              onChanged: (v) {
                                if (v != null) {
                                  setModalState(() {
                                    dayCode = v;
                                    final matched = availableDays
                                        .where((d) => d.code == v)
                                        .firstOrNull;
                                    if (matched != null) {
                                      timeCtrl.text = matched.defaultTimeRange;
                                    }
                                  });
                                }
                              },
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: DropdownButtonFormField<int>(
                              value: period,
                              isExpanded: true,
                              decoration: const InputDecoration(
                                labelText: 'Period',
                                border: OutlineInputBorder(),
                                isDense: true,
                              ),
                              items: [1, 2, 3, 4, 5, 6, 7, 8]
                                  .map(
                                    (p) => DropdownMenuItem(
                                      value: p,
                                      child: Text('Period $p'),
                                    ),
                                  )
                                  .toList(),
                              onChanged: (v) {
                                if (v != null) setModalState(() => period = v);
                              },
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                        value: teacherId,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'Assigned Teacher',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                        items: ecs.teachers
                            .map(
                              (t) => DropdownMenuItem(
                                value: t.id,
                                child: Text(
                                  t.name,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            )
                            .toList(),
                        onChanged: (v) {
                          if (v != null) setModalState(() => teacherId = v);
                        },
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: TextField(
                              controller: timeCtrl,
                              decoration: const InputDecoration(
                                labelText: 'Time Range (HH:MM - HH:MM) *',
                                border: OutlineInputBorder(),
                                isDense: true,
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            flex: 1,
                            child: TextField(
                              controller: roomCtrl,
                              decoration: const InputDecoration(
                                labelText: 'Room *',
                                border: OutlineInputBorder(),
                                isDense: true,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                    if (error != null) ...[
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFEF2F2),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: const Color(0xFFFECACA)),
                        ),
                        child: Text(
                          error!,
                          style: const TextStyle(
                            color: Color(0xFFB91C1C),
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogCtx).pop(),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () async {
                  if (mode == 'existing') {
                    final err = await notifier.assignLessonToTimetableSlot(
                      lessonPlanId: plan.id,
                      timetableSlotId:
                          selectedSlotId.isEmpty ? null : selectedSlotId,
                      syncSlotSubjectAndTeacher: true,
                    );
                    if (err != null) {
                      setModalState(() => error = err);
                      return;
                    }
                    if (dialogCtx.mounted) Navigator.of(dialogCtx).pop();
                    return;
                  }

                  final newSlot = TimetableSlotEntity(
                    id: 'tt_${DateTime.now().millisecondsSinceEpoch}',
                    classroomId: targetClassroomId,
                    subjectId: plan.subjectId,
                    teacherId: teacherId,
                    day: dayCode,
                    period: period,
                    timeRange: timeCtrl.text.trim(),
                    room: roomCtrl.text.trim(),
                    lessonPlanId: plan.id,
                  );
                  final err = await notifier.upsertTimetableSlot(
                    newSlot,
                    syncLessonBinding: true,
                  );
                  if (err != null) {
                    setModalState(() => error = err);
                    return;
                  }
                  if (dialogCtx.mounted) Navigator.of(dialogCtx).pop();
                },
                child: Text(
                  mode == 'existing' ? 'Save Assignment' : 'Create Slot & Assign',
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _confirmDeleteLesson(LessonPlanEntity plan) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogCtx) => AlertDialog(
        title: const Text('Delete Registered Lesson?'),
        content: Text(
          'Remove "${plan.title}" from the Lessons Registry? Any linked Timetable slot will remain open.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogCtx).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFDC2626)),
            onPressed: () => Navigator.of(dialogCtx).pop(true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await ref.read(schoolEcsProvider.notifier).deleteLessonPlan(plan.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(currentUserProvider).valueOrNull;
    final role = user?.role ?? PortalRole.admin;
    final ecs = ref.watch(schoolEcsProvider);
    final isAdmin = role == PortalRole.admin;
    final canEdit = isAdmin || role == PortalRole.teacher;
    final defaultTeacherId = user?.teacherId ?? ecs.teachers.first.id;

    final filtered = ecs.lessonPlans.where((lp) {
      if (_classroomFilter != 'ALL' && lp.classroomId != _classroomFilter) {
        return false;
      }
      if (_filterMode == 'unassigned' &&
          (lp.timetableSlotId?.trim().isNotEmpty ?? false)) {
        return false;
      }
      return true;
    }).toList();

    final assignedCount = ecs.lessonPlans
        .where((lp) => lp.timetableSlotId?.trim().isNotEmpty ?? false)
        .length;
    final unassignedCount = ecs.lessonPlans.length - assignedCount;
    final taughtCount =
        ecs.lessonPlans.where((lp) => lp.status == LessonStatus.taught).length;

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Wrap(
          alignment: WrapAlignment.spaceBetween,
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: 12,
          runSpacing: 12,
          children: [
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Lessons Registry & Timetable Assignment',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                ),
                Text(
                  'Register curriculum lessons, assign them onto mapped Timetable slots, and track Taught syllabus progress.',
                  style: TextStyle(fontSize: 13, color: Color(0xFF475569)),
                ),
              ],
            ),
            if (canEdit)
              FilledButton.icon(
                onPressed: () => _openLessonDialog(
                  role: role,
                  defaultTeacherId: defaultTeacherId,
                ),
                icon: const Icon(Icons.add, size: 16),
                label: const Text('Register Lesson'),
              ),
          ],
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            _kpiCard('Total Registered', '${ecs.lessonPlans.length}', const Color(0xFF0F172A)),
            _kpiCard('Assigned to Timetable', '$assignedCount', const Color(0xFF1D4ED8)),
            _kpiCard('Unassigned Ready', '$unassignedCount', const Color(0xFFB45309)),
            _kpiCard('Taught Plans', '$taughtCount', const Color(0xFF047857)),
          ],
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            ChoiceChip(
              label: Text('All Registered (${ecs.lessonPlans.length})'),
              selected: _filterMode == 'all',
              onSelected: (_) => setState(() => _filterMode = 'all'),
            ),
            ChoiceChip(
              label: Text('Unassigned Only ($unassignedCount)'),
              selected: _filterMode == 'unassigned',
              onSelected: (_) => setState(() => _filterMode = 'unassigned'),
            ),
            ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 220),
              child: DropdownButtonFormField<String>(
                value: _classroomFilter,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'Classroom Filter',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
                items: [
                  const DropdownMenuItem(
                    value: 'ALL',
                    child: Text('All Classrooms', overflow: TextOverflow.ellipsis),
                  ),
                  ...ecs.classrooms.map(
                    (c) => DropdownMenuItem(
                      value: c.id,
                      child: Text(c.name, overflow: TextOverflow.ellipsis),
                    ),
                  ),
                ],
                onChanged: (v) {
                  if (v != null) setState(() => _classroomFilter = v);
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        if (filtered.isEmpty)
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: const Text(
              'No registered lessons match this filter.',
              style: TextStyle(color: Color(0xFF64748B)),
            ),
          )
        else
          ...filtered.map((lp) => _buildLessonCard(ecs, lp, role, defaultTeacherId)),
      ],
    );
  }

  Widget _kpiCard(String label, String value, Color color) {
    return ConstrainedBox(
      constraints: const BoxConstraints(minWidth: 160, maxWidth: 220),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFFE2E8F0)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(fontSize: 12, color: Color(0xFF64748B))),
            const SizedBox(height: 4),
            Text(
              value,
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: color),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLessonCard(
    SchoolEcsState ecs,
    LessonPlanEntity lp,
    PortalRole role,
    String defaultTeacherId,
  ) {
    final subj = ecs.subjects.where((s) => s.id == lp.subjectId).firstOrNull;
    final sub = ecs.substrands.where((s) => s.id == lp.substrandId).firstOrNull;
    final teacher = ecs.teachers.where((t) => t.id == lp.teacherId).firstOrNull;
    final classroom = ecs.classrooms.where((c) => c.id == lp.classroomId).firstOrNull;
    final slot = (lp.timetableSlotId?.trim().isNotEmpty ?? false)
        ? ecs.timetableSlots.where((s) => s.id == lp.timetableSlotId).firstOrNull
        : null;
    final isAdmin = role == PortalRole.admin;
    final canEdit = isAdmin || role == PortalRole.teacher;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${lp.scheduledDate} · ${classroom?.name ?? lp.classroomId} · ${subj?.name ?? ''} · ${sub?.code ?? ''} ${sub?.title ?? ''}',
                      style: const TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      lp.title,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: lp.status == LessonStatus.taught
                      ? const Color(0xFFECFDF5)
                      : lp.status == LessonStatus.inProgress
                          ? const Color(0xFFEFF6FF)
                          : const Color(0xFFF1F5F9),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  '${lp.status.label} (${lp.lessonsDelivered}/${sub?.targetLessons ?? 1})',
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: slot != null ? const Color(0xFFEFF6FF) : const Color(0xFFFFFBEB),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: slot != null ? const Color(0xFFBFDBFE) : const Color(0xFFFDE68A),
              ),
            ),
            child: Text(
              slot != null
                  ? 'Assigned Timetable Slot: ${slot.day} Period ${slot.period} · ${slot.timeRange} · Room ${slot.room}'
                  : 'Unassigned in Registry — ready for Admin timetable slot placement',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: slot != null ? const Color(0xFF1D4ED8) : const Color(0xFFB45309),
              ),
            ),
          ),
          if (lp.reflectionNote.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(
              lp.reflectionNote,
              style: const TextStyle(fontSize: 12, color: Color(0xFF475569)),
            ),
          ],
          const Divider(height: 20),
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 10,
            runSpacing: 10,
            children: [
              Wrap(
                spacing: 8,
                runSpacing: 4,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  Text(
                    'Teacher: ${teacher?.name ?? ''}',
                    style: const TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                  ),
                  AuditAttributionPill(
                    who: ecs.teachers
                            .where((t) => t.id == lp.effectiveTeacherId)
                            .firstOrNull
                            ?.name ??
                        lp.updatedBy ??
                        lp.effectiveTeacherId,
                    when: (lp.taughtAt ?? lp.updatedAt ?? lp.scheduledDate)
                        .replaceFirst('T', ' '),
                  ),
                ],
              ),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  if (canEdit)
                    ...LessonStatus.values.map((nextStatus) {
                      final active = lp.status == nextStatus;
                      return ChoiceChip(
                        label: Text(nextStatus.label, style: const TextStyle(fontSize: 11)),
                        selected: active,
                        onSelected: (_) {
                          final count = nextStatus == LessonStatus.taught
                              ? (lp.lessonsDelivered < 2 ? 2 : lp.lessonsDelivered)
                              : nextStatus == LessonStatus.inProgress
                                  ? (lp.lessonsDelivered < 1 ? 1 : lp.lessonsDelivered)
                                  : 0;
                          ref.read(schoolEcsProvider.notifier).updateLessonPlanStatus(
                                lp.id,
                                nextStatus,
                                count,
                                taughtByTeacherId: role == PortalRole.teacher
                                    ? defaultTeacherId
                                    : lp.teacherId,
                              );
                        },
                      );
                    }),
                  if (isAdmin)
                    OutlinedButton.icon(
                      onPressed: () => _openAssignToTimetableDialog(lp),
                      icon: const Icon(Icons.calendar_month_outlined, size: 15),
                      label: Text(slot != null ? 'Reassign Slot' : 'Assign to Timetable'),
                    ),
                  if (canEdit)
                    IconButton(
                      tooltip: 'Edit Lesson',
                      onPressed: () => _openLessonDialog(
                        role: role,
                        defaultTeacherId: defaultTeacherId,
                        existing: lp,
                      ),
                      icon: const Icon(Icons.edit_outlined, size: 18),
                    ),
                  if (isAdmin)
                    IconButton(
                      tooltip: 'Delete Lesson',
                      onPressed: () => _confirmDeleteLesson(lp),
                      icon: const Icon(Icons.delete_outline, size: 18, color: Color(0xFFDC2626)),
                    ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
