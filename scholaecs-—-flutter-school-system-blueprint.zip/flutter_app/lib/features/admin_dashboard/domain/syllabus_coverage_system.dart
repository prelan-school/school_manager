import '../../../core/ecs/ecs_seed_data.dart';
import '../../../core/ecs/school_entity.dart';
import '../../assessment_books/domain/assessment_entry.dart';
import '../../class_register/domain/attendance_record.dart';
import '../../learners/domain/learner.dart';
import '../../lesson_plans/domain/lesson_plan.dart';
import '../../schemes/domain/scheme_nodes.dart';

class SubstrandCoverageReport {
  const SubstrandCoverageReport({
    required this.substrand,
    required this.strand,
    required this.classroom,
    required this.subject,
    required this.deliveredLessons,
    required this.targetLessons,
    required this.coveragePercent,
  });

  final SchemeSubstrandEntity substrand;
  final SchemeStrandEntity? strand;
  final ClassroomEntity? classroom;
  final SubjectEntity? subject;
  final int deliveredLessons;
  final int targetLessons;
  final int coveragePercent;
}

class TeacherCoverageSummary {
  const TeacherCoverageSummary({
    required this.teacher,
    required this.taughtPlans,
    required this.inProgressPlans,
    required this.totalPlans,
    required this.totalLessonsDelivered,
    required this.assessmentsLogged,
    required this.diaryEntriesLogged,
  });

  final TeacherEntity teacher;
  final int taughtPlans;
  final int inProgressPlans;
  final int totalPlans;
  final int totalLessonsDelivered;
  final int assessmentsLogged;
  final int diaryEntriesLogged;
}

class ScoreCandlestickDatum {
  const ScoreCandlestickDatum({
    required this.label,
    required this.openScore,
    required this.closeScore,
    required this.highScore,
    required this.lowScore,
    required this.sampleCount,
  });

  final String label;
  final double openScore;
  final double closeScore;
  final double highScore;
  final double lowScore;
  final int sampleCount;
}

class TeacherClassSlice {
  const TeacherClassSlice({
    required this.teacher,
    required this.classroom,
    required this.isClassTeacher,
    required this.totalPlans,
    required this.taughtPlans,
    required this.inProgressPlans,
    required this.plannedPlans,
    required this.lessonsDelivered,
    required this.assessmentsLogged,
    required this.diaryEntriesLogged,
  });

  final TeacherEntity teacher;
  final ClassroomEntity classroom;
  final bool isClassTeacher;
  final int totalPlans;
  final int taughtPlans;
  final int inProgressPlans;
  final int plannedPlans;
  final int lessonsDelivered;
  final int assessmentsLogged;
  final int diaryEntriesLogged;

  int get completionPercent =>
      totalPlans == 0 ? 0 : ((taughtPlans / totalPlans) * 100).round();
}

class SubjectDeliverySlice {
  const SubjectDeliverySlice({
    required this.subject,
    required this.totalPlans,
    required this.taughtPlans,
    required this.lessonsDelivered,
  });

  final SubjectEntity subject;
  final int totalPlans;
  final int taughtPlans;
  final int lessonsDelivered;
}

class TeacherMatrixSummary {
  const TeacherMatrixSummary({
    required this.teacher,
    required this.homeroomClassrooms,
    required this.totalPlans,
    required this.taughtPlans,
    required this.inProgressPlans,
    required this.totalLessonsDelivered,
    required this.assessmentsLogged,
    required this.diaryEntriesLogged,
    required this.byClassroom,
    required this.bySubject,
    required this.lessons,
  });

  final TeacherEntity teacher;
  final List<ClassroomEntity> homeroomClassrooms;
  final int totalPlans;
  final int taughtPlans;
  final int inProgressPlans;
  final int totalLessonsDelivered;
  final int assessmentsLogged;
  final int diaryEntriesLogged;
  final List<TeacherClassSlice> byClassroom;
  final List<SubjectDeliverySlice> bySubject;
  final List<LessonPlanEntity> lessons;

  int get completionPercent =>
      totalPlans == 0 ? 0 : ((taughtPlans / totalPlans) * 100).round();
}

class ClassroomTeacherCoverage {
  const ClassroomTeacherCoverage({
    required this.classroom,
    required this.classTeacher,
    required this.learners,
    required this.totalPlans,
    required this.taughtPlans,
    required this.inProgressPlans,
    required this.totalLessonsDelivered,
    required this.teacherSlices,
    required this.masteryExceeding,
    required this.masteryMeeting,
    required this.masteryApproaching,
    required this.masteryDeveloping,
    required this.averageScore,
    required this.attendanceRate,
    required this.subjectCandles,
    required this.lessons,
  });

  final ClassroomEntity classroom;
  final TeacherEntity? classTeacher;
  final List<LearnerEntity> learners;
  final int totalPlans;
  final int taughtPlans;
  final int inProgressPlans;
  final int totalLessonsDelivered;
  final List<TeacherClassSlice> teacherSlices;
  final int masteryExceeding;
  final int masteryMeeting;
  final int masteryApproaching;
  final int masteryDeveloping;
  final int? averageScore;
  final int? attendanceRate;
  final List<ScoreCandlestickDatum> subjectCandles;
  final List<LessonPlanEntity> lessons;

  int get completionPercent =>
      totalPlans == 0 ? 0 : ((taughtPlans / totalPlans) * 100).round();
}

class ParentFamilySummary {
  const ParentFamilySummary({
    required this.parentKey,
    required this.parentName,
    required this.parentEmail,
    required this.guardianPhone,
    required this.children,
    required this.classrooms,
    required this.averageScore,
    required this.attendanceRate,
    required this.diaryTotal,
    required this.diarySigned,
    required this.assessmentCount,
  });

  final String parentKey;
  final String parentName;
  final String parentEmail;
  final String guardianPhone;
  final List<LearnerEntity> children;
  final List<ClassroomEntity> classrooms;
  final int? averageScore;
  final int? attendanceRate;
  final int diaryTotal;
  final int diarySigned;
  final int assessmentCount;

  int get diaryAckRate =>
      diaryTotal == 0 ? 100 : ((diarySigned / diaryTotal) * 100).round();
}

class SyllabusCoverageSystem {
  const SyllabusCoverageSystem._();

  static List<SubstrandCoverageReport> computeSubstrandCoverage(SchoolEcsState state) {
    return state.substrands.map((sub) {
      final strand = state.strands.where((s) => s.id == sub.strandId).firstOrNull;
      final classroom = strand == null
          ? null
          : state.classrooms.where((c) => c.id == strand.classroomId).firstOrNull;
      final subject = state.subjects.where((s) => s.id == sub.subjectId).firstOrNull;
      final linkedPlans = state.lessonPlans.where((lp) =>
          lp.substrandId == sub.id &&
          (strand == null || lp.classroomId == strand.classroomId));
      final delivered = linkedPlans.fold<int>(
        0,
        (sum, lp) => lp.status == LessonStatus.planned ? sum : sum + lp.lessonsDelivered,
      );
      final pct = sub.targetLessons <= 0
          ? 0
          : ((delivered / sub.targetLessons) * 100).round().clamp(0, 100);
      return SubstrandCoverageReport(
        substrand: sub,
        strand: strand,
        classroom: classroom,
        subject: subject,
        deliveredLessons: delivered,
        targetLessons: sub.targetLessons,
        coveragePercent: pct,
      );
    }).toList();
  }

  static List<TeacherCoverageSummary> computeTeacherSummaries(SchoolEcsState state) {
    return state.teachers.map((teacher) {
      final plans = state.lessonPlans
          .where((lp) => lp.effectiveTeacherId == teacher.id)
          .toList();
      final taughtPlans = plans.where((lp) => lp.status == LessonStatus.taught).length;
      final inProgress = plans.where((lp) => lp.status == LessonStatus.inProgress).length;
      final delivered = plans.fold<int>(
        0,
        (sum, lp) => lp.status == LessonStatus.planned ? sum : sum + lp.lessonsDelivered,
      );
      final assessments = state.assessments.where((a) => a.teacherId == teacher.id).length;
      final diary = state.diaryEntries.where((d) => d.teacherId == teacher.id).length;

      return TeacherCoverageSummary(
        teacher: teacher,
        taughtPlans: taughtPlans,
        inProgressPlans: inProgress,
        totalPlans: plans.length,
        totalLessonsDelivered: delivered,
        assessmentsLogged: assessments,
        diaryEntriesLogged: diary,
      );
    }).toList();
  }

  static TeacherClassSlice _buildSlice({
    required SchoolEcsState state,
    required TeacherEntity teacher,
    required ClassroomEntity classroom,
  }) {
    final classLearnerIds = state.learners
        .where((l) => l.classroomId == classroom.id)
        .map((l) => l.id)
        .toSet();
    final plans = state.lessonPlans
        .where((lp) =>
            lp.classroomId == classroom.id &&
            lp.effectiveTeacherId == teacher.id)
        .toList();
    final taught = plans.where((lp) => lp.status == LessonStatus.taught).length;
    final inProgress =
        plans.where((lp) => lp.status == LessonStatus.inProgress).length;
    final planned =
        plans.where((lp) => lp.status == LessonStatus.planned).length;
    final delivered = plans.fold<int>(
      0,
      (sum, lp) =>
          lp.status == LessonStatus.planned ? sum : sum + lp.lessonsDelivered,
    );
    final assessmentsLogged = state.assessments
        .where((a) =>
            a.teacherId == teacher.id && classLearnerIds.contains(a.learnerId))
        .length;
    final diaryLogged = state.diaryEntries
        .where((d) =>
            d.classroomId == classroom.id && d.teacherId == teacher.id)
        .length;

    return TeacherClassSlice(
      teacher: teacher,
      classroom: classroom,
      isClassTeacher: classroom.classTeacherId == teacher.id,
      totalPlans: plans.length,
      taughtPlans: taught,
      inProgressPlans: inProgress,
      plannedPlans: planned,
      lessonsDelivered: delivered,
      assessmentsLogged: assessmentsLogged,
      diaryEntriesLogged: diaryLogged,
    );
  }

  static List<TeacherMatrixSummary> computeTeacherMatrix(SchoolEcsState state) {
    return state.teachers.map((teacher) {
      final lessons = state.lessonPlans
          .where((lp) => lp.effectiveTeacherId == teacher.id)
          .toList()
        ..sort((a, b) => b.scheduledDate.compareTo(a.scheduledDate));
      final homerooms = state.classrooms
          .where((c) => c.classTeacherId == teacher.id)
          .toList();

      final byClassroom = state.classrooms
          .map((c) => _buildSlice(state: state, teacher: teacher, classroom: c))
          .where((slice) =>
              slice.isClassTeacher ||
              slice.totalPlans > 0 ||
              slice.assessmentsLogged > 0 ||
              slice.diaryEntriesLogged > 0)
          .toList();

      final bySubject = state.subjects.map((subj) {
        final sPlans = lessons.where((lp) => lp.subjectId == subj.id).toList();
        return SubjectDeliverySlice(
          subject: subj,
          totalPlans: sPlans.length,
          taughtPlans:
              sPlans.where((lp) => lp.status == LessonStatus.taught).length,
          lessonsDelivered: sPlans.fold<int>(
            0,
            (sum, lp) => lp.status == LessonStatus.planned
                ? sum
                : sum + lp.lessonsDelivered,
          ),
        );
      }).where((s) => s.totalPlans > 0).toList();

      final taughtPlans =
          lessons.where((lp) => lp.status == LessonStatus.taught).length;
      final inProgressPlans =
          lessons.where((lp) => lp.status == LessonStatus.inProgress).length;
      final totalLessonsDelivered = lessons.fold<int>(
        0,
        (sum, lp) =>
            lp.status == LessonStatus.planned ? sum : sum + lp.lessonsDelivered,
      );

      return TeacherMatrixSummary(
        teacher: teacher,
        homeroomClassrooms: homerooms,
        totalPlans: lessons.length,
        taughtPlans: taughtPlans,
        inProgressPlans: inProgressPlans,
        totalLessonsDelivered: totalLessonsDelivered,
        assessmentsLogged:
            state.assessments.where((a) => a.teacherId == teacher.id).length,
        diaryEntriesLogged:
            state.diaryEntries.where((d) => d.teacherId == teacher.id).length,
        byClassroom: byClassroom,
        bySubject: bySubject,
        lessons: lessons,
      );
    }).toList();
  }

  static List<ScoreCandlestickDatum> buildScoreCandlesticks(
    SchoolEcsState state,
    List<AssessmentEntryEntity> assessments,
  ) {
    final grouped = <String, List<AssessmentEntryEntity>>{};
    for (final a in assessments) {
      grouped.putIfAbsent(a.subjectId, () => []).add(a);
    }
    final candles = <ScoreCandlestickDatum>[];
    for (final entry in grouped.entries) {
      final list = [...entry.value]..sort((a, b) => a.date.compareTo(b.date));
      final subj = state.subjects.where((s) => s.id == entry.key).firstOrNull;
      final scores = list.map((a) => a.scorePercent.toDouble()).toList();
      final low = scores.reduce((a, b) => a < b ? a : b);
      final high = scores.reduce((a, b) => a > b ? a : b);
      candles.add(
        ScoreCandlestickDatum(
          label: subj?.code ?? entry.key,
          openScore: scores.first,
          closeScore: scores.last,
          highScore: high,
          lowScore: low,
          sampleCount: list.length,
        ),
      );
    }
    candles.sort((a, b) => a.label.compareTo(b.label));
    return candles;
  }

  static List<ClassroomTeacherCoverage> computeClassroomMatrix(
    SchoolEcsState state,
  ) {
    return state.classrooms.map((cls) {
      final classTeacher = cls.classTeacherId == null
          ? null
          : state.teachers
              .where((t) => t.id == cls.classTeacherId)
              .firstOrNull;
      final learners =
          state.learners.where((l) => l.classroomId == cls.id).toList();
      final learnerIds = learners.map((l) => l.id).toSet();

      final lessons = state.lessonPlans
          .where((lp) => lp.classroomId == cls.id)
          .toList()
        ..sort((a, b) => b.scheduledDate.compareTo(a.scheduledDate));
      final taughtPlans =
          lessons.where((lp) => lp.status == LessonStatus.taught).length;
      final inProgressPlans =
          lessons.where((lp) => lp.status == LessonStatus.inProgress).length;
      final delivered = lessons.fold<int>(
        0,
        (sum, lp) =>
            lp.status == LessonStatus.planned ? sum : sum + lp.lessonsDelivered,
      );

      final teacherSlices = state.teachers
          .map((t) => _buildSlice(state: state, teacher: t, classroom: cls))
          .where((s) =>
              s.isClassTeacher ||
              s.totalPlans > 0 ||
              s.assessmentsLogged > 0 ||
              s.diaryEntriesLogged > 0)
          .toList();

      final classAssessments = state.assessments
          .where((a) => learnerIds.contains(a.learnerId))
          .toList();
      final exceeding = classAssessments
          .where((a) => a.mastery == MasteryLevel.exceeding)
          .length;
      final meeting = classAssessments
          .where((a) => a.mastery == MasteryLevel.meeting)
          .length;
      final approaching = classAssessments
          .where((a) => a.mastery == MasteryLevel.approaching)
          .length;
      final developing = classAssessments
          .where((a) => a.mastery == MasteryLevel.developing)
          .length;
      final int? avgScore = classAssessments.isEmpty
          ? null
          : (classAssessments.fold<int>(0, (s, a) => s + a.scorePercent) /
                  classAssessments.length)
              .round();

      final classAttendance = state.attendanceRecords
          .where((r) => r.classroomId == cls.id)
          .toList();
      final int? attRate = classAttendance.isEmpty
          ? null
          : ((classAttendance
                          .where((r) =>
                              r.status == AttendanceStatus.present ||
                              r.status == AttendanceStatus.late)
                          .length /
                      classAttendance.length) *
                  100)
              .round();

      return ClassroomTeacherCoverage(
        classroom: cls,
        classTeacher: classTeacher,
        learners: learners,
        totalPlans: lessons.length,
        taughtPlans: taughtPlans,
        inProgressPlans: inProgressPlans,
        totalLessonsDelivered: delivered,
        teacherSlices: teacherSlices,
        masteryExceeding: exceeding,
        masteryMeeting: meeting,
        masteryApproaching: approaching,
        masteryDeveloping: developing,
        averageScore: avgScore,
        attendanceRate: attRate,
        subjectCandles: buildScoreCandlesticks(state, classAssessments),
        lessons: lessons,
      );
    }).toList();
  }

  static List<ParentFamilySummary> computeParentSummaries(SchoolEcsState state) {
    final grouped = <String, List<LearnerEntity>>{};
    for (final l in state.learners) {
      final emailKey = l.parentEmail.trim().toLowerCase();
      final key = emailKey.isNotEmpty
          ? emailKey
          : l.parentName.trim().toLowerCase();
      grouped.putIfAbsent(key, () => []).add(l);
    }

    final list = <ParentFamilySummary>[];
    for (final entry in grouped.entries) {
      final children = entry.value;
      final lead = children.first;
      final childIds = children.map((c) => c.id).toSet();
      final classIds = children.map((c) => c.classroomId).toSet();
      final classrooms =
          state.classrooms.where((c) => classIds.contains(c.id)).toList();

      final assessments = state.assessments
          .where((a) => childIds.contains(a.learnerId))
          .toList();
      final int? avgScore = assessments.isEmpty
          ? null
          : (assessments.fold<int>(0, (s, a) => s + a.scorePercent) /
                  assessments.length)
              .round();

      final attendance = state.attendanceRecords
          .where((r) => childIds.contains(r.learnerId))
          .toList();
      final int? attRate = attendance.isEmpty
          ? null
          : ((attendance
                          .where((r) =>
                              r.status == AttendanceStatus.present ||
                              r.status == AttendanceStatus.late)
                          .length /
                      attendance.length) *
                  100)
              .round();

      final diary = state.diaryEntries
          .where((d) => childIds.contains(d.learnerId))
          .toList();
      final signed = diary.where((d) => d.parentAcknowledged).length;

      list.add(
        ParentFamilySummary(
          parentKey: entry.key,
          parentName: lead.parentName,
          parentEmail: lead.parentEmail,
          guardianPhone: lead.guardianPhone,
          children: children,
          classrooms: classrooms,
          averageScore: avgScore,
          attendanceRate: attRate,
          diaryTotal: diary.length,
          diarySigned: signed,
          assessmentCount: assessments.length,
        ),
      );
    }
    list.sort((a, b) => a.parentName.compareTo(b.parentName));
    return list;
  }
}
