import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/ecs/ecs_providers.dart';
import '../../../core/ecs/school_entity.dart';
import '../../../core/widgets/analytics_charts.dart';
import '../../learners/domain/learner.dart';
import '../../learners/domain/learner_longitudinal_system.dart';

class ClassroomAnalyticsPage extends ConsumerStatefulWidget {
  const ClassroomAnalyticsPage({super.key, this.initialClassroomId});

  final String? initialClassroomId;

  @override
  ConsumerState<ClassroomAnalyticsPage> createState() =>
      _ClassroomAnalyticsPageState();
}

class _ClassroomAnalyticsPageState
    extends ConsumerState<ClassroomAnalyticsPage> {
  String? _selectedId;

  @override
  void initState() {
    super.initState();
    _selectedId = widget.initialClassroomId;
  }

  @override
  void didUpdateWidget(covariant ClassroomAnalyticsPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.initialClassroomId != oldWidget.initialClassroomId &&
        widget.initialClassroomId != null) {
      _selectedId = widget.initialClassroomId;
    }
  }

  @override
  Widget build(BuildContext context) {
    final ecs = ref.watch(schoolEcsProvider);
    final notifier = ref.read(schoolEcsProvider.notifier);
    final matrix = ref.watch(classroomMatrixProvider);

    if (matrix.isEmpty) {
      return const Center(child: Text('No classrooms configured yet.'));
    }

    final activeId = matrix.any((m) => m.classroom.id == _selectedId)
        ? _selectedId!
        : matrix.first.classroom.id;
    final selected =
        matrix.firstWhere((m) => m.classroom.id == activeId);
    final classAuditLogs = ecs.auditLogs
        .where((a) => a.classroomId == selected.classroom.id)
        .toList();

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Wrap(
          alignment: WrapAlignment.spaceBetween,
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: 12,
          runSpacing: 12,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Classroom Granular Analytics · ${selected.classroom.name}',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(
                  'Room ${selected.classroom.roomCode} · Class Teacher: ${selected.classTeacher?.name ?? 'Unassigned'}',
                  style: const TextStyle(fontSize: 13, color: Color(0xFF475569)),
                ),
              ],
            ),
            Wrap(
              spacing: 10,
              runSpacing: 8,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                SizedBox(
                  width: 220,
                  child: DropdownButtonFormField<String>(
                    value: activeId,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Select Classroom',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    items: matrix
                        .map(
                          (m) => DropdownMenuItem<String>(
                            value: m.classroom.id,
                            child: Text(
                              m.classroom.name,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (v) {
                      if (v != null) setState(() => _selectedId = v);
                    },
                  ),
                ),
                SizedBox(
                  width: 210,
                  child: DropdownButtonFormField<String>(
                    value: ecs.teachers.any(
                            (t) => t.id == selected.classroom.classTeacherId)
                        ? selected.classroom.classTeacherId
                        : null,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Assign Class Teacher',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    items: ecs.teachers
                        .map(
                          (t) => DropdownMenuItem<String>(
                            value: t.id,
                            child: Text(t.name, overflow: TextOverflow.ellipsis),
                          ),
                        )
                        .toList(),
                    onChanged: (tid) {
                      if (tid != null) {
                        notifier.assignClassTeacher(
                          classroomId: selected.classroom.id,
                          teacherId: tid,
                        );
                      }
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 16),
        LayoutBuilder(
          builder: (ctx, constraints) {
            final cards = [
              _ClassKpi('Enrolled Learners', '${selected.learners.length}'),
              _ClassKpi(
                'Avg Class Score',
                selected.averageScore != null ? '${selected.averageScore}%' : '—',
              ),
              _ClassKpi(
                'Attendance Rate',
                selected.attendanceRate != null
                    ? '${selected.attendanceRate}%'
                    : '—',
              ),
              _ClassKpi(
                'Lessons Delivered',
                '${selected.totalLessonsDelivered} (${selected.taughtPlans}/${selected.totalPlans} plans)',
              ),
            ];
            if (constraints.maxWidth >= 680) {
              return Row(
                children: [
                  for (var i = 0; i < cards.length; i++) ...[
                    Expanded(child: cards[i]),
                    if (i < cards.length - 1) const SizedBox(width: 12),
                  ],
                ],
              );
            }
            return Column(
              children: [
                Row(
                  children: [
                    Expanded(child: cards[0]),
                    const SizedBox(width: 10),
                    Expanded(child: cards[1]),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(child: cards[2]),
                    const SizedBox(width: 10),
                    Expanded(child: cards[3]),
                  ],
                ),
              ],
            );
          },
        ),
        const SizedBox(height: 16),
        LayoutBuilder(
          builder: (ctx, constraints) {
            final isWide = constraints.maxWidth >= 820;
            final teacherBars = GranularBarChart(
              title: 'Teacher Instructional Load in ${selected.classroom.gradeLevel} (Bar)',
              subtitle: 'Lessons delivered vs assessments logged by each teacher.',
              primaryLabel: 'Lessons Delivered',
              secondaryLabel: 'Assessments Logged',
              primaryColor: const Color(0xFF2563EB),
              secondaryColor: const Color(0xFF10B981),
              data: selected.teacherSlices
                  .map(
                    (s) => MetricBarDatum(
                      label: s.teacher.name.split(' ').first,
                      primaryValue: s.lessonsDelivered.toDouble(),
                      secondaryValue: s.assessmentsLogged.toDouble(),
                    ),
                  )
                  .toList(),
            );
            final masteryPie = MasteryBreakdownChart(
              title: '${selected.classroom.gradeLevel} Mastery Breakdown (Pie)',
              exceedingCount: selected.masteryExceeding,
              meetingCount: selected.masteryMeeting,
              approachingCount: selected.masteryApproaching,
              developingCount: selected.masteryDeveloping,
            );
            if (isWide) {
              return Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(child: teacherBars),
                  const SizedBox(width: 16),
                  Expanded(child: masteryPie),
                ],
              );
            }
            return Column(
              children: [
                teacherBars,
                const SizedBox(height: 16),
                masteryPie,
              ],
            );
          },
        ),
        const SizedBox(height: 16),
        ScoreCandlestickChart(
          title: '${selected.classroom.name} Subject Score Spread (Candlestick)',
          subtitle: 'Min–Max score range and earliest-to-latest progression per subject.',
          candles: selected.subjectCandles,
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(
                alignment: WrapAlignment.spaceBetween,
                crossAxisAlignment: WrapCrossAlignment.center,
                spacing: 8,
                runSpacing: 8,
                children: [
                  Text(
                    'Connected Schemes of Work for ${selected.classroom.name}',
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                  ),
                  TextButton.icon(
                    onPressed: () => context.go('/schemes'),
                    icon: const Icon(Icons.account_tree_outlined, size: 15),
                    label: const Text('Manage Class Schemes'),
                  ),
                ],
              ),
              const Divider(height: 18),
              ...(() {
                final classReports = ref
                    .watch(substrandCoverageProvider)
                    .where((r) => r.strand?.classroomId == selected.classroom.id)
                    .toList();
                if (classReports.isEmpty) {
                  return const [
                    Text(
                      'No scheme strands registered for this classroom yet.',
                      style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                    ),
                  ];
                }
                return classReports
                    .map(
                      (r) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: ProgressBarChart(
                          title:
                              '${r.strand?.code ?? ''} · ${r.substrand.code}: ${r.substrand.title}',
                          value: (r.coveragePercent / 100).clamp(0.0, 1.0),
                          label:
                              '${r.coveragePercent}% (${r.deliveredLessons}/${r.targetLessons} lessons)',
                          color: r.coveragePercent >= 100
                              ? const Color(0xFF10B981)
                              : const Color(0xFF2563EB),
                        ),
                      ),
                    )
                    .toList();
              })(),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Enrolled Learners in ${selected.classroom.name} (${selected.learners.length})',
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
              ),
              const Divider(height: 20),
              if (selected.learners.isEmpty)
                const Text(
                  'No learners enrolled in this classroom yet.',
                  style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                )
              else
                ...selected.learners.map((learner) {
                  final report = LearnerLongitudinalSystem.buildReport(
                    ecs,
                    learner.id,
                    PortalRole.admin,
                    const LearnerTimeframe(
                      preset: TimeframePreset.sinceRegistration,
                    ),
                  );
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF8FAFC),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: const Color(0xFFE2E8F0)),
                    ),
                    child: Wrap(
                      alignment: WrapAlignment.spaceBetween,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      spacing: 12,
                      runSpacing: 8,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${learner.name} (${learner.admissionNo})',
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            Text(
                              'Guardian: ${learner.parentName} · Avg: ${report?.averageScore != null ? '${report!.averageScore}%' : '—'} · Attendance: ${report?.attendanceRate != null ? '${report!.attendanceRate}%' : '—'}',
                              style: const TextStyle(
                                fontSize: 12,
                                color: Color(0xFF64748B),
                              ),
                            ),
                          ],
                        ),
                        FilledButton.icon(
                          onPressed: () =>
                              context.go('/learners/${learner.id}'),
                          icon: const Icon(Icons.bar_chart, size: 15),
                          label: const Text('Inspect Learner'),
                        ),
                      ],
                    ),
                  );
                }),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Lesson Plans & Who Taught Them',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
              ),
              const Divider(height: 20),
              ...selected.lessons.map((lp) {
                final teacher = ecs.teachers
                    .where((t) => t.id == lp.effectiveTeacherId)
                    .firstOrNull;
                final subj = ecs.subjects
                    .where((s) => s.id == lp.subjectId)
                    .firstOrNull;
                final when = lp.taughtAt ?? lp.updatedAt ?? lp.scheduledDate;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          '${lp.title} (${subj?.code ?? lp.subjectId}) · ${lp.status.label} (${lp.lessonsDelivered} lessons)',
                          style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      AuditAttributionPill(
                        who: teacher?.name ?? lp.effectiveTeacherId,
                        when: when.replaceFirst('T', ' '),
                      ),
                    ],
                  ),
                );
              }),
              if (classAuditLogs.isNotEmpty) ...[
                const Divider(height: 22),
                const Text(
                  'Classroom Who & When Activity Feed',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                ...classAuditLogs.take(10).map(
                      (log) => Padding(
                        padding: const EdgeInsets.only(bottom: 6),
                        child: Text(
                          '${log.timestamp.replaceFirst('T', ' ')} · ${log.actorName} (${log.actorRole}): ${log.targetLabel} — ${log.detail}',
                          style: const TextStyle(
                            fontSize: 12,
                            color: Color(0xFF475569),
                          ),
                        ),
                      ),
                    ),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

class _ClassKpi extends StatelessWidget {
  const _ClassKpi(this.label, this.value);
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 11, color: Color(0xFF64748B))),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
