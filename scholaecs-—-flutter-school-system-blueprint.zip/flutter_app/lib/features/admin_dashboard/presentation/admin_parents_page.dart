import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/ecs/ecs_providers.dart';
import '../../../core/ecs/school_entity.dart';
import '../../../core/widgets/action_feedback.dart';
import '../../../core/widgets/analytics_charts.dart';
import '../../learners/domain/learner.dart';
import '../../learners/domain/learner_longitudinal_system.dart';

class AdminParentsPage extends ConsumerStatefulWidget {
  const AdminParentsPage({super.key});

  @override
  ConsumerState<AdminParentsPage> createState() => _AdminParentsPageState();
}

class _AdminParentsPageState extends ConsumerState<AdminParentsPage>
    with BusyActionMixin {
  String _search = '';
  String _selectedParentKey = 'all';

  Future<void> _openLocationDialog({LocationEntity? existing}) async {
    final nameCtrl = TextEditingController(text: existing?.name ?? '');
    final zoneCtrl = TextEditingController(text: existing?.zone ?? '');
    final notesCtrl = TextEditingController(text: existing?.notes ?? '');
    String? error;
    var isSubmitting = false;

    await showDialog<void>(
      context: context,
      builder: (dialogCtx) => StatefulBuilder(
        builder: (ctx, setModalState) => AlertDialog(
          title: Text(existing == null ? 'Add Catchment / Bus Zone' : 'Edit Zone'),
          content: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Location Name * (e.g. Lavington)',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: zoneCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Route / Zone Label',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: notesCtrl,
                  maxLines: 2,
                  decoration: const InputDecoration(
                    labelText: 'Pickup / Drop-off Notes',
                    border: OutlineInputBorder(),
                  ),
                ),
                if (error != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    error!,
                    style: const TextStyle(color: Color(0xFFDC2626), fontSize: 12),
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: isSubmitting ? null : () => Navigator.of(dialogCtx).pop(),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: isSubmitting
                  ? null
                  : () async {
                      setModalState(() {
                        error = null;
                        isSubmitting = true;
                      });
                      final err = await ref
                          .read(schoolEcsProvider.notifier)
                          .upsertLocation(
                            LocationEntity(
                              id: existing?.id ??
                                  'loc_${DateTime.now().millisecondsSinceEpoch}',
                              name: nameCtrl.text,
                              zone: zoneCtrl.text,
                              notes: notesCtrl.text,
                            ),
                          );
                      if (err != null) {
                        setModalState(() {
                          isSubmitting = false;
                          error = err;
                        });
                        return;
                      }
                      if (dialogCtx.mounted) Navigator.of(dialogCtx).pop();
                      if (mounted) {
                        showActionSnackBar(
                          context,
                          kind: ActionFeedbackKind.success,
                          message: existing == null
                              ? 'Catchment zone "${nameCtrl.text.trim()}" added.'
                              : 'Catchment zone "${nameCtrl.text.trim()}" updated.',
                        );
                      }
                    },
              child: Text(isSubmitting ? 'Saving...' : 'Save Zone'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ecs = ref.watch(schoolEcsProvider);
    final families = ref.watch(parentSummariesProvider);

    final filtered = families.where((f) {
      final q = _search.trim().toLowerCase();
      final matchesSearch = q.isEmpty ||
          f.parentName.toLowerCase().contains(q) ||
          f.parentEmail.toLowerCase().contains(q) ||
          f.guardianPhone.toLowerCase().contains(q) ||
          f.children.any((c) => c.name.toLowerCase().contains(q));
      final matchesSelected =
          _selectedParentKey == 'all' || f.parentKey == _selectedParentKey;
      return matchesSearch && matchesSelected;
    }).toList();

    final totalChildren =
        families.fold<int>(0, (s, f) => s + f.children.length);
    final totalSigned = families.fold<int>(0, (s, f) => s + f.diarySigned);
    final totalDiary = families.fold<int>(0, (s, f) => s + f.diaryTotal);
    final overallAckRate =
        totalDiary == 0 ? 100 : ((totalSigned / totalDiary) * 100).round();

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Wrap(
          alignment: WrapAlignment.spaceBetween,
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: 12,
          runSpacing: 12,
          children: [
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Parents, Households & Catchment Zones',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                ),
                Text(
                  'Inspect guardian accounts, transport zones, linked children, and engagement.',
                  style: TextStyle(fontSize: 13, color: Color(0xFF475569)),
                ),
              ],
            ),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                FilledButton.tonalIcon(
                  onPressed: isBusy ? null : () => _openLocationDialog(),
                  icon: const Icon(Icons.add_location_alt_outlined, size: 16),
                  label: const Text('Add Zone'),
                ),
                SizedBox(
                  width: 240,
                  child: TextField(
                    decoration: const InputDecoration(
                      hintText: 'Search parent, phone, or child...',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    onChanged: (val) => setState(() => _search = val),
                  ),
                ),
                SizedBox(
                  width: 210,
                  child: DropdownButtonFormField<String>(
                    value: families.any((f) => f.parentKey == _selectedParentKey)
                        ? _selectedParentKey
                        : 'all',
                    isExpanded: true,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    items: [
                      const DropdownMenuItem(
                        value: 'all',
                        child: Text('All Parents', overflow: TextOverflow.ellipsis),
                      ),
                      ...families.map(
                        (f) => DropdownMenuItem(
                          value: f.parentKey,
                          child: Text(f.parentName, overflow: TextOverflow.ellipsis),
                        ),
                      ),
                    ],
                    onChanged: (v) {
                      if (v != null) setState(() => _selectedParentKey = v);
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 16),
        LayoutBuilder(
          builder: (ctx, constraints) {
            final cards = [
              _FamilyKpi(
                label: 'Registered Guardians',
                value: '${families.length} Parents',
                color: const Color(0xFF2563EB),
              ),
              _FamilyKpi(
                label: 'Linked Learners',
                value: '$totalChildren Children',
                color: const Color(0xFF10B981),
              ),
              _FamilyKpi(
                label: 'Multi-Child Families',
                value:
                    '${families.where((f) => f.children.length > 1).length} Households',
                color: const Color(0xFF7C3AED),
              ),
              _FamilyKpi(
                label: 'Diary Sign-Off Rate',
                value: '$overallAckRate% ($totalSigned/$totalDiary)',
                color: const Color(0xFFF59E0B),
              ),
            ];
            if (constraints.maxWidth >= 700) {
              return Row(
                children: [
                  for (var i = 0; i < cards.length; i++) ...[
                    Expanded(child: cards[i]),
                    if (i < cards.length - 1) const SizedBox(width: 12),
                  ],
                ],
              );
            }
            return Column(
              children: [
                Row(
                  children: [
                    Expanded(child: cards[0]),
                    const SizedBox(width: 10),
                    Expanded(child: cards[1]),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(child: cards[2]),
                    const SizedBox(width: 10),
                    Expanded(child: cards[3]),
                  ],
                ),
              ],
            );
          },
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Transport & Catchment Zones',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 8),
              if (ecs.locations.isEmpty)
                const Text(
                  'No catchment zones configured yet. Use "Add Zone" above to create one.',
                  style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                )
              else
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: ecs.locations.map((loc) {
                    final learnerCount =
                        ecs.learners.where((l) => l.locationId == loc.id).length;
                    return Container(
                      width: 250,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: const Color(0xFFE2E8F0)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  loc.name,
                                  style: const TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.edit_outlined, size: 16),
                                constraints: const BoxConstraints(),
                                padding: EdgeInsets.zero,
                                onPressed: isBusy
                                    ? null
                                    : () => _openLocationDialog(existing: loc),
                              ),
                              const SizedBox(width: 6),
                              IconButton(
                                icon: const Icon(
                                  Icons.delete_outline,
                                  size: 16,
                                  color: Colors.red,
                                ),
                                constraints: const BoxConstraints(),
                                padding: EdgeInsets.zero,
                                onPressed: isBusy
                                    ? null
                                    : () => runLockedAction(() async {
                                          await ref
                                              .read(schoolEcsProvider.notifier)
                                              .deleteLocation(loc.id);
                                          if (!context.mounted) return;
                                          showActionSnackBar(
                                            context,
                                            kind: ActionFeedbackKind.info,
                                            message: 'Removed zone "${loc.name}".',
                                          );
                                        }),
                              ),
                            ],
                          ),
                          Text(
                            '${loc.zone} · $learnerCount learner${learnerCount == 1 ? '' : 's'}',
                            style: const TextStyle(fontSize: 11, color: Color(0xFF475569)),
                          ),
                          if (loc.notes.isNotEmpty)
                            Text(
                              loc.notes,
                              style: const TextStyle(fontSize: 11, color: Color(0xFF64748B)),
                            ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        GranularBarChart(
          title: 'Family Engagement: Avg Mastery vs Diary Ack % (Bar Chart)',
          subtitle: 'Compares average learner mastery score and diary acknowledgment across guardians.',
          primaryLabel: 'Avg Mastery %',
          secondaryLabel: 'Diary Signed %',
          primaryColor: const Color(0xFF2563EB),
          secondaryColor: const Color(0xFF10B981),
          maxY: 100,
          unitSuffix: '%',
          data: filtered
              .map(
                (f) => MetricBarDatum(
                  label: f.parentName.split(' ').first,
                  primaryValue: (f.averageScore ?? 0).toDouble(),
                  secondaryValue: f.diaryAckRate.toDouble(),
                ),
              )
              .toList(),
        ),
        const SizedBox(height: 16),
        ...filtered.map((family) {
          return Container(
            margin: const EdgeInsets.only(bottom: 14),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  alignment: WrapAlignment.spaceBetween,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  spacing: 12,
                  runSpacing: 8,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          family.parentName,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '${family.parentEmail} · ${family.guardianPhone}',
                          style: const TextStyle(
                            fontSize: 12,
                            color: Color(0xFF64748B),
                          ),
                        ),
                      ],
                    ),
                    Wrap(
                      spacing: 8,
                      runSpacing: 6,
                      children: [
                        _BadgePill(
                          label: '${family.children.length} Child(ren)',
                          color: const Color(0xFF2563EB),
                        ),
                        _BadgePill(
                          label:
                              'Mastery: ${family.averageScore != null ? '${family.averageScore}%' : '—'}',
                          color: const Color(0xFF10B981),
                        ),
                        _BadgePill(
                          label:
                              'Diary Signed: ${family.diarySigned}/${family.diaryTotal}',
                          color: const Color(0xFFF59E0B),
                        ),
                      ],
                    ),
                  ],
                ),
                const Divider(height: 22),
                const Text(
                  'Linked Children & Classroom Analytics',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 10),
                ...family.children.map((child) {
                  final cls = ecs.classrooms
                      .where((c) => c.id == child.classroomId)
                      .firstOrNull;
                  final loc = child.locationId == null
                      ? null
                      : ecs.locations
                          .where((z) => z.id == child.locationId)
                          .firstOrNull;
                  final classTeacher = cls?.classTeacherId == null
                      ? null
                      : ecs.teachers
                          .where((t) => t.id == cls!.classTeacherId)
                          .firstOrNull;
                  final report = LearnerLongitudinalSystem.buildReport(
                    ecs,
                    child.id,
                    PortalRole.admin,
                    const LearnerTimeframe(
                      preset: TimeframePreset.sinceRegistration,
                    ),
                  );
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF8FAFC),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: const Color(0xFFE2E8F0)),
                    ),
                    child: Wrap(
                      alignment: WrapAlignment.spaceBetween,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      spacing: 12,
                      runSpacing: 10,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${child.name} (${child.admissionNo})',
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              '${cls?.name ?? child.classroomId}${loc != null ? ' · ${loc.name}' : ''} · Class Teacher: ${classTeacher?.name ?? 'Unassigned'}',
                              style: const TextStyle(
                                fontSize: 12,
                                color: Color(0xFF475569),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Avg Score: ${report?.averageScore != null ? '${report!.averageScore}%' : '—'} · Attendance: ${report?.attendanceRate != null ? '${report!.attendanceRate}%' : '—'} · Assessments: ${report?.assessments.length ?? 0} · Diary: ${report?.diary.length ?? 0}',
                              style: const TextStyle(
                                fontSize: 11,
                                color: Color(0xFF64748B),
                              ),
                            ),
                          ],
                        ),
                        Wrap(
                          spacing: 8,
                          runSpacing: 6,
                          children: [
                            if (cls != null)
                              OutlinedButton.icon(
                                onPressed: () =>
                                    context.go('/classrooms/${cls.id}'),
                                icon: const Icon(Icons.analytics_outlined, size: 15),
                                label: const Text('Class Analytics'),
                              ),
                            FilledButton.icon(
                              onPressed: () =>
                                  context.go('/learners/${child.id}'),
                              icon: const Icon(Icons.person_search, size: 15),
                              label: const Text('Learner Charts'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  );
                }),
              ],
            ),
          );
        }),
      ],
    );
  }
}

class _FamilyKpi extends StatelessWidget {
  const _FamilyKpi({
    required this.label,
    required this.value,
    required this.color,
  });

  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 11, color: Color(0xFF64748B))),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

class _BadgePill extends StatelessWidget {
  const _BadgePill({required this.label, required this.color});
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: color,
        ),
      ),
    );
  }
}
