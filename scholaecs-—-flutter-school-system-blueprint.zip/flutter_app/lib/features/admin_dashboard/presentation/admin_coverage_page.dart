import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/ecs/ecs_providers.dart';
import '../../../core/ecs/ecs_seed_data.dart';
import '../../../core/ecs/school_entity.dart';
import '../../../core/widgets/admin_ai_briefing_card.dart';
import '../../../core/widgets/analytics_charts.dart';
import '../../lesson_plans/domain/lesson_plan.dart';
import '../domain/syllabus_coverage_system.dart';

class AdminCoveragePage extends ConsumerStatefulWidget {
  const AdminCoveragePage({super.key});

  @override
  ConsumerState<AdminCoveragePage> createState() => _AdminCoveragePageState();
}

class _AdminCoveragePageState extends ConsumerState<AdminCoveragePage> {
  String _segment = 'classrooms'; // 'substrands' | 'classrooms' | 'teachers' | 'charts' | 'audit'
  String _auditRoleFilter = 'all';
  String _auditQuery = '';

  @override
  Widget build(BuildContext context) {
    final ecs = ref.watch(schoolEcsProvider);
    final notifier = ref.read(schoolEcsProvider.notifier);
    final substrandReports = ref.watch(substrandCoverageProvider);
    final teacherMatrix = ref.watch(teacherMatrixProvider);
    final classroomMatrix = ref.watch(classroomMatrixProvider);

    final avgCoverage = substrandReports.isEmpty
        ? 0
        : (substrandReports.fold<int>(0, (s, r) => s + r.coveragePercent) /
                substrandReports.length)
            .round();
    final taughtCount =
        ecs.lessonPlans.where((lp) => lp.status == LessonStatus.taught).length;

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Wrap(
          alignment: WrapAlignment.spaceBetween,
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: 12,
          runSpacing: 12,
          children: [
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Admin Syllabus Coverage & Analytics',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                ),
                Text(
                  'Two-way Teacher <-> Class attribution, Candlestick/Bar/Pie charts, and Who & When audit tracking.',
                  style: TextStyle(fontSize: 13, color: Color(0xFF475569)),
                ),
              ],
            ),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                OutlinedButton.icon(
                  onPressed: () => context.go('/parents'),
                  icon: const Icon(Icons.family_restroom_outlined, size: 16),
                  label: const Text('Parents & Zones'),
                ),
                FilledButton.icon(
                  onPressed: () => context.go('/classrooms'),
                  icon: const Icon(Icons.class_outlined, size: 16),
                  label: const Text('Classroom Drill-Down'),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 16),
        AdminAiBriefingCard(ecsState: ecs),
        const SizedBox(height: 16),
        LayoutBuilder(
          builder: (ctx, constraints) {
            if (constraints.maxWidth >= 680) {
              return Row(
                children: [
                  Expanded(
                    child: _StatCard(
                      label: 'Overall Coverage',
                      value: '$avgCoverage%',
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _StatCard(
                      label: 'Lesson Plans Taught',
                      value: '$taughtCount / ${ecs.lessonPlans.length}',
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _StatCard(
                      label: 'Active Classrooms',
                      value: '${ecs.classrooms.length} Streams',
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _StatCard(
                      label: 'Tracked Actions',
                      value: '${ecs.auditLogs.length} Events',
                    ),
                  ),
                ],
              );
            }
            return Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: _StatCard(
                        label: 'Overall Coverage',
                        value: '$avgCoverage%',
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _StatCard(
                        label: 'Plans Taught',
                        value: '$taughtCount / ${ecs.lessonPlans.length}',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: _StatCard(
                        label: 'Classrooms',
                        value: '${ecs.classrooms.length} Streams',
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _StatCard(
                        label: 'Audit Events',
                        value: '${ecs.auditLogs.length}',
                      ),
                    ),
                  ],
                ),
              ],
            );
          },
        ),
        const SizedBox(height: 20),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            const Text(
              'Segment View:',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
            ),
            ChoiceChip(
              label: const Text('By Class -> Teacher', style: TextStyle(fontSize: 12)),
              selected: _segment == 'classrooms',
              onSelected: (_) => setState(() => _segment = 'classrooms'),
            ),
            ChoiceChip(
              label: const Text('By Teacher -> Class', style: TextStyle(fontSize: 12)),
              selected: _segment == 'teachers',
              onSelected: (_) => setState(() => _segment = 'teachers'),
            ),
            ChoiceChip(
              label: const Text('By Substrand', style: TextStyle(fontSize: 12)),
              selected: _segment == 'substrands',
              onSelected: (_) => setState(() => _segment = 'substrands'),
            ),
            ChoiceChip(
              label: const Text('Charts & Score Spread', style: TextStyle(fontSize: 12)),
              selected: _segment == 'charts',
              onSelected: (_) => setState(() => _segment = 'charts'),
            ),
            ChoiceChip(
              label: const Text('Who & When Audit Log', style: TextStyle(fontSize: 12)),
              selected: _segment == 'audit',
              onSelected: (_) => setState(() => _segment = 'audit'),
            ),
          ],
        ),
        const SizedBox(height: 16),

        if (_segment == 'classrooms') ...[
          GranularBarChart(
            title: 'Lesson Plans Taught vs Planned per Classroom (Bar Chart)',
            subtitle: 'Compares delivered teaching plans against registered targets across streams.',
            primaryLabel: 'Taught Plans',
            secondaryLabel: 'Total Plans',
            primaryColor: const Color(0xFF0284C7),
            secondaryColor: const Color(0xFFCBD5E1),
            data: classroomMatrix
                .map(
                  (c) => MetricBarDatum(
                    label: c.classroom.gradeLevel,
                    primaryValue: c.taughtPlans.toDouble(),
                    secondaryValue: c.totalPlans.toDouble(),
                  ),
                )
                .toList(),
          ),
          const SizedBox(height: 16),
          ...classroomMatrix.map((c) {
            return Container(
              margin: const EdgeInsets.only(bottom: 14),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Wrap(
                    alignment: WrapAlignment.spaceBetween,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    spacing: 12,
                    runSpacing: 10,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${c.classroom.name} (${c.classroom.gradeLevel} · Room ${c.classroom.roomCode})',
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Wrap(
                            spacing: 8,
                            runSpacing: 4,
                            children: [
                              Text(
                                '${c.learners.length} learners · ${c.totalLessonsDelivered} lessons delivered · Avg Score: ${c.averageScore != null ? '${c.averageScore}%' : '—'}',
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: Color(0xFF64748B),
                                ),
                              ),
                              if (c.classroom.updatedBy != null &&
                                  c.classroom.updatedAt != null)
                                AuditAttributionPill(
                                  who: c.classroom.updatedBy!,
                                  when: c.classroom.updatedAt!.replaceFirst('T', ' '),
                                ),
                            ],
                          ),
                        ],
                      ),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          SizedBox(
                            width: 210,
                            child: DropdownButtonFormField<String>(
                              value: ecs.teachers.any(
                                      (t) => t.id == c.classroom.classTeacherId)
                                  ? c.classroom.classTeacherId
                                  : null,
                              isExpanded: true,
                              decoration: const InputDecoration(
                                labelText: 'Class Teacher',
                                border: OutlineInputBorder(),
                                isDense: true,
                              ),
                              items: ecs.teachers
                                  .map(
                                    (t) => DropdownMenuItem<String>(
                                      value: t.id,
                                      child: Text(
                                        t.name,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  )
                                  .toList(),
                              onChanged: (nextTeacherId) {
                                if (nextTeacherId != null) {
                                  notifier.assignClassTeacher(
                                    classroomId: c.classroom.id,
                                    teacherId: nextTeacherId,
                                  );
                                }
                              },
                            ),
                          ),
                          OutlinedButton.icon(
                            onPressed: () =>
                                context.go('/classrooms/${c.classroom.id}'),
                            icon: const Icon(Icons.open_in_new, size: 15),
                            label: const Text('Inspect Class'),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const Divider(height: 22),
                  const Text(
                    'Teacher Contributions in this Classroom',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 10),
                  if (c.teacherSlices.isEmpty)
                    const Text(
                      'No teacher activity logged in this classroom yet.',
                      style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                    )
                  else
                    ...c.teacherSlices.map((slice) {
                      final ratio = slice.totalPlans == 0
                          ? 0.0
                          : slice.taughtPlans / slice.totalPlans;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ProgressBarChart(
                              title:
                                  '${slice.teacher.name}${slice.isClassTeacher ? ' (Class Teacher)' : ''}',
                              value: ratio,
                              label:
                                  '${slice.completionPercent}% (${slice.taughtPlans}/${slice.totalPlans} plans · ${slice.lessonsDelivered} lessons · ${slice.assessmentsLogged} assessments)',
                              color: slice.isClassTeacher
                                  ? const Color(0xFF2563EB)
                                  : const Color(0xFF7C3AED),
                            ),
                          ],
                        ),
                      );
                    }),
                ],
              ),
            );
          }),
        ] else if (_segment == 'teachers') ...[
          GranularBarChart(
            title: 'Lessons Delivered vs Assessments Logged per Teacher (Bar Chart)',
            subtitle: 'Cross-classroom instructional output and assessment volume by educator.',
            primaryLabel: 'Lessons Delivered',
            secondaryLabel: 'Assessments Logged',
            primaryColor: const Color(0xFF7C3AED),
            secondaryColor: const Color(0xFF10B981),
            data: teacherMatrix
                .map(
                  (t) => MetricBarDatum(
                    label: t.teacher.name.split(' ').first,
                    primaryValue: t.totalLessonsDelivered.toDouble(),
                    secondaryValue: t.assessmentsLogged.toDouble(),
                  ),
                )
                .toList(),
          ),
          const SizedBox(height: 16),
          ...teacherMatrix.map((t) {
            return Container(
              margin: const EdgeInsets.only(bottom: 14),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Wrap(
                    alignment: WrapAlignment.spaceBetween,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    spacing: 12,
                    runSpacing: 8,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${t.teacher.name} (${t.teacher.subjectSpecialties.join(", ")})',
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '${t.totalLessonsDelivered} lessons delivered · ${t.taughtPlans}/${t.totalPlans} plans taught · ${t.assessmentsLogged} assessments · ${t.diaryEntriesLogged} diary notes',
                            style: const TextStyle(
                              fontSize: 12,
                              color: Color(0xFF64748B),
                            ),
                          ),
                        ],
                      ),
                      if (t.homeroomClassrooms.isNotEmpty)
                        Wrap(
                          spacing: 6,
                          children: t.homeroomClassrooms
                              .map(
                                (hc) => ActionChip(
                                  avatar: const Icon(Icons.star, size: 14, color: Color(0xFF2563EB)),
                                  label: Text(
                                    'Class Teacher: ${hc.name}',
                                    style: const TextStyle(fontSize: 11),
                                  ),
                                  onPressed: () =>
                                      context.go('/classrooms/${hc.id}'),
                                ),
                              )
                              .toList(),
                        ),
                    ],
                  ),
                  const Divider(height: 20),
                  const Text(
                    'Coverage Breakdown by Classroom',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 10),
                  ...t.byClassroom.map((slice) {
                    final ratio = slice.totalPlans == 0
                        ? 0.0
                        : slice.taughtPlans / slice.totalPlans;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: ProgressBarChart(
                        title:
                            '${slice.classroom.name}${slice.isClassTeacher ? ' ★' : ''}',
                        value: ratio,
                        label:
                            '${slice.completionPercent}% (${slice.taughtPlans}/${slice.totalPlans} plans · ${slice.lessonsDelivered} lessons)',
                        color: const Color(0xFF0284C7),
                      ),
                    );
                  }),
                  if (t.lessons.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    const Text(
                      'Lesson Attribution Log (When & Class)',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 6),
                    ...t.lessons.map((lp) {
                      final cls = ecs.classrooms
                          .where((c) => c.id == lp.classroomId)
                          .firstOrNull;
                      final when = lp.taughtAt ?? lp.updatedAt ?? lp.scheduledDate;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 6),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                '${lp.title} · ${cls?.name ?? lp.classroomId} (${lp.status.label}, ${lp.lessonsDelivered}p)',
                                style: const TextStyle(fontSize: 12),
                              ),
                            ),
                            AuditAttributionPill(
                              who: t.teacher.name,
                              when: when.replaceFirst('T', ' '),
                            ),
                          ],
                        ),
                      );
                    }),
                  ],
                ],
              ),
            );
          }),
        ] else if (_segment == 'substrands') ...[
          GranularBarChart(
            title: 'Delivered vs Target Lessons per Substrand (Bar Chart)',
            subtitle: 'Pacing comparison across canonical scheme substrands.',
            primaryLabel: 'Delivered Lessons',
            secondaryLabel: 'Target Lessons',
            primaryColor: const Color(0xFF10B981),
            secondaryColor: const Color(0xFFE2E8F0),
            data: substrandReports
                .map(
                  (r) => MetricBarDatum(
                    label: r.substrand.code,
                    primaryValue: r.deliveredLessons.toDouble(),
                    secondaryValue: r.targetLessons.toDouble(),
                  ),
                )
                .toList(),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Coverage Breakdown by Curriculum Substrand',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                ),
                const Divider(height: 20),
                ...substrandReports.map(
                  (r) => Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: ProgressBarChart(
                      title:
                          '${r.classroom?.gradeLevel ?? 'Class'} · ${r.substrand.code}: ${r.substrand.title}',
                      value: (r.coveragePercent / 100).clamp(0.0, 1.0),
                      label:
                          '${r.coveragePercent}% (${r.deliveredLessons}/${r.targetLessons} lessons)',
                      color: r.coveragePercent >= 100
                          ? const Color(0xFF10B981)
                          : (r.coveragePercent > 0
                              ? const Color(0xFF2563EB)
                              : const Color(0xFF94A3B8)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ] else if (_segment == 'charts') ...[
          _buildSchoolWideCharts(ecs),
        ] else ...[
          _buildAuditTrailSection(ecs),
        ],
      ],
    );
  }

  Widget _buildSchoolWideCharts(SchoolEcsState ecs) {
    final assessments = ecs.assessments;
    var exceeding = 0;
    var meeting = 0;
    var approaching = 0;
    var developing = 0;
    for (final a in assessments) {
      switch (a.mastery.label) {
        case 'Exceeding':
          exceeding++;
          break;
        case 'Meeting':
          meeting++;
          break;
        case 'Approaching':
          approaching++;
          break;
        case 'Developing':
          developing++;
          break;
      }
    }

    final candles = SyllabusCoverageSystem.buildScoreCandlesticks(
      ecs,
      ecs.assessments,
    );
    final sortedAssessments = [...ecs.assessments]
      ..sort((a, b) => a.date.compareTo(b.date));
    final trendPoints = sortedAssessments
        .map(
          (a) => TrendPoint(
            label: a.date.length >= 10 ? a.date.substring(5) : a.date,
            value: a.scorePercent.toDouble(),
          ),
        )
        .toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        LayoutBuilder(
          builder: (ctx, constraints) {
            final isWide = constraints.maxWidth >= 820;
            final pie = MasteryBreakdownChart(
              title: 'School-Wide Assessment Mastery (Pie Chart)',
              exceedingCount: exceeding,
              meetingCount: meeting,
              approachingCount: approaching,
              developingCount: developing,
            );
            final candle = ScoreCandlestickChart(
              title: 'Subject Score Open-Close & Range (Candlestick Chart)',
              subtitle: 'Open = earliest assessment, Close = latest score, Wick = Min to Max.',
              candles: candles,
            );
            if (isWide) {
              return Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(child: pie),
                  const SizedBox(width: 16),
                  Expanded(child: candle),
                ],
              );
            }
            return Column(
              children: [pie, const SizedBox(height: 16), candle],
            );
          },
        ),
        const SizedBox(height: 16),
        MetricTrendLineChart(
          title: 'School-Wide Score Trajectory Over Time (Line Chart)',
          subtitle: 'Chronological assessment scores across all learners and subjects.',
          points: trendPoints,
          lineColor: const Color(0xFF4F46E5),
        ),
      ],
    );
  }

  Widget _buildAuditTrailSection(SchoolEcsState ecs) {
    final logs = ecs.auditLogs;
    final filtered = logs.where((entry) {
      final matchesRole =
          _auditRoleFilter == 'all' || entry.actorRole == _auditRoleFilter;
      final q = _auditQuery.trim().toLowerCase();
      final matchesQuery = q.isEmpty ||
          entry.actorName.toLowerCase().contains(q) ||
          entry.targetLabel.toLowerCase().contains(q) ||
          entry.detail.toLowerCase().contains(q) ||
          entry.entityType.toLowerCase().contains(q);
      return matchesRole && matchesQuery;
    }).toList();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 12,
            runSpacing: 10,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Who & When Audit Log',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                  ),
                  Text(
                    'Tracks every lesson taught, class assignment, assessment, diary sign-off, and roll call.',
                    style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                  ),
                ],
              ),
              SizedBox(
                width: 240,
                child: TextField(
                  decoration: const InputDecoration(
                    hintText: 'Filter by person, class, entity...',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  onChanged: (val) => setState(() => _auditQuery = val),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: [
              for (final roleKey in ['all', 'admin', 'teacher', 'parent'])
                ChoiceChip(
                  label: Text(
                    roleKey == 'all' ? 'All Actors' : roleKey.toUpperCase(),
                    style: const TextStyle(fontSize: 11),
                  ),
                  selected: _auditRoleFilter == roleKey,
                  onSelected: (_) =>
                      setState(() => _auditRoleFilter = roleKey),
                ),
            ],
          ),
          const Divider(height: 22),
          if (filtered.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Text(
                'No matching audit records found.',
                style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
              ),
            )
          else
            ...filtered.map(
              (log) => Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8FAFC),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFFE2E8F0)),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: log.actorRole == 'admin'
                            ? const Color(0xFFE0E7FF)
                            : (log.actorRole == 'teacher'
                                ? const Color(0xFFD1FAE5)
                                : const Color(0xFFFEF3C7)),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        log.actorRole.toUpperCase(),
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: log.actorRole == 'admin'
                              ? const Color(0xFF3730A3)
                              : (log.actorRole == 'teacher'
                                  ? const Color(0xFF065F46)
                                  : const Color(0xFF92400E)),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${log.actorName} ${log.action} ${log.entityType.replaceAll('_', ' ')} · ${log.targetLabel}',
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFF0F172A),
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            log.detail,
                            style: const TextStyle(
                              fontSize: 12,
                              color: Color(0xFF475569),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      log.timestamp.replaceFirst('T', ' '),
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF64748B),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 12, color: Color(0xFF64748B))),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
