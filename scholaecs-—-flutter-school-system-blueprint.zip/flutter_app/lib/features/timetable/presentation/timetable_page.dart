import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/ecs/ecs_providers.dart';
import '../../../core/ecs/ecs_seed_data.dart';
import '../../../core/ecs/school_entity.dart';
import '../../auth/data/firebase_auth_repository.dart';
import '../../lesson_plans/domain/lesson_plan.dart';
import '../domain/timetable_slot.dart';

enum _TimetableViewMode { classView, allClassesMatrix }

class TimetablePage extends ConsumerStatefulWidget {
  const TimetablePage({super.key});

  @override
  ConsumerState<TimetablePage> createState() => _TimetablePageState();
}

class _TimetablePageState extends ConsumerState<TimetablePage> {
  String _classroomId = 'cls_5a';
  _TimetableViewMode _viewMode = _TimetableViewMode.classView;

  Future<void> _openSlotDialog(TimetableSlotEntity slot, PortalRole role) async {
    final isAdmin = role == PortalRole.admin;
    final canEditStatus = isAdmin || role == PortalRole.teacher;

    await showDialog<void>(
      context: context,
      builder: (dialogCtx) => Consumer(
        builder: (ctx, modalRef, _) {
          final ecs = modalRef.watch(schoolEcsProvider);
          final liveSlot =
              ecs.timetableSlots.where((s) => s.id == slot.id).firstOrNull ?? slot;
          final classroom =
              ecs.classrooms.where((c) => c.id == liveSlot.classroomId).firstOrNull;
          final subj =
              ecs.subjects.where((s) => s.id == liveSlot.subjectId).firstOrNull;
          final teacher =
              ecs.teachers.where((t) => t.id == liveSlot.teacherId).firstOrNull;
          final plan = ecs.lessonPlans
              .where(
                (lp) =>
                    lp.id == liveSlot.lessonPlanId ||
                    lp.timetableSlotId == liveSlot.id,
              )
              .firstOrNull;
          final sub = plan == null
              ? null
              : ecs.substrands.where((s) => s.id == plan.substrandId).firstOrNull;
          final candidatePlans = ecs.lessonPlans
              .where(
                (lp) =>
                    lp.timetableSlotId == null ||
                    lp.timetableSlotId!.isEmpty ||
                    lp.timetableSlotId == liveSlot.id,
              )
              .toList();

          return AlertDialog(
            title: Text(
              '${liveSlot.day} Period ${liveSlot.period} · ${subj?.name ?? ''}',
            ),
            content: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${classroom?.name ?? liveSlot.classroomId} · ${liveSlot.timeRange} · Room ${liveSlot.room}',
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Teacher: ${teacher?.name ?? ''}',
                      style: const TextStyle(fontSize: 12, color: Color(0xFF475569)),
                    ),
                    const Divider(height: 22),
                    if (plan == null)
                      const Text(
                        'No registered Lesson Plan bound to this period yet.',
                        style: TextStyle(color: Color(0xFF64748B)),
                      )
                    else ...[
                      Text(
                        'Substrand: ${sub?.code ?? ''} ${sub?.title ?? ''}',
                        style: const TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        plan.title,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                      ),
                      if (plan.reflectionNote.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(plan.reflectionNote, style: const TextStyle(fontSize: 12)),
                      ],
                      const SizedBox(height: 10),
                      Text(
                        'Status: ${plan.status.label} (${plan.lessonsDelivered}/${sub?.targetLessons ?? 1})',
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                      if (canEditStatus) ...[
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: LessonStatus.values.map((st) {
                            return ChoiceChip(
                              label: Text(st.label),
                              selected: plan.status == st,
                              onSelected: (_) {
                                final delivered = st == LessonStatus.taught
                                    ? (plan.lessonsDelivered < 2
                                        ? 2
                                        : plan.lessonsDelivered)
                                    : st == LessonStatus.inProgress
                                        ? (plan.lessonsDelivered < 1
                                            ? 1
                                            : plan.lessonsDelivered)
                                        : 0;
                                modalRef
                                    .read(schoolEcsProvider.notifier)
                                    .updateLessonPlanStatus(plan.id, st, delivered);
                              },
                            );
                          }).toList(),
                        ),
                      ],
                    ],
                    if (isAdmin) ...[
                      const Divider(height: 24),
                      DropdownButtonFormField<String>(
                        value: plan?.id ?? '',
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'Bind / Swap Registered Lesson',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                        items: [
                          const DropdownMenuItem(
                            value: '',
                            child: Text(
                              'Unbound (Keep Slot Open)',
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          ...candidatePlans.map((lp) {
                            final lpSubj = ecs.subjects
                                .where((s) => s.id == lp.subjectId)
                                .firstOrNull;
                            return DropdownMenuItem(
                              value: lp.id,
                              child: Text(
                                '${lp.title} (${lpSubj?.code ?? ''})',
                                overflow: TextOverflow.ellipsis,
                              ),
                            );
                          }),
                        ],
                        onChanged: (nextPlanId) async {
                          if (nextPlanId == null) return;
                          final notifier =
                              modalRef.read(schoolEcsProvider.notifier);
                          if (nextPlanId.isEmpty) {
                            if (plan != null) {
                              await notifier.assignLessonToTimetableSlot(
                                lessonPlanId: plan.id,
                                timetableSlotId: null,
                              );
                            }
                          } else {
                            final err = await notifier.assignLessonToTimetableSlot(
                              lessonPlanId: nextPlanId,
                              timetableSlotId: liveSlot.id,
                              syncSlotSubjectAndTeacher: true,
                            );
                            if (err != null && ctx.mounted) {
                              ScaffoldMessenger.of(ctx).showSnackBar(
                                SnackBar(content: Text(err)),
                              );
                            }
                          }
                        },
                      ),
                    ],
                  ],
                ),
              ),
            ),
            actions: [
              if (isAdmin) ...[
                TextButton(
                  style: TextButton.styleFrom(
                    foregroundColor: const Color(0xFFDC2626),
                  ),
                  onPressed: () async {
                    Navigator.of(dialogCtx).pop();
                    await ref
                        .read(schoolEcsProvider.notifier)
                        .deleteTimetableSlot(liveSlot.id);
                  },
                  child: const Text('Delete Slot'),
                ),
                OutlinedButton(
                  onPressed: () {
                    Navigator.of(dialogCtx).pop();
                    _openSlotEditorDialog(existing: liveSlot);
                  },
                  child: const Text('Edit Slot'),
                ),
              ],
              FilledButton(
                onPressed: () => Navigator.of(dialogCtx).pop(),
                child: const Text('Close'),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _openSlotEditorDialog({
    TimetableSlotEntity? existing,
    String? presetClassroomId,
    String? presetDay,
    LessonPlanEntity? presetLesson,
  }) async {
    final ecs = ref.read(schoolEcsProvider);
    final notifier = ref.read(schoolEcsProvider.notifier);
    if (ecs.subjects.isEmpty || ecs.teachers.isEmpty || ecs.classrooms.isEmpty) {
      return;
    }

    var classroomId = existing?.classroomId ??
        presetLesson?.classroomId ??
        presetClassroomId ??
        _classroomId;
    if (!ecs.classrooms.any((c) => c.id == classroomId)) {
      classroomId = ecs.classrooms.first.id;
    }

    var mappedDays = notifier.scheduleDaysForClassroom(classroomId);
    final allDays = mappedDays.isNotEmpty ? mappedDays : ecs.scheduleDays;
    var day = existing?.day ??
        presetDay ??
        (allDays.isNotEmpty ? allDays.first.code : 'Mon');

    var selectedLessonId = existing?.lessonPlanId ??
        ecs.lessonPlans
            .where((lp) => lp.timetableSlotId == existing?.id)
            .firstOrNull
            ?.id ??
        presetLesson?.id ??
        '';

    var subjectId = existing?.subjectId ??
        presetLesson?.subjectId ??
        ecs.subjects.first.id;
    var teacherId = existing?.teacherId ??
        presetLesson?.teacherId ??
        ecs.teachers.first.id;
    var period = existing?.period ?? 1;

    final classRoomObj =
        ecs.classrooms.where((c) => c.id == classroomId).firstOrNull;
    final defaultDayObj =
        ecs.scheduleDays.where((d) => d.code == day).firstOrNull;

    final timeCtrl = TextEditingController(
      text: existing?.timeRange ??
          defaultDayObj?.defaultTimeRange ??
          '08:00 - 08:45',
    );
    final roomCtrl = TextEditingController(
      text: existing?.room ?? classRoomObj?.roomCode ?? 'B2-04',
    );
    String? error;

    await showDialog<void>(
      context: context,
      builder: (dialogCtx) => StatefulBuilder(
        builder: (ctx, setModalState) {
          final currentMapped = notifier.scheduleDaysForClassroom(classroomId);
          final selectableDays =
              currentMapped.isNotEmpty ? currentMapped : ecs.scheduleDays;
          final dayValue = selectableDays.any((d) => d.code == day)
              ? day
              : (selectableDays.isNotEmpty ? selectableDays.first.code : day);

          return AlertDialog(
            title: Text(
              existing == null ? 'Add Timetable Slot' : 'Edit Timetable Slot',
            ),
            content: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 500),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    DropdownButtonFormField<String>(
                      value: classroomId,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Classroom',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      items: ecs.classrooms
                          .map(
                            (c) => DropdownMenuItem(
                              value: c.id,
                              child: Text(
                                '${c.name} (${c.roomCode})',
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (v) {
                        if (v == null) return;
                        setModalState(() {
                          classroomId = v;
                          final nextDays = notifier.scheduleDaysForClassroom(v);
                          if (nextDays.isNotEmpty &&
                              !nextDays.any((d) => d.code == day)) {
                            day = nextDays.first.code;
                            if (existing == null) {
                              timeCtrl.text = nextDays.first.defaultTimeRange;
                            }
                          }
                          if (existing == null) {
                            final cObj = ecs.classrooms
                                .where((c) => c.id == v)
                                .firstOrNull;
                            if (cObj != null) roomCtrl.text = cObj.roomCode;
                          }
                        });
                      },
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: selectedLessonId,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Assign Registered Lesson (optional)',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      items: [
                        const DropdownMenuItem(
                          value: '',
                          child: Text(
                            'None (Custom Subject / Teacher Only)',
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        ...ecs.lessonPlans.map((lp) {
                          final subj = ecs.subjects
                              .where((s) => s.id == lp.subjectId)
                              .firstOrNull;
                          final tag =
                              (lp.timetableSlotId?.trim().isNotEmpty ?? false)
                                  ? 'Assigned'
                                  : 'Unassigned';
                          return DropdownMenuItem(
                            value: lp.id,
                            child: Text(
                              '[$tag] ${lp.title} · ${subj?.code ?? ''}',
                              overflow: TextOverflow.ellipsis,
                            ),
                          );
                        }),
                      ],
                      onChanged: (v) {
                        if (v == null) return;
                        setModalState(() {
                          selectedLessonId = v;
                          if (v.isNotEmpty) {
                            final picked = ecs.lessonPlans
                                .where((lp) => lp.id == v)
                                .firstOrNull;
                            if (picked != null) {
                              subjectId = picked.subjectId;
                              teacherId = picked.teacherId;
                            }
                          }
                        });
                      },
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: dayValue,
                            isExpanded: true,
                            decoration: InputDecoration(
                              labelText: currentMapped.isNotEmpty
                                  ? 'Mapped Day'
                                  : 'Day (Unmapped)',
                              border: const OutlineInputBorder(),
                              isDense: true,
                            ),
                            items: selectableDays
                                .map(
                                  (d) => DropdownMenuItem(
                                    value: d.code,
                                    child: Text(
                                      '${d.code} — ${d.label}',
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                )
                                .toList(),
                            onChanged: (v) {
                              if (v != null) {
                                setModalState(() {
                                  day = v;
                                  final matched = selectableDays
                                      .where((d) => d.code == v)
                                      .firstOrNull;
                                  if (existing == null && matched != null) {
                                    timeCtrl.text = matched.defaultTimeRange;
                                  }
                                });
                              }
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: DropdownButtonFormField<int>(
                            value: period,
                            isExpanded: true,
                            decoration: const InputDecoration(
                              labelText: 'Period',
                              border: OutlineInputBorder(),
                              isDense: true,
                            ),
                            items: const [1, 2, 3, 4, 5, 6, 7, 8]
                                .map(
                                  (p) => DropdownMenuItem(
                                    value: p,
                                    child: Text('Period $p'),
                                  ),
                                )
                                .toList(),
                            onChanged: (v) {
                              if (v != null) setModalState(() => period = v);
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: subjectId,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Subject',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      items: ecs.subjects
                          .map(
                            (s) => DropdownMenuItem(
                              value: s.id,
                              child: Text(
                                s.name,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (v) {
                        if (v != null) setModalState(() => subjectId = v);
                      },
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: teacherId,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Assigned Teacher',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      items: ecs.teachers
                          .map(
                            (t) => DropdownMenuItem(
                              value: t.id,
                              child: Text(
                                t.name,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (v) {
                        if (v != null) setModalState(() => teacherId = v);
                      },
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: TextField(
                            controller: timeCtrl,
                            decoration: const InputDecoration(
                              labelText: 'Time Range (HH:MM - HH:MM) *',
                              border: OutlineInputBorder(),
                              isDense: true,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          flex: 1,
                          child: TextField(
                            controller: roomCtrl,
                            decoration: const InputDecoration(
                              labelText: 'Room *',
                              border: OutlineInputBorder(),
                              isDense: true,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: const [
                        '08:00 - 08:45',
                        '08:50 - 09:35',
                        '09:45 - 10:30',
                        '11:00 - 11:45',
                      ]
                          .map(
                            (preset) => ActionChip(
                              label: Text(preset, style: const TextStyle(fontSize: 11)),
                              onPressed: () {
                                timeCtrl.text = preset;
                              },
                            ),
                          )
                          .toList(),
                    ),
                    if (error != null) ...[
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFEF2F2),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: const Color(0xFFFECACA)),
                        ),
                        child: Text(
                          error!,
                          style: const TextStyle(
                            color: Color(0xFFB91C1C),
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            actions: [
              if (existing != null)
                TextButton(
                  style: TextButton.styleFrom(
                    foregroundColor: const Color(0xFFDC2626),
                  ),
                  onPressed: () async {
                    Navigator.of(dialogCtx).pop();
                    await notifier.deleteTimetableSlot(existing.id);
                  },
                  child: const Text('Delete'),
                ),
              TextButton(
                onPressed: () => Navigator.of(dialogCtx).pop(),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () async {
                  final slot = TimetableSlotEntity(
                    id: existing?.id ?? 'tt_${DateTime.now().millisecondsSinceEpoch}',
                    classroomId: classroomId,
                    subjectId: subjectId,
                    teacherId: teacherId,
                    day: dayValue,
                    period: period,
                    timeRange: timeCtrl.text.trim(),
                    room: roomCtrl.text.trim(),
                    lessonPlanId:
                        selectedLessonId.isEmpty ? null : selectedLessonId,
                  );
                  final conflictError = await notifier.upsertTimetableSlot(
                    slot,
                    ignoreSlotId: existing?.id,
                    syncLessonBinding: true,
                  );
                  if (conflictError != null) {
                    setModalState(() => error = conflictError);
                    return;
                  }
                  if (dialogCtx.mounted) Navigator.of(dialogCtx).pop();
                },
                child: Text(existing == null ? 'Save Slot' : 'Update Slot'),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _openManageDaysDialog() async {
    final notifier = ref.read(schoolEcsProvider.notifier);
    String? editingDayId;
    final codeCtrl = TextEditingController();
    final labelCtrl = TextEditingController();
    final orderCtrl = TextEditingController(
      text: '${ref.read(schoolEcsProvider).scheduleDays.length + 1}',
    );
    final defaultTimeCtrl = TextEditingController(text: '09:00 - 09:45');
    var selectedClasses = ref
        .read(schoolEcsProvider)
        .classrooms
        .map((c) => c.id)
        .toList();
    String? error;

    await showDialog<void>(
      context: context,
      builder: (dialogCtx) => Consumer(
        builder: (ctx, modalRef, _) {
          final ecs = modalRef.watch(schoolEcsProvider);
          final sortedDays = [...ecs.scheduleDays]
            ..sort((a, b) => a.order.compareTo(b.order));

          return StatefulBuilder(
            builder: (innerCtx, setModalState) => AlertDialog(
              title: const Text('Manage Schedule Days & Class Mapping'),
              content: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 600),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text(
                        'Add school days (e.g. Sat Clinic, Block Day) and toggle which classes come on each day.',
                        style: TextStyle(fontSize: 12, color: Color(0xFF475569)),
                      ),
                      const SizedBox(height: 12),
                      ...sortedDays.map((day) {
                        return Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF8FAFC),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: const Color(0xFFE2E8F0)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      '#${day.order} · ${day.code} — ${day.label} (${day.defaultTimeRange})',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ),
                                  IconButton(
                                    tooltip: 'Edit Day',
                                    icon: const Icon(Icons.edit_outlined, size: 17),
                                    onPressed: () {
                                      setModalState(() {
                                        editingDayId = day.id;
                                        codeCtrl.text = day.code;
                                        labelCtrl.text = day.label;
                                        orderCtrl.text = '${day.order}';
                                        defaultTimeCtrl.text = day.defaultTimeRange;
                                        selectedClasses = [...day.classroomIds];
                                        error = null;
                                      });
                                    },
                                  ),
                                  IconButton(
                                    tooltip: 'Delete Day',
                                    icon: const Icon(
                                      Icons.delete_outline,
                                      size: 17,
                                      color: Color(0xFFDC2626),
                                    ),
                                    onPressed: () async {
                                      await notifier.deleteScheduleDay(day.id);
                                      if (editingDayId == day.id) {
                                        setModalState(() {
                                          editingDayId = null;
                                          codeCtrl.clear();
                                          labelCtrl.clear();
                                        });
                                      }
                                    },
                                  ),
                                ],
                              ),
                              const SizedBox(height: 6),
                              Wrap(
                                spacing: 6,
                                runSpacing: 6,
                                children: ecs.classrooms.map((cls) {
                                  final isMapped =
                                      day.classroomIds.contains(cls.id);
                                  return FilterChip(
                                    label: Text(
                                      cls.name,
                                      style: const TextStyle(fontSize: 11),
                                    ),
                                    selected: isMapped,
                                    onSelected: (_) => notifier
                                        .toggleDayClassroomMapping(day.id, cls.id),
                                  );
                                }).toList(),
                              ),
                            ],
                          ),
                        );
                      }),
                      const Divider(height: 24),
                      Text(
                        editingDayId == null
                            ? 'Add New Schedule Day'
                            : 'Editing Schedule Day',
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            flex: 1,
                            child: TextField(
                              controller: codeCtrl,
                              decoration: const InputDecoration(
                                labelText: 'Code (e.g. Sat) *',
                                border: OutlineInputBorder(),
                                isDense: true,
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            flex: 2,
                            child: TextField(
                              controller: labelCtrl,
                              decoration: const InputDecoration(
                                labelText: 'Full Label (e.g. Saturday Clinic)',
                                border: OutlineInputBorder(),
                                isDense: true,
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            flex: 1,
                            child: TextField(
                              controller: orderCtrl,
                              keyboardType: TextInputType.number,
                              decoration: const InputDecoration(
                                labelText: 'Order',
                                border: OutlineInputBorder(),
                                isDense: true,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: defaultTimeCtrl,
                        decoration: const InputDecoration(
                          labelText: 'Default Period Time (HH:MM - HH:MM)',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'Map to Classrooms:',
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 6),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: ecs.classrooms.map((cls) {
                          final active = selectedClasses.contains(cls.id);
                          return FilterChip(
                            label: Text(cls.name, style: const TextStyle(fontSize: 11)),
                            selected: active,
                            onSelected: (checked) {
                              setModalState(() {
                                if (checked) {
                                  if (!selectedClasses.contains(cls.id)) {
                                    selectedClasses.add(cls.id);
                                  }
                                } else {
                                  selectedClasses.remove(cls.id);
                                }
                              });
                            },
                          );
                        }).toList(),
                      ),
                      if (error != null) ...[
                        const SizedBox(height: 8),
                        Text(
                          error!,
                          style: const TextStyle(
                            color: Color(0xFFB91C1C),
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          FilledButton.icon(
                            onPressed: () async {
                              final dayEntity = ScheduleDayEntity(
                                id: editingDayId ??
                                    'day_${DateTime.now().millisecondsSinceEpoch}',
                                code: codeCtrl.text.trim(),
                                label: labelCtrl.text.trim(),
                                order: int.tryParse(orderCtrl.text) ??
                                    (ecs.scheduleDays.length + 1),
                                classroomIds: [...selectedClasses],
                                defaultTimeRange: defaultTimeCtrl.text.trim().isEmpty
                                    ? '08:00 - 08:45'
                                    : defaultTimeCtrl.text.trim(),
                              );
                              final err = await notifier.upsertScheduleDay(dayEntity);
                              if (err != null) {
                                setModalState(() => error = err);
                                return;
                              }
                              setModalState(() {
                                editingDayId = null;
                                codeCtrl.clear();
                                labelCtrl.clear();
                                orderCtrl.text =
                                    '${ref.read(schoolEcsProvider).scheduleDays.length + 1}';
                                error = null;
                              });
                            },
                            icon: const Icon(Icons.save_outlined, size: 16),
                            label: Text(
                              editingDayId == null ? 'Add Schedule Day' : 'Save Day',
                            ),
                          ),
                          if (editingDayId != null)
                            OutlinedButton(
                              onPressed: () {
                                setModalState(() {
                                  editingDayId = null;
                                  codeCtrl.clear();
                                  labelCtrl.clear();
                                  error = null;
                                });
                              },
                              child: const Text('Cancel Edit'),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                FilledButton(
                  onPressed: () => Navigator.of(dialogCtx).pop(),
                  child: const Text('Done'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<void> _openCreateClassDialog() async {
    final ecs = ref.read(schoolEcsProvider);
    final notifier = ref.read(schoolEcsProvider.notifier);
    final nameCtrl = TextEditingController();
    final gradeCtrl = TextEditingController();
    final roomCtrl = TextEditingController();
    String? classTeacherId =
        ecs.teachers.isNotEmpty ? ecs.teachers.first.id : null;
    final selectedDayIds = ecs.scheduleDays.map((d) => d.id).toSet();
    String? error;

    await showDialog<void>(
      context: context,
      builder: (dialogCtx) => StatefulBuilder(
        builder: (ctx, setModalState) => AlertDialog(
          title: const Text('Add Classroom & Map Schedule Days'),
          content: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  TextField(
                    controller: nameCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Classroom Name (e.g. Grade 7A — Cedar) *',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: gradeCtrl,
                          decoration: const InputDecoration(
                            labelText: 'Grade Level *',
                            border: OutlineInputBorder(),
                            isDense: true,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextField(
                          controller: roomCtrl,
                          decoration: const InputDecoration(
                            labelText: 'Home Room *',
                            border: OutlineInputBorder(),
                            isDense: true,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String?>(
                    value: classTeacherId,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Class Teacher',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    items: [
                      const DropdownMenuItem<String?>(
                        value: null,
                        child: Text('Unassigned', overflow: TextOverflow.ellipsis),
                      ),
                      ...ecs.teachers.map(
                        (t) => DropdownMenuItem<String?>(
                          value: t.id,
                          child: Text(t.name, overflow: TextOverflow.ellipsis),
                        ),
                      ),
                    ],
                    onChanged: (val) =>
                        setModalState(() => classTeacherId = val),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Active School Days for this Class:',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: ecs.scheduleDays.map((d) {
                      final active = selectedDayIds.contains(d.id);
                      return FilterChip(
                        label: Text('${d.code} (${d.label})'),
                        selected: active,
                        onSelected: (checked) {
                          setModalState(() {
                            if (checked) {
                              selectedDayIds.add(d.id);
                            } else {
                              selectedDayIds.remove(d.id);
                            }
                          });
                        },
                      );
                    }).toList(),
                  ),
                  if (error != null) ...[
                    const SizedBox(height: 8),
                    Text(
                      error!,
                      style: const TextStyle(
                        color: Color(0xFFB91C1C),
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogCtx).pop(),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () async {
                final newClass = ClassroomEntity(
                  id: 'cls_${DateTime.now().millisecondsSinceEpoch}',
                  name: nameCtrl.text.trim(),
                  gradeLevel: gradeCtrl.text.trim(),
                  roomCode: roomCtrl.text.trim(),
                  classTeacherId: classTeacherId,
                );
                final err = await notifier.upsertClassroom(
                  newClass,
                  mapDayIds: selectedDayIds.toList(),
                );
                if (err != null) {
                  setModalState(() => error = err);
                  return;
                }
                if (mounted) {
                  setState(() => _classroomId = newClass.id);
                }
                if (dialogCtx.mounted) Navigator.of(dialogCtx).pop();
              },
              child: const Text('Create Classroom'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(currentUserProvider).valueOrNull;
    final role = user?.role ?? PortalRole.admin;
    final isAdmin = role == PortalRole.admin;
    final ecs = ref.watch(schoolEcsProvider);
    final notifier = ref.read(schoolEcsProvider.notifier);

    if (!ecs.classrooms.any((c) => c.id == _classroomId) &&
        ecs.classrooms.isNotEmpty) {
      _classroomId = ecs.classrooms.first.id;
    }

    final mappedDays = notifier.scheduleDaysForClassroom(_classroomId);
    final slots =
        ecs.timetableSlots.where((s) => s.classroomId == _classroomId).toList();
    final unassignedLessons = ecs.lessonPlans
        .where((lp) => lp.timetableSlotId == null || lp.timetableSlotId!.isEmpty)
        .toList();

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Wrap(
          alignment: WrapAlignment.spaceBetween,
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: 12,
          runSpacing: 12,
          children: [
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Weekly Timetable & Class Days',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                ),
                Text(
                  'Admin controls schedule days per class, slot CRUD, teacher times, and registered lesson bindings.',
                  style: TextStyle(fontSize: 13, color: Color(0xFF475569)),
                ),
              ],
            ),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                ChoiceChip(
                  label: const Text('Class View'),
                  selected: _viewMode == _TimetableViewMode.classView,
                  onSelected: (_) =>
                      setState(() => _viewMode = _TimetableViewMode.classView),
                ),
                ChoiceChip(
                  label: const Text('All Classes Active'),
                  selected: _viewMode == _TimetableViewMode.allClassesMatrix,
                  onSelected: (_) => setState(
                      () => _viewMode = _TimetableViewMode.allClassesMatrix),
                ),
                if (_viewMode == _TimetableViewMode.classView)
                  ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 210),
                    child: DropdownButtonFormField<String>(
                      value: _classroomId,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      items: ecs.classrooms
                          .map(
                            (c) => DropdownMenuItem(
                              value: c.id,
                              child: Text(
                                c.name,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (v) {
                        if (v != null) setState(() => _classroomId = v);
                      },
                    ),
                  ),
                if (isAdmin) ...[
                  OutlinedButton.icon(
                    onPressed: _openManageDaysDialog,
                    icon: const Icon(Icons.date_range_outlined, size: 16),
                    label: const Text('Manage Days'),
                  ),
                  OutlinedButton.icon(
                    onPressed: _openCreateClassDialog,
                    icon: const Icon(Icons.meeting_room_outlined, size: 16),
                    label: const Text('Add Class'),
                  ),
                  FilledButton.icon(
                    onPressed: () => _openSlotEditorDialog(),
                    icon: const Icon(Icons.add, size: 16),
                    label: const Text('Add Slot'),
                  ),
                ],
              ],
            ),
          ],
        ),
        const SizedBox(height: 16),
        if (_viewMode == _TimetableViewMode.allClassesMatrix)
          _buildAllClassesMatrix(ecs, isAdmin)
        else ...[
          if (mappedDays.isEmpty)
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: const Text(
                'No schedule days are mapped to this classroom yet. Click "Manage Days" to map school days.',
                style: TextStyle(color: Color(0xFF64748B)),
              ),
            )
          else
            ...mappedDays.map((day) {
              final daySlots = slots
                  .where((s) => s.day.toLowerCase() == day.code.toLowerCase())
                  .toList()
                ..sort((a, b) => a.period.compareTo(b.period));

              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFE2E8F0)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            '${day.label} (${day.code}) · Default ${day.defaultTimeRange}',
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        if (isAdmin)
                          TextButton.icon(
                            onPressed: () => _openSlotEditorDialog(
                              presetClassroomId: _classroomId,
                              presetDay: day.code,
                            ),
                            icon: const Icon(Icons.add, size: 15),
                            label: Text('Add ${day.code} Slot'),
                          ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (daySlots.isEmpty)
                      const Text(
                        'No periods scheduled yet.',
                        style: TextStyle(fontSize: 12, color: Color(0xFF94A3B8)),
                      )
                    else
                      Wrap(
                        spacing: 10,
                        runSpacing: 10,
                        children: daySlots.map((slot) {
                          final subj = ecs.subjects
                              .where((s) => s.id == slot.subjectId)
                              .firstOrNull;
                          final tch = ecs.teachers
                              .where((t) => t.id == slot.teacherId)
                              .firstOrNull;
                          final plan = ecs.lessonPlans
                              .where(
                                (lp) =>
                                    lp.id == slot.lessonPlanId ||
                                    lp.timetableSlotId == slot.id,
                              )
                              .firstOrNull;
                          return InkWell(
                            onTap: () => _openSlotDialog(slot, role),
                            borderRadius: BorderRadius.circular(10),
                            child: Container(
                              width: 245,
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: const Color(0xFFF8FAFC),
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  color: plan != null
                                      ? const Color(0xFFBFDBFE)
                                      : const Color(0xFFE2E8F0),
                                ),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'P${slot.period} · ${slot.timeRange}',
                                    style: const TextStyle(
                                      fontSize: 11,
                                      color: Color(0xFF64748B),
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    subj?.name ?? '',
                                    style: const TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  Text(
                                    '${tch?.name ?? ''} · Room ${slot.room}',
                                    style: const TextStyle(
                                      fontSize: 12,
                                      color: Color(0xFF475569),
                                    ),
                                  ),
                                  if (plan != null) ...[
                                    const Divider(height: 14),
                                    Text(
                                      '${plan.title} (${plan.status.label})',
                                      style: const TextStyle(
                                        fontSize: 11,
                                        color: Color(0xFF1D4ED8),
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                  ],
                ),
              );
            }),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Unassigned Registered Lessons (${unassignedLessons.length})',
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Lessons registered in the Lessons Registry that have not yet been placed onto a Timetable slot.',
                  style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                ),
                const SizedBox(height: 12),
                if (unassignedLessons.isEmpty)
                  const Text(
                    'All registered lessons are currently assigned to Timetable slots.',
                    style: TextStyle(fontSize: 12, color: Color(0xFF047857)),
                  )
                else
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: unassignedLessons.map((plan) {
                      final cls = ecs.classrooms
                          .where((c) => c.id == plan.classroomId)
                          .firstOrNull;
                      final subj = ecs.subjects
                          .where((s) => s.id == plan.subjectId)
                          .firstOrNull;
                      final tch = ecs.teachers
                          .where((t) => t.id == plan.teacherId)
                          .firstOrNull;
                      return ConstrainedBox(
                        constraints: const BoxConstraints(minWidth: 250, maxWidth: 320),
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFFFBEB),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: const Color(0xFFFDE68A)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '${cls?.name ?? plan.classroomId} · ${subj?.code ?? ''}',
                                style: const TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  color: Color(0xFFB45309),
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                plan.title,
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              Text(
                                'Teacher: ${tch?.name ?? ''}',
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: Color(0xFF475569),
                                ),
                              ),
                              if (isAdmin) ...[
                                const SizedBox(height: 8),
                                FilledButton.tonalIcon(
                                  onPressed: () =>
                                      _openSlotEditorDialog(presetLesson: plan),
                                  icon: const Icon(Icons.schedule, size: 15),
                                  label: const Text('Assign to Slot'),
                                ),
                              ],
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  ),
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildAllClassesMatrix(SchoolEcsState ecs, bool isAdmin) {
    final notifier = ref.read(schoolEcsProvider.notifier);
    final days = [...ecs.scheduleDays]
      ..sort((a, b) => a.order.compareTo(b.order));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: days.map((day) {
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${day.label} (${day.code}) — Classes Active & Teacher Schedule',
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: ecs.classrooms.map((cls) {
                  final classIsOn = day.classroomIds.contains(cls.id);
                  final dayClassSlots = ecs.timetableSlots
                      .where(
                        (s) =>
                            s.classroomId == cls.id &&
                            s.day.toLowerCase() == day.code.toLowerCase(),
                      )
                      .toList()
                    ..sort((a, b) => a.period.compareTo(b.period));

                  return ConstrainedBox(
                    constraints: const BoxConstraints(minWidth: 260, maxWidth: 340),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: classIsOn
                            ? const Color(0xFFF8FAFC)
                            : const Color(0xFFF1F5F9),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: classIsOn
                              ? const Color(0xFFBBF7D0)
                              : const Color(0xFFE2E8F0),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  cls.name,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 2,
                                ),
                                decoration: BoxDecoration(
                                  color: classIsOn
                                      ? const Color(0xFFDCFCE7)
                                      : const Color(0xFFE2E8F0),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  classIsOn ? 'Class ON' : 'Off Day',
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: classIsOn
                                        ? const Color(0xFF166534)
                                        : const Color(0xFF475569),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          if (!classIsOn)
                            if (isAdmin)
                              OutlinedButton(
                                onPressed: () => notifier
                                    .toggleDayClassroomMapping(day.id, cls.id),
                                child: const Text('Turn Class On'),
                              )
                            else
                              const Text(
                                'Not scheduled on this day.',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Color(0xFF64748B),
                                ),
                              )
                          else if (dayClassSlots.isEmpty) ...[
                            const Text(
                              'Class is ON — no periods placed yet.',
                              style: TextStyle(
                                fontSize: 12,
                                color: Color(0xFF64748B),
                              ),
                            ),
                            if (isAdmin) ...[
                              const SizedBox(height: 6),
                              TextButton.icon(
                                onPressed: () => _openSlotEditorDialog(
                                  presetClassroomId: cls.id,
                                  presetDay: day.code,
                                ),
                                icon: const Icon(Icons.add, size: 15),
                                label: const Text('Add Slot'),
                              ),
                            ],
                          ] else ...[
                            ...dayClassSlots.map((sl) {
                              final subj = ecs.subjects
                                  .where((s) => s.id == sl.subjectId)
                                  .firstOrNull;
                              final tch = ecs.teachers
                                  .where((t) => t.id == sl.teacherId)
                                  .firstOrNull;
                              return InkWell(
                                onTap: () => _openSlotDialog(
                                  sl,
                                  isAdmin ? PortalRole.admin : PortalRole.teacher,
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.only(bottom: 6),
                                  child: Text(
                                    'P${sl.period} (${sl.timeRange}) · ${subj?.code ?? ''} · ${tch?.name ?? ''} · ${sl.room}',
                                    style: const TextStyle(fontSize: 12),
                                  ),
                                ),
                              );
                            }),
                            if (isAdmin)
                              TextButton.icon(
                                onPressed: () => _openSlotEditorDialog(
                                  presetClassroomId: cls.id,
                                  presetDay: day.code,
                                ),
                                icon: const Icon(Icons.add, size: 15),
                                label: const Text('Add Slot'),
                              ),
                          ],
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}
