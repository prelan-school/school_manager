class TimetableSlotEntity {
  const TimetableSlotEntity({
    required this.id,
    required this.classroomId,
    required this.subjectId,
    required this.teacherId,
    required this.day,
    required this.period,
    required this.timeRange,
    required this.room,
    this.lessonPlanId,
  });

  final String id;
  final String classroomId;
  final String subjectId;
  final String teacherId;
  final String day;
  final int period;
  final String timeRange;
  final String room;
  final String? lessonPlanId;

  TimetableSlotEntity copyWith({
    String? classroomId,
    String? subjectId,
    String? teacherId,
    String? day,
    int? period,
    String? timeRange,
    String? room,
    String? lessonPlanId,
    bool clearLessonPlan = false,
  }) {
    return TimetableSlotEntity(
      id: id,
      classroomId: classroomId ?? this.classroomId,
      subjectId: subjectId ?? this.subjectId,
      teacherId: teacherId ?? this.teacherId,
      day: day ?? this.day,
      period: period ?? this.period,
      timeRange: timeRange ?? this.timeRange,
      room: room ?? this.room,
      lessonPlanId: clearLessonPlan ? null : (lessonPlanId ?? this.lessonPlanId),
    );
  }

  factory TimetableSlotEntity.fromMap(String id, Map<String, dynamic> map) {
    return TimetableSlotEntity(
      id: id,
      classroomId: map['classroomId'] as String? ?? '',
      subjectId: map['subjectId'] as String? ?? '',
      teacherId: map['teacherId'] as String? ?? '',
      day: map['day'] as String? ?? 'Mon',
      period: (map['period'] as num?)?.toInt() ?? 1,
      timeRange: map['timeRange'] as String? ?? '',
      room: map['room'] as String? ?? '',
      lessonPlanId: map['lessonPlanId'] as String?,
    );
  }

  Map<String, dynamic> toMap() => {
        'classroomId': classroomId,
        'subjectId': subjectId,
        'teacherId': teacherId,
        'day': day,
        'period': period,
        'timeRange': timeRange,
        'room': room,
        'lessonPlanId': lessonPlanId,
      };
}

class TimetableConflictValidator {
  const TimetableConflictValidator._();

  static ({int start, int end})? _parseMinutes(String timeRange) {
    final match = RegExp(r'(\d{1,2}):(\d{2})\s*[-–—]\s*(\d{1,2}):(\d{2})')
        .firstMatch(timeRange);
    if (match == null) return null;
    final start =
        int.parse(match.group(1)!) * 60 + int.parse(match.group(2)!);
    final end = int.parse(match.group(3)!) * 60 + int.parse(match.group(4)!);
    if (end <= start) return null;
    return (start: start, end: end);
  }

  static bool _timesConflict(TimetableSlotEntity a, TimetableSlotEntity b) {
    if (a.period == b.period) return true;
    final parsedA = _parseMinutes(a.timeRange);
    final parsedB = _parseMinutes(b.timeRange);
    if (parsedA == null || parsedB == null) return false;
    return parsedA.start < parsedB.end && parsedB.start < parsedA.end;
  }

  static String? detectConflict({
    required List<TimetableSlotEntity> existingSlots,
    required TimetableSlotEntity candidate,
    String? ignoreSlotId,
  }) {
    final normalizedRoom = candidate.room.trim().toLowerCase();
    final normalizedDay = candidate.day.trim().toLowerCase();
    for (final slot in existingSlots) {
      if (ignoreSlotId != null && slot.id == ignoreSlotId) continue;
      if (slot.id == candidate.id) continue;
      if (slot.day.trim().toLowerCase() != normalizedDay) continue;
      if (!_timesConflict(slot, candidate)) continue;

      if (slot.classroomId == candidate.classroomId) {
        return 'Classroom already has a period scheduled on ${candidate.day} (${candidate.timeRange}).';
      }
      if (slot.teacherId == candidate.teacherId) {
        return 'Teacher is already booked on ${candidate.day} (${candidate.timeRange}).';
      }
      if (normalizedRoom.isNotEmpty &&
          slot.room.trim().toLowerCase() == normalizedRoom) {
        return 'Room "${candidate.room.trim()}" is already occupied on ${candidate.day} (${candidate.timeRange}).';
      }
    }
    return null;
  }
}
