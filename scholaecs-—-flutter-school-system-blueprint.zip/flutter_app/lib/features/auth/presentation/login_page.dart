import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/ecs/ecs_providers.dart';
import '../../../core/ecs/school_entity.dart';
import '../data/firebase_auth_repository.dart';
import '../domain/auth_user.dart';
import '../domain/firebase_web_config.dart';

class LoginPage extends ConsumerStatefulWidget {
  const LoginPage({super.key});

  @override
  ConsumerState<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends ConsumerState<LoginPage> {
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _confirmPasswordCtrl = TextEditingController();
  final _nameCtrl = TextEditingController();
  bool _isRegister = false;
  bool _obscurePassword = true;
  bool _obscureConfirm = true;
  bool _loading = false;
  PortalRole _selectedRole = PortalRole.parent;
  String? _selectedTeacherId;
  final Set<String> _selectedLearnerIds = <String>{};
  String? _error;
  String? _info;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    _confirmPasswordCtrl.dispose();
    _nameCtrl.dispose();
    super.dispose();
  }

  bool _ensureFirebaseReady() {
    if (ref.read(firebaseReadyProvider)) return true;
    if (Firebase.apps.isNotEmpty) {
      ref.read(firebaseReadyProvider.notifier).state = true;
      return true;
    }
    return false;
  }

  String _friendlyAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case 'operation-not-allowed':
        return 'This sign-in provider is disabled in Firebase Console -> Authentication -> Sign-in method.';
      case 'unauthorized-domain':
        return 'This domain is not authorized. Add it (or localhost) under Firebase Console -> Authentication -> Settings -> Authorized domains.';
      case 'popup-blocked':
        return 'Google Sign-In popup was blocked by your browser. Allow popups for this site and try again.';
      case 'invalid-credential':
      case 'wrong-password':
      case 'user-not-found':
        return 'Invalid email or password. If registering for the first time, switch to "Sign Up" above.';
      case 'email-already-in-use':
        return 'An account already exists for this email. Switch to "Sign In" instead.';
      case 'weak-password':
        return 'Password is too weak. Use at least 6 characters.';
      default:
        return e.message ?? 'Authentication failed (${e.code}).';
    }
  }

  Future<void> _openFirebaseConfigDialog() async {
    final snippetCtrl = TextEditingController();
    final apiKeyCtrl = TextEditingController();
    final appIdCtrl = TextEditingController();
    final senderIdCtrl = TextEditingController();
    final projectIdCtrl = TextEditingController();
    final authDomainCtrl = TextEditingController();
    final storageBucketCtrl = TextEditingController();
    String? dialogError;
    bool connecting = false;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            void applySnippet() {
              final parsed = parseFirebaseWebConfigSnippet(snippetCtrl.text);
              if (parsed == null) {
                setDialogState(
                  () => dialogError =
                      'Could not detect apiKey, appId, messagingSenderId, and projectId in snippet.',
                );
                return;
              }
              apiKeyCtrl.text = parsed.apiKey;
              appIdCtrl.text = parsed.appId;
              senderIdCtrl.text = parsed.messagingSenderId;
              projectIdCtrl.text = parsed.projectId;
              authDomainCtrl.text = parsed.effectiveAuthDomain;
              storageBucketCtrl.text = parsed.storageBucket;
              setDialogState(() => dialogError = null);
            }

            Future<void> connectFirebase() async {
              final data = FirebaseWebConfigData(
                apiKey: apiKeyCtrl.text.trim(),
                appId: appIdCtrl.text.trim(),
                messagingSenderId: senderIdCtrl.text.trim(),
                projectId: projectIdCtrl.text.trim(),
                authDomain: authDomainCtrl.text.trim(),
                storageBucket: storageBucketCtrl.text.trim(),
              );
              if (!data.isComplete) {
                setDialogState(
                  () => dialogError =
                      'apiKey, appId, messagingSenderId, and projectId are required.',
                );
                return;
              }
              setDialogState(() {
                connecting = true;
                dialogError = null;
              });
              try {
                if (Firebase.apps.isEmpty) {
                  await Firebase.initializeApp(
                    options: FirebaseOptions(
                      apiKey: data.apiKey,
                      appId: data.appId,
                      messagingSenderId: data.messagingSenderId,
                      projectId: data.projectId,
                      authDomain: data.effectiveAuthDomain,
                      storageBucket: data.storageBucket.isEmpty
                          ? null
                          : data.storageBucket,
                    ),
                  );
                }
                try {
                  FirebaseFirestore.instance.settings = const Settings(
                    persistenceEnabled: true,
                  );
                } catch (_) {}
                if (mounted) {
                  ref.read(firebaseReadyProvider.notifier).state = true;
                  setState(() {
                    _error = null;
                    _info =
                        'Connected to Firebase project "${data.projectId}". Sign in or create an account below.';
                  });
                }
                if (dialogContext.mounted) Navigator.of(dialogContext).pop();
              } catch (e) {
                setDialogState(() {
                  connecting = false;
                  dialogError = 'Firebase initialization failed: $e';
                });
              }
            }

            return AlertDialog(
              title: const Text('Connect Firebase Web Config'),
              content: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 480),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text(
                        'Paste your Web App config snippet from Firebase Console -> Project Settings:',
                        style: TextStyle(fontSize: 12, color: Color(0xFF475569)),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: snippetCtrl,
                        maxLines: 4,
                        decoration: const InputDecoration(
                          labelText: 'Paste firebaseConfig JS or JSON snippet',
                          hintText:
                              'const firebaseConfig = { apiKey: "...", ... };',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: OutlinedButton.icon(
                          onPressed: applySnippet,
                          icon: const Icon(Icons.auto_fix_high, size: 16),
                          label: const Text('Parse Snippet Fields'),
                        ),
                      ),
                      const Divider(height: 20),
                      TextField(
                        controller: projectIdCtrl,
                        decoration: const InputDecoration(
                          labelText: 'projectId *',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: apiKeyCtrl,
                        decoration: const InputDecoration(
                          labelText: 'apiKey *',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: appIdCtrl,
                        decoration: const InputDecoration(
                          labelText: 'appId *',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: senderIdCtrl,
                        decoration: const InputDecoration(
                          labelText: 'messagingSenderId *',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                      ),
                      if (dialogError != null) ...[
                        const SizedBox(height: 10),
                        Text(
                          dialogError!,
                          style: const TextStyle(
                            fontSize: 12,
                            color: Color(0xFFDC2626),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed:
                      connecting ? null : () => Navigator.of(dialogContext).pop(),
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed: connecting ? null : connectFirebase,
                  child: Text(connecting ? 'Connecting...' : 'Connect Firebase'),
                ),
              ],
            );
          },
        );
      },
    );

    snippetCtrl.dispose();
    apiKeyCtrl.dispose();
    appIdCtrl.dispose();
    senderIdCtrl.dispose();
    projectIdCtrl.dispose();
    authDomainCtrl.dispose();
    storageBucketCtrl.dispose();
  }

  Future<void> _submitEmail() async {
    final validationError = validateAuthInputs(
      isRegister: _isRegister,
      email: _emailCtrl.text,
      password: _passwordCtrl.text,
      confirmPassword: _confirmPasswordCtrl.text,
      displayName: _nameCtrl.text,
    );
    if (validationError != null) {
      setState(() {
        _error = validationError;
        _info = null;
      });
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
      _info = null;
    });

    final ecs = ref.read(schoolEcsProvider);
    final normalizedEmail = _emailCtrl.text.trim().toLowerCase();

    // Auto-match guardian learners or teacher record if user didn't pick manually
    final autoMatchedLearners = ecs.learners
        .where((l) => l.parentEmail.trim().toLowerCase() == normalizedEmail)
        .map((l) => l.id)
        .toList();
    final effectiveLearnerIds = _selectedLearnerIds.isNotEmpty
        ? _selectedLearnerIds.toList()
        : (autoMatchedLearners.isNotEmpty
            ? autoMatchedLearners
            : ecs.learners.take(1).map((l) => l.id).toList());
    final matchedTeacher = ecs.teachers
        .where((t) => t.email.trim().toLowerCase() == normalizedEmail)
        .firstOrNull;
    final effectiveTeacherId =
        _selectedTeacherId ?? matchedTeacher?.id ?? ecs.teachers.firstOrNull?.id;

    try {
      if (_ensureFirebaseReady()) {
        final repo = FirebaseAuthRepository(
          FirebaseAuth.instance,
          FirebaseFirestore.instance,
        );
        if (_isRegister) {
          await repo.registerWithEmail(
            _emailCtrl.text,
            _passwordCtrl.text,
            _nameCtrl.text,
            requestedRole: _selectedRole,
            teacherId: _selectedRole == PortalRole.parent ? null : effectiveTeacherId,
          );
        } else {
          await repo.signInWithEmail(_emailCtrl.text, _passwordCtrl.text);
        }
        ref.read(demoSessionProvider.notifier).state = null;
        if (mounted) context.go('/');
        return;
      }

      // Portal Registry Mode (when Firebase is not configured yet)
      final registry = ref.read(localAuthAccountsProvider.notifier);
      final AuthUser signedInUser;
      if (_isRegister) {
        signedInUser = registry.register(
          email: normalizedEmail,
          password: _passwordCtrl.text,
          displayName: _nameCtrl.text,
          role: _selectedRole,
          teacherId: _selectedRole == PortalRole.parent ? null : effectiveTeacherId,
          linkedLearnerIds:
              _selectedRole == PortalRole.parent ? effectiveLearnerIds : const [],
        );
      } else {
        signedInUser = registry.signIn(normalizedEmail, _passwordCtrl.text);
      }
      ref.read(demoSessionProvider.notifier).state = signedInUser;
      if (mounted) context.go('/');
    } on FirebaseAuthException catch (e) {
      setState(() => _error = _friendlyAuthError(e));
    } on FormatException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = 'Authentication error: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _submitGoogle() async {
    if (!_ensureFirebaseReady()) {
      setState(
        () => _error =
            'Connect Firebase Config first to use Google Sign-In, or use Email & Password / Quick Preview below.',
      );
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
      _info = null;
    });
    try {
      final repo = FirebaseAuthRepository(
        FirebaseAuth.instance,
        FirebaseFirestore.instance,
      );
      await repo.signInWithGoogle();
      ref.read(demoSessionProvider.notifier).state = null;
      if (mounted) context.go('/');
    } on FirebaseAuthException catch (e) {
      setState(() => _error = _friendlyAuthError(e));
    } catch (e) {
      setState(() => _error = 'Google Sign-In error: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _forgotPassword() async {
    final email = _emailCtrl.text.trim();
    if (!email.contains('@')) {
      setState(() {
        _error = 'Enter your email address above first to reset your password.';
        _info = null;
      });
      return;
    }
    if (_ensureFirebaseReady()) {
      try {
        await FirebaseAuthRepository(
          FirebaseAuth.instance,
          FirebaseFirestore.instance,
        ).sendPasswordResetEmail(email);
        setState(() {
          _error = null;
          _info = 'Password reset link sent to $email.';
        });
      } on FirebaseAuthException catch (e) {
        setState(() => _error = _friendlyAuthError(e));
      }
      return;
    }

    final ok = ref
        .read(localAuthAccountsProvider.notifier)
        .resetPassword(email, defaultSeedPassword);
    setState(() {
      if (ok) {
        _error = null;
        _passwordCtrl.text = defaultSeedPassword;
        _info =
            'Local account password reset to $defaultSeedPassword. Click Sign In to continue.';
      } else {
        _error = 'No account found for $email.';
      }
    });
  }

  void _fillCredential(String email) {
    setState(() {
      _isRegister = false;
      _emailCtrl.text = email;
      _passwordCtrl.text = defaultSeedPassword;
      _error = null;
      _info = null;
    });
  }

  void _enterDemo(PortalRole role) {
    ref.read(demoSessionProvider.notifier).state = AuthUser(
      uid: 'demo_${role.key}',
      email: switch (role) {
        PortalRole.admin => defaultAdminEmail,
        PortalRole.teacher => 'amara.okafor@scholaecs.edu',
        PortalRole.parent => 'grace.mwangi@family.org',
      },
      displayName: switch (role) {
        PortalRole.admin => 'Default Admin',
        PortalRole.teacher => 'Amara Okafor',
        PortalRole.parent => 'Grace Mwangi',
      },
      role: role,
      teacherId: role == PortalRole.teacher ? 'tch_amara' : 'tch_amara',
      linkedLearnerIds: role == PortalRole.parent
          ? const ['lrn_01', 'lrn_02']
          : const ['lrn_01'],
      emailVerified: true,
      isDemoMode: true,
    );
    context.go('/');
  }

  @override
  Widget build(BuildContext context) {
    final firebaseReady = ref.watch(firebaseReadyProvider);
    final ecs = ref.watch(schoolEcsProvider);

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Container(
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFE2E8F0)),
                boxShadow: const [
                  BoxShadow(
                    color: Color.fromRGBO(15, 23, 42, 0.05),
                    blurRadius: 18,
                    offset: Offset(0, 6),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: const Color(0xFF1D4ED8),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(
                          Icons.school_rounded,
                          color: Colors.white,
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'ScholaECS',
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFF0F172A),
                              ),
                            ),
                            Text(
                              'Admin, Teacher & Parent Portal',
                              style: TextStyle(
                                fontSize: 12,
                                color: Color(0xFF64748B),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  SegmentedButton<bool>(
                    segments: const [
                      ButtonSegment<bool>(
                        value: false,
                        icon: Icon(Icons.login, size: 16),
                        label: Text('Sign In'),
                      ),
                      ButtonSegment<bool>(
                        value: true,
                        icon: Icon(Icons.person_add_alt_1, size: 16),
                        label: Text('Sign Up'),
                      ),
                    ],
                    selected: {_isRegister},
                    onSelectionChanged: (sel) {
                      setState(() {
                        _isRegister = sel.first;
                        _error = null;
                        _info = null;
                      });
                    },
                  ),
                  const SizedBox(height: 16),
                  if (_isRegister) ...[
                    TextField(
                      controller: _nameCtrl,
                      textInputAction: TextInputAction.next,
                      decoration: const InputDecoration(
                        labelText: 'Full Name *',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<PortalRole>(
                      value: _selectedRole,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Account Role *',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      items: PortalRole.values
                          .map(
                            (r) => DropdownMenuItem(
                              value: r,
                              child: Text(r.label, overflow: TextOverflow.ellipsis),
                            ),
                          )
                          .toList(),
                      onChanged: (next) {
                        if (next != null) setState(() => _selectedRole = next);
                      },
                    ),
                    if (_selectedRole == PortalRole.teacher &&
                        ecs.teachers.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: _selectedTeacherId ?? ecs.teachers.first.id,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'Link Staff Profile',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                        items: ecs.teachers
                            .map(
                              (t) => DropdownMenuItem(
                                value: t.id,
                                child: Text(
                                  '${t.name} (${t.subjectSpecialties.join(", ")})',
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            )
                            .toList(),
                        onChanged: (v) => setState(() => _selectedTeacherId = v),
                      ),
                    ],
                    if (_selectedRole == PortalRole.parent &&
                        ecs.learners.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      const Text(
                        'Link Child(ren) (optional — auto-links by email too):',
                        style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Color(0xFF475569)),
                      ),
                      const SizedBox(height: 4),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: ecs.learners.map((l) {
                          final selected = _selectedLearnerIds.contains(l.id);
                          return FilterChip(
                            label: Text(l.name, style: const TextStyle(fontSize: 11)),
                            selected: selected,
                            onSelected: (checked) {
                              setState(() {
                                if (checked) {
                                  _selectedLearnerIds.add(l.id);
                                } else {
                                  _selectedLearnerIds.remove(l.id);
                                }
                              });
                            },
                          );
                        }).toList(),
                      ),
                    ],
                    if (firebaseReady && _selectedRole != PortalRole.parent) ...[
                      const SizedBox(height: 8),
                      Text(
                        _selectedRole == PortalRole.admin
                            ? 'Firebase mode: verify $defaultAdminEmail or request admin approval after registration.'
                            : 'Firebase mode: account starts with verified access and your teacher role request is saved for Admin confirmation.',
                        style: const TextStyle(fontSize: 11, color: Color(0xFF64748B)),
                      ),
                    ],
                    const SizedBox(height: 12),
                  ],
                  TextField(
                    controller: _emailCtrl,
                    keyboardType: TextInputType.emailAddress,
                    textInputAction: TextInputAction.next,
                    decoration: const InputDecoration(
                      labelText: 'Email Address *',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _passwordCtrl,
                    obscureText: _obscurePassword,
                    textInputAction:
                        _isRegister ? TextInputAction.next : TextInputAction.done,
                    onSubmitted: (_) {
                      if (!_isRegister && !_loading) _submitEmail();
                    },
                    decoration: InputDecoration(
                      labelText: 'Password *',
                      border: const OutlineInputBorder(),
                      isDense: true,
                      suffixIcon: IconButton(
                        tooltip: _obscurePassword ? 'Show password' : 'Hide password',
                        icon: Icon(
                          _obscurePassword
                              ? Icons.visibility_outlined
                              : Icons.visibility_off_outlined,
                          size: 18,
                        ),
                        onPressed: () =>
                            setState(() => _obscurePassword = !_obscurePassword),
                      ),
                    ),
                  ),
                  if (_isRegister) ...[
                    const SizedBox(height: 12),
                    TextField(
                      controller: _confirmPasswordCtrl,
                      obscureText: _obscureConfirm,
                      onSubmitted: (_) {
                        if (!_loading) _submitEmail();
                      },
                      decoration: InputDecoration(
                        labelText: 'Confirm Password *',
                        border: const OutlineInputBorder(),
                        isDense: true,
                        suffixIcon: IconButton(
                          tooltip: _obscureConfirm ? 'Show password' : 'Hide password',
                          icon: Icon(
                            _obscureConfirm
                                ? Icons.visibility_outlined
                                : Icons.visibility_off_outlined,
                            size: 18,
                          ),
                          onPressed: () =>
                              setState(() => _obscureConfirm = !_obscureConfirm),
                        ),
                      ),
                    ),
                  ] else ...[
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: _loading ? null : _forgotPassword,
                        child: const Text(
                          'Forgot / Reset Password?',
                          style: TextStyle(fontSize: 12),
                        ),
                      ),
                    ),
                  ],
                  if (_error != null) ...[
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFEF2F2),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: const Color(0xFFFECACA)),
                      ),
                      child: Text(
                        _error!,
                        style: const TextStyle(
                          fontSize: 12,
                          color: Color(0xFFDC2626),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                  if (_info != null) ...[
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: const Color(0xFFECFDF5),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: const Color(0xFFA7F3D0)),
                      ),
                      child: Text(
                        _info!,
                        style: const TextStyle(
                          fontSize: 12,
                          color: Color(0xFF065F46),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                  const SizedBox(height: 14),
                  FilledButton(
                    onPressed: _loading ? null : _submitEmail,
                    style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: Text(
                      _loading
                          ? 'Please wait...'
                          : (_isRegister
                              ? 'Create ${_selectedRole.label} Account'
                              : 'Sign In'),
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                  ),
                  if (firebaseReady) ...[
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: _loading ? null : _submitGoogle,
                      icon: const Icon(Icons.g_mobiledata, size: 24),
                      label: const Text('Continue with Google'),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                    ),
                  ],
                  const Divider(height: 28),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF8FAFC),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: const Color(0xFFE2E8F0)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              'Portal Accounts & Quick Preview',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: Color(0xFF475569),
                              ),
                            ),
                            if (!firebaseReady)
                              TextButton(
                                onPressed: _openFirebaseConfigDialog,
                                style: TextButton.styleFrom(
                                  visualDensity: VisualDensity.compact,
                                ),
                                child: const Text(
                                  'Connect Firebase',
                                  style: TextStyle(fontSize: 11),
                                ),
                              ),
                          ],
                        ),
                        if (!firebaseReady)
                          const Padding(
                            padding: EdgeInsets.only(bottom: 8),
                            child: Text(
                              'Fill test credentials (Password: $defaultSeedPassword) or launch instant role preview:',
                              style: TextStyle(fontSize: 11, color: Color(0xFF64748B)),
                            ),
                          ),
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: [
                            if (!firebaseReady) ...[
                              ActionChip(
                                label: const Text('Fill Admin', style: TextStyle(fontSize: 11)),
                                onPressed: () => _fillCredential(defaultAdminEmail),
                              ),
                              ActionChip(
                                label: const Text('Fill Teacher', style: TextStyle(fontSize: 11)),
                                onPressed: () => _fillCredential('amara.okafor@scholaecs.edu'),
                              ),
                              ActionChip(
                                label: const Text('Fill Parent', style: TextStyle(fontSize: 11)),
                                onPressed: () => _fillCredential('grace.mwangi@family.org'),
                              ),
                            ],
                            ...PortalRole.values.map(
                              (role) => ActionChip(
                                avatar: Icon(
                                  role == PortalRole.admin
                                      ? Icons.admin_panel_settings_outlined
                                      : role == PortalRole.teacher
                                          ? Icons.co_present_outlined
                                          : Icons.family_restroom_outlined,
                                  size: 14,
                                ),
                                label: Text(
                                  'Preview ${role.label}',
                                  style: const TextStyle(fontSize: 11),
                                ),
                                onPressed: () => _enterDemo(role),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
