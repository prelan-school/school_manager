import '../../../core/ecs/school_entity.dart';

class AuthUser {
  const AuthUser({
    required this.uid,
    required this.email,
    required this.displayName,
    required this.role,
    this.requestedRole,
    this.teacherId,
    this.linkedLearnerIds = const [],
    this.emailVerified = true,
    this.isDemoMode = false,
  });

  final String uid;
  final String email;
  final String displayName;
  final PortalRole role;
  final PortalRole? requestedRole;
  final String? teacherId;
  final List<String> linkedLearnerIds;
  final bool emailVerified;
  final bool isDemoMode;

  factory AuthUser.fromMap(
    String uid,
    Map<String, dynamic> map, {
    bool emailVerified = true,
  }) {
    final requestedRaw = map['requestedRole'] as String?;
    return AuthUser(
      uid: uid,
      email: map['email'] as String? ?? '',
      displayName: map['displayName'] as String? ?? 'School User',
      role: PortalRole.fromKey(map['role'] as String?),
      requestedRole:
          requestedRaw == null ? null : PortalRole.fromKey(requestedRaw),
      teacherId: map['teacherId'] as String?,
      linkedLearnerIds:
          List<String>.from(map['linkedLearnerIds'] as List<dynamic>? ?? const []),
      emailVerified: emailVerified,
    );
  }

  AuthUser copyWith({
    PortalRole? role,
    PortalRole? requestedRole,
    String? teacherId,
    List<String>? linkedLearnerIds,
    bool? emailVerified,
  }) {
    return AuthUser(
      uid: uid,
      email: email,
      displayName: displayName,
      role: role ?? this.role,
      requestedRole: requestedRole ?? this.requestedRole,
      teacherId: teacherId ?? this.teacherId,
      linkedLearnerIds: linkedLearnerIds ?? this.linkedLearnerIds,
      emailVerified: emailVerified ?? this.emailVerified,
      isDemoMode: isDemoMode,
    );
  }
}
