/// Pure Dart parser for Firebase Web SDK config snippets (JSON or Console JS).
class FirebaseWebConfigData {
  const FirebaseWebConfigData({
    required this.apiKey,
    required this.appId,
    required this.messagingSenderId,
    required this.projectId,
    this.authDomain = '',
    this.storageBucket = '',
  });

  final String apiKey;
  final String appId;
  final String messagingSenderId;
  final String projectId;
  final String authDomain;
  final String storageBucket;

  bool get isComplete =>
      apiKey.trim().isNotEmpty &&
      appId.trim().isNotEmpty &&
      messagingSenderId.trim().isNotEmpty &&
      projectId.trim().isNotEmpty;

  String get effectiveAuthDomain =>
      authDomain.trim().isNotEmpty ? authDomain.trim() : '$projectId.firebaseapp.com';
}

/// Parses either valid JSON or a JS `const firebaseConfig = { ... };` snippet
/// copied directly from Firebase Console -> Project Settings -> Web App.
FirebaseWebConfigData? parseFirebaseWebConfigSnippet(String raw) {
  String extractKey(String key) {
    final pattern = RegExp(
      '(?:["\']?)$key(?:["\']?)\\s*:\\s*(?:"([^"\\n]+)"|\'([^\'\\n]+)\')',
    );
    final match = pattern.firstMatch(raw);
    if (match == null) return '';
    return (match.group(1) ?? match.group(2) ?? '').trim();
  }

  final apiKey = extractKey('apiKey');
  final appId = extractKey('appId');
  final messagingSenderId = extractKey('messagingSenderId');
  final projectId = extractKey('projectId');
  final authDomain = extractKey('authDomain');
  final storageBucket = extractKey('storageBucket');

  if (apiKey.isEmpty ||
      appId.isEmpty ||
      messagingSenderId.isEmpty ||
      projectId.isEmpty) {
    return null;
  }

  return FirebaseWebConfigData(
    apiKey: apiKey,
    appId: appId,
    messagingSenderId: messagingSenderId,
    projectId: projectId,
    authDomain: authDomain,
    storageBucket: storageBucket,
  );
}
