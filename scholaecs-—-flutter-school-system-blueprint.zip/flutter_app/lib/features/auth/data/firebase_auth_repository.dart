import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../../../core/ecs/school_entity.dart';
import '../domain/auth_user.dart';

/// Bootstrapped Default Admin email. Override at build time via:
/// `flutter build web --dart-define=DEFAULT_ADMIN_EMAIL=you@school.edu`
const String defaultAdminEmail = String.fromEnvironment(
  'DEFAULT_ADMIN_EMAIL',
  defaultValue: 'prelanadm@gmail.com',
);

const String defaultSeedPassword = 'Schola@2026';

bool isDefaultAdminEmail(String? email) {
  if (email == null) return false;
  return email.trim().toLowerCase() == defaultAdminEmail.trim().toLowerCase();
}

/// Validates auth inputs cleanly on both Sign In and Sign Up.
String? validateAuthInputs({
  required bool isRegister,
  required String email,
  required String password,
  String confirmPassword = '',
  String displayName = '',
}) {
  final trimmedEmail = email.trim();
  if (isRegister && displayName.trim().length < 2) {
    return 'Enter your full name (at least 2 characters).';
  }
  final emailPattern = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');
  if (!emailPattern.hasMatch(trimmedEmail)) {
    return 'Enter a valid email address.';
  }
  if (password.length < 6) {
    return 'Password must be at least 6 characters.';
  }
  if (isRegister && password != confirmPassword) {
    return 'Passwords do not match.';
  }
  return null;
}

/// Resolves the initial or synced Firestore role for an authenticated account.
/// Only a verified default admin email auto-claims `admin`; all other self-signups
/// safely default to `parent` until promoted by an Admin.
PortalRole resolveBootstrapRole({
  required String? email,
  required bool emailVerified,
  PortalRole? existingRole,
}) {
  if (isDefaultAdminEmail(email) && emailVerified) {
    return PortalRole.admin;
  }
  return existingRole ?? PortalRole.parent;
}

class LocalPortalAccount {
  const LocalPortalAccount({
    required this.user,
    required this.password,
  });

  final AuthUser user;
  final String password;

  LocalPortalAccount copyWith({
    AuthUser? user,
    String? password,
  }) {
    return LocalPortalAccount(
      user: user ?? this.user,
      password: password ?? this.password,
    );
  }
}

class LocalAuthRegistryNotifier extends StateNotifier<List<LocalPortalAccount>> {
  LocalAuthRegistryNotifier()
      : super(const [
          LocalPortalAccount(
            user: AuthUser(
              uid: 'local_admin',
              email: defaultAdminEmail,
              displayName: 'Default Admin',
              role: PortalRole.admin,
              teacherId: 'tch_amara',
              linkedLearnerIds: ['lrn_01'],
              emailVerified: true,
              isDemoMode: true,
            ),
            password: defaultSeedPassword,
          ),
          LocalPortalAccount(
            user: AuthUser(
              uid: 'local_tch_amara',
              email: 'amara.okafor@scholaecs.edu',
              displayName: 'Amara Okafor',
              role: PortalRole.teacher,
              teacherId: 'tch_amara',
              emailVerified: true,
              isDemoMode: true,
            ),
            password: defaultSeedPassword,
          ),
          LocalPortalAccount(
            user: AuthUser(
              uid: 'local_tch_david',
              email: 'david.kamau@scholaecs.edu',
              displayName: 'David Kamau',
              role: PortalRole.teacher,
              teacherId: 'tch_david',
              emailVerified: true,
              isDemoMode: true,
            ),
            password: defaultSeedPassword,
          ),
          LocalPortalAccount(
            user: AuthUser(
              uid: 'local_parent_grace',
              email: 'grace.mwangi@family.org',
              displayName: 'Grace Mwangi',
              role: PortalRole.parent,
              linkedLearnerIds: ['lrn_01', 'lrn_02'],
              emailVerified: true,
              isDemoMode: true,
            ),
            password: defaultSeedPassword,
          ),
        ]);

  AuthUser signIn(String email, String password) {
    final normalized = email.trim().toLowerCase();
    final idx = state.indexWhere((a) => a.user.email.toLowerCase() == normalized);
    if (idx < 0) {
      throw const FormatException(
        'No account found for this email. Switch to Sign Up to create one.',
      );
    }
    final match = state[idx];
    if (match.password != password) {
      throw const FormatException(
        'Incorrect password. Check your password or use Reset Password.',
      );
    }
    return match.user;
  }

  AuthUser register({
    required String email,
    required String password,
    required String displayName,
    required PortalRole role,
    String? teacherId,
    List<String> linkedLearnerIds = const [],
  }) {
    final normalized = email.trim().toLowerCase();
    final exists = state.any((a) => a.user.email.toLowerCase() == normalized);
    if (exists) {
      throw const FormatException(
        'An account already exists with this email. Switch to Sign In instead.',
      );
    }
    final effectiveRole = isDefaultAdminEmail(normalized) ? PortalRole.admin : role;
    final created = AuthUser(
      uid: 'local_${DateTime.now().millisecondsSinceEpoch}',
      email: normalized,
      displayName: displayName.trim(),
      role: effectiveRole,
      requestedRole: role,
      teacherId: effectiveRole == PortalRole.parent ? null : teacherId,
      linkedLearnerIds:
          effectiveRole == PortalRole.parent ? linkedLearnerIds : const [],
      emailVerified: true,
      isDemoMode: true,
    );
    state = [...state, LocalPortalAccount(user: created, password: password)];
    return created;
  }

  void updateUser({
    String? uid,
    required String email,
    required String displayName,
    required PortalRole role,
    String? teacherId,
    required List<String> linkedLearnerIds,
  }) {
    final normalized = email.trim().toLowerCase();
    final idx = state.indexWhere(
      (a) => (uid != null && a.user.uid == uid) || a.user.email.toLowerCase() == normalized,
    );
    if (idx >= 0) {
      final existing = state[idx];
      final updatedUser = AuthUser(
        uid: existing.user.uid,
        email: normalized,
        displayName: displayName.trim().isEmpty ? existing.user.displayName : displayName.trim(),
        role: role,
        teacherId: role == PortalRole.parent ? null : teacherId,
        linkedLearnerIds: role == PortalRole.parent ? linkedLearnerIds : const [],
        emailVerified: existing.user.emailVerified,
        isDemoMode: existing.user.isDemoMode,
      );
      final next = [...state];
      next[idx] = existing.copyWith(user: updatedUser);
      state = next;
    } else {
      state = [
        ...state,
        LocalPortalAccount(
          user: AuthUser(
            uid: uid ?? 'invited_${normalized.replaceAll(RegExp(r'[^a-z0-9]+'), '_')}',
            email: normalized,
            displayName: displayName.trim(),
            role: role,
            teacherId: role == PortalRole.parent ? null : teacherId,
            linkedLearnerIds: role == PortalRole.parent ? linkedLearnerIds : const [],
            emailVerified: true,
            isDemoMode: true,
          ),
          password: defaultSeedPassword,
        ),
      ];
    }
  }

  bool resetPassword(String email, String newPassword) {
    final normalized = email.trim().toLowerCase();
    final idx = state.indexWhere((a) => a.user.email.toLowerCase() == normalized);
    if (idx < 0) return false;
    final next = [...state];
    next[idx] = next[idx].copyWith(password: newPassword);
    state = next;
    return true;
  }
}

abstract interface class AuthRepository {
  Stream<AuthUser?> watchSession();
  Future<AuthUser> signInWithEmail(String email, String password);
  Future<AuthUser> registerWithEmail(
    String email,
    String password,
    String displayName, {
    PortalRole requestedRole = PortalRole.parent,
    String? teacherId,
  });
  Future<AuthUser> signInWithGoogle();
  Future<void> sendPasswordResetEmail(String email);
  Future<void> resendVerificationEmail();
  Future<AuthUser?> reloadCurrentUser();
  Future<void> signOut();
}

class FirebaseAuthRepository implements AuthRepository {
  FirebaseAuthRepository(this._auth, this._db);

  final FirebaseAuth _auth;
  final FirebaseFirestore _db;

  @override
  Stream<AuthUser?> watchSession() {
    return _auth.userChanges().asyncMap((user) async {
      if (user == null) return null;
      return _resolveUserProfile(user);
    });
  }

  @override
  Future<AuthUser> signInWithEmail(String email, String password) async {
    final cred = await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    await _ensureUserDocExistsSafe(cred.user!);
    return _resolveUserProfile(cred.user!);
  }

  @override
  Future<AuthUser> registerWithEmail(
    String email,
    String password,
    String displayName, {
    PortalRole requestedRole = PortalRole.parent,
    String? teacherId,
  }) async {
    final normalizedEmail = email.trim();
    final trimmedName = displayName.trim();
    final cred = await _auth.createUserWithEmailAndPassword(
      email: normalizedEmail,
      password: password,
    );
    try {
      await cred.user!.updateDisplayName(trimmedName);
    } catch (_) {}
    if (!cred.user!.emailVerified) {
      try {
        await cred.user!.sendEmailVerification();
      } catch (_) {
        // Non-fatal: user can resend from PortalShell verification banner.
      }
    }
    final assignedRole = resolveBootstrapRole(
      email: normalizedEmail,
      emailVerified: cred.user!.emailVerified,
    );
    try {
      await _db.collection('users').doc(cred.user!.uid).set({
        'email': normalizedEmail,
        'displayName': trimmedName.isEmpty ? 'School User' : trimmedName,
        'role': assignedRole.key,
        'requestedRole': requestedRole.key,
        if (teacherId != null && teacherId.trim().isNotEmpty)
          'teacherId': teacherId.trim(),
        'linkedLearnerIds': <String>[],
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (_) {
      // Non-fatal if Firestore database/rules are not yet provisioned; fallback AuthUser returned below.
    }
    return _resolveUserProfile(
      cred.user!,
      fallbackRequestedRole: requestedRole,
      fallbackTeacherId: teacherId,
    );
  }

  @override
  Future<AuthUser> signInWithGoogle() async {
    if (kIsWeb) {
      final provider = GoogleAuthProvider()
        ..addScope('email')
        ..addScope('profile');
      final cred = await _auth.signInWithPopup(provider);
      await _ensureUserDocExistsSafe(cred.user!);
      return _resolveUserProfile(cred.user!);
    }
    final googleUser = await GoogleSignIn().signIn();
    if (googleUser == null) {
      throw FirebaseAuthException(
        code: 'cancelled-by-user',
        message: 'Google Sign-In was cancelled.',
      );
    }
    final googleAuth = await googleUser.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );
    final cred = await _auth.signInWithCredential(credential);
    await _ensureUserDocExistsSafe(cred.user!);
    return _resolveUserProfile(cred.user!);
  }

  @override
  Future<void> sendPasswordResetEmail(String email) async {
    await _auth.sendPasswordResetEmail(email: email.trim());
  }

  @override
  Future<void> resendVerificationEmail() async {
    final user = _auth.currentUser;
    if (user != null && !user.emailVerified) {
      await user.sendEmailVerification();
    }
  }

  @override
  Future<AuthUser?> reloadCurrentUser() async {
    final user = _auth.currentUser;
    if (user == null) return null;
    await user.reload();
    final refreshed = _auth.currentUser;
    if (refreshed == null) return null;
    return _resolveUserProfile(refreshed);
  }

  @override
  Future<void> signOut() async {
    await _auth.signOut();
  }

  Stream<List<AuthUser>> watchAllUsers() {
    return _db.collection('users').snapshots().map(
          (snap) => snap.docs
              .map((doc) => AuthUser.fromMap(doc.id, doc.data()))
              .toList()
            ..sort((a, b) => a.email.compareTo(b.email)),
        );
  }

  Future<void> updateUserRole({
    required String uid,
    required PortalRole role,
    String? teacherId,
    List<String>? linkedLearnerIds,
  }) async {
    final payload = <String, dynamic>{
      'role': role.key,
      'updatedAt': FieldValue.serverTimestamp(),
    };
    if (teacherId != null) {
      payload['teacherId'] = teacherId.trim().isEmpty ? null : teacherId.trim();
    }
    if (linkedLearnerIds != null) {
      payload['linkedLearnerIds'] = linkedLearnerIds;
    }
    await _db.collection('users').doc(uid).update(payload);
  }

  /// Admin utility to pre-provision or update a staff/guardian record in `/users/{uid}`.
  Future<void> createOrUpdateUserRecord({
    String? uid,
    required String email,
    required String displayName,
    required PortalRole role,
    String? teacherId,
    required List<String> linkedLearnerIds,
  }) async {
    final normalizedEmail = email.trim().toLowerCase();
    final targetId = (uid != null && uid.trim().isNotEmpty)
        ? uid.trim()
        : 'invited_${normalizedEmail.replaceAll(RegExp(r'[^a-z0-9]+'), '_')}';

    await _db.collection('users').doc(targetId).set(
      {
        'email': normalizedEmail,
        'displayName': displayName.trim(),
        'role': role.key,
        'teacherId': role == PortalRole.parent
            ? null
            : (teacherId?.trim().isEmpty ?? true)
                ? null
                : teacherId!.trim(),
        'linkedLearnerIds': linkedLearnerIds.toSet().toList(),
        'updatedAt': FieldValue.serverTimestamp(),
      },
      SetOptions(merge: true),
    );
  }

  Future<void> _ensureUserDocExistsSafe(User user) async {
    try {
      final ref = _db.collection('users').doc(user.uid);
      final snap = await ref.get();
      final initialRole = resolveBootstrapRole(
        email: user.email,
        emailVerified: user.emailVerified,
      );
      if (!snap.exists) {
        await ref.set({
          'email': user.email ?? '',
          'displayName': user.displayName ??
              (initialRole == PortalRole.admin ? 'Default Admin' : 'School User'),
          'role': initialRole.key,
          'linkedLearnerIds': <String>[],
          'createdAt': FieldValue.serverTimestamp(),
        });
      } else {
        final data = snap.data() ?? <String, dynamic>{};
        final existingRole = PortalRole.fromKey(data['role'] as String?);
        if (isDefaultAdminEmail(user.email) &&
            user.emailVerified &&
            existingRole != PortalRole.admin) {
          await ref.update({
            'role': PortalRole.admin.key,
            'updatedAt': FieldValue.serverTimestamp(),
          });
        }
      }
    } catch (_) {
      // Prevent Firestore read/rule failures from breaking Firebase Authentication sign-in.
    }
  }

  Future<AuthUser> _resolveUserProfile(
    User user, {
    PortalRole? fallbackRequestedRole,
    String? fallbackTeacherId,
  }) async {
    try {
      final ref = _db.collection('users').doc(user.uid);
      final doc = await ref.get();
      if (!doc.exists) {
        await _ensureUserDocExistsSafe(user);
        final created = await ref.get();
        if (created.exists) {
          final createdData = created.data() ?? <String, dynamic>{};
          return AuthUser.fromMap(
            user.uid,
            createdData,
            emailVerified: user.emailVerified,
          );
        }
      } else {
        final data = doc.data() ?? <String, dynamic>{};
        final existingRole = PortalRole.fromKey(data['role'] as String?);
        final resolvedRole = resolveBootstrapRole(
          email: user.email,
          emailVerified: user.emailVerified,
          existingRole: existingRole,
        );
        if (resolvedRole == PortalRole.admin && existingRole != PortalRole.admin) {
          try {
            await ref.update({
              'role': PortalRole.admin.key,
              'updatedAt': FieldValue.serverTimestamp(),
            });
          } catch (_) {}
        }
        final requestedRaw = data['requestedRole'] as String?;
        return AuthUser(
          uid: user.uid,
          email: user.email ?? '',
          displayName: (data['displayName'] as String?) ?? user.displayName ?? 'User',
          role: resolvedRole,
          requestedRole: requestedRaw == null
              ? fallbackRequestedRole
              : PortalRole.fromKey(requestedRaw),
          teacherId: data['teacherId'] as String? ?? fallbackTeacherId,
          linkedLearnerIds: List<String>.from(
            data['linkedLearnerIds'] as List<dynamic>? ?? const [],
          ),
          emailVerified: user.emailVerified,
        );
      }
    } catch (_) {
      // Fall back to safe bootstrap AuthUser if Firestore is unreachable/unprovisioned.
    }

    final fallbackRole = resolveBootstrapRole(
      email: user.email,
      emailVerified: user.emailVerified,
    );
    return AuthUser(
      uid: user.uid,
      email: user.email ?? '',
      displayName: user.displayName?.trim().isNotEmpty == true
          ? user.displayName!.trim()
          : (fallbackRole == PortalRole.admin ? 'Default Admin' : 'School User'),
      role: fallbackRole,
      requestedRole: fallbackRequestedRole,
      teacherId: fallbackTeacherId,
      linkedLearnerIds: const [],
      emailVerified: user.emailVerified,
    );
  }
}

/// Initial Firebase readiness set by `main.dart` at startup.
final firebaseInitialReadyProvider = Provider<bool>((ref) => false);

/// Live Firebase readiness (supports startup init + in-app Web config connect).
final firebaseReadyProvider = StateProvider<bool>(
  (ref) => ref.watch(firebaseInitialReadyProvider),
);

/// Local account directory supporting Email+Password sign-in & sign-up across Admin, Teacher, and Parent roles.
final localAuthAccountsProvider =
    StateNotifierProvider<LocalAuthRegistryNotifier, List<LocalPortalAccount>>(
  (ref) => LocalAuthRegistryNotifier(),
);

/// Active local/demo portal session (`null` when signed out so `/login` is enforced).
final demoSessionProvider = StateProvider<AuthUser?>((ref) => null);

final currentUserProvider = StreamProvider<AuthUser?>((ref) {
  final firebaseReady = ref.watch(firebaseReadyProvider);
  final localSession = ref.watch(demoSessionProvider);
  if (localSession != null) {
    return Stream.value(localSession);
  }
  if (!firebaseReady) {
    return Stream.value(null);
  }
  return FirebaseAuthRepository(
    FirebaseAuth.instance,
    FirebaseFirestore.instance,
  ).watchSession();
});

final allUsersStreamProvider = StreamProvider<List<AuthUser>>((ref) {
  final firebaseReady = ref.watch(firebaseReadyProvider);
  final user = ref.watch(currentUserProvider).valueOrNull;
  final localUsers = ref.watch(localAuthAccountsProvider).map((a) => a.user).toList();
  if (!firebaseReady || user?.role != PortalRole.admin || (user?.isDemoMode ?? false)) {
    return Stream.value(localUsers);
  }
  return FirebaseAuthRepository(
    FirebaseAuth.instance,
    FirebaseFirestore.instance,
  ).watchAllUsers();
});
