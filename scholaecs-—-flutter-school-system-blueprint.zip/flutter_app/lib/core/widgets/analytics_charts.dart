import 'dart:math' as math;
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../../features/admin_dashboard/domain/syllabus_coverage_system.dart';

class ProgressBarChart extends StatelessWidget {
  const ProgressBarChart({
    super.key,
    required this.title,
    required this.value, // 0.0 to 1.0
    required this.label,
    this.color = const Color(0xFF2563EB),
    this.backgroundColor = const Color(0xFFE2E8F0),
  });

  final String title;
  final double value;
  final String label;
  final Color color;
  final Color backgroundColor;

  @override
  Widget build(BuildContext context) {
    final clamped = value.clamp(0.0, 1.0);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF1E293B),
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: color,
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(
            value: clamped,
            minHeight: 10,
            backgroundColor: backgroundColor,
            valueColor: AlwaysStoppedAnimation<Color>(color),
          ),
        ),
      ],
    );
  }
}

class MasteryBreakdownChart extends StatefulWidget {
  const MasteryBreakdownChart({
    super.key,
    required this.exceedingCount,
    required this.meetingCount,
    required this.approachingCount,
    required this.developingCount,
    this.title = 'Mastery Level Distribution (Pie)',
  });

  final int exceedingCount;
  final int meetingCount;
  final int approachingCount;
  final int developingCount;
  final String title;

  @override
  State<MasteryBreakdownChart> createState() => _MasteryBreakdownChartState();
}

class _MasteryBreakdownChartState extends State<MasteryBreakdownChart> {
  int? touchedIndex;

  @override
  Widget build(BuildContext context) {
    final total = widget.exceedingCount +
        widget.meetingCount +
        widget.approachingCount +
        widget.developingCount;

    if (total == 0) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFFE2E8F0)),
        ),
        child: const Text(
          'No assessment data recorded yet.',
          style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            widget.title,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: Color(0xFF0F172A),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 180,
            child: PieChart(
              PieChartData(
                pieTouchData: PieTouchData(
                  touchCallback: (FlTouchEvent event, pieTouchResponse) {
                    setState(() {
                      if (pieTouchResponse == null ||
                          pieTouchResponse.touchedSection == null) {
                        touchedIndex = null;
                        return;
                      }
                      touchedIndex =
                          pieTouchResponse.touchedSection!.touchedSectionIndex;
                    });
                  },
                ),
                borderData: FlBorderData(show: false),
                sectionsSpace: 3,
                centerSpaceRadius: 40,
                sections: [
                  if (widget.exceedingCount > 0)
                    PieChartSectionData(
                      color: const Color(0xFF10B981),
                      value: widget.exceedingCount.toDouble(),
                      title: '${widget.exceedingCount}',
                      radius: touchedIndex == 0 ? 55 : 48,
                      titleStyle: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  if (widget.meetingCount > 0)
                    PieChartSectionData(
                      color: const Color(0xFF3B82F6),
                      value: widget.meetingCount.toDouble(),
                      title: '${widget.meetingCount}',
                      radius: touchedIndex == 1 ? 55 : 48,
                      titleStyle: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  if (widget.approachingCount > 0)
                    PieChartSectionData(
                      color: const Color(0xFFF59E0B),
                      value: widget.approachingCount.toDouble(),
                      title: '${widget.approachingCount}',
                      radius: touchedIndex == 2 ? 55 : 48,
                      titleStyle: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  if (widget.developingCount > 0)
                    PieChartSectionData(
                      color: const Color(0xFFEF4444),
                      value: widget.developingCount.toDouble(),
                      title: '${widget.developingCount}',
                      radius: touchedIndex == 3 ? 55 : 48,
                      titleStyle: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 16,
            runSpacing: 8,
            alignment: WrapAlignment.center,
            children: [
              _LegendItem(
                color: const Color(0xFF10B981),
                label: 'Exceeding (${widget.exceedingCount})',
              ),
              _LegendItem(
                color: const Color(0xFF3B82F6),
                label: 'Meeting (${widget.meetingCount})',
              ),
              _LegendItem(
                color: const Color(0xFFF59E0B),
                label: 'Approaching (${widget.approachingCount})',
              ),
              _LegendItem(
                color: const Color(0xFFEF4444),
                label: 'Developing (${widget.developingCount})',
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class MetricBarDatum {
  const MetricBarDatum({
    required this.label,
    required this.primaryValue,
    this.secondaryValue,
  });

  final String label;
  final double primaryValue;
  final double? secondaryValue;
}

class GranularBarChart extends StatelessWidget {
  const GranularBarChart({
    super.key,
    required this.title,
    this.subtitle,
    required this.data,
    required this.primaryLabel,
    this.secondaryLabel,
    this.primaryColor = const Color(0xFF2563EB),
    this.secondaryColor = const Color(0xFFCBD5E1),
    this.maxY,
    this.unitSuffix = '',
  });

  final String title;
  final String? subtitle;
  final List<MetricBarDatum> data;
  final String primaryLabel;
  final String? secondaryLabel;
  final Color primaryColor;
  final Color secondaryColor;
  final double? maxY;
  final String unitSuffix;

  @override
  Widget build(BuildContext context) {
    if (data.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFFE2E8F0)),
        ),
        child: Text(
          '$title — No records available yet.',
          style: const TextStyle(fontSize: 12, color: Color(0xFF64748B)),
        ),
      );
    }

    var computedMax = 5.0;
    for (final d in data) {
      computedMax = math.max(computedMax, d.primaryValue);
      if (d.secondaryValue != null) {
        computedMax = math.max(computedMax, d.secondaryValue!);
      }
    }
    final topY = maxY ?? (computedMax * 1.2).ceilToDouble();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: Color(0xFF0F172A),
            ),
          ),
          if (subtitle != null) ...[
            const SizedBox(height: 2),
            Text(
              subtitle!,
              style: const TextStyle(fontSize: 11, color: Color(0xFF64748B)),
            ),
          ],
          const SizedBox(height: 16),
          SizedBox(
            height: 200,
            child: BarChart(
              BarChartData(
                maxY: topY <= 0 ? 10 : topY,
                alignment: BarChartAlignment.spaceAround,
                barTouchData: BarTouchData(enabled: true),
                gridData: const FlGridData(show: true, drawVerticalLine: false),
                borderData: FlBorderData(show: false),
                titlesData: FlTitlesData(
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 38,
                      getTitlesWidget: (value, meta) => Padding(
                        padding: const EdgeInsets.only(right: 4),
                        child: Text(
                          '${value.toInt()}$unitSuffix',
                          style: const TextStyle(
                            fontSize: 10,
                            color: Color(0xFF64748B),
                          ),
                        ),
                      ),
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 34,
                      getTitlesWidget: (value, meta) {
                        final idx = value.toInt();
                        if (idx < 0 || idx >= data.length) {
                          return const SizedBox.shrink();
                        }
                        return Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: Text(
                            data[idx].label,
                            style: const TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF334155),
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        );
                      },
                    ),
                  ),
                ),
                barGroups: [
                  for (var i = 0; i < data.length; i++)
                    BarChartGroupData(
                      x: i,
                      barsSpace: 4,
                      barRods: [
                        BarChartRodData(
                          toY: data[i].primaryValue,
                          color: primaryColor,
                          width: data[i].secondaryValue != null ? 13 : 20,
                          borderRadius: const BorderRadius.vertical(
                            top: Radius.circular(4),
                          ),
                        ),
                        if (data[i].secondaryValue != null)
                          BarChartRodData(
                            toY: data[i].secondaryValue!,
                            color: secondaryColor,
                            width: 13,
                            borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(4),
                            ),
                          ),
                      ],
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 16,
            runSpacing: 6,
            alignment: WrapAlignment.center,
            children: [
              _LegendItem(color: primaryColor, label: primaryLabel),
              if (secondaryLabel != null)
                _LegendItem(color: secondaryColor, label: secondaryLabel!),
            ],
          ),
        ],
      ),
    );
  }
}

class TrendPoint {
  const TrendPoint({
    required this.label,
    required this.value,
  });

  final String label;
  final double value;
}

class MetricTrendLineChart extends StatelessWidget {
  const MetricTrendLineChart({
    super.key,
    required this.title,
    this.subtitle,
    required this.points,
    this.lineColor = const Color(0xFF2563EB),
    this.maxY = 100,
    this.unitSuffix = '%',
  });

  final String title;
  final String? subtitle;
  final List<TrendPoint> points;
  final Color lineColor;
  final double maxY;
  final String unitSuffix;

  @override
  Widget build(BuildContext context) {
    if (points.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFFE2E8F0)),
        ),
        child: Text(
          '$title — Not enough timestamped records yet.',
          style: const TextStyle(fontSize: 12, color: Color(0xFF64748B)),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: Color(0xFF0F172A),
            ),
          ),
          if (subtitle != null) ...[
            const SizedBox(height: 2),
            Text(
              subtitle!,
              style: const TextStyle(fontSize: 11, color: Color(0xFF64748B)),
            ),
          ],
          const SizedBox(height: 16),
          SizedBox(
            height: 190,
            child: LineChart(
              LineChartData(
                minY: 0,
                maxY: maxY,
                gridData: const FlGridData(show: true, drawVerticalLine: false),
                borderData: FlBorderData(show: false),
                titlesData: FlTitlesData(
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 38,
                      interval: maxY >= 100 ? 25 : null,
                      getTitlesWidget: (value, meta) => Padding(
                        padding: const EdgeInsets.only(right: 4),
                        child: Text(
                          '${value.toInt()}$unitSuffix',
                          style: const TextStyle(
                            fontSize: 10,
                            color: Color(0xFF64748B),
                          ),
                        ),
                      ),
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 30,
                      interval: 1,
                      getTitlesWidget: (value, meta) {
                        final idx = value.toInt();
                        if (idx < 0 || idx >= points.length) {
                          return const SizedBox.shrink();
                        }
                        return Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: Text(
                            points[idx].label,
                            style: const TextStyle(
                              fontSize: 10,
                              color: Color(0xFF475569),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                lineBarsData: [
                  LineChartBarData(
                    spots: [
                      for (var i = 0; i < points.length; i++)
                        FlSpot(i.toDouble(), points[i].value),
                    ],
                    isCurved: points.length > 2,
                    color: lineColor,
                    barWidth: 3,
                    dotData: const FlDotData(show: true),
                    belowBarData: BarAreaData(
                      show: true,
                      color: lineColor.withOpacity(0.12),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ScoreCandlestickChart extends StatelessWidget {
  const ScoreCandlestickChart({
    super.key,
    required this.title,
    this.subtitle,
    required this.candles,
  });

  final String title;
  final String? subtitle;
  final List<ScoreCandlestickDatum> candles;

  @override
  Widget build(BuildContext context) {
    if (candles.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFFE2E8F0)),
        ),
        child: Text(
          '$title — No score candles available yet.',
          style: const TextStyle(fontSize: 12, color: Color(0xFF64748B)),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: Color(0xFF0F172A),
            ),
          ),
          if (subtitle != null) ...[
            const SizedBox(height: 2),
            Text(
              subtitle!,
              style: const TextStyle(fontSize: 11, color: Color(0xFF64748B)),
            ),
          ],
          const SizedBox(height: 14),
          SizedBox(
            height: 195,
            child: CustomPaint(
              painter: _CandlestickPainter(candles),
              child: const SizedBox.expand(),
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 14,
            runSpacing: 6,
            alignment: WrapAlignment.center,
            children: const [
              _LegendItem(
                color: Color(0xFF10B981),
                label: 'Gain / Steady (Open -> Latest Close)',
              ),
              _LegendItem(
                color: Color(0xFFEF4444),
                label: 'Decline (Latest < Open)',
              ),
              _LegendItem(
                color: Color(0xFF64748B),
                label: 'Wick = Min to Max Score',
              ),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: candles.map((c) {
              final gain = c.closeScore >= c.openScore;
              return Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8FAFC),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: const Color(0xFFE2E8F0)),
                ),
                child: Text(
                  '${c.label}: Open ${c.openScore.round()}% -> Close ${c.closeScore.round()}% (Range ${c.lowScore.round()}-${c.highScore.round()}%, n=${c.sampleCount})',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: gain
                        ? const Color(0xFF065F46)
                        : const Color(0xFF991B1B),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

class _CandlestickPainter extends CustomPainter {
  _CandlestickPainter(this.candles);

  final List<ScoreCandlestickDatum> candles;

  @override
  void paint(Canvas canvas, Size size) {
    const leftPad = 36.0;
    const rightPad = 12.0;
    const topPad = 12.0;
    const bottomPad = 26.0;

    final chartWidth = size.width - leftPad - rightPad;
    final chartHeight = size.height - topPad - bottomPad;
    if (chartWidth <= 0 || chartHeight <= 0 || candles.isEmpty) return;

    double yForScore(double score) {
      final clamped = score.clamp(0.0, 100.0);
      return topPad + chartHeight * (1 - clamped / 100.0);
    }

    final gridPaint = Paint()
      ..color = const Color(0xFFE2E8F0)
      ..strokeWidth = 1;

    for (final tick in [0, 25, 50, 75, 100]) {
      final y = yForScore(tick.toDouble());
      canvas.drawLine(Offset(leftPad, y), Offset(size.width - rightPad, y), gridPaint);
      final tp = TextPainter(
        text: TextSpan(
          text: '$tick%',
          style: const TextStyle(fontSize: 10, color: Color(0xFF64748B)),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(leftPad - tp.width - 6, y - tp.height / 2));
    }

    final slotWidth = chartWidth / candles.length;
    final bodyWidth = math.min(28.0, slotWidth * 0.42);

    for (var i = 0; i < candles.length; i++) {
      final c = candles[i];
      final cx = leftPad + slotWidth * (i + 0.5);
      final yHigh = yForScore(c.highScore);
      final yLow = yForScore(c.lowScore);
      final yOpen = yForScore(c.openScore);
      final yClose = yForScore(c.closeScore);

      final isBull = c.closeScore >= c.openScore;
      final candleColor =
          isBull ? const Color(0xFF10B981) : const Color(0xFFEF4444);

      final wickPaint = Paint()
        ..color = const Color(0xFF475569)
        ..strokeWidth = 2;
      canvas.drawLine(Offset(cx, yHigh), Offset(cx, yLow), wickPaint);

      final bodyTop = math.min(yOpen, yClose);
      final bodyBottom = math.max(yOpen, yClose);
      final rect = Rect.fromLTRB(
        cx - bodyWidth / 2,
        bodyTop,
        cx + bodyWidth / 2,
        math.max(bodyTop + 6, bodyBottom),
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect, const Radius.circular(3)),
        Paint()..color = candleColor,
      );

      final labelPainter = TextPainter(
        text: TextSpan(
          text: c.label,
          style: const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w700,
            color: Color(0xFF1E293B),
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      labelPainter.paint(
        canvas,
        Offset(cx - labelPainter.width / 2, size.height - bottomPad + 6),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _CandlestickPainter oldDelegate) =>
      oldDelegate.candles != candles;
}

class AuditAttributionPill extends StatelessWidget {
  const AuditAttributionPill({
    super.key,
    required this.who,
    required this.when,
  });

  final String who;
  final String when;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: const Color(0xFFF1F5F9),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.history, size: 12, color: Color(0xFF475569)),
          const SizedBox(width: 4),
          Flexible(
            child: Text(
              '$who · $when',
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w600,
                color: Color(0xFF475569),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _LegendItem extends StatelessWidget {
  const _LegendItem({required this.color, required this.label});
  final Color color;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          style: const TextStyle(
            fontSize: 11,
            color: Color(0xFF475569),
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}
