import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../features/admin_dashboard/domain/syllabus_coverage_system.dart';
import '../../features/assessment_books/domain/assessment_entry.dart';
import '../../features/class_register/domain/attendance_record.dart';
import '../../features/lesson_plans/domain/lesson_plan.dart';
import '../ecs/ecs_seed_data.dart';
import '../ecs/school_entity.dart';

class AdminAiBriefingCard extends StatefulWidget {
  const AdminAiBriefingCard({
    super.key,
    required this.ecsState,
    this.apiBaseUrl = '',
  });

  final SchoolEcsState ecsState;
  final String apiBaseUrl;

  @override
  State<AdminAiBriefingCard> createState() => _AdminAiBriefingCardState();
}

class _AdminAiBriefingCardState extends State<AdminAiBriefingCard> {
  bool _loading = false;
  String? _error;
  Map<String, dynamic>? _summary;
  String? _generatedAt;

  Map<String, dynamic> _buildSnapshot(SchoolEcsState state) {
    final substrands = SyllabusCoverageSystem.computeSubstrandCoverage(state);
    final teachers = SyllabusCoverageSystem.computeTeacherSummaries(state);

    String learnerName(String id) =>
        state.learners.where((l) => l.id == id).firstOrNull?.name ?? id;
    String subjectName(String id) =>
        state.subjects.where((s) => s.id == id).firstOrNull?.name ?? id;
    String teacherName(String id) =>
        state.teachers.where((t) => t.id == id).firstOrNull?.name ?? id;
    String classroomName(String id) =>
        state.classrooms.where((c) => c.id == id).firstOrNull?.name ?? id;

    final pendingDiaries = state.diaryEntries
        .where((d) => !d.parentAcknowledged)
        .map((d) => {
              'date': d.date,
              'learner': learnerName(d.learnerId),
              'homework': d.homeworkSummary,
              'note': d.teacherNote,
            })
        .toList();

    final lowMastery = state.assessments
        .where((a) =>
            a.mastery == MasteryLevel.approaching ||
            a.mastery == MasteryLevel.developing)
        .map((a) => {
              'learner': learnerName(a.learnerId),
              'subject': subjectName(a.subjectId),
              'mastery': a.mastery.label,
              'scorePercent': a.scorePercent,
              'comment': a.performanceComment,
            })
        .toList();

    final topMastery = state.assessments
        .where((a) =>
            a.mastery == MasteryLevel.exceeding ||
            a.mastery == MasteryLevel.meeting)
        .map((a) => {
              'learner': learnerName(a.learnerId),
              'subject': subjectName(a.subjectId),
              'mastery': a.mastery.label,
              'scorePercent': a.scorePercent,
              'comment': a.performanceComment,
            })
        .toList();

    final attendanceIssues = state.attendanceRecords
        .where((r) =>
            r.status != AttendanceStatus.present ||
            r.customFields['uniform_compliant'] == false)
        .map((r) => {
              'date': r.date,
              'learner': learnerName(r.learnerId),
              'status': r.status.label,
              'uniformCompliant': r.customFields['uniform_compliant'] != false,
              'remark': r.remark,
            })
        .toList();

    final unscheduledPlans = state.lessonPlans
        .where((lp) =>
            (lp.timetableSlotId == null || lp.timetableSlotId!.isEmpty) &&
            lp.status != LessonStatus.taught)
        .map((lp) => {
              'title': lp.title,
              'teacher': teacherName(lp.teacherId),
              'classroom': classroomName(lp.classroomId),
              'scheduledDate': lp.scheduledDate,
            })
        .toList();

    return {
      'counts': {
        'learners': state.learners.length,
        'classrooms': state.classrooms.length,
        'teachers': state.teachers.length,
        'strands': state.strands.length,
        'substrands': state.substrands.length,
        'lessonPlansTotal': state.lessonPlans.length,
        'lessonPlansTaught': state.lessonPlans
            .where((lp) => lp.status == LessonStatus.taught)
            .length,
        'diaryEntriesTotal': state.diaryEntries.length,
        'diarySignedCount':
            state.diaryEntries.where((d) => d.parentAcknowledged).length,
        'attendanceRecordsTotal': state.attendanceRecords.length,
        'attendancePresentCount': state.attendanceRecords
            .where((a) => a.status == AttendanceStatus.present)
            .length,
      },
      'upcomingCalendarEvents': state.schoolEvents
          .map((e) => {
                'date': e.date,
                'title': e.title,
                'kind': e.kind,
                'description': e.description,
              })
          .toList(),
      'teacherRollups': teachers
          .map((t) => {
                'teacher': t.teacher.name,
                'taughtPlans': t.taughtPlans,
                'totalPlans': t.totalPlans,
                'lessonsDelivered': t.totalLessonsDelivered,
                'assessmentsLogged': t.assessmentsLogged,
                'diaryEntriesLogged': t.diaryEntriesLogged,
              })
          .toList(),
      'substrandCoverage': substrands
          .map((s) => {
                'subject': s.subject?.name ?? s.substrand.subjectId,
                'substrand': '${s.substrand.code} ${s.substrand.title}',
                'coveragePercent': s.coveragePercent,
                'deliveredLessons': s.deliveredLessons,
                'targetLessons': s.targetLessons,
              })
          .toList(),
      'alertsContext': {
        'pendingParentDiarySignoffs': pendingDiaries,
        'lowMasteryAssessments': lowMastery,
        'attendanceOrUniformFlags': attendanceIssues,
        'unscheduledLessonPlans': unscheduledPlans,
      },
      'highlightsContext': {
        'strongAssessments': topMastery,
        'recentReflections': state.lessonPlans
            .where((lp) =>
                lp.status == LessonStatus.taught &&
                lp.reflectionNote.isNotEmpty)
            .map((lp) => {
                  'title': lp.title,
                  'reflection': lp.reflectionNote,
                })
            .toList(),
      },
    };
  }

  Future<void> _generateBriefing() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final uri = Uri.parse('${widget.apiBaseUrl}/api/admin/ai-summary');
      final response = await http.post(
        uri,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'role': 'admin',
          'snapshot': _buildSnapshot(widget.ecsState),
        }),
      );
      final decoded = jsonDecode(response.body) as Map<String, dynamic>;
      if (response.statusCode < 200 || response.statusCode >= 300) {
        setState(() {
          _error = (decoded['error'] as String?) ??
              'Request failed (${response.statusCode}).';
          _loading = false;
        });
        return;
      }
      setState(() {
        _summary = decoded['summary'] as Map<String, dynamic>?;
        _generatedAt = decoded['generatedAt'] as String?;
        _loading = false;
      });
    } catch (err) {
      setState(() {
        _error = 'Failed to fetch AI briefing: $err';
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final alerts =
        (_summary?['urgentAlerts'] as List<dynamic>? ?? const <dynamic>[])
            .cast<Map<String, dynamic>>();
    final highlights =
        (_summary?['positiveHighlights'] as List<dynamic>? ?? const <dynamic>[])
            .cast<Map<String, dynamic>>();
    final workflows =
        (_summary?['workflowStatuses'] as List<dynamic>? ?? const <dynamic>[])
            .cast<Map<String, dynamic>>();

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFFF5F7FF),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFC7D2FE)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 12,
            runSpacing: 12,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xFF4F46E5),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(
                      Icons.auto_awesome,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'AI Admin Operations Briefing',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF0F172A),
                        ),
                      ),
                      Text(
                        'gemini-4-hydrogen · Summarizes alerts, positive highlights & workflow health',
                        style: TextStyle(
                          fontSize: 11,
                          color: Color(0xFF475569),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              FilledButton.icon(
                onPressed: _loading ? null : _generateBriefing,
                icon: _loading
                    ? const SizedBox(
                        width: 14,
                        height: 14,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : Icon(
                        _summary == null ? Icons.auto_awesome : Icons.refresh,
                        size: 16,
                      ),
                label: Text(
                  _loading
                      ? 'Summarizing...'
                      : (_summary == null
                          ? 'Generate AI Briefing'
                          : 'Refresh Summary'),
                ),
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF4F46E5),
                ),
              ),
            ],
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFEF2F2),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFFECACA)),
              ),
              child: Text(
                _error!,
                style: const TextStyle(fontSize: 12, color: Color(0xFF991B1B)),
              ),
            ),
          ],
          if (_summary == null && _error == null && !_loading) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFE0E7FF)),
              ),
              child: const Text(
                'Generate an executive AI summary of pending parent sign-offs, learner mastery alerts, well-going events, and workflow progress.',
                style: TextStyle(fontSize: 12, color: Color(0xFF475569)),
              ),
            ),
          ],
          if (_summary != null) ...[
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'EXECUTIVE OVERVIEW',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF64748B),
                        ),
                      ),
                      if (_generatedAt != null)
                        Text(
                          _generatedAt!,
                          style: const TextStyle(
                            fontSize: 10,
                            color: Color(0xFF94A3B8),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    (_summary!['executiveOverview'] as String?) ?? '',
                    style: const TextStyle(
                      fontSize: 13,
                      color: Color(0xFF1E293B),
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
            if (alerts.isNotEmpty) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFFDE68A)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'ALERTS & ATTENTION (${alerts.length})',
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF92400E),
                      ),
                    ),
                    const SizedBox(height: 8),
                    ...alerts.map(
                      (a) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '[${(a['severity'] ?? 'medium').toString().toUpperCase()}] ${a['area'] ?? ''}',
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: Color(0xFF0F172A),
                              ),
                            ),
                            Text(
                              '${a['summary'] ?? ''}',
                              style: const TextStyle(
                                fontSize: 12,
                                color: Color(0xFF475569),
                              ),
                            ),
                            Text(
                              'Next: ${a['recommendedAction'] ?? ''}',
                              style: const TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF4338CA),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            if (highlights.isNotEmpty) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFA7F3D0)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'WELL-GOING EVENTS & HIGHLIGHTS (${highlights.length})',
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF065F46),
                      ),
                    ),
                    const SizedBox(height: 8),
                    ...highlights.map(
                      (h) => Padding(
                        padding: const EdgeInsets.only(bottom: 6),
                        child: Text(
                          '• ${h['area'] ?? ''}: ${h['comment'] ?? ''}',
                          style: const TextStyle(
                            fontSize: 12,
                            color: Color(0xFF1E293B),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            if (workflows.isNotEmpty) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFE2E8F0)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'WORKFLOW STATUSES',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF64748B),
                      ),
                    ),
                    const SizedBox(height: 8),
                    ...workflows.map(
                      (w) => Padding(
                        padding: const EdgeInsets.only(bottom: 6),
                        child: Text(
                          '• ${w['workflow'] ?? ''} (${(w['status'] ?? 'smooth').toString().toUpperCase()}): ${w['summary'] ?? ''}',
                          style: const TextStyle(
                            fontSize: 12,
                            color: Color(0xFF334155),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ],
      ),
    );
  }
}
