import 'package:flutter/material.dart';

enum ActionFeedbackKind {
  success,
  info,
  warning,
  error,
}

void showActionSnackBar(
  BuildContext context, {
  required ActionFeedbackKind kind,
  required String message,
  Duration duration = const Duration(seconds: 3),
}) {
  if (!context.mounted) return;
  final (Color bg, IconData icon) = switch (kind) {
    ActionFeedbackKind.success => (
        const Color(0xFF047857),
        Icons.check_circle_outline,
      ),
    ActionFeedbackKind.info => (
        const Color(0xFF1D4ED8),
        Icons.info_outline,
      ),
    ActionFeedbackKind.warning => (
        const Color(0xFFB45309),
        Icons.warning_amber_rounded,
      ),
    ActionFeedbackKind.error => (
        const Color(0xFFB91C1C),
        Icons.error_outline,
      ),
  };

  final messenger = ScaffoldMessenger.of(context);
  messenger.hideCurrentSnackBar();
  messenger.showSnackBar(
    SnackBar(
      behavior: SnackBarBehavior.floating,
      duration: duration,
      backgroundColor: bg,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      content: Row(
        children: [
          Icon(icon, color: Colors.white, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              message,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

mixin BusyActionMixin<T extends StatefulWidget> on State<T> {
  bool isBusy = false;

  Future<R?> runLockedAction<R>(
    Future<R> Function() action, {
    void Function(Object error)? onError,
  }) async {
    if (isBusy) return null;
    setState(() => isBusy = true);
    try {
      return await action();
    } catch (err) {
      if (onError != null) {
        onError(err);
      } else if (mounted) {
        showActionSnackBar(
          context,
          kind: ActionFeedbackKind.error,
          message: err.toString(),
        );
      }
      return null;
    } finally {
      if (mounted) {
        setState(() => isBusy = false);
      }
    }
  }
}
