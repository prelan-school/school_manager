class AuditLogEntry {
  const AuditLogEntry({
    required this.id,
    required this.timestamp,
    required this.actorId,
    required this.actorName,
    required this.actorRole,
    required this.action,
    required this.entityType,
    required this.entityId,
    required this.targetLabel,
    required this.detail,
    this.classroomId,
    this.teacherId,
    this.learnerId,
  });

  final String id;
  final String timestamp; // ISO-8601 YYYY-MM-DDTHH:mm:ss
  final String actorId;
  final String actorName;
  final String actorRole; // admin | teacher | parent
  final String action; // created | updated | taught | signed | assigned | deleted | recorded
  final String entityType; // classroom | lesson_plan | assessment_entry | diary_entry | attendance_record | learner | school_event | timetable_slot | scheme_strand | scheme_substrand | dynamic_field | page_widget
  final String entityId;
  final String targetLabel;
  final String detail;
  final String? classroomId;
  final String? teacherId;
  final String? learnerId;

  String get datePart =>
      timestamp.length >= 10 ? timestamp.substring(0, 10) : timestamp;

  String get timePart =>
      timestamp.length >= 16 ? timestamp.substring(11, 16) : '';

  factory AuditLogEntry.fromMap(String id, Map<String, dynamic> map) {
    return AuditLogEntry(
      id: id,
      timestamp: map['timestamp'] as String? ?? '',
      actorId: map['actorId'] as String? ?? '',
      actorName: map['actorName'] as String? ?? 'System',
      actorRole: map['actorRole'] as String? ?? 'admin',
      action: map['action'] as String? ?? 'updated',
      entityType: map['entityType'] as String? ?? '',
      entityId: map['entityId'] as String? ?? '',
      targetLabel: map['targetLabel'] as String? ?? '',
      detail: map['detail'] as String? ?? '',
      classroomId: map['classroomId'] as String?,
      teacherId: map['teacherId'] as String?,
      learnerId: map['learnerId'] as String?,
    );
  }

  Map<String, dynamic> toMap() => {
        'timestamp': timestamp,
        'actorId': actorId,
        'actorName': actorName,
        'actorRole': actorRole,
        'action': action,
        'entityType': entityType,
        'entityId': entityId,
        'targetLabel': targetLabel,
        'detail': detail,
        'classroomId': classroomId,
        'teacherId': teacherId,
        'learnerId': learnerId,
      };
}
