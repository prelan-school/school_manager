enum PortalRole {
  admin('admin', 'Admin Side'),
  teacher('teacher', 'Teacher Side'),
  parent('parent', 'Parent Portal');

  const PortalRole(this.key, this.label);
  final String key;
  final String label;

  static PortalRole fromKey(String? raw) {
    return PortalRole.values.firstWhere(
      (r) => r.key == raw,
      orElse: () => PortalRole.parent,
    );
  }
}

enum EntityType {
  learner('learner'),
  diaryEntry('diary_entry'),
  schemeStrand('scheme_strand'),
  schemeSubstrand('scheme_substrand'),
  assessmentEntry('assessment_entry'),
  lessonPlan('lesson_plan'),
  timetableSlot('timetable_slot'),
  scheduleDay('schedule_day'),
  attendanceRecord('attendance_record'),
  location('location');

  const EntityType(this.key);
  final String key;

  static EntityType fromKey(String raw) {
    return EntityType.values.firstWhere(
      (e) => e.key == raw,
      orElse: () => EntityType.diaryEntry,
    );
  }
}

enum DynamicFieldType {
  text('text'),
  number('number'),
  boolean('boolean'),
  select('select'),
  date('date');

  const DynamicFieldType(this.key);
  final String key;

  static DynamicFieldType fromKey(String? raw) {
    return DynamicFieldType.values.firstWhere(
      (t) => t.key == raw,
      orElse: () => DynamicFieldType.text,
    );
  }
}

class DynamicFieldDefinition {
  const DynamicFieldDefinition({
    required this.id,
    required this.targetEntityType,
    required this.key,
    required this.label,
    required this.fieldType,
    this.options = const [],
    this.required = false,
    required this.visibleTo,
    required this.editableBy,
    required this.description,
    this.archived = false,
  });

  final String id;
  final EntityType targetEntityType;
  final String key;
  final String label;
  final DynamicFieldType fieldType;
  final List<String> options;
  final bool required;
  final List<PortalRole> visibleTo;
  final List<PortalRole> editableBy;
  final String description;
  final bool archived;

  bool isVisibleTo(PortalRole role) => visibleTo.contains(role);
  bool isEditableBy(PortalRole role) => editableBy.contains(role);

  DynamicFieldDefinition copyWith({
    EntityType? targetEntityType,
    String? key,
    String? label,
    DynamicFieldType? fieldType,
    List<String>? options,
    bool? required,
    List<PortalRole>? visibleTo,
    List<PortalRole>? editableBy,
    String? description,
    bool? archived,
  }) {
    return DynamicFieldDefinition(
      id: id,
      targetEntityType: targetEntityType ?? this.targetEntityType,
      key: key ?? this.key,
      label: label ?? this.label,
      fieldType: fieldType ?? this.fieldType,
      options: options ?? this.options,
      required: required ?? this.required,
      visibleTo: visibleTo ?? this.visibleTo,
      editableBy: editableBy ?? this.editableBy,
      description: description ?? this.description,
      archived: archived ?? this.archived,
    );
  }

  factory DynamicFieldDefinition.fromMap(String id, Map<String, dynamic> map) {
    return DynamicFieldDefinition(
      id: id,
      targetEntityType: EntityType.fromKey(map['targetEntityType'] as String? ?? ''),
      key: map['key'] as String? ?? '',
      label: map['label'] as String? ?? '',
      fieldType: DynamicFieldType.fromKey(map['fieldType'] as String?),
      options: List<String>.from(map['options'] as List<dynamic>? ?? const []),
      required: map['required'] as bool? ?? false,
      visibleTo: (map['visibleTo'] as List<dynamic>? ?? const ['admin'])
          .map((e) => PortalRole.fromKey(e as String?))
          .toList(),
      editableBy: (map['editableBy'] as List<dynamic>? ?? const ['admin'])
          .map((e) => PortalRole.fromKey(e as String?))
          .toList(),
      description: map['description'] as String? ?? '',
      archived: map['archived'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toMap() => {
        'targetEntityType': targetEntityType.key,
        'key': key,
        'label': label,
        'fieldType': fieldType.key,
        'options': options,
        'required': required,
        'visibleTo': visibleTo.map((r) => r.key).toList(),
        'editableBy': editableBy.map((r) => r.key).toList(),
        'description': description,
        'archived': archived,
      };
}

enum PageWidgetId {
  learnerOverview('learner_overview'),
  learnerTimeline('learner_timeline'),
  learnerAssessments('learner_assessments'),
  learnerDiary('learner_diary'),
  learnerAttendance('learner_attendance'),
  learnerTimetable('learner_timetable'),
  learnerEnrollment('learner_enrollment');

  const PageWidgetId(this.key);
  final String key;

  static PageWidgetId fromKey(String? raw) {
    return PageWidgetId.values.firstWhere(
      (w) => w.key == raw,
      orElse: () => PageWidgetId.learnerOverview,
    );
  }
}

class PageWidgetDefinition {
  const PageWidgetDefinition({
    required this.id,
    required this.pageId,
    required this.title,
    required this.description,
    required this.allowedRoles,
    required this.order,
    required this.enabled,
  });

  final PageWidgetId id;
  final String pageId;
  final String title;
  final String description;
  final List<PortalRole> allowedRoles;
  final int order;
  final bool enabled;

  PageWidgetDefinition copyWith({
    List<PortalRole>? allowedRoles,
    int? order,
    bool? enabled,
  }) {
    return PageWidgetDefinition(
      id: id,
      pageId: pageId,
      title: title,
      description: description,
      allowedRoles: allowedRoles ?? this.allowedRoles,
      order: order ?? this.order,
      enabled: enabled ?? this.enabled,
    );
  }

  factory PageWidgetDefinition.fromMap(String id, Map<String, dynamic> map) {
    return PageWidgetDefinition(
      id: PageWidgetId.fromKey(id),
      pageId: map['pageId'] as String? ?? 'learner_profile',
      title: map['title'] as String? ?? '',
      description: map['description'] as String? ?? '',
      allowedRoles: (map['allowedRoles'] as List<dynamic>? ?? const ['admin'])
          .map((r) => PortalRole.fromKey(r as String?))
          .toList(),
      order: (map['order'] as num?)?.toInt() ?? 0,
      enabled: map['enabled'] as bool? ?? true,
    );
  }

  Map<String, dynamic> toMap() => {
        'pageId': pageId,
        'title': title,
        'description': description,
        'allowedRoles': allowedRoles.map((r) => r.key).toList(),
        'order': order,
        'enabled': enabled,
      };
}

class SubjectEntity {
  const SubjectEntity({
    required this.id,
    required this.code,
    required this.name,
  });

  final String id;
  final String code;
  final String name;

  factory SubjectEntity.fromMap(String id, Map<String, dynamic> map) {
    return SubjectEntity(
      id: id,
      code: map['code'] as String? ?? '',
      name: map['name'] as String? ?? '',
    );
  }

  Map<String, dynamic> toMap() => {
        'code': code,
        'name': name,
      };
}

class ClassroomEntity {
  const ClassroomEntity({
    required this.id,
    required this.name,
    required this.gradeLevel,
    this.roomCode = 'B2-04',
    this.classTeacherId,
    this.updatedBy,
    this.updatedAt,
  });

  final String id;
  final String name;
  final String gradeLevel;
  final String roomCode;
  final String? classTeacherId;
  final String? updatedBy;
  final String? updatedAt;

  ClassroomEntity copyWith({
    String? name,
    String? gradeLevel,
    String? roomCode,
    String? classTeacherId,
    bool clearClassTeacher = false,
    String? updatedBy,
    String? updatedAt,
  }) {
    return ClassroomEntity(
      id: id,
      name: name ?? this.name,
      gradeLevel: gradeLevel ?? this.gradeLevel,
      roomCode: roomCode ?? this.roomCode,
      classTeacherId:
          clearClassTeacher ? null : (classTeacherId ?? this.classTeacherId),
      updatedBy: updatedBy ?? this.updatedBy,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  factory ClassroomEntity.fromMap(String id, Map<String, dynamic> map) {
    return ClassroomEntity(
      id: id,
      name: map['name'] as String? ?? '',
      gradeLevel: map['gradeLevel'] as String? ?? '',
      roomCode: map['roomCode'] as String? ?? 'B2-04',
      classTeacherId: map['classTeacherId'] as String?,
      updatedBy: map['updatedBy'] as String?,
      updatedAt: map['updatedAt'] as String?,
    );
  }

  Map<String, dynamic> toMap() => {
        'name': name,
        'gradeLevel': gradeLevel,
        'roomCode': roomCode,
        'classTeacherId': classTeacherId,
        'updatedBy': updatedBy,
        'updatedAt': updatedAt,
      };
}

class LocationEntity {
  const LocationEntity({
    required this.id,
    required this.name,
    required this.zone,
    this.notes = '',
    this.updatedBy,
    this.updatedAt,
  });

  final String id;
  final String name;
  final String zone;
  final String notes;
  final String? updatedBy;
  final String? updatedAt;

  LocationEntity copyWith({
    String? name,
    String? zone,
    String? notes,
    String? updatedBy,
    String? updatedAt,
  }) {
    return LocationEntity(
      id: id,
      name: name ?? this.name,
      zone: zone ?? this.zone,
      notes: notes ?? this.notes,
      updatedBy: updatedBy ?? this.updatedBy,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  factory LocationEntity.fromMap(String id, Map<String, dynamic> map) {
    return LocationEntity(
      id: id,
      name: map['name'] as String? ?? '',
      zone: map['zone'] as String? ?? 'General Catchment',
      notes: map['notes'] as String? ?? '',
      updatedBy: map['updatedBy'] as String?,
      updatedAt: map['updatedAt'] as String?,
    );
  }

  Map<String, dynamic> toMap() => {
        'name': name,
        'zone': zone,
        'notes': notes,
        'updatedBy': updatedBy,
        'updatedAt': updatedAt,
      };
}

class ScheduleDayEntity {
  const ScheduleDayEntity({
    required this.id,
    required this.code,
    required this.label,
    required this.order,
    required this.classroomIds,
    this.defaultTimeRange = '08:00 - 08:45',
  });

  final String id;
  final String code;
  final String label;
  final int order;
  final List<String> classroomIds;
  final String defaultTimeRange;

  ScheduleDayEntity copyWith({
    String? code,
    String? label,
    int? order,
    List<String>? classroomIds,
    String? defaultTimeRange,
  }) {
    return ScheduleDayEntity(
      id: id,
      code: code ?? this.code,
      label: label ?? this.label,
      order: order ?? this.order,
      classroomIds: classroomIds ?? this.classroomIds,
      defaultTimeRange: defaultTimeRange ?? this.defaultTimeRange,
    );
  }

  factory ScheduleDayEntity.fromMap(String id, Map<String, dynamic> map) {
    return ScheduleDayEntity(
      id: id,
      code: map['code'] as String? ?? id,
      label: map['label'] as String? ?? (map['code'] as String? ?? id),
      order: (map['order'] as num?)?.toInt() ?? 1,
      classroomIds: List<String>.from(
        map['classroomIds'] as List<dynamic>? ?? const [],
      ),
      defaultTimeRange: map['defaultTimeRange'] as String? ?? '08:00 - 08:45',
    );
  }

  Map<String, dynamic> toMap() => {
        'code': code,
        'label': label,
        'order': order,
        'classroomIds': classroomIds,
        'defaultTimeRange': defaultTimeRange,
      };
}

class TeacherEntity {
  const TeacherEntity({
    required this.id,
    required this.name,
    required this.email,
    required this.subjectIds,
  });

  final String id;
  final String name;
  final String email;
  final List<String> subjectIds;
  List<String> get subjectSpecialties => subjectIds;

  factory TeacherEntity.fromMap(String id, Map<String, dynamic> map) {
    return TeacherEntity(
      id: id,
      name: map['name'] as String? ?? '',
      email: map['email'] as String? ?? '',
      subjectIds: List<String>.from(map['subjectIds'] as List<dynamic>? ?? const []),
    );
  }

  Map<String, dynamic> toMap() => {
        'name': name,
        'email': email,
        'subjectIds': subjectIds,
      };
}

String slugifyFieldKey(String label) {
  return label
      .trim()
      .toLowerCase()
      .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
      .replaceAll(RegExp(r'^_+|_+$'), '');
}

extension IterableFirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
