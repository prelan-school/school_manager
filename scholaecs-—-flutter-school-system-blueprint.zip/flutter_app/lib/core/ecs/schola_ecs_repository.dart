import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../features/assessment_books/domain/assessment_entry.dart';
import '../../features/auth/domain/auth_user.dart';
import '../../features/class_register/domain/attendance_record.dart';
import '../../features/home/domain/school_event.dart';
import '../../features/learners/domain/learner.dart';
import '../../features/lesson_plans/domain/lesson_plan.dart';
import '../../features/schemes/domain/scheme_nodes.dart';
import '../../features/school_diary/domain/diary_entry.dart';
import '../../features/timetable/domain/timetable_slot.dart';
import 'audit_log.dart';
import 'ecs_seed_data.dart';
import 'school_entity.dart';

class SchoolEcsNotifier extends StateNotifier<SchoolEcsState> {
  SchoolEcsNotifier({
    required this.useFirestore,
    FirebaseFirestore? firestore,
    AuthUser? currentUser,
  })  : _db = firestore,
        _currentUser = currentUser,
        super(initialSchoolEcsState) {
    if (useFirestore && _db != null && currentUser != null) {
      _startFirestoreSubscriptions(currentUser);
    }
  }

  final bool useFirestore;
  final FirebaseFirestore? _db;
  final AuthUser? _currentUser;
  final List<StreamSubscription<dynamic>> _subscriptions = [];

  String get _actorId => _currentUser?.uid ?? 'demo_admin';
  String get _actorName => _currentUser?.displayName ?? 'Default Admin';
  String get _actorRole => _currentUser?.role.key ?? PortalRole.admin.key;
  String _nowIso() => DateTime.now().toIso8601String().substring(0, 19);

  Future<void> _recordAudit({
    required String action,
    required String entityType,
    required String entityId,
    required String targetLabel,
    required String detail,
    String? actorId,
    String? actorName,
    String? actorRole,
    String? classroomId,
    String? teacherId,
    String? learnerId,
  }) async {
    final ts = _nowIso();
    final entry = AuditLogEntry(
      id: 'aud_${DateTime.now().microsecondsSinceEpoch}',
      timestamp: ts,
      actorId: actorId ?? _actorId,
      actorName: actorName ?? _actorName,
      actorRole: actorRole ?? _actorRole,
      action: action,
      entityType: entityType,
      entityId: entityId,
      targetLabel: targetLabel,
      detail: detail,
      classroomId: classroomId,
      teacherId: teacherId,
      learnerId: learnerId,
    );
    state = state.copyWith(auditLogs: [entry, ...state.auditLogs]);
    if (useFirestore && _db != null) {
      await _db.collection('audit_logs').doc(entry.id).set(entry.toMap());
    }
  }

  void _startFirestoreSubscriptions(AuthUser user) {
    final db = _db;
    if (db == null) return;
    _cancelSubscriptions();

    void handleSyncError(Object err) {
      state = state.copyWith(syncError: err.toString());
    }

    _subscriptions.add(
      db.collection('subjects').snapshots().listen(
        (snap) {
          if (snap.docs.isEmpty) return;
          state = state.copyWith(
            subjects: snap.docs
                .map((d) => SubjectEntity.fromMap(d.id, d.data()))
                .toList(),
            isLiveSynced: true,
          );
        },
        onError: handleSyncError,
      ),
    );

    _subscriptions.add(
      db.collection('classrooms').snapshots().listen(
        (snap) {
          if (snap.docs.isEmpty) return;
          state = state.copyWith(
            classrooms: snap.docs
                .map((d) => ClassroomEntity.fromMap(d.id, d.data()))
                .toList(),
            isLiveSynced: true,
          );
        },
        onError: handleSyncError,
      ),
    );

    _subscriptions.add(
      db.collection('teachers').snapshots().listen(
        (snap) {
          if (snap.docs.isEmpty) return;
          state = state.copyWith(
            teachers: snap.docs
                .map((d) => TeacherEntity.fromMap(d.id, d.data()))
                .toList(),
            isLiveSynced: true,
          );
        },
        onError: handleSyncError,
      ),
    );

    _subscriptions.add(
      db.collection('component_schemas').snapshots().listen(
        (snap) {
          if (snap.docs.isEmpty) return;
          state = state.copyWith(
            dynamicFields: snap.docs
                .map((d) => DynamicFieldDefinition.fromMap(d.id, d.data()))
                .toList(),
            isLiveSynced: true,
          );
        },
        onError: handleSyncError,
      ),
    );

    _subscriptions.add(
      db.collection('page_widgets').snapshots().listen(
        (snap) {
          if (snap.docs.isEmpty) return;
          final widgets = snap.docs
              .map((d) => PageWidgetDefinition.fromMap(d.id, d.data()))
              .toList()
            ..sort((a, b) => a.order.compareTo(b.order));
          state = state.copyWith(pageWidgets: widgets, isLiveSynced: true);
        },
        onError: handleSyncError,
      ),
    );

    _subscriptions.add(
      db.collection('scheme_strands').snapshots().listen(
        (snap) {
          if (snap.docs.isEmpty) return;
          state = state.copyWith(
            strands: snap.docs
                .map((d) => SchemeStrandEntity.fromMap(d.id, d.data()))
                .toList(),
            isLiveSynced: true,
          );
        },
        onError: handleSyncError,
      ),
    );

    _subscriptions.add(
      db.collection('scheme_substrands').snapshots().listen(
        (snap) {
          if (snap.docs.isEmpty) return;
          state = state.copyWith(
            substrands: snap.docs
                .map((d) => SchemeSubstrandEntity.fromMap(d.id, d.data()))
                .toList(),
            isLiveSynced: true,
          );
        },
        onError: handleSyncError,
      ),
    );

    _subscriptions.add(
      db.collection('schedule_days').snapshots().listen(
        (snap) {
          if (snap.docs.isEmpty) return;
          final days = snap.docs
              .map((d) => ScheduleDayEntity.fromMap(d.id, d.data()))
              .toList()
            ..sort((a, b) => a.order.compareTo(b.order));
          state = state.copyWith(scheduleDays: days, isLiveSynced: true);
        },
        onError: handleSyncError,
      ),
    );

    _subscriptions.add(
      db.collection('timetable_slots').snapshots().listen(
        (snap) {
          if (snap.docs.isEmpty) return;
          state = state.copyWith(
            timetableSlots: snap.docs
                .map((d) => TimetableSlotEntity.fromMap(d.id, d.data()))
                .toList(),
            isLiveSynced: true,
          );
        },
        onError: handleSyncError,
      ),
    );

    _subscriptions.add(
      db.collection('locations').snapshots().listen(
        (snap) {
          if (snap.docs.isEmpty) return;
          state = state.copyWith(
            locations: snap.docs
                .map((d) => LocationEntity.fromMap(d.id, d.data()))
                .toList(),
            isLiveSynced: true,
          );
        },
        onError: handleSyncError,
      ),
    );

    _subscriptions.add(
      db.collection('school_events').snapshots().listen(
        (snap) {
          if (snap.docs.isEmpty) return;
          final events = snap.docs
              .map((d) => SchoolEventEntity.fromMap(d.id, d.data()))
              .toList()
            ..sort((a, b) => a.date.compareTo(b.date));
          state = state.copyWith(schoolEvents: events, isLiveSynced: true);
        },
        onError: handleSyncError,
      ),
    );

    if (user.role == PortalRole.parent) {
      final scopedIds = user.linkedLearnerIds.take(10).toList();
      if (scopedIds.isEmpty) {
        state = state.copyWith(
          learners: const [],
          diaryEntries: const [],
          assessments: const [],
          attendanceRecords: const [],
          lessonPlans: const [],
          isLiveSynced: true,
        );
        return;
      }

      _subscriptions.add(
        db
            .collection('learners')
            .where(FieldPath.documentId, whereIn: scopedIds)
            .snapshots()
            .listen(
          (snap) {
            state = state.copyWith(
              learners: snap.docs
                  .map((d) => LearnerEntity.fromMap(d.id, d.data()))
                  .toList(),
              lessonPlans: const [],
              isLiveSynced: true,
            );
          },
          onError: handleSyncError,
        ),
      );

      _subscriptions.add(
        db
            .collection('diary_entries')
            .where('learnerId', whereIn: scopedIds)
            .snapshots()
            .listen(
          (snap) {
            final entries = snap.docs
                .map((d) => DiaryEntryEntity.fromMap(d.id, d.data()))
                .toList()
              ..sort((a, b) => b.date.compareTo(a.date));
            state = state.copyWith(diaryEntries: entries, isLiveSynced: true);
          },
          onError: handleSyncError,
        ),
      );

      _subscriptions.add(
        db
            .collection('assessment_entries')
            .where('learnerId', whereIn: scopedIds)
            .snapshots()
            .listen(
          (snap) {
            final items = snap.docs
                .map((d) => AssessmentEntryEntity.fromMap(d.id, d.data()))
                .toList()
              ..sort((a, b) => b.date.compareTo(a.date));
            state = state.copyWith(assessments: items, isLiveSynced: true);
          },
          onError: handleSyncError,
        ),
      );

      _subscriptions.add(
        db
            .collection('attendance_records')
            .where('learnerId', whereIn: scopedIds)
            .snapshots()
            .listen(
          (snap) {
            final items = snap.docs
                .map((d) => AttendanceRecordEntity.fromMap(d.id, d.data()))
                .toList()
              ..sort((a, b) => b.date.compareTo(a.date));
            state = state.copyWith(
              attendanceRecords: items,
              isLiveSynced: true,
            );
          },
          onError: handleSyncError,
        ),
      );
      return;
    }

    // Staff (Admin / Teacher) school-wide live collection subscriptions
    _subscriptions.add(
      db.collection('learners').snapshots().listen(
        (snap) {
          if (snap.docs.isEmpty) return;
          state = state.copyWith(
            learners: snap.docs
                .map((d) => LearnerEntity.fromMap(d.id, d.data()))
                .toList(),
            isLiveSynced: true,
          );
        },
        onError: handleSyncError,
      ),
    );

    _subscriptions.add(
      db.collection('diary_entries').snapshots().listen(
        (snap) {
          if (snap.docs.isEmpty) return;
          final entries = snap.docs
              .map((d) => DiaryEntryEntity.fromMap(d.id, d.data()))
              .toList()
            ..sort((a, b) => b.date.compareTo(a.date));
          state = state.copyWith(diaryEntries: entries, isLiveSynced: true);
        },
        onError: handleSyncError,
      ),
    );

    _subscriptions.add(
      db.collection('assessment_entries').snapshots().listen(
        (snap) {
          if (snap.docs.isEmpty) return;
          final items = snap.docs
              .map((d) => AssessmentEntryEntity.fromMap(d.id, d.data()))
              .toList()
            ..sort((a, b) => b.date.compareTo(a.date));
          state = state.copyWith(assessments: items, isLiveSynced: true);
        },
        onError: handleSyncError,
      ),
    );

    _subscriptions.add(
      db.collection('lesson_plans').snapshots().listen(
        (snap) {
          if (snap.docs.isEmpty) return;
          final plans = snap.docs
              .map((d) => LessonPlanEntity.fromMap(d.id, d.data()))
              .toList()
            ..sort((a, b) => b.scheduledDate.compareTo(a.scheduledDate));
          state = state.copyWith(lessonPlans: plans, isLiveSynced: true);
        },
        onError: handleSyncError,
      ),
    );

    _subscriptions.add(
      db.collection('attendance_records').snapshots().listen(
        (snap) {
          if (snap.docs.isEmpty) return;
          final items = snap.docs
              .map((d) => AttendanceRecordEntity.fromMap(d.id, d.data()))
              .toList()
            ..sort((a, b) => b.date.compareTo(a.date));
          state = state.copyWith(
            attendanceRecords: items,
            isLiveSynced: true,
          );
        },
        onError: handleSyncError,
      ),
    );

    _subscriptions.add(
      db.collection('audit_logs').snapshots().listen(
        (snap) {
          if (snap.docs.isEmpty) return;
          final logs = snap.docs
              .map((d) => AuditLogEntry.fromMap(d.id, d.data()))
              .toList()
            ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
          state = state.copyWith(auditLogs: logs, isLiveSynced: true);
        },
        onError: handleSyncError,
      ),
    );
  }

  void _cancelSubscriptions() {
    for (final sub in _subscriptions) {
      sub.cancel();
    }
    _subscriptions.clear();
  }

  @override
  void dispose() {
    _cancelSubscriptions();
    super.dispose();
  }

  /// Idempotent one-click Admin seed script writing initial demo data to Firestore.
  Future<int> seedFirestoreDemoData() async {
    final seed = initialSchoolEcsState;
    if (!useFirestore || _db == null) {
      state = seed;
      return 0;
    }

    final batch = _db.batch();
    var count = 0;

    for (final s in seed.subjects) {
      batch.set(_db.collection('subjects').doc(s.id), s.toMap());
      count++;
    }
    for (final c in seed.classrooms) {
      batch.set(_db.collection('classrooms').doc(c.id), c.toMap());
      count++;
    }
    for (final loc in seed.locations) {
      batch.set(_db.collection('locations').doc(loc.id), loc.toMap());
      count++;
    }
    for (final t in seed.teachers) {
      batch.set(_db.collection('teachers').doc(t.id), t.toMap());
      count++;
    }
    for (final l in seed.learners) {
      batch.set(_db.collection('learners').doc(l.id), l.toMap());
      count++;
    }
    for (final f in seed.dynamicFields) {
      batch.set(_db.collection('component_schemas').doc(f.id), f.toMap());
      count++;
    }
    for (final w in seed.pageWidgets) {
      batch.set(_db.collection('page_widgets').doc(w.id.key), w.toMap());
      count++;
    }
    for (final str in seed.strands) {
      batch.set(_db.collection('scheme_strands').doc(str.id), str.toMap());
      count++;
    }
    for (final sub in seed.substrands) {
      batch.set(_db.collection('scheme_substrands').doc(sub.id), sub.toMap());
      count++;
    }
    for (final d in seed.diaryEntries) {
      batch.set(_db.collection('diary_entries').doc(d.id), d.toMap());
      count++;
    }
    for (final a in seed.assessments) {
      batch.set(_db.collection('assessment_entries').doc(a.id), a.toMap());
      count++;
    }
    for (final lp in seed.lessonPlans) {
      batch.set(_db.collection('lesson_plans').doc(lp.id), lp.toMap());
      count++;
    }
    for (final day in seed.scheduleDays) {
      batch.set(_db.collection('schedule_days').doc(day.id), day.toMap());
      count++;
    }
    for (final tt in seed.timetableSlots) {
      batch.set(_db.collection('timetable_slots').doc(tt.id), tt.toMap());
      count++;
    }
    for (final att in seed.attendanceRecords) {
      batch.set(
        _db.collection('attendance_records').doc('${att.learnerId}_${att.date}'),
        att.toMap(),
      );
      count++;
    }
    for (final evt in seed.schoolEvents) {
      batch.set(_db.collection('school_events').doc(evt.id), evt.toMap());
      count++;
    }
    for (final aud in seed.auditLogs) {
      batch.set(_db.collection('audit_logs').doc(aud.id), aud.toMap());
      count++;
    }

    await batch.commit();
    return count;
  }

  Future<void> upsertSchoolEvent(SchoolEventEntity event) async {
    final exists = state.schoolEvents.any((e) => e.id == event.id);
    final nextList = exists
        ? state.schoolEvents.map((e) => e.id == event.id ? event : e).toList()
        : [...state.schoolEvents, event];
    nextList.sort((a, b) => a.date.compareTo(b.date));
    state = state.copyWith(schoolEvents: nextList);
    if (useFirestore && _db != null) {
      await _db.collection('school_events').doc(event.id).set(event.toMap());
    }
    await _recordAudit(
      action: exists ? 'updated' : 'created',
      entityType: 'school_event',
      entityId: event.id,
      targetLabel: event.title,
      detail: '${event.kind.toUpperCase()} on ${event.date}: ${event.description}',
    );
  }

  Future<void> deleteSchoolEvent(String eventId) async {
    final target =
        state.schoolEvents.where((e) => e.id == eventId).firstOrNull;
    state = state.copyWith(
      schoolEvents: state.schoolEvents.where((e) => e.id != eventId).toList(),
    );
    if (useFirestore && _db != null) {
      await _db.collection('school_events').doc(eventId).delete();
    }
    await _recordAudit(
      action: 'deleted',
      entityType: 'school_event',
      entityId: eventId,
      targetLabel: target?.title ?? eventId,
      detail: 'Removed event scheduled on ${target?.date ?? ''}',
    );
  }

  Future<void> toggleDiaryAcknowledgment(String entryId) async {
    state = state.copyWith(
      diaryEntries: state.diaryEntries
          .map((e) => e.id == entryId
              ? e.copyWith(parentAcknowledged: !e.parentAcknowledged)
              : e)
          .toList(),
    );
    final updated = state.diaryEntries.firstWhere((e) => e.id == entryId);
    if (useFirestore && _db != null) {
      await _db.collection('diary_entries').doc(entryId).update({
        'parentAcknowledged': updated.parentAcknowledged,
      });
    }
    final learner =
        state.learners.where((l) => l.id == updated.learnerId).firstOrNull;
    await _recordAudit(
      action: updated.parentAcknowledged ? 'signed' : 'updated',
      entityType: 'diary_entry',
      entityId: entryId,
      targetLabel: '${learner?.name ?? updated.learnerId} · Diary ${updated.date}',
      detail: updated.parentAcknowledged
          ? 'Guardian acknowledged homework: ${updated.homeworkSummary}'
          : 'Reopened diary sign-off status',
      classroomId: updated.classroomId,
      learnerId: updated.learnerId,
    );
  }

  Future<void> addDiaryEntry(DiaryEntryEntity entry) async {
    state = state.copyWith(diaryEntries: [entry, ...state.diaryEntries]);
    if (useFirestore && _db != null) {
      await _db.collection('diary_entries').doc(entry.id).set(entry.toMap());
    }
    final learner =
        state.learners.where((l) => l.id == entry.learnerId).firstOrNull;
    final teacher =
        state.teachers.where((t) => t.id == entry.teacherId).firstOrNull;
    await _recordAudit(
      action: 'recorded',
      entityType: 'diary_entry',
      entityId: entry.id,
      targetLabel: '${learner?.name ?? entry.learnerId} · Diary ${entry.date}',
      detail: 'Logged homework by ${teacher?.name ?? entry.teacherId}: ${entry.homeworkSummary}',
      classroomId: entry.classroomId,
      teacherId: entry.teacherId,
      learnerId: entry.learnerId,
    );
  }

  /// Broadcasts one homework/note payload across every learner in a classroom.
  Future<int> broadcastClassroomDiary({
    required String classroomId,
    required String teacherId,
    required String date,
    required String homeworkSummary,
    required String teacherNote,
    required Map<String, dynamic> customFields,
  }) async {
    final learners =
        state.learners.where((l) => l.classroomId == classroomId).toList();
    if (learners.isEmpty) return 0;

    final stamp = DateTime.now().millisecondsSinceEpoch;
    final generated = [
      for (var i = 0; i < learners.length; i++)
        DiaryEntryEntity(
          id: 'dry_${stamp}_$i',
          learnerId: learners[i].id,
          classroomId: learners[i].classroomId,
          teacherId: teacherId,
          date: date,
          homeworkSummary: homeworkSummary.trim(),
          teacherNote: teacherNote.trim(),
          parentAcknowledged: false,
          customFields: Map<String, dynamic>.from(customFields),
        ),
    ];

    state = state.copyWith(diaryEntries: [...generated, ...state.diaryEntries]);
    if (useFirestore && _db != null) {
      final batch = _db.batch();
      for (final entry in generated) {
        batch.set(_db.collection('diary_entries').doc(entry.id), entry.toMap());
      }
      await batch.commit();
    }
    return generated.length;
  }

  Future<void> addSchemeStrand(SchemeStrandEntity strand) async {
    state = state.copyWith(strands: [...state.strands, strand]);
    if (useFirestore && _db != null) {
      await _db.collection('scheme_strands').doc(strand.id).set(strand.toMap());
    }
    final cls =
        state.classrooms.where((c) => c.id == strand.classroomId).firstOrNull;
    await _recordAudit(
      action: 'created',
      entityType: 'scheme_strand',
      entityId: strand.id,
      targetLabel: '${strand.code}: ${strand.title}',
      detail: 'Registered scheme strand under ${cls?.name ?? strand.classroomId} (${strand.term})',
      classroomId: strand.classroomId,
      teacherId: strand.createdByTeacherId,
    );
  }

  Future<void> addSchemeSubstrand(SchemeSubstrandEntity substrand) async {
    state = state.copyWith(substrands: [...state.substrands, substrand]);
    if (useFirestore && _db != null) {
      await _db
          .collection('scheme_substrands')
          .doc(substrand.id)
          .set(substrand.toMap());
    }
    final strand =
        state.strands.where((s) => s.id == substrand.strandId).firstOrNull;
    final cls = strand == null
        ? null
        : state.classrooms.where((c) => c.id == strand.classroomId).firstOrNull;
    await _recordAudit(
      action: 'created',
      entityType: 'scheme_substrand',
      entityId: substrand.id,
      targetLabel: '${substrand.code}: ${substrand.title}',
      detail: 'Added substrand under ${strand?.code ?? substrand.strandId} (${cls?.name ?? strand?.classroomId ?? ''})',
      classroomId: strand?.classroomId,
    );
  }

  Future<void> addAssessmentEntry(AssessmentEntryEntity entry) async {
    state = state.copyWith(assessments: [entry, ...state.assessments]);
    if (useFirestore && _db != null) {
      await _db
          .collection('assessment_entries')
          .doc(entry.id)
          .set(entry.toMap());
    }
    final learner =
        state.learners.where((l) => l.id == entry.learnerId).firstOrNull;
    final subj =
        state.subjects.where((s) => s.id == entry.subjectId).firstOrNull;
    final teacher =
        state.teachers.where((t) => t.id == entry.teacherId).firstOrNull;
    await _recordAudit(
      action: 'recorded',
      entityType: 'assessment_entry',
      entityId: entry.id,
      targetLabel: '${learner?.name ?? entry.learnerId} · ${subj?.name ?? entry.subjectId}',
      detail: 'Scored ${entry.scorePercent}% (${entry.mastery.label}) by ${teacher?.name ?? entry.teacherId}',
      classroomId: learner?.classroomId,
      teacherId: entry.teacherId,
      learnerId: entry.learnerId,
    );
  }

  ({
    List<LessonPlanEntity> lessonPlans,
    List<TimetableSlotEntity> timetableSlots,
    List<String> changedPlanIds,
    List<String> changedSlotIds,
  }) _syncLessonSlotBinding({
    required List<LessonPlanEntity> plans,
    required List<TimetableSlotEntity> slots,
    String? planId,
    String? slotId,
  }) {
    final changedPlanIds = <String>{};
    final changedSlotIds = <String>{};

    final nextPlans = plans.map((lp) {
      if (planId != null && lp.id == planId) {
        changedPlanIds.add(lp.id);
        return lp.copyWith(
          timetableSlotId: slotId,
          clearTimetableSlot: slotId == null || slotId.isEmpty,
        );
      }
      if (slotId != null &&
          slotId.isNotEmpty &&
          lp.timetableSlotId == slotId &&
          lp.id != planId) {
        changedPlanIds.add(lp.id);
        return lp.copyWith(clearTimetableSlot: true);
      }
      return lp;
    }).toList();

    final nextSlots = slots.map((sl) {
      if (slotId != null && slotId.isNotEmpty && sl.id == slotId) {
        changedSlotIds.add(sl.id);
        return sl.copyWith(
          lessonPlanId: planId,
          clearLessonPlan: planId == null || planId.isEmpty,
        );
      }
      if (planId != null &&
          planId.isNotEmpty &&
          sl.lessonPlanId == planId &&
          sl.id != slotId) {
        changedSlotIds.add(sl.id);
        return sl.copyWith(clearLessonPlan: true);
      }
      return sl;
    }).toList();

    return (
      lessonPlans: nextPlans,
      timetableSlots: nextSlots,
      changedPlanIds: changedPlanIds.toList(),
      changedSlotIds: changedSlotIds.toList(),
    );
  }

  Future<void> addLessonPlan(LessonPlanEntity plan) async {
    final now = _nowIso();
    final enriched = plan.copyWith(
      taughtByTeacherId: plan.status != LessonStatus.planned
          ? (plan.taughtByTeacherId ?? plan.teacherId)
          : null,
      taughtAt: plan.status != LessonStatus.planned
          ? (plan.taughtAt ?? now)
          : null,
      updatedBy: _actorName,
      updatedAt: now,
    );
    final slotId = (enriched.timetableSlotId?.trim().isNotEmpty ?? false)
        ? enriched.timetableSlotId
        : null;
    final synced = _syncLessonSlotBinding(
      plans: [enriched, ...state.lessonPlans],
      slots: state.timetableSlots,
      planId: enriched.id,
      slotId: slotId,
    );
    state = state.copyWith(
      lessonPlans: synced.lessonPlans,
      timetableSlots: synced.timetableSlots,
    );
    if (useFirestore && _db != null) {
      final batch = _db.batch();
      for (final pid in synced.changedPlanIds) {
        final item = synced.lessonPlans.firstWhere((e) => e.id == pid);
        batch.set(_db.collection('lesson_plans').doc(pid), item.toMap());
      }
      for (final sid in synced.changedSlotIds) {
        final item = synced.timetableSlots.firstWhere((e) => e.id == sid);
        batch.set(_db.collection('timetable_slots').doc(sid), item.toMap());
      }
      await batch.commit();
    }
    final teacher =
        state.teachers.where((t) => t.id == enriched.effectiveTeacherId).firstOrNull;
    final cls =
        state.classrooms.where((c) => c.id == enriched.classroomId).firstOrNull;
    await _recordAudit(
      action: enriched.status == LessonStatus.taught ? 'taught' : 'created',
      entityType: 'lesson_plan',
      entityId: enriched.id,
      targetLabel: enriched.title,
      detail: 'Assigned to ${teacher?.name ?? enriched.teacherId} in ${cls?.name ?? enriched.classroomId} (${enriched.status.label})',
      classroomId: enriched.classroomId,
      teacherId: enriched.effectiveTeacherId,
    );
  }

  Future<void> updateLessonPlan(LessonPlanEntity updated) async {
    final now = _nowIso();
    final enriched = updated.copyWith(
      taughtByTeacherId: updated.status != LessonStatus.planned
          ? (updated.taughtByTeacherId ?? updated.teacherId)
          : null,
      taughtAt: updated.status != LessonStatus.planned
          ? (updated.taughtAt ?? now)
          : null,
      updatedBy: _actorName,
      updatedAt: now,
    );
    final slotId = (enriched.timetableSlotId?.trim().isNotEmpty ?? false)
        ? enriched.timetableSlotId
        : null;
    final replaced = state.lessonPlans
        .map((lp) => lp.id == enriched.id ? enriched : lp)
        .toList();
    final synced = _syncLessonSlotBinding(
      plans: replaced,
      slots: state.timetableSlots,
      planId: enriched.id,
      slotId: slotId,
    );
    state = state.copyWith(
      lessonPlans: synced.lessonPlans,
      timetableSlots: synced.timetableSlots,
    );
    if (useFirestore && _db != null) {
      final batch = _db.batch();
      batch.set(_db.collection('lesson_plans').doc(enriched.id), enriched.toMap());
      for (final pid in synced.changedPlanIds) {
        final item = synced.lessonPlans.firstWhere((e) => e.id == pid);
        batch.set(_db.collection('lesson_plans').doc(pid), item.toMap());
      }
      for (final sid in synced.changedSlotIds) {
        final item = synced.timetableSlots.firstWhere((e) => e.id == sid);
        batch.set(_db.collection('timetable_slots').doc(sid), item.toMap());
      }
      await batch.commit();
    }
    final teacher =
        state.teachers.where((t) => t.id == enriched.effectiveTeacherId).firstOrNull;
    final cls =
        state.classrooms.where((c) => c.id == enriched.classroomId).firstOrNull;
    await _recordAudit(
      action: enriched.status == LessonStatus.taught ? 'taught' : 'updated',
      entityType: 'lesson_plan',
      entityId: enriched.id,
      targetLabel: enriched.title,
      detail: 'Updated for ${cls?.name ?? enriched.classroomId} · Teacher: ${teacher?.name ?? enriched.teacherId} (${enriched.lessonsDelivered} lessons)',
      classroomId: enriched.classroomId,
      teacherId: enriched.effectiveTeacherId,
    );
  }

  Future<void> deleteLessonPlan(String planId) async {
    final touchedSlots = <String>[];
    final nextSlots = state.timetableSlots.map((sl) {
      if (sl.lessonPlanId == planId) {
        touchedSlots.add(sl.id);
        return sl.copyWith(clearLessonPlan: true);
      }
      return sl;
    }).toList();

    state = state.copyWith(
      lessonPlans: state.lessonPlans.where((lp) => lp.id != planId).toList(),
      timetableSlots: nextSlots,
    );
    if (useFirestore && _db != null) {
      final batch = _db.batch();
      batch.delete(_db.collection('lesson_plans').doc(planId));
      for (final sid in touchedSlots) {
        final item = nextSlots.firstWhere((e) => e.id == sid);
        batch.set(_db.collection('timetable_slots').doc(sid), item.toMap());
      }
      await batch.commit();
    }
  }

  Future<String?> assignLessonToTimetableSlot({
    required String lessonPlanId,
    String? timetableSlotId,
    bool syncSlotSubjectAndTeacher = false,
  }) async {
    final plan = state.lessonPlans.where((lp) => lp.id == lessonPlanId).firstOrNull;
    if (plan == null) return 'Registered lesson not found.';

    final cleanSlotId =
        (timetableSlotId?.trim().isNotEmpty ?? false) ? timetableSlotId!.trim() : null;

    if (cleanSlotId == null) {
      final synced = _syncLessonSlotBinding(
        plans: state.lessonPlans,
        slots: state.timetableSlots,
        planId: plan.id,
        slotId: null,
      );
      state = state.copyWith(
        lessonPlans: synced.lessonPlans,
        timetableSlots: synced.timetableSlots,
      );
      if (useFirestore && _db != null) {
        final batch = _db.batch();
        for (final pid in synced.changedPlanIds) {
          final item = synced.lessonPlans.firstWhere((e) => e.id == pid);
          batch.set(_db.collection('lesson_plans').doc(pid), item.toMap());
        }
        for (final sid in synced.changedSlotIds) {
          final item = synced.timetableSlots.firstWhere((e) => e.id == sid);
          batch.set(_db.collection('timetable_slots').doc(sid), item.toMap());
        }
        await batch.commit();
      }
      return null;
    }

    final targetSlot =
        state.timetableSlots.where((s) => s.id == cleanSlotId).firstOrNull;
    if (targetSlot == null) return 'Timetable slot not found.';

    var baseSlots = state.timetableSlots;
    if (syncSlotSubjectAndTeacher) {
      final candidate = targetSlot.copyWith(
        subjectId: plan.subjectId,
        teacherId: plan.teacherId,
      );
      final conflict = TimetableConflictValidator.detectConflict(
        existingSlots: state.timetableSlots,
        candidate: candidate,
        ignoreSlotId: targetSlot.id,
      );
      if (conflict != null) return conflict;
      baseSlots = baseSlots
          .map((s) => s.id == targetSlot.id ? candidate : s)
          .toList();
    }

    final updatedPlans = state.lessonPlans
        .map((lp) => lp.id == plan.id
            ? lp.copyWith(
                classroomId: targetSlot.classroomId,
                timetableSlotId: targetSlot.id,
              )
            : lp)
        .toList();
    final synced = _syncLessonSlotBinding(
      plans: updatedPlans,
      slots: baseSlots,
      planId: plan.id,
      slotId: targetSlot.id,
    );
    state = state.copyWith(
      lessonPlans: synced.lessonPlans,
      timetableSlots: synced.timetableSlots,
    );

    if (useFirestore && _db != null) {
      final batch = _db.batch();
      for (final pid in synced.changedPlanIds) {
        final item = synced.lessonPlans.firstWhere((e) => e.id == pid);
        batch.set(_db.collection('lesson_plans').doc(pid), item.toMap());
      }
      for (final sid in synced.changedSlotIds) {
        final item = synced.timetableSlots.firstWhere((e) => e.id == sid);
        batch.set(_db.collection('timetable_slots').doc(sid), item.toMap());
      }
      await batch.commit();
    }
    return null;
  }

  Future<void> updateLessonPlanStatus(
    String planId,
    LessonStatus nextStatus,
    int deliveredCount, {
    String? taughtByTeacherId,
  }) async {
    final now = _nowIso();
    final target = state.lessonPlans.where((lp) => lp.id == planId).firstOrNull;
    final resolvedTeacherId = taughtByTeacherId ??
        _currentUser?.teacherId ??
        target?.teacherId ??
        '';
    state = state.copyWith(
      lessonPlans: state.lessonPlans
          .map(
            (lp) => lp.id == planId
                ? lp.copyWith(
                    status: nextStatus,
                    lessonsDelivered: deliveredCount,
                    taughtByTeacherId: nextStatus != LessonStatus.planned
                        ? resolvedTeacherId
                        : null,
                    taughtAt: nextStatus != LessonStatus.planned ? now : null,
                    updatedBy: _actorName,
                    updatedAt: now,
                  )
                : lp,
          )
          .toList(),
    );
    if (useFirestore && _db != null) {
      await _db.collection('lesson_plans').doc(planId).update({
        'status': nextStatus.key,
        'lessonsDelivered': deliveredCount,
        'taughtByTeacherId':
            nextStatus != LessonStatus.planned ? resolvedTeacherId : null,
        'taughtAt': nextStatus != LessonStatus.planned ? now : null,
        'updatedBy': _actorName,
        'updatedAt': now,
      });
    }
    if (target != null) {
      final teacher =
          state.teachers.where((t) => t.id == resolvedTeacherId).firstOrNull;
      final cls =
          state.classrooms.where((c) => c.id == target.classroomId).firstOrNull;
      await _recordAudit(
        action: nextStatus == LessonStatus.taught ? 'taught' : 'updated',
        entityType: 'lesson_plan',
        entityId: planId,
        targetLabel: target.title,
        detail: '${nextStatus.label} ($deliveredCount lessons) in ${cls?.name ?? target.classroomId} by ${teacher?.name ?? resolvedTeacherId}',
        classroomId: target.classroomId,
        teacherId: resolvedTeacherId,
      );
    }
  }

  Future<void> upsertAttendance(AttendanceRecordEntity record) async {
    final exists = state.attendanceRecords.any(
      (r) => r.learnerId == record.learnerId && r.date == record.date,
    );
    final nextList = exists
        ? state.attendanceRecords
            .map((r) =>
                (r.learnerId == record.learnerId && r.date == record.date)
                    ? record
                    : r)
            .toList()
        : [record, ...state.attendanceRecords];
    state = state.copyWith(attendanceRecords: nextList);
    if (useFirestore && _db != null) {
      await _db
          .collection('attendance_records')
          .doc('${record.learnerId}_${record.date}')
          .set(record.toMap());
    }
    final learner =
        state.learners.where((l) => l.id == record.learnerId).firstOrNull;
    final teacher =
        state.teachers.where((t) => t.id == record.teacherId).firstOrNull;
    await _recordAudit(
      action: 'recorded',
      entityType: 'attendance_record',
      entityId: record.id,
      targetLabel: '${learner?.name ?? record.learnerId} · ${record.date}',
      detail: 'Marked ${record.status.label} by ${teacher?.name ?? record.teacherId}${record.remark.isNotEmpty ? ' (${record.remark})' : ''}',
      classroomId: record.classroomId,
      teacherId: record.teacherId,
      learnerId: record.learnerId,
    );
  }

  /// Marks every learner in [classroomId] present for [date] in one batch.
  Future<int> markClassroomAllPresent({
    required String classroomId,
    required String teacherId,
    required String date,
  }) async {
    final learners =
        state.learners.where((l) => l.classroomId == classroomId).toList();
    if (learners.isEmpty) return 0;

    final records = [...state.attendanceRecords];
    final updatedRecords = <AttendanceRecordEntity>[];
    for (final learner in learners) {
      final idx = records.indexWhere(
        (r) => r.learnerId == learner.id && r.date == date,
      );
      final existing = idx >= 0 ? records[idx] : null;
      final rec = AttendanceRecordEntity(
        id: existing?.id ?? 'att_${learner.id}_$date',
        learnerId: learner.id,
        classroomId: learner.classroomId,
        teacherId: teacherId,
        date: date,
        status: AttendanceStatus.present,
        remark: (existing?.remark.isNotEmpty ?? false)
            ? existing!.remark
            : 'Batch roll call: Present.',
        customFields: Map<String, dynamic>.from(
          existing?.customFields ?? const {'uniform_compliant': true},
        ),
      );
      if (idx >= 0) {
        records[idx] = rec;
      } else {
        records.insert(0, rec);
      }
      updatedRecords.add(rec);
    }

    state = state.copyWith(attendanceRecords: records);
    if (useFirestore && _db != null) {
      final batch = _db.batch();
      for (final rec in updatedRecords) {
        batch.set(
          _db.collection('attendance_records').doc('${rec.learnerId}_${rec.date}'),
          rec.toMap(),
        );
      }
      await batch.commit();
    }
    return updatedRecords.length;
  }

  /// Copies prior register statuses for [classroomId] onto [toDate] in one batch.
  Future<({int count, String? sourceDate, String? error})>
      copyClassroomAttendanceFromDate({
    required String classroomId,
    required String teacherId,
    required String toDate,
    String? fromDate,
  }) async {
    final learners =
        state.learners.where((l) => l.classroomId == classroomId).toList();
    if (learners.isEmpty) {
      return (
        count: 0,
        sourceDate: null,
        error: 'No learners enrolled in the selected classroom.',
      );
    }

    var sourceDate = fromDate?.trim();
    if (sourceDate == null || sourceDate.isEmpty) {
      final priorDates = state.attendanceRecords
          .where((r) => r.classroomId == classroomId && r.date.compareTo(toDate) < 0)
          .map((r) => r.date)
          .toSet()
          .toList()
        ..sort((a, b) => b.compareTo(a));
      sourceDate = priorDates.firstOrNull;
    }

    if (sourceDate == null) {
      return (
        count: 0,
        sourceDate: null,
        error: 'No earlier register exists for this classroom before $toDate.',
      );
    }

    final sourceRecords = state.attendanceRecords
        .where((r) => r.classroomId == classroomId && r.date == sourceDate)
        .toList();
    if (sourceRecords.isEmpty) {
      return (
        count: 0,
        sourceDate: sourceDate,
        error: 'No attendance records found on $sourceDate for this classroom.',
      );
    }

    final records = [...state.attendanceRecords];
    final copiedRecords = <AttendanceRecordEntity>[];
    for (final learner in learners) {
      final prev = sourceRecords.where((r) => r.learnerId == learner.id).firstOrNull;
      if (prev == null) continue;
      final idx = records.indexWhere(
        (r) => r.learnerId == learner.id && r.date == toDate,
      );
      final existing = idx >= 0 ? records[idx] : null;
      final rec = AttendanceRecordEntity(
        id: existing?.id ?? 'att_${learner.id}_$toDate',
        learnerId: learner.id,
        classroomId: learner.classroomId,
        teacherId: teacherId,
        date: toDate,
        status: prev.status,
        remark: prev.remark.isNotEmpty ? prev.remark : 'Copied from $sourceDate.',
        customFields: Map<String, dynamic>.from(prev.customFields),
      );
      if (idx >= 0) {
        records[idx] = rec;
      } else {
        records.insert(0, rec);
      }
      copiedRecords.add(rec);
    }

    if (copiedRecords.isEmpty) {
      return (
        count: 0,
        sourceDate: sourceDate,
        error: 'No matching learner attendance records found on $sourceDate.',
      );
    }

    state = state.copyWith(attendanceRecords: records);
    if (useFirestore && _db != null) {
      final batch = _db.batch();
      for (final rec in copiedRecords) {
        batch.set(
          _db.collection('attendance_records').doc('${rec.learnerId}_${rec.date}'),
          rec.toMap(),
        );
      }
      await batch.commit();
    }

    final cls =
        state.classrooms.where((c) => c.id == classroomId).firstOrNull;
    await _recordAudit(
      action: 'copied',
      entityType: 'attendance_record',
      entityId: '${classroomId}_$toDate',
      targetLabel: '${cls?.name ?? classroomId} · $toDate',
      detail: 'Copied ${copiedRecords.length} attendance marks from $sourceDate',
      classroomId: classroomId,
      teacherId: teacherId,
    );

    return (count: copiedRecords.length, sourceDate: sourceDate, error: null);
  }

  List<ScheduleDayEntity> scheduleDaysForClassroom(String classroomId) {
    return state.scheduleDays
        .where((d) => d.classroomIds.contains(classroomId))
        .toList()
      ..sort((a, b) => a.order.compareTo(b.order));
  }

  Future<String?> upsertScheduleDay(ScheduleDayEntity candidate) async {
    final code = candidate.code.trim();
    if (code.isEmpty) {
      return 'Day short code (e.g. Sat) is required.';
    }
    final duplicate = state.scheduleDays.any(
      (d) =>
          d.id != candidate.id &&
          d.code.trim().toLowerCase() == code.toLowerCase(),
    );
    if (duplicate) {
      return 'Schedule day "$code" already exists.';
    }

    final existing =
        state.scheduleDays.where((d) => d.id == candidate.id).firstOrNull;
    final normalized = candidate.copyWith(
      code: code,
      label: candidate.label.trim().isEmpty ? code : candidate.label.trim(),
      classroomIds: candidate.classroomIds.toSet().toList(),
    );

    final nextDays = existing != null
        ? state.scheduleDays
            .map((d) => d.id == normalized.id ? normalized : d)
            .toList()
        : [...state.scheduleDays, normalized];
    nextDays.sort((a, b) => a.order.compareTo(b.order));

    final updatedSlots = <TimetableSlotEntity>[];
    final nextSlots = existing != null && existing.code != normalized.code
        ? state.timetableSlots.map((s) {
            if (s.day == existing.code) {
              final moved = s.copyWith(day: normalized.code);
              updatedSlots.add(moved);
              return moved;
            }
            return s;
          }).toList()
        : state.timetableSlots;

    state = state.copyWith(scheduleDays: nextDays, timetableSlots: nextSlots);
    if (useFirestore && _db != null) {
      final batch = _db.batch();
      batch.set(_db.collection('schedule_days').doc(normalized.id), normalized.toMap());
      for (final s in updatedSlots) {
        batch.set(_db.collection('timetable_slots').doc(s.id), s.toMap());
      }
      await batch.commit();
    }
    return null;
  }

  Future<void> toggleDayClassroomMapping(
    String dayId,
    String classroomId,
  ) async {
    ScheduleDayEntity? updatedDay;
    state = state.copyWith(
      scheduleDays: state.scheduleDays.map((d) {
        if (d.id != dayId) return d;
        final mapped = d.classroomIds.contains(classroomId)
            ? d.classroomIds.where((id) => id != classroomId).toList()
            : [...d.classroomIds, classroomId];
        updatedDay = d.copyWith(classroomIds: mapped);
        return updatedDay!;
      }).toList(),
    );
    if (updatedDay != null && useFirestore && _db != null) {
      await _db
          .collection('schedule_days')
          .doc(dayId)
          .set(updatedDay!.toMap());
    }
  }

  Future<void> deleteScheduleDay(String dayId) async {
    final target = state.scheduleDays.where((d) => d.id == dayId).firstOrNull;
    if (target == null) return;

    final removedSlotIds = state.timetableSlots
        .where((s) => s.day == target.code)
        .map((s) => s.id)
        .toSet();
    final detachedPlanIds = <String>[];
    final nextPlans = state.lessonPlans.map((lp) {
      if (lp.timetableSlotId != null &&
          removedSlotIds.contains(lp.timetableSlotId)) {
        detachedPlanIds.add(lp.id);
        return lp.copyWith(clearTimetableSlot: true);
      }
      return lp;
    }).toList();

    state = state.copyWith(
      scheduleDays: state.scheduleDays.where((d) => d.id != dayId).toList(),
      timetableSlots: state.timetableSlots
          .where((s) => !removedSlotIds.contains(s.id))
          .toList(),
      lessonPlans: nextPlans,
    );

    if (useFirestore && _db != null) {
      final batch = _db.batch();
      batch.delete(_db.collection('schedule_days').doc(dayId));
      for (final sid in removedSlotIds) {
        batch.delete(_db.collection('timetable_slots').doc(sid));
      }
      for (final pid in detachedPlanIds) {
        final item = nextPlans.firstWhere((e) => e.id == pid);
        batch.set(_db.collection('lesson_plans').doc(pid), item.toMap());
      }
      await batch.commit();
    }
  }

  Future<String?> upsertClassroom(
    ClassroomEntity classroom, {
    List<String> mapDayIds = const [],
  }) async {
    if (classroom.name.trim().isEmpty ||
        classroom.gradeLevel.trim().isEmpty ||
        classroom.roomCode.trim().isEmpty) {
      return 'Classroom name, grade level, and home room are required.';
    }
    final now = _nowIso();
    final enriched = classroom.copyWith(
      updatedBy: _actorName,
      updatedAt: now,
    );
    final exists = state.classrooms.any((c) => c.id == enriched.id);
    final nextClasses = exists
        ? state.classrooms
            .map((c) => c.id == enriched.id ? enriched : c)
            .toList()
        : [...state.classrooms, enriched];

    final updatedDays = <ScheduleDayEntity>[];
    final nextDays = state.scheduleDays.map((d) {
      if (mapDayIds.contains(d.id) && !d.classroomIds.contains(enriched.id)) {
        final next = d.copyWith(classroomIds: [...d.classroomIds, enriched.id]);
        updatedDays.add(next);
        return next;
      }
      return d;
    }).toList();

    state = state.copyWith(classrooms: nextClasses, scheduleDays: nextDays);
    if (useFirestore && _db != null) {
      final batch = _db.batch();
      batch.set(_db.collection('classrooms').doc(enriched.id), enriched.toMap());
      for (final d in updatedDays) {
        batch.set(_db.collection('schedule_days').doc(d.id), d.toMap());
      }
      await batch.commit();
    }
    final classTeacher = enriched.classTeacherId == null
        ? null
        : state.teachers
            .where((t) => t.id == enriched.classTeacherId)
            .firstOrNull;
    await _recordAudit(
      action: exists ? 'updated' : 'created',
      entityType: 'classroom',
      entityId: enriched.id,
      targetLabel: enriched.name,
      detail: 'Room ${enriched.roomCode}${classTeacher != null ? ' · Class Teacher: ${classTeacher.name}' : ''}',
      classroomId: enriched.id,
      teacherId: enriched.classTeacherId,
    );
    return null;
  }

  Future<void> assignClassTeacher({
    required String classroomId,
    required String teacherId,
  }) async {
    final now = _nowIso();
    ClassroomEntity? updated;
    state = state.copyWith(
      classrooms: state.classrooms.map((c) {
        if (c.id != classroomId) return c;
        updated = c.copyWith(
          classTeacherId: teacherId,
          updatedBy: _actorName,
          updatedAt: now,
        );
        return updated!;
      }).toList(),
    );
    if (updated != null && useFirestore && _db != null) {
      await _db.collection('classrooms').doc(classroomId).update({
        'classTeacherId': teacherId,
        'updatedBy': _actorName,
        'updatedAt': now,
      });
    }
    if (updated != null) {
      final teacher =
          state.teachers.where((t) => t.id == teacherId).firstOrNull;
      await _recordAudit(
        action: 'assigned',
        entityType: 'classroom',
        entityId: classroomId,
        targetLabel: updated!.name,
        detail: 'Assigned ${teacher?.name ?? teacherId} as Class Teacher',
        classroomId: classroomId,
        teacherId: teacherId,
      );
    }
  }

  /// Validates against classroom/teacher/room double-booking before saving,
  /// and keeps linked registered lesson <-> slot bindings synchronized.
  Future<String?> upsertTimetableSlot(
    TimetableSlotEntity slot, {
    String? ignoreSlotId,
    bool syncLessonBinding = false,
  }) async {
    if (slot.day.trim().isEmpty ||
        slot.room.trim().isEmpty ||
        slot.timeRange.trim().isEmpty) {
      return 'Day, time range, and room code are required.';
    }
    final conflict = TimetableConflictValidator.detectConflict(
      existingSlots: state.timetableSlots,
      candidate: slot,
      ignoreSlotId: ignoreSlotId,
    );
    if (conflict != null) {
      return conflict;
    }

    final exists = state.timetableSlots.any((s) => s.id == slot.id);
    final baseSlots = exists
        ? state.timetableSlots.map((s) => s.id == slot.id ? slot : s).toList()
        : [...state.timetableSlots, slot];

    final planId = (slot.lessonPlanId?.trim().isNotEmpty ?? false)
        ? slot.lessonPlanId!.trim()
        : null;

    if (!syncLessonBinding && planId == null) {
      state = state.copyWith(timetableSlots: baseSlots);
      if (useFirestore && _db != null) {
        await _db.collection('timetable_slots').doc(slot.id).set(slot.toMap());
      }
      return null;
    }

    final preUpdatedPlans = planId != null
        ? state.lessonPlans
            .map((lp) => lp.id == planId
                ? lp.copyWith(
                    classroomId: slot.classroomId,
                    teacherId: slot.teacherId,
                  )
                : lp)
            .toList()
        : state.lessonPlans;

    final synced = _syncLessonSlotBinding(
      plans: preUpdatedPlans,
      slots: baseSlots,
      planId: planId,
      slotId: slot.id,
    );
    state = state.copyWith(
      timetableSlots: synced.timetableSlots,
      lessonPlans: synced.lessonPlans,
    );

    if (useFirestore && _db != null) {
      final batch = _db.batch();
      batch.set(
        _db.collection('timetable_slots').doc(slot.id),
        synced.timetableSlots.firstWhere((e) => e.id == slot.id).toMap(),
      );
      for (final pid in synced.changedPlanIds) {
        final item = synced.lessonPlans.firstWhere((e) => e.id == pid);
        batch.set(_db.collection('lesson_plans').doc(pid), item.toMap());
      }
      for (final sid in synced.changedSlotIds) {
        final item = synced.timetableSlots.firstWhere((e) => e.id == sid);
        batch.set(_db.collection('timetable_slots').doc(sid), item.toMap());
      }
      await batch.commit();
    }
    return null;
  }

  Future<void> deleteTimetableSlot(String slotId) async {
    final detachedPlans = <String>[];
    final nextPlans = state.lessonPlans.map((lp) {
      if (lp.timetableSlotId == slotId) {
        detachedPlans.add(lp.id);
        return lp.copyWith(clearTimetableSlot: true);
      }
      return lp;
    }).toList();

    state = state.copyWith(
      timetableSlots: state.timetableSlots.where((s) => s.id != slotId).toList(),
      lessonPlans: nextPlans,
    );
    if (useFirestore && _db != null) {
      final batch = _db.batch();
      batch.delete(_db.collection('timetable_slots').doc(slotId));
      for (final pid in detachedPlans) {
        final item = nextPlans.firstWhere((e) => e.id == pid);
        batch.set(_db.collection('lesson_plans').doc(pid), item.toMap());
      }
      await batch.commit();
    }
  }

  Future<void> registerDynamicField(DynamicFieldDefinition field) async {
    state = state.copyWith(dynamicFields: [...state.dynamicFields, field]);
    if (useFirestore && _db != null) {
      await _db.collection('component_schemas').doc(field.id).set(field.toMap());
    }
  }

  Future<void> updateDynamicField(DynamicFieldDefinition updated) async {
    final ensuredVisible = updated.visibleTo.contains(PortalRole.admin)
        ? updated.visibleTo
        : [PortalRole.admin, ...updated.visibleTo];
    final ensuredEditable = updated.editableBy.contains(PortalRole.admin)
        ? updated.editableBy
        : [PortalRole.admin, ...updated.editableBy];
    final normalized = updated.copyWith(
      visibleTo: ensuredVisible,
      editableBy: ensuredEditable,
    );

    state = state.copyWith(
      dynamicFields: state.dynamicFields
          .map((f) => f.id == normalized.id ? normalized : f)
          .toList(),
    );
    if (useFirestore && _db != null) {
      await _db
          .collection('component_schemas')
          .doc(normalized.id)
          .set(normalized.toMap());
    }
  }

  /// Safe soft-archive: keeps historical records able to render old field labels.
  Future<void> archiveDynamicField(String fieldId) async {
    state = state.copyWith(
      dynamicFields: state.dynamicFields
          .map((f) => f.id == fieldId ? f.copyWith(archived: true) : f)
          .toList(),
    );
    if (useFirestore && _db != null) {
      await _db
          .collection('component_schemas')
          .doc(fieldId)
          .update({'archived': true});
    }
  }

  Future<void> restoreDynamicField(String fieldId) async {
    state = state.copyWith(
      dynamicFields: state.dynamicFields
          .map((f) => f.id == fieldId ? f.copyWith(archived: false) : f)
          .toList(),
    );
    if (useFirestore && _db != null) {
      await _db
          .collection('component_schemas')
          .doc(fieldId)
          .update({'archived': false});
    }
  }

  Future<void> removeDynamicField(String fieldId) async {
    await archiveDynamicField(fieldId);
  }

  Future<String?> upsertLocation(LocationEntity location) async {
    final name = location.name.trim();
    final zone = location.zone.trim().isEmpty
        ? 'General Catchment'
        : location.zone.trim();
    if (name.isEmpty) {
      return 'Location name is required.';
    }
    final duplicate = state.locations.any(
      (loc) =>
          loc.id != location.id &&
          loc.name.trim().toLowerCase() == name.toLowerCase(),
    );
    if (duplicate) {
      return 'Location "$name" already exists.';
    }
    final now = _nowIso();
    final exists = state.locations.any((loc) => loc.id == location.id);
    final enriched = location.copyWith(
      name: name,
      zone: zone,
      notes: location.notes.trim(),
      updatedBy: _actorName,
      updatedAt: now,
    );
    final nextLocations = exists
        ? state.locations
            .map((loc) => loc.id == enriched.id ? enriched : loc)
            .toList()
        : [...state.locations, enriched];

    state = state.copyWith(locations: nextLocations);
    if (useFirestore && _db != null) {
      await _db.collection('locations').doc(enriched.id).set(enriched.toMap());
    }
    await _recordAudit(
      action: exists ? 'updated' : 'created',
      entityType: 'location',
      entityId: enriched.id,
      targetLabel: enriched.name,
      detail: '${enriched.zone}${enriched.notes.isNotEmpty ? ' · ${enriched.notes}' : ''}',
    );
    return null;
  }

  Future<void> deleteLocation(String locationId) async {
    final existing =
        state.locations.where((loc) => loc.id == locationId).firstOrNull;
    if (existing == null) return;

    final affectedLearners =
        state.learners.where((l) => l.locationId == locationId).toList();
    state = state.copyWith(
      locations: state.locations.where((loc) => loc.id != locationId).toList(),
      learners: state.learners
          .map((l) => l.locationId == locationId
              ? l.copyWith(clearLocation: true)
              : l)
          .toList(),
    );

    if (useFirestore && _db != null) {
      final batch = _db.batch();
      batch.delete(_db.collection('locations').doc(locationId));
      for (final learner in affectedLearners) {
        batch.update(
          _db.collection('learners').doc(learner.id),
          {'locationId': null},
        );
      }
      await batch.commit();
    }
    await _recordAudit(
      action: 'deleted',
      entityType: 'location',
      entityId: locationId,
      targetLabel: existing.name,
      detail: 'Removed from ${existing.zone}',
    );
  }

  Future<void> updateLearnerProfile({
    required String learnerId,
    required String name,
    required String enrollmentStatus,
    required String parentName,
    required String guardianPhone,
    required String internalHealthNote,
    required Map<String, dynamic> customFields,
    String? locationId,
    bool clearLocation = false,
  }) async {
    state = state.copyWith(
      learners: state.learners.map((l) {
        if (l.id != learnerId) return l;
        return l.copyWith(
          name: name.trim(),
          locationId: locationId,
          clearLocation: clearLocation,
          enrollmentStatus: enrollmentStatus,
          parentName: parentName.trim(),
          guardianPhone: guardianPhone.trim(),
          internalHealthNote: internalHealthNote.trim(),
          customFields: Map<String, dynamic>.from(customFields),
        );
      }).toList(),
    );
    if (useFirestore && _db != null) {
      final payload = <String, dynamic>{
        'name': name.trim(),
        'enrollmentStatus': enrollmentStatus,
        'parentName': parentName.trim(),
        'guardianPhone': guardianPhone.trim(),
        'internalHealthNote': internalHealthNote.trim(),
        'customFields': customFields,
      };
      if (clearLocation) {
        payload['locationId'] = null;
      } else if (locationId != null) {
        payload['locationId'] = locationId;
      }
      await _db.collection('learners').doc(learnerId).update(payload);
    }
    final targetLearner =
        state.learners.where((l) => l.id == learnerId).firstOrNull;
    await _recordAudit(
      action: 'updated',
      entityType: 'learner',
      entityId: learnerId,
      targetLabel: name.trim(),
      detail: 'Updated enrollment ($enrollmentStatus) & guardian contact ($parentName)',
      classroomId: targetLearner?.classroomId,
      learnerId: learnerId,
    );
  }

  Future<void> togglePageWidgetEnabled(PageWidgetId widgetId) async {
    state = state.copyWith(
      pageWidgets: state.pageWidgets
          .map((w) => w.id == widgetId ? w.copyWith(enabled: !w.enabled) : w)
          .toList(),
    );
    if (useFirestore && _db != null) {
      final w = state.pageWidgets.firstWhere((item) => item.id == widgetId);
      await _db.collection('page_widgets').doc(widgetId.key).set(w.toMap());
    }
  }

  Future<void> togglePageWidgetRole(
    PageWidgetId widgetId,
    PortalRole role,
  ) async {
    if (role == PortalRole.admin) return;
    state = state.copyWith(
      pageWidgets: state.pageWidgets.map((w) {
        if (w.id != widgetId) return w;
        final roles = w.allowedRoles.contains(role)
            ? w.allowedRoles.where((r) => r != role).toList()
            : [...w.allowedRoles, role];
        return w.copyWith(allowedRoles: roles);
      }).toList(),
    );
    if (useFirestore && _db != null) {
      final w = state.pageWidgets.firstWhere((item) => item.id == widgetId);
      await _db.collection('page_widgets').doc(widgetId.key).set(w.toMap());
    }
  }

  Future<void> movePageWidget(PageWidgetId widgetId, int delta) async {
    final sorted = [...state.pageWidgets]
      ..sort((a, b) => a.order.compareTo(b.order));
    final idx = sorted.indexWhere((w) => w.id == widgetId);
    final swapIdx = idx + delta;
    if (idx < 0 || swapIdx < 0 || swapIdx >= sorted.length) return;
    final temp = sorted[idx];
    sorted[idx] = sorted[swapIdx];
    sorted[swapIdx] = temp;

    final reindexed = [
      for (var i = 0; i < sorted.length; i++) sorted[i].copyWith(order: i + 1),
    ];
    state = state.copyWith(pageWidgets: reindexed);
    if (useFirestore && _db != null) {
      final batch = _db.batch();
      for (final w in reindexed) {
        batch.set(_db.collection('page_widgets').doc(w.id.key), w.toMap());
      }
      await batch.commit();
    }
  }
}
