import 'dotenv/config';
import express, { type Request, type Response } from 'express';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const IS_PRODUCTION = process.env.NODE_ENV === 'production';

const SUMMARY_RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    executiveOverview: {
      type: Type.STRING,
      description:
        'A crisp 2-3 sentence executive summary of overall school health, operational momentum, and key priorities.',
    },
    urgentAlerts: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          severity: {
            type: Type.STRING,
            description: 'One of: high, medium, low',
          },
          area: {
            type: Type.STRING,
            description: 'Module or operational area (e.g. Attendance, Assessments, Diary, Timetable).',
          },
          summary: {
            type: Type.STRING,
            description: 'Concise description of the issue or pending item.',
          },
          recommendedAction: {
            type: Type.STRING,
            description: 'Specific next step for the school administrator.',
          },
        },
        required: ['severity', 'area', 'summary', 'recommendedAction'],
      },
    },
    positiveHighlights: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          area: {
            type: Type.STRING,
            description: 'Area performing well (e.g. Curriculum, Mastery, Events, Attendance).',
          },
          comment: {
            type: Type.STRING,
            description: 'Brief encouraging commentary on well-going events, classes, or workflows.',
          },
        },
        required: ['area', 'comment'],
      },
    },
    workflowStatuses: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          workflow: {
            type: Type.STRING,
            description: 'Name of the school workflow.',
          },
          status: {
            type: Type.STRING,
            description: 'One of: smooth, attention, blocked',
          },
          summary: {
            type: Type.STRING,
            description: 'One-sentence commentary on workflow execution.',
          },
        },
        required: ['workflow', 'status', 'summary'],
      },
    },
  },
  required: [
    'executiveOverview',
    'urgentAlerts',
    'positiveHighlights',
    'workflowStatuses',
  ],
};

function createGeminiClient(): GoogleGenAI | null {
  const rawKey = process.env.GEMINI_API_KEY?.trim();
  if (!rawKey || rawKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey: rawKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ ok: true, model: 'gemini-4-hydrogen' });
  });

  app.post('/api/admin/ai-summary', async (req: Request, res: Response) => {
    try {
      const { role, snapshot } = req.body ?? {};
      if (role !== 'admin') {
        res.status(403).json({
          error: 'Admin AI briefings are restricted to the Admin Side portal.',
        });
        return;
      }
      if (!snapshot || typeof snapshot !== 'object') {
        res.status(400).json({
          error: 'A valid school operational snapshot is required.',
        });
        return;
      }

      const ai = createGeminiClient();
      if (!ai) {
        res.status(503).json({
          error:
            'GEMINI_API_KEY is not configured yet. Add it in Settings > Secrets to enable live AI briefings.',
        });
        return;
      }

      const prompt = [
        'Analyze this live ScholaECS school snapshot for the School Administrator.',
        'Provide:',
        '1. An executive overview (2-3 sentences).',
        '2. Urgent alerts for pending parent diary acknowledgments, learners scoring Approaching/Developing, attendance late/absent/uniform flags, unscheduled lesson plans, or upcoming exams.',
        '3. Positive highlights commenting on well-going events, high-mastery learners, smooth workflows, and strong curriculum progress.',
        '4. Workflow status summaries across Curriculum, Timetable, Class Register, School Diary, Assessment Books, and Calendar Events.',
        '',
        'School Snapshot JSON:',
        JSON.stringify(snapshot),
      ].join('\n');

      const runGeneration = () =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: prompt,
          config: {
            systemInstruction:
              'You are an expert K-12 school operations analyst assisting a school principal/administrator. Be concrete, cite actual learner/teacher/event names and numbers from the provided JSON snapshot, keep commentary concise and constructive, and never invent data not present in the snapshot.',
            responseMimeType: 'application/json',
            responseSchema: SUMMARY_RESPONSE_SCHEMA,
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          },
        });

      let response;
      try {
        response = await runGeneration();
      } catch (firstErr: unknown) {
        const firstStatus = (firstErr as { status?: number })?.status;
        const firstMsg =
          firstErr instanceof Error ? firstErr.message : String(firstErr);
        if (firstStatus === 503 || firstStatus === 429 || firstMsg.includes('"code":503')) {
          await new Promise((resolve) => setTimeout(resolve, 800));
          response = await runGeneration();
        } else {
          throw firstErr;
        }
      }

      const rawText = (response.text ?? '').trim();
      if (!rawText) {
        res.status(502).json({
          error: 'Gemini returned an empty summary response. Please try again.',
        });
        return;
      }

      const parsed = JSON.parse(rawText);
      res.json({
        model: 'gemini-4-hydrogen',
        generatedAt: new Date().toISOString(),
        summary: parsed,
      });
    } catch (err: unknown) {
      let message =
        err instanceof Error ? err.message : 'Unexpected Gemini API error.';
      let status =
        typeof (err as { status?: unknown })?.status === 'number'
          ? (err as { status: number }).status
          : 500;

      if (message.trim().startsWith('{')) {
        try {
          const parsedErr = JSON.parse(message) as {
            error?: { message?: string; code?: number };
          };
          if (parsedErr.error?.message) {
            message = parsedErr.error.message;
          }
          if (typeof parsedErr.error?.code === 'number') {
            status = parsedErr.error.code;
          }
        } catch {
          // Keep original message if not valid JSON
        }
      }

      res.status(status >= 400 && status < 600 ? status : 500).json({
        error: message,
      });
    }
  });

  const httpServer = http.createServer(app);

  if (!IS_PRODUCTION) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        ws: { server: httpServer },
        hmr: { server: httpServer },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Build output not found. Run npm run build.');
      }
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`ScholaECS server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
