import {
  ArrowRight,
  BookOpen,
  ClipboardCheck,
  GraduationCap,
  LayoutGrid,
  Search,
} from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { buildQuickJumpItems } from '../ecs/engine';
import type { QuickJumpItem, Role, SchoolECSState } from '../ecs/types';
import { AppDialog } from './AppDialog';
import type { SandboxModule } from './SandboxWorkspace';

interface QuickJumpModalProps {
  open: boolean;
  state: SchoolECSState;
  role: Role;
  linkedLearnerIds?: string[];
  onClose: () => void;
  onSelectModule: (module: SandboxModule) => void;
  onSelectLearner: (learnerId: string) => void;
  onSelectRegisterClassroom: (classroomId: string) => void;
}

export function QuickJumpModal({
  open,
  state,
  role,
  linkedLearnerIds,
  onClose,
  onSelectModule,
  onSelectLearner,
  onSelectRegisterClassroom,
}: QuickJumpModalProps) {
  const [query, setQuery] = useState('');
  const [highlightedIdx, setHighlightedIdx] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const items = useMemo(
    () => buildQuickJumpItems(state, role, query, linkedLearnerIds),
    [state, role, query, linkedLearnerIds]
  );

  useEffect(() => {
    if (open) {
      setQuery('');
      setHighlightedIdx(0);
      setTimeout(() => inputRef.current?.focus(), 20);
    }
  }, [open]);

  useEffect(() => {
    if (highlightedIdx >= items.length) {
      setHighlightedIdx(0);
    }
  }, [items.length, highlightedIdx]);

  const handleSelectItem = (item: QuickJumpItem) => {
    onClose();
    if (item.category === 'learner' && item.learnerId) {
      onSelectLearner(item.learnerId);
      return;
    }
    if (item.category === 'classroom' && item.classroomId) {
      onSelectRegisterClassroom(item.classroomId);
      return;
    }
    onSelectModule(item.targetModule as SandboxModule);
  };

  const categoryIcon = (cat: QuickJumpItem['category']) => {
    switch (cat) {
      case 'learner':
        return <GraduationCap className="h-4 w-4 text-blue-700" aria-hidden="true" />;
      case 'classroom':
        return <ClipboardCheck className="h-4 w-4 text-emerald-700" aria-hidden="true" />;
      case 'lesson':
        return <BookOpen className="h-4 w-4 text-violet-700" aria-hidden="true" />;
      default:
        return <LayoutGrid className="h-4 w-4 text-slate-600" aria-hidden="true" />;
    }
  };

  const categoryLabel = (cat: QuickJumpItem['category']) => {
    switch (cat) {
      case 'learner':
        return 'Learner';
      case 'classroom':
        return 'Register';
      case 'lesson':
        return 'Lesson';
      default:
        return 'Page';
    }
  };

  return (
    <AppDialog
      open={open}
      title="Quick Jump"
      subtitle={
        role === 'parent'
          ? 'Search your child’s profile or school events calendar.'
          : 'Jump to any learner, class register, lesson plan, or module (Ctrl/Cmd + K).'
      }
      onClose={onClose}
    >
      <div className="space-y-3">
        <div className="relative">
          <Search
            className="pointer-events-none absolute top-3 left-3 h-4 w-4 text-slate-400"
            aria-hidden="true"
          />
          <input
            ref={inputRef}
            type="search"
            aria-label="Quick jump search"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setHighlightedIdx(0);
            }}
            onKeyDown={(e) => {
              if (e.key === 'ArrowDown' && items.length > 0) {
                e.preventDefault();
                setHighlightedIdx((prev) => (prev + 1) % items.length);
              } else if (e.key === 'ArrowUp' && items.length > 0) {
                e.preventDefault();
                setHighlightedIdx((prev) => (prev - 1 + items.length) % items.length);
              } else if (e.key === 'Enter' && items[highlightedIdx]) {
                e.preventDefault();
                handleSelectItem(items[highlightedIdx]);
              }
            }}
            placeholder={
              role === 'parent'
                ? 'Search child name or calendar...'
                : 'Type e.g. Zuri Mwangi, Grade 5A register, Schemes...'
            }
            className="w-full rounded-lg border border-slate-300 bg-white py-2.5 pr-3 pl-9 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-700 focus:outline-none"
          />
        </div>

        <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 rounded-lg border border-slate-200 bg-white">
          {items.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500">
              No matching learners, classrooms, or pages found for &ldquo;{query}&rdquo;.
            </div>
          ) : (
            items.map((item, idx) => {
              const active = idx === highlightedIdx;
              return (
                <button
                  key={item.id}
                  type="button"
                  onMouseEnter={() => setHighlightedIdx(idx)}
                  onClick={() => handleSelectItem(item)}
                  className={`flex w-full items-center justify-between gap-3 px-3.5 py-2.5 text-left transition-colors ${
                    active ? 'bg-blue-50/80' : 'hover:bg-slate-50'
                  }`}
                >
                  <div className="flex min-w-0 items-center gap-3">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-white">
                      {categoryIcon(item.category)}
                    </div>
                    <div className="min-w-0">
                      <p className="truncate text-xs font-semibold text-slate-900">
                        {item.title}
                      </p>
                      <p className="truncate text-[11px] text-slate-500">
                        {categoryLabel(item.category)} · {item.subtitle}
                      </p>
                    </div>
                  </div>
                  <ArrowRight
                    className={`h-3.5 w-3.5 shrink-0 ${
                      active ? 'text-blue-700' : 'text-slate-400'
                    }`}
                    aria-hidden="true"
                  />
                </button>
              );
            })
          )}
        </div>
      </div>
    </AppDialog>
  );
}
