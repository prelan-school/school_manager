import { Download, GraduationCap, LogOut, Search } from 'lucide-react';

export type MainSection = 'plan' | 'sandbox' | 'specs';

interface TopBarProps {
  activeSection: MainSection;
  onNavigate: (section: MainSection) => void;
  onExportPlan: () => void;
  exportConfirmed: boolean;
  isDevMode?: boolean;
  showQuickJump?: boolean;
  onOpenQuickJump?: () => void;
  showSignOut?: boolean;
  onSignOut?: () => void;
}

export function TopBar({
  activeSection,
  onNavigate,
  onExportPlan,
  exportConfirmed,
  isDevMode = false,
  showQuickJump = false,
  onOpenQuickJump,
  showSignOut,
  onSignOut,
}: TopBarProps) {
  const navItems: { id: MainSection; label: string; shortLabel: string }[] = isDevMode
    ? [
        { id: 'sandbox', label: 'School Web App', shortLabel: 'App' },
        { id: 'plan', label: 'Architecture Plan', shortLabel: 'Plan' },
        { id: 'specs', label: 'Firebase & Dart', shortLabel: 'Specs' },
      ]
    : [];

  return (
    <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-sm">
      <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-4 px-4 py-3 sm:gap-8 sm:px-6 sm:py-3.5">
        {/* Zone 1: Single-line Brand Wordmark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            onNavigate('sandbox');
          }}
          className="inline-flex items-center gap-2 font-display text-base font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 sm:text-lg"
        >
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-blue-700 text-white">
            <GraduationCap className="h-4 w-4" aria-hidden="true" />
          </span>
          <span>ScholaECS</span>
        </a>

        {/* Zone 2: Clean single-line navigation links (Developer links gated behind isDevMode) */}
        <nav
          aria-label="Primary navigation"
          className="flex min-w-0 items-center justify-center gap-4 sm:gap-6"
        >
          {navItems.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onNavigate(item.id)}
                className={`relative py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-700 sm:text-sm ${
                  isActive
                    ? 'font-semibold text-blue-700'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span className="sm:hidden">{item.shortLabel}</span>
                <span className="hidden sm:inline">{item.label}</span>
                {isActive && (
                  <span
                    aria-hidden="true"
                    className="absolute inset-x-0 -bottom-[13px] h-0.5 bg-blue-700 sm:-bottom-[15px]"
                  />
                )}
              </button>
            );
          })}

          {showQuickJump && onOpenQuickJump && activeSection === 'sandbox' && (
            <button
              type="button"
              onClick={onOpenQuickJump}
              aria-label="Quick Jump search"
              className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-600 transition-colors hover:border-slate-300 hover:bg-white hover:text-slate-900 whitespace-nowrap shrink-0"
            >
              <Search className="h-3.5 w-3.5 text-slate-400" aria-hidden="true" />
              <span>Quick Jump</span>
              <span className="hidden font-mono text-[11px] text-slate-400 sm:inline">
                Ctrl K
              </span>
            </button>
          )}
        </nav>

        {/* Zone 3: Primary Action */}
        <div className="flex shrink-0 items-center gap-2">
          {isDevMode && (
            <button
              type="button"
              aria-label="Export architecture plan"
              onClick={onExportPlan}
              className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-2.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-slate-800 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-700 sm:gap-2 sm:px-3.5 sm:py-2"
            >
              <Download className="h-3.5 w-3.5" aria-hidden="true" />
              <span className="sm:hidden">
                {exportConfirmed ? 'Saved' : 'Export'}
              </span>
              <span className="hidden sm:inline">
                {exportConfirmed ? 'Plan Downloaded' : 'Export Plan'}
              </span>
            </button>
          )}

          {showSignOut && onSignOut && (
            <button
              type="button"
              aria-label="Sign out of portal"
              onClick={onSignOut}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-700 transition-colors hover:bg-slate-50 whitespace-nowrap shrink-0 sm:px-3 sm:py-2"
            >
              <LogOut className="h-3.5 w-3.5" aria-hidden="true" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
