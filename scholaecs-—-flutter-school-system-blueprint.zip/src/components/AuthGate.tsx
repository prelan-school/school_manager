import { Eye, EyeOff, KeyRound, Lock, Mail, School, UserPlus } from 'lucide-react';
import { useState, type FormEvent } from 'react';
import {
  authenticatePortalAccount,
  registerPortalAccount,
  resetPortalAccountPassword,
} from '../ecs/engine';
import { DEFAULT_WEB_ADMIN_EMAIL, DEFAULT_WEB_SEED_PASSWORD } from '../ecs/initialData';
import type { PortalAccount, Role, SchoolECSState } from '../ecs/types';
import { ActionSubmitButton, useActionFeedback } from './ActionFeedback';

interface AuthGateProps {
  accounts: PortalAccount[];
  state: SchoolECSState;
  onAuthenticated: (
    account: PortalAccount,
    nextAccounts: PortalAccount[],
    nextState: SchoolECSState
  ) => void;
  onAccountsChange: (nextAccounts: PortalAccount[]) => void;
  onQuickPreviewRole: (role: Role) => void;
}

export function AuthGate({
  accounts,
  state,
  onAuthenticated,
  onAccountsChange,
  onQuickPreviewRole,
}: AuthGateProps) {
  const [mode, setMode] = useState<'signin' | 'signup' | 'reset'>('signin');
  const [email, setEmail] = useState(DEFAULT_WEB_ADMIN_EMAIL);
  const [password, setPassword] = useState(DEFAULT_WEB_SEED_PASSWORD);
  const [confirmPassword, setConfirmPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [role, setRole] = useState<Role>('teacher');
  const [teacherId, setTeacherId] = useState(state.teachers[0]?.id ?? '');
  const [selectedLearnerIds, setSelectedLearnerIds] = useState<string[]>([]);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const { isBusy, runLockedAction, showFeedback } = useActionFeedback();

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setStatusMessage(null);

    const lockLabel =
      mode === 'reset'
        ? 'Updating password...'
        : mode === 'signin'
          ? 'Signing in...'
          : 'Creating account...';

    void runLockedAction(lockLabel, () => {
      if (mode === 'reset') {
        const res = resetPortalAccountPassword(accounts, email, password);
        if (res.error) {
          setError(res.error);
          showFeedback('error', res.error);
          return;
        }
        onAccountsChange(res.accounts);
        setMode('signin');
        const msg = `Password updated for ${email.trim().toLowerCase()}. Sign in with your new password.`;
        setStatusMessage(msg);
        showFeedback('success', 'Password updated successfully');
        return;
      }

      if (mode === 'signin') {
        const res = authenticatePortalAccount(accounts, email, password);
        if (res.error || !res.account) {
          const msg = res.error ?? 'Unable to sign in.';
          setError(msg);
          showFeedback('error', msg);
          return;
        }
        showFeedback('success', `Signed in as ${res.account.displayName}`);
        onAuthenticated(res.account, accounts, state);
        return;
      }

      const res = registerPortalAccount(accounts, state, {
        email,
        password,
        confirmPassword,
        displayName,
        role,
        teacherId: role === 'parent' ? undefined : teacherId,
        linkedLearnerIds: role === 'parent' ? selectedLearnerIds : [],
        emailVerified: true,
      });
      if (res.error || !res.account) {
        const msg = res.error ?? 'Unable to create account.';
        setError(msg);
        showFeedback('error', msg);
        return;
      }
      showFeedback('success', `Account created for ${res.account.displayName}`);
      onAuthenticated(res.account, res.accounts, res.state);
    });
  };

  const toggleChildLink = (learnerId: string) => {
    setSelectedLearnerIds((prev) =>
      prev.includes(learnerId)
        ? prev.filter((id) => id !== learnerId)
        : [...prev, learnerId]
    );
  };

  const quickCredentials: { label: string; email: string; role: Role }[] = [
    { label: 'Admin', email: 'prelanadm@gmail.com', role: 'admin' },
    { label: 'Teacher (Amara)', email: 'amara.okafor@scholaecs.edu', role: 'teacher' },
    { label: 'Teacher (David)', email: 'david.kamau@scholaecs.edu', role: 'teacher' },
    { label: 'Parent (Grace)', email: 'grace.mwangi@family.org', role: 'parent' },
  ];

  return (
    <div className="min-h-screen bg-slate-50 px-4 py-8 sm:px-6 lg:py-12">
      <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 lg:grid-cols-12 lg:items-start">
        {/* Left column: Brand & Portal Role Scope */}
        <section className="space-y-6 lg:col-span-5">
          <div>
            <div className="inline-flex items-center gap-2 text-blue-700">
              <School className="h-6 w-6" aria-hidden="true" />
              <span className="font-display text-xl font-bold tracking-tight text-slate-900">
                ScholaECS
              </span>
            </div>
            <h1 className="mt-4 font-display text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
              Role-Aware School Operations &amp; Curriculum Portal
            </h1>
            <p className="mt-2 text-sm leading-relaxed text-slate-600">
              Sign in or register an account for Administrator, Teacher, or Parent &amp; Guardian access. Each portal projects class schemes, learners, assessments, and diary records cleanly to your role.
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-3">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Included Portal Roles
            </h2>
            <div className="space-y-2.5 text-xs">
              <div>
                <p className="font-semibold text-slate-900">Administrator</p>
                <p className="text-slate-600">
                  Full calendar CRUD, class teachers, class-scoped schemes, teacher coverage matrix, parents directory, learner analytics, and audit logs.
                </p>
              </div>
              <div className="border-t border-slate-100 pt-2.5">
                <p className="font-semibold text-slate-900">Teacher</p>
                <p className="text-slate-600">
                  Class schemes &amp; substrands, lesson delivery tracking, class register, homework diary broadcast, and learner assessments.
                </p>
              </div>
              <div className="border-t border-slate-100 pt-2.5">
                <p className="font-semibold text-slate-900">Parent / Guardian</p>
                <p className="text-slate-600">
                  Scoped to linked children across classes: diary sign-off, mastery progress charts, timetable, and attendance log.
                </p>
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Instant Sandbox Preview
            </h2>
            <p className="mt-1 text-xs text-slate-600">
              Jump directly into any role perspective without typing credentials:
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => onQuickPreviewRole('admin')}
                className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap"
              >
                Preview Admin
              </button>
              <button
                type="button"
                onClick={() => onQuickPreviewRole('teacher')}
                className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap"
              >
                Preview Teacher
              </button>
              <button
                type="button"
                onClick={() => onQuickPreviewRole('parent')}
                className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap"
              >
                Preview Parent
              </button>
            </div>
          </div>
        </section>

        {/* Right column: Auth Card */}
        <section className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 lg:col-span-7">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div className="inline-flex rounded-lg bg-slate-100 p-1">
              <button
                type="button"
                onClick={() => {
                  setMode('signin');
                  setError(null);
                  setStatusMessage(null);
                }}
                className={`rounded-md px-4 py-1.5 text-xs font-semibold transition-colors ${
                  mode === 'signin'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('signup');
                  setError(null);
                  setStatusMessage(null);
                  setEmail('');
                  setPassword('');
                  setConfirmPassword('');
                }}
                className={`rounded-md px-4 py-1.5 text-xs font-semibold transition-colors ${
                  mode === 'signup'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Create Account
              </button>
            </div>

            {mode !== 'reset' && (
              <button
                type="button"
                onClick={() => {
                  setMode('reset');
                  setPassword('');
                  setError(null);
                  setStatusMessage(null);
                }}
                className="text-xs font-semibold text-blue-700 hover:underline"
              >
                Forgot password?
              </button>
            )}
          </div>

          <form onSubmit={handleSubmit} className="mt-5">
            <fieldset disabled={isBusy} className="space-y-4 disabled:opacity-75">
            {mode === 'signup' && (
              <>
                <div>
                  <label
                    htmlFor="auth-display-name"
                    className="mb-1 block text-xs font-medium text-slate-700"
                  >
                    Full Name *
                  </label>
                  <input
                    id="auth-display-name"
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="e.g. Samuel Ochieng"
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                  />
                </div>

                <div>
                  <span className="mb-1.5 block text-xs font-medium text-slate-700">
                    Portal Role *
                  </span>
                  <div className="grid grid-cols-3 gap-2">
                    {(['admin', 'teacher', 'parent'] as Role[]).map((r) => (
                      <button
                        key={r}
                        type="button"
                        onClick={() => setRole(r)}
                        className={`rounded-lg border px-3 py-2 text-xs font-semibold capitalize transition-colors ${
                          role === r
                            ? 'border-blue-700 bg-blue-50 text-blue-800'
                            : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        {r}
                      </button>
                    ))}
                  </div>
                </div>

                {role !== 'parent' ? (
                  <div>
                    <label
                      htmlFor="auth-teacher-link"
                      className="mb-1 block text-xs font-medium text-slate-700"
                    >
                      Bind Staff Profile
                    </label>
                    <select
                      id="auth-teacher-link"
                      value={teacherId}
                      onChange={(e) => setTeacherId(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                    >
                      {state.teachers.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.name} ({t.email})
                        </option>
                      ))}
                    </select>
                  </div>
                ) : (
                  <div>
                    <span className="mb-1.5 block text-xs font-medium text-slate-700">
                      Link Child / Learner Records (or auto-match by guardian email)
                    </span>
                    <div className="grid grid-cols-1 gap-2 rounded-lg border border-slate-200 bg-slate-50 p-3 sm:grid-cols-2">
                      {state.learners.map((l) => {
                        const cls = state.classrooms.find((c) => c.id === l.classroomId);
                        return (
                          <label
                            key={l.id}
                            className="flex items-center gap-2 text-xs text-slate-800"
                          >
                            <input
                              type="checkbox"
                              checked={selectedLearnerIds.includes(l.id)}
                              onChange={() => toggleChildLink(l.id)}
                              className="h-4 w-4 rounded border-slate-300 text-blue-700"
                            />
                            <span className="truncate">
                              {l.name} ({cls?.gradeLevel ?? l.classroomId})
                            </span>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                )}
              </>
            )}

            <div>
              <label
                htmlFor="auth-email"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Email Address *
              </label>
              <div className="relative">
                <Mail
                  className="pointer-events-none absolute top-2.5 left-3 h-4 w-4 text-slate-400"
                  aria-hidden="true"
                />
                <input
                  id="auth-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@school.edu"
                  className="w-full rounded-lg border border-slate-300 bg-white py-2 pr-3 pl-9 text-sm focus:border-blue-700 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="auth-password"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                {mode === 'reset' ? 'New Password (min 6 chars) *' : 'Password *'}
              </label>
              <div className="relative">
                <Lock
                  className="pointer-events-none absolute top-2.5 left-3 h-4 w-4 text-slate-400"
                  aria-hidden="true"
                />
                <input
                  id="auth-password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="w-full rounded-lg border border-slate-300 bg-white py-2 pr-10 pl-9 text-sm focus:border-blue-700 focus:outline-none"
                />
                <button
                  type="button"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute top-2 right-2.5 rounded p-1 text-slate-500 hover:text-slate-800"
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4" aria-hidden="true" />
                  ) : (
                    <Eye className="h-4 w-4" aria-hidden="true" />
                  )}
                </button>
              </div>
            </div>

            {mode === 'signup' && (
              <div>
                <label
                  htmlFor="auth-confirm-password"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Confirm Password *
                </label>
                <input
                  id="auth-confirm-password"
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-enter password"
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                />
              </div>
            )}

            {error && (
              <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs font-medium text-red-700">
                {error}
              </div>
            )}

            {statusMessage && (
              <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-medium text-emerald-800">
                {statusMessage}
              </div>
            )}

            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              {mode === 'reset' && (
                <button
                  type="button"
                  onClick={() => {
                    setMode('signin');
                    setError(null);
                  }}
                  className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  Back to Sign In
                </button>
              )}
              <ActionSubmitButton
                busy={isBusy}
                busyLabel={
                  mode === 'signup'
                    ? 'Creating account...'
                    : mode === 'reset'
                      ? 'Updating...'
                      : 'Signing in...'
                }
                idleLabel={
                  mode === 'signup'
                    ? `Create ${role.charAt(0).toUpperCase() + role.slice(1)} Account`
                    : mode === 'reset'
                      ? 'Update Password'
                      : 'Sign In to Portal'
                }
                icon={
                  mode === 'signup' ? (
                    <UserPlus className="h-4 w-4" aria-hidden="true" />
                  ) : mode === 'reset' ? (
                    <KeyRound className="h-4 w-4" aria-hidden="true" />
                  ) : undefined
                }
                className="ml-auto rounded-lg bg-blue-700 px-5 py-2.5 text-xs font-semibold text-white hover:bg-blue-800"
              />
            </div>
            </fieldset>
          </form>

          {mode === 'signin' && (
            <div className="mt-6 border-t border-slate-100 pt-4">
              <p className="text-xs font-semibold text-slate-600">
                Demo Account Shortcuts (Password:{' '}
                <span className="font-mono text-slate-900">
                  {DEFAULT_WEB_SEED_PASSWORD}
                </span>
                )
              </p>
              <div className="mt-2.5 flex flex-wrap gap-2">
                {quickCredentials.map((cred) => {
                  const isFilled =
                    email.trim().toLowerCase() === cred.email.toLowerCase();
                  return (
                    <button
                      key={cred.email}
                      type="button"
                      onClick={() => {
                        setEmail(cred.email);
                        setPassword(DEFAULT_WEB_SEED_PASSWORD);
                        setError(null);
                        setStatusMessage(null);
                      }}
                      className={`rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                        isFilled
                          ? 'border-blue-700 bg-blue-50 text-blue-800'
                          : 'border-slate-200 bg-slate-50 text-slate-800 hover:border-blue-400 hover:bg-blue-50/50'
                      }`}
                    >
                      Fill {cred.label}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
