import {
  AlertTriangle,
  CheckCircle2,
  Info,
  Loader2,
  X,
  XCircle,
} from 'lucide-react';
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type ReactNode,
} from 'react';

export type FeedbackVariant = 'success' | 'info' | 'warning' | 'error';

export interface FeedbackToast {
  id: number;
  variant: FeedbackVariant;
  message: string;
  title?: string;
}

interface ActionFeedbackContextValue {
  isBusy: boolean;
  busyLabel: string | null;
  toast: FeedbackToast | null;
  showFeedback: (
    variant: FeedbackVariant,
    message: string,
    title?: string
  ) => void;
  dismissFeedback: () => void;
  runLockedAction: <T>(
    label: string,
    work: () => Promise<T> | T
  ) => Promise<T | undefined>;
}

const ActionFeedbackContext = createContext<ActionFeedbackContextValue | null>(
  null
);

const FALLBACK_CONTEXT: ActionFeedbackContextValue = {
  isBusy: false,
  busyLabel: null,
  toast: null,
  showFeedback: () => {},
  dismissFeedback: () => {},
  runLockedAction: async <T,>(_label: string, work: () => Promise<T> | T) =>
    await work(),
};

const VARIANT_STYLES: Record<
  FeedbackVariant,
  { container: string; badge: string; label: string; Icon: typeof CheckCircle2 }
> = {
  success: {
    container: 'border-emerald-800 bg-emerald-700 text-white shadow-lg',
    badge: 'bg-emerald-800/80 text-emerald-50',
    label: 'Saved',
    Icon: CheckCircle2,
  },
  info: {
    container: 'border-blue-800 bg-blue-700 text-white shadow-lg',
    badge: 'bg-blue-800/80 text-blue-50',
    label: 'Updated',
    Icon: Info,
  },
  warning: {
    container: 'border-amber-700 bg-amber-600 text-white shadow-lg',
    badge: 'bg-amber-700/80 text-amber-50',
    label: 'Removed',
    Icon: AlertTriangle,
  },
  error: {
    container: 'border-red-800 bg-red-700 text-white shadow-lg',
    badge: 'bg-red-800/80 text-red-50',
    label: 'Error',
    Icon: XCircle,
  },
};

export function ActionFeedbackProvider({ children }: { children: ReactNode }) {
  const [busyLabel, setBusyLabel] = useState<string | null>(null);
  const [toast, setToast] = useState<FeedbackToast | null>(null);
  const busyRef = useRef(false);
  const timerRef = useRef<number | null>(null);

  const dismissFeedback = useCallback(() => {
    if (timerRef.current !== null && typeof window !== 'undefined') {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    setToast(null);
  }, []);

  const showFeedback = useCallback(
    (variant: FeedbackVariant, message: string, title?: string) => {
      if (timerRef.current !== null && typeof window !== 'undefined') {
        window.clearTimeout(timerRef.current);
      }
      const next: FeedbackToast = {
        id: Date.now() + Math.floor(Math.random() * 1000),
        variant,
        message,
        title,
      };
      setToast(next);
      if (typeof window !== 'undefined') {
        timerRef.current = window.setTimeout(() => {
          setToast((curr) => (curr?.id === next.id ? null : curr));
        }, 4500);
      }
    },
    []
  );

  useEffect(() => {
    return () => {
      if (timerRef.current !== null && typeof window !== 'undefined') {
        window.clearTimeout(timerRef.current);
      }
    };
  }, []);

  const runLockedAction = useCallback(
    async <T,>(
      label: string,
      work: () => Promise<T> | T
    ): Promise<T | undefined> => {
      if (busyRef.current) {
        return undefined;
      }
      busyRef.current = true;
      setBusyLabel(label);
      const startedAt = Date.now();
      try {
        const result = await Promise.resolve(work());
        const elapsed = Date.now() - startedAt;
        const remaining = Math.max(0, 180 - elapsed);
        if (remaining > 0) {
          await new Promise<void>((resolve) => {
            setTimeout(resolve, remaining);
          });
        }
        return result;
      } catch (err) {
        const msg =
          err instanceof Error && err.message
            ? err.message
            : 'Unable to complete action. Please try again.';
        showFeedback('error', msg);
        return undefined;
      } finally {
        busyRef.current = false;
        setBusyLabel(null);
      }
    },
    [showFeedback]
  );

  const isBusy = busyLabel !== null;

  return (
    <ActionFeedbackContext.Provider
      value={{
        isBusy,
        busyLabel,
        toast,
        showFeedback,
        dismissFeedback,
        runLockedAction,
      }}
    >
      {isBusy && (
        <div
          aria-hidden="true"
          data-testid="global-busy-bar"
          className="pointer-events-none fixed top-0 right-0 left-0 z-[110] h-0.5 bg-blue-700 animate-pulse"
        />
      )}

      {children}

      {toast && (
        <div
          role={toast.variant === 'error' ? 'alert' : 'status'}
          aria-live={toast.variant === 'error' ? 'assertive' : 'polite'}
          data-testid="action-snackbar"
          data-variant={toast.variant}
          className={`fixed right-4 bottom-20 z-[100] flex w-[calc(100%-2rem)] max-w-sm items-start gap-3 rounded-xl border px-4 py-3 md:bottom-5 ${
            VARIANT_STYLES[toast.variant].container
          }`}
        >
          {(() => {
            const { Icon } = VARIANT_STYLES[toast.variant];
            return (
              <Icon
                className="mt-0.5 h-4 w-4 shrink-0"
                aria-hidden="true"
              />
            );
          })()}
          <div className="min-w-0 flex-1">
            <p className="text-xs font-bold tracking-wide uppercase opacity-90">
              {toast.title ?? VARIANT_STYLES[toast.variant].label}
            </p>
            <p className="mt-0.5 text-xs font-medium leading-snug">
              {toast.message}
            </p>
          </div>
          <button
            type="button"
            aria-label="Dismiss notification"
            onClick={dismissFeedback}
            className="rounded p-1 opacity-80 transition-opacity hover:bg-black/15 hover:opacity-100"
          >
            <X className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        </div>
      )}
    </ActionFeedbackContext.Provider>
  );
}

export function useActionFeedback(): ActionFeedbackContextValue {
  return useContext(ActionFeedbackContext) ?? FALLBACK_CONTEXT;
}

export function useActionFeedbackOptional(): ActionFeedbackContextValue | null {
  return useContext(ActionFeedbackContext);
}

interface ActionSubmitButtonProps
  extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children'> {
  idleLabel: string;
  busyLabel?: string;
  busy?: boolean;
  icon?: ReactNode;
}

export function ActionSubmitButton({
  idleLabel,
  busyLabel = 'Saving...',
  busy,
  icon,
  disabled,
  className = '',
  type = 'submit',
  ...rest
}: ActionSubmitButtonProps) {
  const feedback = useActionFeedback();
  const effectiveBusy = busy ?? feedback.isBusy;

  return (
    <button
      type={type}
      disabled={effectiveBusy || disabled}
      aria-busy={effectiveBusy}
      className={`inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 transition-colors disabled:cursor-not-allowed disabled:opacity-60 ${className}`}
      {...rest}
    >
      {effectiveBusy ? (
        <>
          <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
          <span>{busyLabel}</span>
        </>
      ) : (
        <>
          {icon}
          <span>{idleLabel}</span>
        </>
      )}
    </button>
  );
}
