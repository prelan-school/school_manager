import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Loader2,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import {
  buildAdminAiSnapshot,
  type AdminAiApiResponse,
} from '../ecs/aiSummaryPayload';
import type { SchoolECSState } from '../ecs/types';

interface AdminAiBriefingCardProps {
  state: SchoolECSState;
}

const AI_BRIEFING_CACHE_KEY = 'schola_ecs_ai_briefing_v1';

interface CachedBriefing {
  fingerprint: string;
  response: AdminAiApiResponse;
}

function buildLocalFallbackBriefing(
  snapshot: ReturnType<typeof buildAdminAiSnapshot>
): AdminAiApiResponse {
  const pendingDiaryCount = snapshot.alertsContext.pendingParentDiarySignoffs.length;
  const taughtCount = snapshot.teacherRollups.reduce((s, t) => s + t.taughtPlans, 0);
  const totalPlans = snapshot.teacherRollups.reduce((s, t) => s + t.totalPlans, 0);
  const lowCoverage = snapshot.substrandCoverage.filter((c) => c.coveragePercent < 50);

  const urgentAlerts: AdminAiApiResponse['summary']['urgentAlerts'] = [];
  if (pendingDiaryCount > 0) {
    urgentAlerts.push({
      area: 'Parent Diary Sign-Offs',
      severity: 'medium',
      summary: `${pendingDiaryCount} diary entr${pendingDiaryCount === 1 ? 'y' : 'ies'} await parent confirmation.`,
      recommendedAction: 'Review unsigned entries in School Diary or notify families.',
    });
  }
  if (lowCoverage.length > 0) {
    urgentAlerts.push({
      area: 'Curriculum Pacing',
      severity: 'medium',
      summary: `${lowCoverage.length} scheme topic${lowCoverage.length === 1 ? '' : 's'} are currently below 50% target coverage.`,
      recommendedAction: 'Check unassigned lesson plans in Schemes of Work.',
    });
  }
  if (snapshot.alertsContext.attendanceOrUniformFlags.length > 0) {
    urgentAlerts.push({
      area: 'Daily Attendance',
      severity: 'high',
      summary: `${snapshot.alertsContext.attendanceOrUniformFlags.length} recent attendance or uniform flag recorded.`,
      recommendedAction: 'Confirm guardian follow-up on flagged learners.',
    });
  }
  if (urgentAlerts.length === 0) {
    urgentAlerts.push({
      area: 'Daily Operations',
      severity: 'low',
      summary: 'No critical unresolved operational gaps flagged across classes.',
      recommendedAction: 'Continue routine daily register and homework logging.',
    });
  }

  const positiveHighlights: AdminAiApiResponse['summary']['positiveHighlights'] = [];
  if (snapshot.highlightsContext.strongAssessments.length > 0) {
    const top = snapshot.highlightsContext.strongAssessments[0];
    positiveHighlights.push({
      area: 'Learner Mastery',
      comment: `${snapshot.highlightsContext.strongAssessments.length} high-performing assessments recorded (top: ${top.learner} at ${top.scorePercent}%).`,
    });
  }
  if (snapshot.upcomingCalendarEvents.length > 0) {
    const nextEvt = snapshot.upcomingCalendarEvents[0];
    positiveHighlights.push({
      area: 'Upcoming School Calendar',
      comment: `Next scheduled milestone: ${nextEvt.title} on ${nextEvt.date}.`,
    });
  }
  if (positiveHighlights.length === 0) {
    positiveHighlights.push({
      area: 'Classroom Readiness',
      comment: `${snapshot.counts.classrooms} classrooms and ${snapshot.counts.teachers} teachers active.`,
    });
  }

  return {
    generatedAt: new Date().toISOString(),
    model: 'local-digest',
    summary: {
      executiveOverview: `${snapshot.counts.learners} enrolled learners across ${snapshot.counts.classrooms} classrooms. ${taughtCount} of ${totalPlans} lesson plans are marked taught, and ${pendingDiaryCount} diary note${pendingDiaryCount === 1 ? '' : 's'} await parent sign-off.`,
      urgentAlerts,
      positiveHighlights,
      workflowStatuses: [
        {
          workflow: 'Class Register',
          status:
            snapshot.alertsContext.attendanceOrUniformFlags.length > 2
              ? 'attention'
              : 'smooth',
          summary: `${snapshot.counts.attendanceRecordsTotal} attendance roll entries logged.`,
        },
        {
          workflow: 'Lesson Delivery',
          status: lowCoverage.length > 2 ? 'attention' : 'smooth',
          summary: `${taughtCount}/${totalPlans} lesson plans taught.`,
        },
        {
          workflow: 'Parent Sign-Offs',
          status: pendingDiaryCount > 0 ? 'attention' : 'smooth',
          summary: `${pendingDiaryCount} awaiting guardian confirmation.`,
        },
      ],
    },
  };
}

export function AdminAiBriefingCard({ state }: AdminAiBriefingCardProps) {
  const snapshot = useMemo(() => buildAdminAiSnapshot(state), [state]);
  const fingerprint = useMemo(
    () =>
      JSON.stringify({
        counts: snapshot.counts,
        pendingDiary: snapshot.alertsContext.pendingParentDiarySignoffs.length,
        lowAtt: snapshot.alertsContext.attendanceOrUniformFlags.length,
        events: snapshot.upcomingCalendarEvents.length,
      }),
    [snapshot]
  );

  const [loading, setLoading] = useState(false);
  const [sourceNote, setSourceNote] = useState<'ai' | 'local'>('local');
  const [briefing, setBriefing] = useState<AdminAiApiResponse>(() => {
    if (typeof window !== 'undefined') {
      try {
        const raw = window.localStorage.getItem(AI_BRIEFING_CACHE_KEY);
        if (raw) {
          const cached = JSON.parse(raw) as CachedBriefing;
          if (cached.fingerprint === fingerprint && cached.response?.summary) {
            return cached.response;
          }
        }
      } catch {
        // Ignore invalid cache
      }
    }
    return buildLocalFallbackBriefing(snapshot);
  });

  const handleGenerate = useCallback(
    async (forceNetwork = true) => {
      if (!forceNetwork && typeof window !== 'undefined') {
        try {
          const raw = window.localStorage.getItem(AI_BRIEFING_CACHE_KEY);
          if (raw) {
            const cached = JSON.parse(raw) as CachedBriefing;
            if (cached.fingerprint === fingerprint && cached.response?.summary) {
              setBriefing(cached.response);
              setSourceNote(cached.response.model === 'local-digest' ? 'local' : 'ai');
              return;
            }
          }
        } catch {
          // Ignore invalid cache
        }
      }

      setLoading(true);
      try {
        const res = await fetch('/api/admin/ai-summary', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ role: 'admin', snapshot }),
        });
        if (res.ok) {
          const data = (await res.json()) as AdminAiApiResponse;
          if (data?.summary) {
            setBriefing(data);
            setSourceNote('ai');
            try {
              window.localStorage.setItem(
                AI_BRIEFING_CACHE_KEY,
                JSON.stringify({ fingerprint, response: data })
              );
            } catch {
              // Ignore quota error
            }
            return;
          }
        }
      } catch {
        // Fall through to cached local digest
      } finally {
        setLoading(false);
      }

      const fallback = buildLocalFallbackBriefing(snapshot);
      setBriefing(fallback);
      setSourceNote('local');
      try {
        window.localStorage.setItem(
          AI_BRIEFING_CACHE_KEY,
          JSON.stringify({ fingerprint, response: fallback })
        );
      } catch {
        // Ignore quota error
      }
    },
    [fingerprint, snapshot]
  );

  useEffect(() => {
    void handleGenerate(false);
  }, [handleGenerate]);

  return (
    <section
      aria-label="School Executive Briefing"
      className="rounded-xl border border-slate-200 bg-white p-5"
    >
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-blue-200 bg-blue-50 text-blue-700">
            <Sparkles className="h-5 w-5" aria-hidden="true" />
          </div>
          <div>
            <div className="flex flex-wrap items-baseline gap-x-2.5 gap-y-0.5">
              <h3 className="font-display text-sm font-bold text-slate-900">
                Daily School Briefing
              </h3>
              <span className="text-xs font-medium text-slate-500">
                {sourceNote === 'ai' ? 'AI Summary Cached' : 'Live Snapshot Digest'}
              </span>
            </div>
            <p className="mt-0.5 text-xs text-slate-600">
              Automatically tracks alerts, pending parent sign-offs, and syllabus progress.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => void handleGenerate(true)}
          disabled={loading}
          className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 transition-colors hover:bg-slate-50 disabled:opacity-60 whitespace-nowrap shrink-0"
        >
          {loading ? (
            <>
              <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
              Refreshing...
            </>
          ) : (
            <>
              <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
              Refresh Briefing
            </>
          )}
        </button>
      </div>

      <div className="mt-4 space-y-4 border-t border-slate-100 pt-4">
        <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h4 className="text-xs font-semibold text-slate-500">
              Overview
            </h4>
            <span className="font-mono text-[11px] text-slate-400 tabular-nums">
              {new Date(briefing.generatedAt).toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit',
              })}
            </span>
          </div>
          <p className="mt-1.5 text-sm leading-relaxed text-slate-800">
            {briefing.summary.executiveOverview}
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <div className="rounded-lg border border-slate-200 bg-white p-4">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-2.5">
              <AlertTriangle
                className="h-4 w-4 text-amber-600"
                aria-hidden="true"
              />
              <h4 className="text-xs font-bold text-slate-900">
                Attention Items ({briefing.summary.urgentAlerts.length})
              </h4>
            </div>
            <div className="mt-3 space-y-2.5">
              {briefing.summary.urgentAlerts.map((alert, idx) => (
                <div
                  key={idx}
                  className="rounded-lg border border-slate-100 bg-slate-50/60 p-3 text-xs"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-slate-900">
                      {alert.area}
                    </span>
                    <span
                      className={`text-[11px] font-semibold capitalize ${
                        alert.severity === 'high'
                          ? 'text-red-700'
                          : alert.severity === 'medium'
                            ? 'text-amber-700'
                            : 'text-slate-600'
                      }`}
                    >
                      {alert.severity}
                    </span>
                  </div>
                  <p className="mt-1 text-slate-700">{alert.summary}</p>
                  <p className="mt-1 font-medium text-blue-700">
                    Next step: {alert.recommendedAction}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-lg border border-slate-200 bg-white p-4">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-2.5">
              <CheckCircle2
                className="h-4 w-4 text-emerald-600"
                aria-hidden="true"
              />
              <h4 className="text-xs font-bold text-slate-900">
                Highlights ({briefing.summary.positiveHighlights.length})
              </h4>
            </div>
            <div className="mt-3 space-y-2.5">
              {briefing.summary.positiveHighlights.map((item, idx) => (
                <div
                  key={idx}
                  className="rounded-lg border border-emerald-100 bg-emerald-50/40 p-3 text-xs"
                >
                  <p className="font-semibold text-emerald-950">{item.area}</p>
                  <p className="mt-1 text-slate-700">{item.comment}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
