import { useEffect, useState, type FormEvent } from 'react';
import {
  broadcastClassroomDiary,
  createDiaryEntry,
  getFieldsForEntity,
} from '../../ecs/engine';
import type { AuditActor, Role, SchoolECSState } from '../../ecs/types';
import { ActionSubmitButton, useActionFeedback } from '../ActionFeedback';
import { AppDialog } from '../AppDialog';
import { DynamicFieldInputs } from '../DynamicFieldsRenderer';

interface DiaryEntryDialogProps {
  open: boolean;
  state: SchoolECSState;
  role: Role;
  activeTeacherId: string;
  actor?: AuditActor;
  initialLearnerId?: string;
  initialClassroomId?: string;
  initialDate?: string;
  initialHomeworkSummary?: string;
  initialTeacherNote?: string;
  onClose: () => void;
  onStateChange: (next: SchoolECSState) => void;
}

export function DiaryEntryDialog({
  open,
  state,
  role,
  activeTeacherId,
  actor,
  initialLearnerId,
  initialClassroomId,
  initialDate,
  initialHomeworkSummary,
  initialTeacherNote,
  onClose,
  onStateChange,
}: DiaryEntryDialogProps) {
  const [targetScope, setTargetScope] = useState<'learner' | 'classroom'>('learner');
  const [selectedLearnerId, setSelectedLearnerId] = useState(
    initialLearnerId || state.learners[0]?.id || ''
  );
  const [selectedClassroomId, setSelectedClassroomId] = useState(
    initialClassroomId || state.classrooms[0]?.id || ''
  );
  const [date, setDate] = useState(initialDate || '2026-11-25');
  const [homeworkSummary, setHomeworkSummary] = useState('');
  const [teacherNote, setTeacherNote] = useState('');
  const [customValues, setCustomValues] = useState<
    Record<string, string | number | boolean>
  >({});
  const [formError, setFormError] = useState<string | null>(null);
  const { isBusy, runLockedAction, showFeedback } = useActionFeedback();

  useEffect(() => {
    if (!open) return;
    setFormError(null);
    if (initialClassroomId) {
      setTargetScope('classroom');
      setSelectedClassroomId(initialClassroomId);
    } else {
      setTargetScope('learner');
    }
    if (initialLearnerId) {
      setSelectedLearnerId(initialLearnerId);
    }
    setDate(initialDate || '2026-11-25');
    setHomeworkSummary(initialHomeworkSummary ?? '');
    setTeacherNote(initialTeacherNote ?? '');
  }, [
    open,
    initialLearnerId,
    initialClassroomId,
    initialDate,
    initialHomeworkSummary,
    initialTeacherNote,
  ]);

  const diaryFields = getFieldsForEntity(state, 'diary_entry', role);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    void runLockedAction('Publishing diary entry...', () => {
      if (targetScope === 'classroom') {
        const res = broadcastClassroomDiary(
          state,
          {
            classroomId: selectedClassroomId,
            teacherId: activeTeacherId,
            date,
            homeworkSummary,
            teacherNote,
            customFields: customValues,
            actorRole: role,
          },
          actor
        );
        if (res.error) {
          setFormError(res.error);
          showFeedback('error', res.error);
          return;
        }
        setFormError(null);
        setHomeworkSummary('');
        setTeacherNote('');
        setCustomValues({});
        onStateChange(res.state);
        showFeedback(
          'success',
          `Homework published to ${res.entries.length} learners`
        );
        onClose();
        return;
      }

      const res = createDiaryEntry(
        state,
        {
          learnerId: selectedLearnerId,
          teacherId: activeTeacherId,
          date,
          homeworkSummary,
          teacherNote,
          customFields: customValues,
          actorRole: role,
        },
        actor
      );
      if (res.error) {
        setFormError(res.error);
        showFeedback('error', res.error);
        return;
      }
      setFormError(null);
      setHomeworkSummary('');
      setTeacherNote('');
      setCustomValues({});
      onStateChange(res.state);
      showFeedback('success', 'Diary entry saved');
      onClose();
    });
  };

  return (
    <AppDialog
      open={open}
      busy={isBusy}
      title={
        targetScope === 'classroom'
          ? 'Post Homework to Classroom Diary'
          : 'Log Daily Diary Entry'
      }
      subtitle="Publish daily homework and teacher notes to a learner or whole classroom."
      onClose={onClose}
    >
      <form onSubmit={handleSubmit}>
        <fieldset disabled={isBusy} className="space-y-4 disabled:opacity-75">
          <div className="inline-flex rounded-lg bg-slate-100 p-1">
            <button
              type="button"
              onClick={() => setTargetScope('learner')}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors ${
                targetScope === 'learner'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Single Learner
            </button>
            <button
              type="button"
              onClick={() => setTargetScope('classroom')}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors ${
                targetScope === 'classroom'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Whole Classroom
            </button>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {targetScope === 'classroom' ? (
              <div>
                <label
                  htmlFor="dlg-diary-classroom"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Classroom
                </label>
                <select
                  id="dlg-diary-classroom"
                  value={selectedClassroomId}
                  onChange={(e) => setSelectedClassroomId(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                >
                  {state.classrooms.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
            ) : (
              <div>
                <label
                  htmlFor="dlg-diary-learner"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Learner
                </label>
                <select
                  id="dlg-diary-learner"
                  value={selectedLearnerId}
                  onChange={(e) => setSelectedLearnerId(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                >
                  {state.learners.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name} ({l.admissionNo})
                    </option>
                  ))}
                </select>
              </div>
            )}
            <div>
              <label
                htmlFor="dlg-diary-date"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Date
              </label>
              <input
                id="dlg-diary-date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="dlg-diary-homework"
              className="mb-1 block text-xs font-medium text-slate-700"
            >
              Homework &amp; Tasks *
            </label>
            <textarea
              id="dlg-diary-homework"
              rows={2}
              value={homeworkSummary}
              onChange={(e) => setHomeworkSummary(e.target.value)}
              placeholder="Describe assigned homework or study tasks..."
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
            />
          </div>

          <div>
            <label
              htmlFor="dlg-diary-note"
              className="mb-1 block text-xs font-medium text-slate-700"
            >
              Teacher Remark
            </label>
            <input
              id="dlg-diary-note"
              type="text"
              value={teacherNote}
              onChange={(e) => setTeacherNote(e.target.value)}
              placeholder="Classroom participation or reminders..."
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
            />
          </div>

          <DynamicFieldInputs
            fields={diaryFields}
            values={customValues}
            role={role}
            onChange={(key, value) =>
              setCustomValues((prev) => ({ ...prev, [key]: value }))
            }
          />

          {formError && (
            <p className="text-xs font-medium text-red-600">{formError}</p>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <ActionSubmitButton
              busy={isBusy}
              busyLabel="Publishing..."
              idleLabel={
                targetScope === 'classroom'
                  ? 'Post to Whole Classroom'
                  : 'Publish Diary Entry'
              }
              className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
            />
          </div>
        </fieldset>
      </form>
    </AppDialog>
  );
}
