import { X } from 'lucide-react';
import { useEffect, useRef, type ReactNode } from 'react';
import { useActionFeedbackOptional } from './ActionFeedback';

interface AppDialogProps {
  open: boolean;
  title: string;
  subtitle?: string;
  busy?: boolean;
  onClose: () => void;
  children: ReactNode;
  maxWidthClass?: string;
}

export function AppDialog({
  open,
  title,
  subtitle,
  busy,
  onClose,
  children,
  maxWidthClass = 'max-w-xl',
}: AppDialogProps) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const feedback = useActionFeedbackOptional();
  const isDialogBusy = Boolean(busy || feedback?.isBusy);

  useEffect(() => {
    const el = dialogRef.current;
    if (!el) return;
    if (open && !el.open) {
      el.showModal();
    } else if (!open && el.open) {
      el.close();
    }
  }, [open]);

  if (!open) {
    return null;
  }

  return (
    <dialog
      ref={dialogRef}
      aria-busy={isDialogBusy}
      onCancel={(e) => {
        e.preventDefault();
        if (!isDialogBusy) {
          onClose();
        }
      }}
      onClick={(e) => {
        if (!isDialogBusy && e.target === dialogRef.current) {
          onClose();
        }
      }}
      className={`m-auto w-[calc(100%-2rem)] ${maxWidthClass} rounded-xl border border-slate-200 bg-white p-0 text-slate-900 shadow-xl backdrop:bg-slate-900/40 backdrop:backdrop-blur-[1px]`}
    >
      <div className="flex items-start justify-between gap-4 border-b border-slate-200 px-6 py-4">
        <div>
          <h2 className="font-display text-base font-bold text-slate-900">
            {title}
          </h2>
          {subtitle && (
            <p className="mt-0.5 text-xs text-slate-500">{subtitle}</p>
          )}
        </div>
        <button
          type="button"
          aria-label={`Close ${title}`}
          disabled={isDialogBusy}
          onClick={() => {
            if (!isDialogBusy) onClose();
          }}
          className="rounded-lg p-1.5 text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-900 disabled:cursor-not-allowed disabled:opacity-40"
        >
          <X className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>
      <div className="max-h-[80vh] overflow-y-auto px-6 py-5">{children}</div>
    </dialog>
  );
}
