import { Clock, UserCheck } from 'lucide-react';
import type { ScoreCandlestickPoint } from '../ecs/types';

export interface BarChartDatum {
  label: string;
  primary: number;
  secondary?: number;
  sublabel?: string;
}

interface GroupedBarChartProps {
  title: string;
  subtitle?: string;
  primaryLabel: string;
  secondaryLabel?: string;
  primaryColor?: string;
  secondaryColor?: string;
  maxValue?: number;
  unit?: string;
  data: BarChartDatum[];
}

export function GroupedBarChart({
  title,
  subtitle,
  primaryLabel,
  secondaryLabel,
  primaryColor = '#1d4ed8',
  secondaryColor = '#059669',
  maxValue,
  unit = '',
  data,
}: GroupedBarChartProps) {
  const computedMax = Math.max(
    1,
    maxValue ??
      Math.max(
        ...data.flatMap((d) => [d.primary, d.secondary ?? 0]),
        10
      )
  );
  const width = Math.max(360, data.length * 92 + 56);
  const height = 210;
  const padLeft = 36;
  const padRight = 16;
  const padTop = 18;
  const padBottom = 44;
  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;
  const slotW = data.length > 0 ? plotW / data.length : plotW;
  const hasSecondary = Boolean(secondaryLabel);

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <div>
          <h4 className="text-sm font-bold text-slate-900">{title}</h4>
          {subtitle && (
            <p className="mt-0.5 text-xs text-slate-500">{subtitle}</p>
          )}
        </div>
        <div className="flex items-center gap-4 text-xs text-slate-600">
          <span className="inline-flex items-center gap-1.5">
            <span
              className="h-2.5 w-2.5 rounded-xs"
              style={{ backgroundColor: primaryColor }}
            />
            {primaryLabel}
          </span>
          {secondaryLabel && (
            <span className="inline-flex items-center gap-1.5">
              <span
                className="h-2.5 w-2.5 rounded-xs"
                style={{ backgroundColor: secondaryColor }}
              />
              {secondaryLabel}
            </span>
          )}
        </div>
      </div>

      {data.length === 0 ? (
        <p className="py-10 text-center text-xs text-slate-500">
          No chart series available for this filter.
        </p>
      ) : (
        <div className="mt-3 overflow-x-auto">
          <svg
            viewBox={`0 0 ${width} ${height}`}
            className="h-52 w-full min-w-[340px]"
            role="img"
            aria-label={title}
          >
            {[0, 0.25, 0.5, 0.75, 1].map((tick) => {
              const y = padTop + plotH * (1 - tick);
              const val = Math.round(computedMax * tick);
              return (
                <g key={tick}>
                  <line
                    x1={padLeft}
                    y1={y}
                    x2={width - padRight}
                    y2={y}
                    stroke="#e2e8f0"
                    strokeWidth="1"
                    strokeDasharray={tick === 0 ? undefined : '3 3'}
                  />
                  <text
                    x={padLeft - 6}
                    y={y + 3}
                    textAnchor="end"
                    fontSize="10"
                    fill="#64748b"
                    className="font-mono"
                  >
                    {val}
                  </text>
                </g>
              );
            })}

            {data.map((d, idx) => {
              const cx = padLeft + slotW * idx + slotW / 2;
              const barW = hasSecondary ? Math.min(20, slotW * 0.28) : Math.min(28, slotW * 0.44);
              const gap = hasSecondary ? 4 : 0;

              const h1 = Math.max(2, (d.primary / computedMax) * plotH);
              const y1 = padTop + plotH - h1;
              const x1 = hasSecondary ? cx - barW - gap / 2 : cx - barW / 2;

              const secVal = d.secondary ?? 0;
              const h2 = Math.max(2, (secVal / computedMax) * plotH);
              const y2 = padTop + plotH - h2;
              const x2 = cx + gap / 2;

              return (
                <g key={d.label}>
                  <rect
                    x={x1}
                    y={y1}
                    width={barW}
                    height={h1}
                    rx="3"
                    fill={primaryColor}
                  >
                    <title>{`${d.label} · ${primaryLabel}: ${d.primary}${unit}`}</title>
                  </rect>
                  <text
                    x={x1 + barW / 2}
                    y={y1 - 4}
                    textAnchor="middle"
                    fontSize="9.5"
                    fill="#0f172a"
                    className="font-mono font-semibold"
                  >
                    {d.primary}
                    {unit}
                  </text>

                  {hasSecondary && (
                    <>
                      <rect
                        x={x2}
                        y={y2}
                        width={barW}
                        height={h2}
                        rx="3"
                        fill={secondaryColor}
                      >
                        <title>{`${d.label} · ${secondaryLabel}: ${secVal}${unit}`}</title>
                      </rect>
                      <text
                        x={x2 + barW / 2}
                        y={y2 - 4}
                        textAnchor="middle"
                        fontSize="9.5"
                        fill="#0f172a"
                        className="font-mono font-semibold"
                      >
                        {secVal}
                        {unit}
                      </text>
                    </>
                  )}

                  <text
                    x={cx}
                    y={padTop + plotH + 15}
                    textAnchor="middle"
                    fontSize="10.5"
                    fill="#334155"
                    fontWeight="600"
                  >
                    {d.label.length > 13 ? `${d.label.slice(0, 12)}…` : d.label}
                  </text>
                  {d.sublabel && (
                    <text
                      x={cx}
                      y={padTop + plotH + 28}
                      textAnchor="middle"
                      fontSize="9.5"
                      fill="#64748b"
                    >
                      {d.sublabel.length > 18 ? `${d.sublabel.slice(0, 17)}…` : d.sublabel}
                    </text>
                  )}
                </g>
              );
            })}
          </svg>
        </div>
      )}
    </div>
  );
}

interface MasteryBreakdownDonutProps {
  title?: string;
  subtitle?: string;
  exceedingCount: number;
  meetingCount: number;
  approachingCount: number;
  developingCount: number;
}

export function MasteryBreakdownDonut({
  title = 'Mastery Breakdown',
  subtitle,
  exceedingCount,
  meetingCount,
  approachingCount,
  developingCount,
}: MasteryBreakdownDonutProps) {
  const segments = [
    { label: 'Exceeding', count: exceedingCount, color: '#059669' },
    { label: 'Meeting', count: meetingCount, color: '#1d4ed8' },
    { label: 'Approaching', count: approachingCount, color: '#d97706' },
    { label: 'Developing', count: developingCount, color: '#dc2626' },
  ];
  const total = segments.reduce((s, item) => s + item.count, 0);
  const radius = 44;
  const circumference = 2 * Math.PI * radius;
  let cumulative = 0;

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4">
      <h4 className="text-sm font-bold text-slate-900">{title}</h4>
      {subtitle && <p className="mt-0.5 text-xs text-slate-500">{subtitle}</p>}

      {total === 0 ? (
        <p className="py-10 text-center text-xs text-slate-500">
          No assessment records yet for this selection.
        </p>
      ) : (
        <div className="mt-4 flex flex-wrap items-center gap-6">
          <div className="relative flex h-32 w-32 shrink-0 items-center justify-center">
            <svg viewBox="0 0 120 120" className="h-32 w-32 -rotate-90" role="img" aria-label={title}>
              <circle
                cx="60"
                cy="60"
                r={radius}
                fill="none"
                stroke="#f1f5f9"
                strokeWidth="16"
              />
              {segments.map((seg) => {
                if (seg.count === 0) return null;
                const frac = seg.count / total;
                const dash = frac * circumference;
                const offset = -cumulative * circumference;
                cumulative += frac;
                return (
                  <circle
                    key={seg.label}
                    cx="60"
                    cy="60"
                    r={radius}
                    fill="none"
                    stroke={seg.color}
                    strokeWidth="16"
                    strokeDasharray={`${dash} ${circumference - dash}`}
                    strokeDashoffset={offset}
                  >
                    <title>{`${seg.label}: ${seg.count} (${Math.round(frac * 100)}%)`}</title>
                  </circle>
                );
              })}
            </svg>
            <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="font-mono text-xl font-bold text-slate-900 tabular-nums">
                {total}
              </span>
              <span className="text-[10px] font-medium text-slate-500">
                entries
              </span>
            </div>
          </div>

          <div className="min-w-[170px] flex-1 space-y-2">
            {segments.map((seg) => {
              const pct = Math.round((seg.count / total) * 100);
              return (
                <div key={seg.label} className="flex items-center justify-between gap-3 text-xs">
                  <span className="inline-flex items-center gap-2 font-medium text-slate-700">
                    <span
                      className="h-2.5 w-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: seg.color }}
                    />
                    {seg.label}
                  </span>
                  <span className="font-mono text-slate-900 tabular-nums">
                    {seg.count} ({pct}%)
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

export interface LineChartPoint {
  label: string;
  value: number;
  caption?: string;
}

interface TrendLineChartProps {
  title: string;
  subtitle?: string;
  color?: string;
  unit?: string;
  points: LineChartPoint[];
}

export function TrendLineChart({
  title,
  subtitle,
  color = '#1d4ed8',
  unit = '%',
  points,
}: TrendLineChartProps) {
  const width = Math.max(340, points.length * 76 + 56);
  const height = 188;
  const padLeft = 36;
  const padRight = 18;
  const padTop = 18;
  const padBottom = 36;
  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;

  const coords = points.map((pt, i) => {
    const x =
      points.length <= 1
        ? padLeft + plotW / 2
        : padLeft + (i / (points.length - 1)) * plotW;
    const clamped = Math.max(0, Math.min(100, pt.value));
    const y = padTop + plotH - (clamped / 100) * plotH;
    return { x, y, pt };
  });

  const polyline = coords.map((c) => `${c.x.toFixed(1)},${c.y.toFixed(1)}`).join(' ');

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <div>
          <h4 className="text-sm font-bold text-slate-900">{title}</h4>
          {subtitle && (
            <p className="mt-0.5 text-xs text-slate-500">{subtitle}</p>
          )}
        </div>
        {points.length > 0 && (
          <span className="font-mono text-xs font-semibold text-blue-700 tabular-nums">
            Latest: {points[points.length - 1].value}
            {unit}
          </span>
        )}
      </div>

      {points.length === 0 ? (
        <p className="py-10 text-center text-xs text-slate-500">
          No chronological data points yet.
        </p>
      ) : (
        <div className="mt-3 overflow-x-auto">
          <svg
            viewBox={`0 0 ${width} ${height}`}
            className="h-44 w-full min-w-[320px]"
            role="img"
            aria-label={title}
          >
            {[0, 25, 50, 75, 100].map((v) => {
              const y = padTop + plotH - (v / 100) * plotH;
              return (
                <g key={v}>
                  <line
                    x1={padLeft}
                    y1={y}
                    x2={width - padRight}
                    y2={y}
                    stroke="#e2e8f0"
                    strokeWidth="1"
                    strokeDasharray={v === 0 ? undefined : '3 3'}
                  />
                  <text
                    x={padLeft - 6}
                    y={y + 3}
                    textAnchor="end"
                    fontSize="10"
                    fill="#64748b"
                    className="font-mono"
                  >
                    {v}
                  </text>
                </g>
              );
            })}

            {coords.length > 1 && (
              <polyline
                fill="none"
                stroke={color}
                strokeWidth="2.5"
                strokeLinejoin="round"
                strokeLinecap="round"
                points={polyline}
              />
            )}

            {coords.map((c, idx) => (
              <g key={`${c.pt.label}_${idx}`}>
                <circle cx={c.x} cy={c.y} r="4.5" fill="#ffffff" stroke={color} strokeWidth="2.5">
                  <title>{`${c.pt.label}: ${c.pt.value}${unit}${c.pt.caption ? ` (${c.pt.caption})` : ''}`}</title>
                </circle>
                <text
                  x={c.x}
                  y={c.y - 8}
                  textAnchor="middle"
                  fontSize="9.5"
                  fill="#0f172a"
                  className="font-mono font-semibold"
                >
                  {c.pt.value}
                  {unit}
                </text>
                <text
                  x={c.x}
                  y={padTop + plotH + 16}
                  textAnchor="middle"
                  fontSize="10"
                  fill="#475569"
                  className="font-mono"
                >
                  {c.pt.label}
                </text>
              </g>
            ))}
          </svg>
        </div>
      )}
    </div>
  );
}

interface ScoreCandlestickChartProps {
  title: string;
  subtitle?: string;
  points: ScoreCandlestickPoint[];
}

export function ScoreCandlestickChart({
  title,
  subtitle,
  points,
}: ScoreCandlestickChartProps) {
  const width = Math.max(360, points.length * 88 + 56);
  const height = 216;
  const padLeft = 36;
  const padRight = 18;
  const padTop = 18;
  const padBottom = 46;
  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;
  const slotW = points.length > 0 ? plotW / points.length : plotW;

  const yFor = (score: number) =>
    padTop + plotH - (Math.max(0, Math.min(100, score)) / 100) * plotH;

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <div>
          <h4 className="text-sm font-bold text-slate-900">{title}</h4>
          {subtitle && (
            <p className="mt-0.5 text-xs text-slate-500">{subtitle}</p>
          )}
        </div>
        <div className="flex items-center gap-3 text-[11px] text-slate-600">
          <span className="inline-flex items-center gap-1">
            <span className="h-2.5 w-2.5 rounded-xs bg-emerald-600" />
            Gain (Close &ge; Open)
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="h-2.5 w-2.5 rounded-xs bg-red-600" />
            Dip (Close &lt; Open)
          </span>
        </div>
      </div>

      {points.length === 0 ? (
        <p className="py-10 text-center text-xs text-slate-500">
          No assessment spread points to plot yet.
        </p>
      ) : (
        <>
          <div className="mt-3 overflow-x-auto">
            <svg
              viewBox={`0 0 ${width} ${height}`}
              className="h-52 w-full min-w-[340px]"
              role="img"
              aria-label={title}
            >
              {[0, 25, 50, 75, 100].map((v) => {
                const y = yFor(v);
                return (
                  <g key={v}>
                    <line
                      x1={padLeft}
                      y1={y}
                      x2={width - padRight}
                      y2={y}
                      stroke="#e2e8f0"
                      strokeWidth="1"
                      strokeDasharray={v === 0 ? undefined : '3 3'}
                    />
                    <text
                      x={padLeft - 6}
                      y={y + 3}
                      textAnchor="end"
                      fontSize="10"
                      fill="#64748b"
                      className="font-mono"
                    >
                      {v}
                    </text>
                  </g>
                );
              })}

              {points.map((pt, idx) => {
                const cx = padLeft + slotW * idx + slotW / 2;
                const yHigh = yFor(pt.high);
                const yLow = yFor(pt.low);
                const yOpen = yFor(pt.open);
                const yClose = yFor(pt.close);
                const yAvg = yFor(pt.average);
                const bullish = pt.close >= pt.open;
                const color = bullish ? '#059669' : '#dc2626';
                const bodyTop = Math.min(yOpen, yClose);
                const bodyHeight = Math.max(4, Math.abs(yClose - yOpen));
                const candleW = Math.min(22, slotW * 0.34);

                return (
                  <g key={pt.label}>
                    {/* High-Low range wick */}
                    <line
                      x1={cx}
                      y1={yHigh}
                      x2={cx}
                      y2={yLow}
                      stroke={color}
                      strokeWidth="2"
                    >
                      <title>{`${pt.label} (n=${pt.sampleCount}) · Open ${pt.open}% · High ${pt.high}% · Low ${pt.low}% · Close ${pt.close}% · Avg ${pt.average}%`}</title>
                    </line>
                    <line
                      x1={cx - 5}
                      y1={yHigh}
                      x2={cx + 5}
                      y2={yHigh}
                      stroke={color}
                      strokeWidth="1.5"
                    />
                    <line
                      x1={cx - 5}
                      y1={yLow}
                      x2={cx + 5}
                      y2={yLow}
                      stroke={color}
                      strokeWidth="1.5"
                    />
                    {/* Open-Close body */}
                    <rect
                      x={cx - candleW / 2}
                      y={bodyTop}
                      width={candleW}
                      height={bodyHeight}
                      rx="2"
                      fill={color}
                      fillOpacity="0.88"
                    >
                      <title>{`${pt.label} · Open ${pt.open}% -> Close ${pt.close}% (Avg ${pt.average}%)`}</title>
                    </rect>
                    {/* Mean marker */}
                    <circle cx={cx} cy={yAvg} r="2.5" fill="#ffffff" stroke="#0f172a" strokeWidth="1.2" />

                    <text
                      x={cx}
                      y={yHigh - 5}
                      textAnchor="middle"
                      fontSize="9"
                      fill="#0f172a"
                      className="font-mono font-semibold"
                    >
                      {pt.high}%
                    </text>
                    <text
                      x={cx}
                      y={padTop + plotH + 15}
                      textAnchor="middle"
                      fontSize="10.5"
                      fill="#334155"
                      fontWeight="600"
                    >
                      {pt.label}
                    </text>
                    <text
                      x={cx}
                      y={padTop + plotH + 28}
                      textAnchor="middle"
                      fontSize="9"
                      fill="#64748b"
                      className="font-mono"
                    >
                      n={pt.sampleCount} · avg {pt.average}%
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </>
      )}
    </div>
  );
}

interface AuditAttributionLineProps {
  who?: string;
  when?: string;
  prefix?: string;
}

export function AuditAttributionLine({
  who,
  when,
  prefix,
}: AuditAttributionLineProps) {
  if (!who && !when) return null;
  return (
    <span className="inline-flex flex-wrap items-center gap-1.5 text-[11px] text-slate-500">
      <UserCheck className="h-3 w-3 text-slate-400" aria-hidden="true" />
      <span>{prefix ? `${prefix} ${who || 'Staff'}` : who || 'Staff'}</span>
      {when && (
        <>
          <span aria-hidden="true">·</span>
          <Clock className="h-3 w-3 text-slate-400" aria-hidden="true" />
          <span className="font-mono tabular-nums">{when}</span>
        </>
      )}
    </span>
  );
}
