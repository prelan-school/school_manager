import {
  ClipboardCheck,
  Clock,
  Home,
  LayoutGrid,
  Users,
} from 'lucide-react';
import { useState } from 'react';
import type { AuditActor, PortalAccount, Role, SchoolECSState } from '../ecs/types';
import { AppDialog } from './AppDialog';
import { LearnerProfilePage } from './LearnerProfilePage';
import {
  AdminCoverageModule,
  SchemaStudioModule,
} from './modules/AdminCoverageAndSchemaModule';
import {
  AdminParentsModule,
  ClassroomAnalyticsModule,
} from './modules/AdminParentsAndClassroomsModules';
import { AssessmentsModule } from './modules/AssessmentsModule';
import { DiaryModule } from './modules/DiaryModule';
import { HomeDashboardModule } from './modules/HomeDashboardModule';
import { LearnersDirectoryModule } from './modules/LearnersDirectoryModule';
import { LessonPlansModule } from './modules/LessonPlansModule';
import { SchemesModule } from './modules/SchemesModule';
import {
  ClassRegisterModule,
  TimetableModule,
} from './modules/TimetableAndRegisterModule';
import { PWAInstallButton } from './PWAInstallButton';
import { QuickJumpModal } from './QuickJumpModal';

export type SandboxModule =
  | 'home'
  | 'learners'
  | 'diary'
  | 'schemes'
  | 'assessments'
  | 'lessons'
  | 'timetable'
  | 'register'
  | 'classrooms'
  | 'parents'
  | 'coverage'
  | 'schema';

export interface LessonPrefillDraft {
  classroomId: string;
  subjectId?: string;
  teacherId?: string;
  timetableSlotId?: string;
  scheduledDate?: string;
}

export interface DiaryPrefillInput {
  learnerId?: string;
  classroomId?: string;
  date?: string;
  homeworkSummary?: string;
  teacherNote?: string;
}

interface SandboxWorkspaceProps {
  state: SchoolECSState;
  role: Role;
  activeModule: SandboxModule;
  activeTeacherId: string;
  activeParentUserId: string;
  activeLearnerId: string;
  selectedLearnerId: string | null;
  currentAccount?: PortalAccount | null;
  actor?: AuditActor;
  isDevMode?: boolean;
  quickJumpOpen?: boolean;
  lessonPrefill?: LessonPrefillDraft | null;
  onToggleDevMode?: () => void;
  onSetQuickJumpOpen?: (open: boolean) => void;
  onClearLessonPrefill?: () => void;
  onCreateLessonFromSlot?: (draft: LessonPrefillDraft) => void;
  onRoleChange: (role: Role) => void;
  onModuleChange: (module: SandboxModule) => void;
  onTeacherChange: (teacherId: string) => void;
  onParentUserChange: (userId: string) => void;
  onLearnerChange: (learnerId: string) => void;
  onOpenLearnerPage: (learnerId: string) => void;
  onCloseLearnerPage: () => void;
  onOpenDiaryDialog: (input?: string | DiaryPrefillInput) => void;
  onOpenAssessmentDialog: (learnerId?: string) => void;
  onStateChange: (next: SchoolECSState) => void;
}

interface ModuleTabDef {
  id: SandboxModule;
  label: string;
  parentLabel?: string;
  group: 'today' | 'learners' | 'planning' | 'admin';
  roles: Role[];
}

const MODULE_TABS: ModuleTabDef[] = [
  {
    id: 'home',
    label: 'Home & Calendar',
    parentLabel: 'School Events & Calendar',
    group: 'today',
    roles: ['admin', 'teacher', 'parent'],
  },
  {
    id: 'timetable',
    label: 'Timetable',
    group: 'today',
    roles: ['admin', 'teacher'],
  },
  {
    id: 'register',
    label: 'Class Register',
    group: 'today',
    roles: ['admin', 'teacher'],
  },
  {
    id: 'learners',
    label: 'Learners',
    parentLabel: "My Child's Details",
    group: 'learners',
    roles: ['admin', 'teacher', 'parent'],
  },
  {
    id: 'diary',
    label: 'School Diary',
    group: 'learners',
    roles: ['admin', 'teacher'],
  },
  {
    id: 'assessments',
    label: 'Assessments',
    group: 'learners',
    roles: ['admin', 'teacher'],
  },
  {
    id: 'schemes',
    label: 'Schemes of Work',
    group: 'planning',
    roles: ['admin', 'teacher'],
  },
  {
    id: 'lessons',
    label: 'Lesson Plans',
    group: 'planning',
    roles: ['admin', 'teacher'],
  },
  {
    id: 'coverage',
    label: 'Coverage & Audit',
    group: 'admin',
    roles: ['admin'],
  },
  {
    id: 'classrooms',
    label: 'Classrooms',
    group: 'admin',
    roles: ['admin'],
  },
  {
    id: 'parents',
    label: 'Parents & Zones',
    group: 'admin',
    roles: ['admin'],
  },
  {
    id: 'schema',
    label: 'Custom Fields & Terms',
    group: 'admin',
    roles: ['admin'],
  },
];

const NAV_GROUPS: { id: ModuleTabDef['group']; label: string }[] = [
  { id: 'today', label: 'Today' },
  { id: 'learners', label: 'Learners' },
  { id: 'planning', label: 'Planning' },
  { id: 'admin', label: 'School Admin' },
];

const REGISTER_PREF_KEY = 'schola_ecs_register_prefs_v1';

function loadRegisterPrefs(defaultClassroomId: string): {
  classroomId: string;
  date: string;
} {
  if (typeof window === 'undefined') {
    return { classroomId: defaultClassroomId, date: '2026-11-25' };
  }
  try {
    const raw = window.localStorage.getItem(REGISTER_PREF_KEY);
    if (!raw) return { classroomId: defaultClassroomId, date: '2026-11-25' };
    const parsed = JSON.parse(raw) as { classroomId?: string; date?: string };
    return {
      classroomId: parsed.classroomId || defaultClassroomId,
      date: parsed.date || '2026-11-25',
    };
  } catch {
    return { classroomId: defaultClassroomId, date: '2026-11-25' };
  }
}

export function SandboxWorkspace({
  state,
  role,
  activeModule,
  activeTeacherId,
  activeParentUserId,
  activeLearnerId,
  selectedLearnerId,
  currentAccount,
  actor,
  isDevMode = false,
  quickJumpOpen = false,
  lessonPrefill = null,
  onToggleDevMode,
  onSetQuickJumpOpen,
  onClearLessonPrefill,
  onCreateLessonFromSlot,
  onRoleChange,
  onModuleChange,
  onTeacherChange,
  onParentUserChange,
  onLearnerChange,
  onOpenLearnerPage,
  onCloseLearnerPage,
  onOpenDiaryDialog,
  onOpenAssessmentDialog,
  onStateChange,
}: SandboxWorkspaceProps) {
  const [focusedClassroomId, setFocusedClassroomId] = useState<string>(
    state.classrooms[0]?.id ?? 'cls_5a'
  );
  const [registerPrefs, setRegisterPrefs] = useState<{
    classroomId: string;
    date: string;
  }>(() => loadRegisterPrefs(state.classrooms[0]?.id ?? 'cls_5a'));
  const [mobileMoreOpen, setMobileMoreOpen] = useState(false);

  const showRoleSwitcher = !currentAccount || isDevMode;

  const updateRegisterPrefs = (next: { classroomId: string; date: string }) => {
    setRegisterPrefs(next);
    try {
      window.localStorage.setItem(REGISTER_PREF_KEY, JSON.stringify(next));
    } catch {
      // Ignore quota error
    }
  };

  const handleOpenClassroom = (classroomId: string) => {
    setFocusedClassroomId(classroomId);
    onCloseLearnerPage();
    onModuleChange('classrooms');
  };

  const handleNavigateRegister = (classroomId?: string) => {
    if (classroomId) {
      updateRegisterPrefs({ ...registerPrefs, classroomId });
    }
    onCloseLearnerPage();
    onModuleChange('register');
  };

  const availableTabs = MODULE_TABS.filter((t) => t.roles.includes(role));
  const resolvedModule = availableTabs.some((t) => t.id === activeModule)
    ? activeModule
    : availableTabs[0].id;

  const guardianAccounts = state.users.filter((u) => u.linkedLearnerIds.length > 0);
  const activeGuardian =
    guardianAccounts.find((u) => u.id === activeParentUserId) ??
    guardianAccounts[0];
  const guardianChildren = activeGuardian
    ? state.learners.filter((l) =>
        activeGuardian.linkedLearnerIds.includes(l.id)
      )
    : state.learners;
  const resolvedActiveLearnerId = guardianChildren.some(
    (l) => l.id === activeLearnerId
  )
    ? activeLearnerId
    : (guardianChildren[0]?.id ?? activeLearnerId);

  const scopedSelectedLearnerId =
    selectedLearnerId && role === 'parent'
      ? resolvedActiveLearnerId
      : selectedLearnerId;

  const activeGroup =
    availableTabs.find((t) => t.id === resolvedModule)?.group ?? 'today';

  const selectTab = (tabId: SandboxModule) => {
    onCloseLearnerPage();
    onModuleChange(tabId);
    setMobileMoreOpen(false);
    if (role === 'parent' && tabId === 'learners') {
      onOpenLearnerPage(resolvedActiveLearnerId);
    }
  };

  return (
    <div className="mx-auto max-w-[1440px] px-4 py-5 pb-24 sm:px-6 sm:py-6 md:pb-8">
      {/* Workspace Navigation & Persona Control Bar */}
      <div className="rounded-xl border border-slate-200 bg-white p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {showRoleSwitcher ? (
            <div className="flex flex-wrap items-center gap-3">
              <span className="text-xs font-semibold text-slate-500">
                {!currentAccount ? 'Demo Preview Role' : 'Active Portal Role'}
              </span>
              <div
                role="group"
                aria-label="Portal role switcher"
                className="inline-flex rounded-lg bg-slate-100 p-1"
              >
                {(['admin', 'teacher', 'parent'] as Role[]).map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => onRoleChange(r)}
                    className={`rounded-md px-3 py-1.5 text-xs font-semibold capitalize transition-colors whitespace-nowrap shrink-0 ${
                      role === r
                        ? 'bg-white text-blue-700 shadow-sm'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {r === 'admin'
                      ? 'Admin Side'
                      : r === 'teacher'
                        ? 'Teacher Side'
                        : 'Parent Portal'}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-xs text-slate-600">
              <span className="font-semibold text-slate-900">
                {currentAccount?.displayName}
              </span>
              <span aria-hidden="true">·</span>
              <span className="capitalize">{role} Portal</span>
            </div>
          )}

          <div className="flex flex-wrap items-center gap-3">
            {role === 'teacher' && (
              <div className="flex items-center gap-2">
                <label
                  htmlFor="active-teacher-select"
                  className="text-xs font-medium text-slate-600"
                >
                  Teacher
                </label>
                <select
                  id="active-teacher-select"
                  value={activeTeacherId}
                  onChange={(e) => onTeacherChange(e.target.value)}
                  className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
                >
                  {state.teachers.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {role === 'parent' && (
              <div className="flex flex-wrap items-center gap-2">
                {showRoleSwitcher && guardianAccounts.length > 0 && (
                  <div className="flex items-center gap-1.5">
                    <label
                      htmlFor="active-guardian-select"
                      className="text-xs font-medium text-slate-600"
                    >
                      Guardian
                    </label>
                    <select
                      id="active-guardian-select"
                      value={activeGuardian?.id ?? ''}
                      onChange={(e) => onParentUserChange(e.target.value)}
                      className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
                    >
                      {guardianAccounts.map((u) => (
                        <option key={u.id} value={u.id}>
                          {u.displayName} ({u.linkedLearnerIds.length} child
                          {u.linkedLearnerIds.length === 1 ? '' : 'ren'})
                        </option>
                      ))}
                    </select>
                  </div>
                )}
                {guardianChildren.length > 0 && (
                  <div className="flex items-center gap-1.5">
                    <label
                      htmlFor="active-parent-select"
                      className="text-xs font-medium text-slate-600"
                    >
                      Child
                    </label>
                    <select
                      id="active-parent-select"
                      value={resolvedActiveLearnerId}
                      onChange={(e) => onLearnerChange(e.target.value)}
                      className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
                    >
                      {guardianChildren.map((l) => (
                        <option key={l.id} value={l.id}>
                          {l.name} ({l.admissionNo})
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
            )}

            <PWAInstallButton />
          </div>
        </div>

        {/* Grouped Navigation (4 Task Groups for Staff, 2 Simple Tabs for Parent) */}
        {role === 'parent' ? (
          <div
            role="tablist"
            aria-label="Parent portal views"
            className="mt-3 flex flex-nowrap gap-2 border-t border-slate-100 pt-3"
          >
            {availableTabs.map((tab) => {
              const isSelected =
                !scopedSelectedLearnerId && resolvedModule === tab.id;
              return (
                <button
                  key={tab.id}
                  role="tab"
                  type="button"
                  aria-selected={isSelected}
                  onClick={() => selectTab(tab.id)}
                  className={`rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    isSelected
                      ? 'bg-blue-700 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {tab.parentLabel ?? tab.label}
                </button>
              );
            })}
          </div>
        ) : (
          <div
            role="tablist"
            aria-label="School software modules"
            className="mt-3 hidden flex-wrap items-center gap-x-5 gap-y-2 border-t border-slate-100 pt-3 md:flex"
          >
            {NAV_GROUPS.map((grp) => {
              const grpTabs = availableTabs.filter((t) => t.group === grp.id);
              if (grpTabs.length === 0) return null;
              const isGroupActive =
                !scopedSelectedLearnerId && activeGroup === grp.id;
              return (
                <div
                  key={grp.id}
                  className="flex flex-wrap items-center gap-1.5"
                >
                  <span
                    className={`text-[11px] font-semibold whitespace-nowrap ${
                      isGroupActive ? 'text-blue-700' : 'text-slate-400'
                    }`}
                  >
                    {grp.label}
                  </span>
                  <div className="flex flex-wrap items-center gap-1">
                    {grpTabs.map((tab) => {
                      const isSelected =
                        !scopedSelectedLearnerId && resolvedModule === tab.id;
                      return (
                        <button
                          key={tab.id}
                          role="tab"
                          type="button"
                          aria-selected={isSelected}
                          onClick={() => selectTab(tab.id)}
                          className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                            isSelected
                              ? 'bg-blue-700 text-white'
                              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                          }`}
                        >
                          {tab.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Active Module or Loosely Coupled Learner Page Viewport */}
      <main className="mt-6">
        {scopedSelectedLearnerId ? (
          <div className="space-y-4">
            {role === 'parent' && guardianChildren.length > 1 && (
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-4">
                <div>
                  <p className="text-xs font-semibold text-slate-500">
                    Viewing Child Details
                  </p>
                  <p className="font-display text-base font-bold text-slate-900">
                    {state.learners.find((l) => l.id === scopedSelectedLearnerId)?.name}
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs text-slate-500">Switch child:</span>
                  {guardianChildren.map((child) => {
                    const isCur = scopedSelectedLearnerId === child.id;
                    const cls = state.classrooms.find((c) => c.id === child.classroomId);
                    return (
                      <button
                        key={child.id}
                        type="button"
                        onClick={() => {
                          onLearnerChange(child.id);
                          onOpenLearnerPage(child.id);
                        }}
                        className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                          isCur
                            ? 'bg-blue-700 text-white shadow-xs'
                            : 'border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        {child.name} ({cls?.name ?? child.admissionNo})
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
            <LearnerProfilePage
              state={state}
              learnerId={scopedSelectedLearnerId}
              role={role}
              actor={actor}
              onBack={() => {
                onCloseLearnerPage();
                onModuleChange('home');
              }}
              onStateChange={onStateChange}
              onOpenDiaryDialog={(lid) => onOpenDiaryDialog(lid)}
              onOpenAssessmentDialog={(lid) => onOpenAssessmentDialog(lid)}
              onOpenClassroom={handleOpenClassroom}
            />
          </div>
        ) : (
          <>
            {resolvedModule === 'home' && (
              <HomeDashboardModule
                state={state}
                role={role}
                actor={actor}
                activeTeacherId={activeTeacherId}
                activeLearnerId={resolvedActiveLearnerId}
                linkedLearnerIds={activeGuardian?.linkedLearnerIds}
                onNavigateModule={(nextMod) => {
                  if (role === 'parent' && nextMod === 'learners') {
                    onOpenLearnerPage(resolvedActiveLearnerId);
                  } else {
                    onCloseLearnerPage();
                  }
                  onModuleChange(nextMod);
                }}
                onNavigateRegister={handleNavigateRegister}
                onCreateLessonFromSlot={onCreateLessonFromSlot}
                onOpenLearnerPage={(lid) => {
                  onLearnerChange(lid);
                  onOpenLearnerPage(lid);
                }}
                onStateChange={onStateChange}
              />
            )}
            {resolvedModule === 'learners' &&
              (role === 'parent' ? (
                <div className="space-y-4">
                  {guardianChildren.length > 1 && (
                    <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-4">
                      <div>
                        <p className="text-xs font-semibold text-slate-500">
                          Viewing Child Details
                        </p>
                        <p className="font-display text-base font-bold text-slate-900">
                          {state.learners.find((l) => l.id === resolvedActiveLearnerId)?.name}
                        </p>
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs text-slate-500">Switch child:</span>
                        {guardianChildren.map((child) => {
                          const isCur = resolvedActiveLearnerId === child.id;
                          const cls = state.classrooms.find((c) => c.id === child.classroomId);
                          return (
                            <button
                              key={child.id}
                              type="button"
                              onClick={() => {
                                onLearnerChange(child.id);
                                onOpenLearnerPage(child.id);
                              }}
                              className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                                isCur
                                  ? 'bg-blue-700 text-white shadow-xs'
                                  : 'border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                              }`}
                            >
                              {child.name} ({cls?.name ?? child.admissionNo})
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                  <LearnerProfilePage
                    state={state}
                    learnerId={resolvedActiveLearnerId}
                    role={role}
                    actor={actor}
                    onBack={() => onModuleChange('home')}
                    onStateChange={onStateChange}
                    onOpenDiaryDialog={(lid) => onOpenDiaryDialog(lid)}
                    onOpenAssessmentDialog={(lid) => onOpenAssessmentDialog(lid)}
                    onOpenClassroom={handleOpenClassroom}
                  />
                </div>
              ) : (
                <LearnersDirectoryModule
                  state={state}
                  role={role}
                  activeLearnerId={resolvedActiveLearnerId}
                  linkedLearnerIds={activeGuardian?.linkedLearnerIds}
                  actor={actor}
                  onStateChange={onStateChange}
                  onOpenLearnerPage={onOpenLearnerPage}
                  onOpenDiaryDialog={onOpenDiaryDialog}
                  onOpenAssessmentDialog={onOpenAssessmentDialog}
                />
              ))}
            {resolvedModule === 'diary' && (
              <DiaryModule
                state={state}
                role={role}
                activeTeacherId={activeTeacherId}
                activeLearnerId={resolvedActiveLearnerId}
                actor={actor}
                onStateChange={onStateChange}
                onOpenDiaryDialog={onOpenDiaryDialog}
                onOpenLearnerPage={onOpenLearnerPage}
              />
            )}
            {resolvedModule === 'schemes' && (
              <SchemesModule
                state={state}
                role={role}
                activeTeacherId={activeTeacherId}
                actor={actor}
                onStateChange={onStateChange}
              />
            )}
            {resolvedModule === 'assessments' && (
              <AssessmentsModule
                state={state}
                role={role}
                activeLearnerId={resolvedActiveLearnerId}
                onOpenAssessmentDialog={onOpenAssessmentDialog}
                onOpenLearnerPage={onOpenLearnerPage}
              />
            )}
            {resolvedModule === 'lessons' && (
              <LessonPlansModule
                state={state}
                role={role}
                activeTeacherId={activeTeacherId}
                actor={actor}
                initialPrefill={lessonPrefill}
                onClearPrefill={onClearLessonPrefill}
                onOpenHomeworkDialog={(prefill) => onOpenDiaryDialog(prefill)}
                onStateChange={onStateChange}
              />
            )}
            {resolvedModule === 'timetable' && (
              <TimetableModule
                state={state}
                role={role}
                activeTeacherId={activeTeacherId}
                actor={actor}
                onCreateLessonFromSlot={onCreateLessonFromSlot}
                onOpenHomeworkDialog={(prefill) => onOpenDiaryDialog(prefill)}
                onStateChange={onStateChange}
              />
            )}
            {resolvedModule === 'register' && (
              <ClassRegisterModule
                state={state}
                role={role}
                activeTeacherId={activeTeacherId}
                activeLearnerId={resolvedActiveLearnerId}
                stickyClassroomId={registerPrefs.classroomId}
                stickyDate={registerPrefs.date}
                onChangeRegisterPrefs={updateRegisterPrefs}
                actor={actor}
                onStateChange={onStateChange}
                onOpenLearnerPage={onOpenLearnerPage}
              />
            )}
            {resolvedModule === 'classrooms' && (
              <ClassroomAnalyticsModule
                state={state}
                selectedClassroomId={focusedClassroomId}
                onSelectClassroom={setFocusedClassroomId}
                onStateChange={onStateChange}
                onOpenLearnerPage={onOpenLearnerPage}
                onOpenSchemes={() => {
                  onCloseLearnerPage();
                  onModuleChange('schemes');
                }}
                actor={actor}
              />
            )}
            {resolvedModule === 'parents' && (
              <AdminParentsModule
                state={state}
                actor={actor}
                onStateChange={onStateChange}
                onOpenLearnerPage={onOpenLearnerPage}
                onOpenClassroom={handleOpenClassroom}
              />
            )}
            {resolvedModule === 'coverage' && (
              <AdminCoverageModule
                state={state}
                actor={actor}
                onStateChange={onStateChange}
                onNavigateModule={(nextMod) => {
                  onCloseLearnerPage();
                  onModuleChange(nextMod);
                }}
                onSelectClassroom={handleOpenClassroom}
              />
            )}
            {resolvedModule === 'schema' && (
              <SchemaStudioModule
                state={state}
                role={role}
                actor={actor}
                isDevMode={isDevMode}
                onToggleDevMode={onToggleDevMode}
                onStateChange={onStateChange}
              />
            )}
          </>
        )}
      </main>

      {/* Mobile PWA Bottom App Bar */}
      <nav
        aria-label="Mobile quick navigation"
        className="fixed inset-x-0 bottom-0 z-30 border-t border-slate-200 bg-white/95 backdrop-blur-sm md:hidden"
      >
        {role === 'parent' ? (
          <div className="grid grid-cols-2">
            {[
              { id: 'home' as SandboxModule, label: 'School Events', Icon: Home },
              { id: 'learners' as SandboxModule, label: 'Child Details', Icon: Users },
            ].map(({ id, label, Icon }) => {
              const active = !scopedSelectedLearnerId && resolvedModule === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => selectTab(id)}
                  className={`flex flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-semibold transition-colors ${
                    active ? 'text-blue-700' : 'text-slate-600'
                  }`}
                >
                  <Icon className="h-4 w-4" aria-hidden="true" />
                  <span>{label}</span>
                </button>
              );
            })}
          </div>
        ) : (
          <div className="grid grid-cols-5">
            {[
              { id: 'home' as SandboxModule, label: 'Home', Icon: Home },
              { id: 'timetable' as SandboxModule, label: 'Timetable', Icon: Clock },
              { id: 'register' as SandboxModule, label: 'Register', Icon: ClipboardCheck },
              { id: 'learners' as SandboxModule, label: 'Learners', Icon: Users },
            ].map(({ id, label, Icon }) => {
              const active = !scopedSelectedLearnerId && resolvedModule === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => selectTab(id)}
                  className={`flex flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-semibold transition-colors ${
                    active ? 'text-blue-700' : 'text-slate-600'
                  }`}
                >
                  <Icon className="h-4 w-4" aria-hidden="true" />
                  <span>{label}</span>
                </button>
              );
            })}
            <button
              type="button"
              onClick={() => setMobileMoreOpen(true)}
              className={`flex flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-semibold transition-colors ${
                mobileMoreOpen ? 'text-blue-700' : 'text-slate-600'
              }`}
            >
              <LayoutGrid className="h-4 w-4" aria-hidden="true" />
              <span>More</span>
            </button>
          </div>
        )}
      </nav>

      {/* Mobile More Grouped Navigation Sheet */}
      <AppDialog
        open={mobileMoreOpen}
        title="All School Pages"
        subtitle="Jump directly to any grouped tool."
        onClose={() => setMobileMoreOpen(false)}
      >
        <div className="space-y-4">
          {NAV_GROUPS.map((grp) => {
            const grpTabs = availableTabs.filter((t) => t.group === grp.id);
            if (grpTabs.length === 0) return null;
            return (
              <div key={grp.id}>
                <p className="mb-1.5 text-xs font-semibold text-slate-500">
                  {grp.label}
                </p>
                <div className="grid grid-cols-2 gap-2">
                  {grpTabs.map((tab) => (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => selectTab(tab.id)}
                      className={`rounded-lg border px-3 py-2 text-left text-xs font-semibold ${
                        resolvedModule === tab.id
                          ? 'border-blue-700 bg-blue-50 text-blue-800'
                          : 'border-slate-200 bg-white text-slate-800 hover:bg-slate-50'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </AppDialog>

      {/* Global Cmd/Ctrl+K Quick Jump Modal */}
      {onSetQuickJumpOpen && (
        <QuickJumpModal
          open={quickJumpOpen}
          state={state}
          role={role}
          linkedLearnerIds={activeGuardian?.linkedLearnerIds}
          onClose={() => onSetQuickJumpOpen(false)}
          onSelectModule={(mod) => selectTab(mod)}
          onSelectLearner={(lid) => {
            onLearnerChange(lid);
            onOpenLearnerPage(lid);
          }}
          onSelectRegisterClassroom={(cid) => handleNavigateRegister(cid)}
        />
      )}
    </div>
  );
}
