import { useMemo, useState } from 'react';
import { Plus, Search } from 'lucide-react';
import { getFieldsForEntity } from '../../ecs/engine';
import type { MasteryLevel, Role, SchoolECSState } from '../../ecs/types';
import { DynamicFieldReadout } from '../DynamicFieldsRenderer';

interface AssessmentsModuleProps {
  state: SchoolECSState;
  role: Role;
  activeLearnerId: string;
  onOpenAssessmentDialog: (learnerId?: string) => void;
  onOpenLearnerPage: (learnerId: string) => void;
}

export function AssessmentsModule({
  state,
  role,
  activeLearnerId,
  onOpenAssessmentDialog,
  onOpenLearnerPage,
}: AssessmentsModuleProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [classroomFilter, setClassroomFilter] = useState('all');
  const [subjectFilter, setSubjectFilter] = useState('all');
  const [masteryFilter, setMasteryFilter] = useState<'all' | MasteryLevel>('all');

  const assessFields = getFieldsForEntity(state, 'assessment_entry', role, true);

  const baseAssessments = useMemo(
    () =>
      role === 'parent'
        ? state.assessments.filter((a) => a.learnerId === activeLearnerId)
        : state.assessments,
    [state.assessments, role, activeLearnerId]
  );

  const visibleAssessments = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return baseAssessments.filter((entry) => {
      const learner = state.learners.find((l) => l.id === entry.learnerId);
      if (
        role !== 'parent' &&
        classroomFilter !== 'all' &&
        learner?.classroomId !== classroomFilter
      ) {
        return false;
      }
      if (subjectFilter !== 'all' && entry.subjectId !== subjectFilter) {
        return false;
      }
      if (masteryFilter !== 'all' && entry.mastery !== masteryFilter) {
        return false;
      }
      if (!q) return true;
      const substrand = state.substrands.find((s) => s.id === entry.substrandId);
      const subject = state.subjects.find((s) => s.id === entry.subjectId);
      const teacher = state.teachers.find((t) => t.id === entry.teacherId);
      return (
        (learner?.name.toLowerCase().includes(q) ?? false) ||
        (substrand?.title.toLowerCase().includes(q) ?? false) ||
        (subject?.name.toLowerCase().includes(q) ?? false) ||
        (teacher?.name.toLowerCase().includes(q) ?? false) ||
        entry.performanceComment.toLowerCase().includes(q)
      );
    });
  }, [
    baseAssessments,
    role,
    classroomFilter,
    subjectFilter,
    masteryFilter,
    searchQuery,
    state.learners,
    state.substrands,
    state.subjects,
    state.teachers,
  ]);

  const avgScorePercent =
    baseAssessments.length === 0
      ? null
      : Math.round(
          baseAssessments.reduce((sum, a) => sum + a.scorePercent, 0) /
            baseAssessments.length
        );
  const proficientCount = baseAssessments.filter(
    (a) => a.mastery === 'Exceeding' || a.mastery === 'Meeting'
  ).length;
  const proficientRate =
    baseAssessments.length === 0
      ? 0
      : Math.round((proficientCount / baseAssessments.length) * 100);
  const hasActiveFilters =
    Boolean(searchQuery.trim()) ||
    (role !== 'parent' && classroomFilter !== 'all') ||
    subjectFilter !== 'all' ||
    masteryFilter !== 'all';

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            Assessment Books
          </h2>
          <p className="mt-0.5 text-sm text-slate-600">
            Strands and Substrands are pulled directly from Schemes DB. Click any learner to open their longitudinal page.
          </p>
        </div>

        {(role === 'admin' || role === 'teacher') && (
          <button
            type="button"
            onClick={() => onOpenAssessmentDialog()}
            className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white transition-colors hover:bg-blue-800 whitespace-nowrap shrink-0"
          >
            <Plus className="h-3.5 w-3.5" aria-hidden="true" />
            Record Assessment
          </button>
        )}
      </div>

      {/* KPI Summary Strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Logged Evaluations</p>
          <p className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
            {baseAssessments.length}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Average Score</p>
          <p className="mt-1 font-mono text-2xl font-bold text-blue-700 tabular-nums">
            {avgScorePercent !== null ? `${avgScorePercent}%` : '—'}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Exceeding / Meeting Rate</p>
          <p className="mt-1 font-mono text-2xl font-bold text-emerald-700 tabular-nums">
            {proficientRate}%{' '}
            <span className="text-xs font-normal text-slate-500">
              ({proficientCount}/{baseAssessments.length})
            </span>
          </p>
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-3.5">
        <div className="relative">
          <Search
            className="pointer-events-none absolute top-2.5 left-3 h-3.5 w-3.5 text-slate-400"
            aria-hidden="true"
          />
          <input
            type="search"
            aria-label="Search assessments"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search learner, substrand, or comment..."
            className="w-64 rounded-lg border border-slate-300 bg-white py-1.5 pr-3 pl-8 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {role !== 'parent' && (
            <select
              aria-label="Filter assessments by classroom"
              value={classroomFilter}
              onChange={(e) => setClassroomFilter(e.target.value)}
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
            >
              <option value="all">All Classrooms</option>
              {state.classrooms.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          )}
          <select
            aria-label="Filter assessments by subject"
            value={subjectFilter}
            onChange={(e) => setSubjectFilter(e.target.value)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
          >
            <option value="all">All Subjects</option>
            {state.subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
          <select
            aria-label="Filter assessments by mastery level"
            value={masteryFilter}
            onChange={(e) =>
              setMasteryFilter(e.target.value as 'all' | MasteryLevel)
            }
            className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
          >
            <option value="all">All Mastery Levels</option>
            <option value="Exceeding">Exceeding</option>
            <option value="Meeting">Meeting</option>
            <option value="Approaching">Approaching</option>
            <option value="Developing">Developing</option>
          </select>
        </div>
      </div>

      {visibleAssessments.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-8 text-center">
          <p className="text-sm font-medium text-slate-800">
            {hasActiveFilters
              ? 'No assessment records match your active filters.'
              : 'No assessments recorded yet for this view.'}
          </p>
          <div className="mt-3 flex justify-center gap-2">
            {hasActiveFilters && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setClassroomFilter('all');
                  setSubjectFilter('all');
                  setMasteryFilter('all');
                }}
                className="rounded-lg border border-slate-300 bg-white px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Clear Filters
              </button>
            )}
            {(role === 'admin' || role === 'teacher') && (
              <button
                type="button"
                onClick={() => onOpenAssessmentDialog()}
                className="rounded-lg bg-blue-700 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-blue-800"
              >
                Record Assessment
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {visibleAssessments.map((entry) => {
            const learner = state.learners.find((l) => l.id === entry.learnerId);
            const classroom = learner
              ? state.classrooms.find((c) => c.id === learner.classroomId)
              : undefined;
            const subject = state.subjects.find((s) => s.id === entry.subjectId);
            const strand = state.strands.find((st) => st.id === entry.strandId);
            const substrand = state.substrands.find(
              (sub) => sub.id === entry.substrandId
            );
            const teacher = state.teachers.find((t) => t.id === entry.teacherId);

            const masteryTone =
              entry.mastery === 'Exceeding' || entry.mastery === 'Meeting'
                ? 'text-emerald-700'
                : entry.mastery === 'Approaching'
                  ? 'text-amber-700'
                  : 'text-red-700';
            const masteryDot =
              entry.mastery === 'Exceeding' || entry.mastery === 'Meeting'
                ? 'bg-emerald-600'
                : entry.mastery === 'Approaching'
                  ? 'bg-amber-600'
                  : 'bg-red-600';

            return (
              <article
                key={entry.id}
                className="rounded-xl border border-slate-200 bg-white p-5"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="text-xs text-slate-500">
                      <span className="font-mono tabular-nums">{entry.date}</span> ·{' '}
                      {classroom?.name ?? 'Class'} · {subject?.name} ·{' '}
                      {strand?.code} {strand?.title}
                    </p>
                    <h3 className="mt-1 font-display text-base font-bold text-slate-900">
                      <button
                        type="button"
                        onClick={() => learner && onOpenLearnerPage(learner.id)}
                        className="text-left hover:text-blue-700 hover:underline"
                      >
                        {learner?.name}
                      </button>
                      {' — '}
                      <span className="font-semibold text-slate-700">
                        {substrand?.code} {substrand?.title}
                      </span>
                    </h3>
                  </div>
                  <div className="text-right">
                    <span
                      className={`inline-flex items-center gap-1.5 text-xs font-semibold ${masteryTone}`}
                    >
                      <span className={`h-2 w-2 rounded-full ${masteryDot}`} />
                      {entry.mastery}
                    </span>
                    <p className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                      {entry.scorePercent}%
                    </p>
                  </div>
                </div>

                <p className="mt-3 text-sm leading-relaxed text-slate-700">
                  {entry.performanceComment}
                </p>
                <p className="mt-2 text-xs text-slate-500">
                  Assessed by <span className="font-medium text-slate-700">{teacher?.name}</span> ·{' '}
                  Substrand ref:{' '}
                  <span className="font-mono">{entry.substrandId}</span>
                </p>

                <DynamicFieldReadout
                  fields={assessFields}
                  values={entry.customFields}
                  role={role}
                />
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
