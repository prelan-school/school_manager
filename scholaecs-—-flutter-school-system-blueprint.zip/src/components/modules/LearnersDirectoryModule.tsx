import {
  ArrowRight,
  BookOpen,
  FileSpreadsheet,
  MapPin,
  Plus,
  Search,
  Upload,
} from 'lucide-react';
import { useState, type ChangeEvent, type FormEvent } from 'react';
import {
  buildLearnerLongitudinalReport,
  createLearner,
  parseAndImportLearnersCsv,
} from '../../ecs/engine';
import type { AuditActor, Role, SchoolECSState } from '../../ecs/types';
import { ActionSubmitButton, useActionFeedback } from '../ActionFeedback';
import { AppDialog } from '../AppDialog';

interface LearnersDirectoryModuleProps {
  state: SchoolECSState;
  role: Role;
  activeLearnerId: string;
  linkedLearnerIds?: string[];
  actor?: AuditActor;
  onStateChange?: (next: SchoolECSState) => void;
  onOpenLearnerPage: (learnerId: string) => void;
  onOpenDiaryDialog?: (learnerId: string) => void;
  onOpenAssessmentDialog?: (learnerId: string) => void;
}

export function LearnersDirectoryModule({
  state,
  role,
  activeLearnerId,
  linkedLearnerIds,
  actor,
  onStateChange,
  onOpenLearnerPage,
  onOpenDiaryDialog,
  onOpenAssessmentDialog,
}: LearnersDirectoryModuleProps) {
  const [search, setSearch] = useState('');
  const [classroomFilter, setClassroomFilter] = useState('all');
  const [locationFilter, setLocationFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState<
    'all' | 'Active' | 'Probation' | 'Alumni'
  >('all');

  const [showEnrollDialog, setShowEnrollDialog] = useState(false);
  const [newName, setNewName] = useState('');
  const [newAdmissionNo, setNewAdmissionNo] = useState('');
  const [newClassroomId, setNewClassroomId] = useState(
    state.classrooms[0]?.id ?? ''
  );
  const [newLocationId, setNewLocationId] = useState(
    state.locations?.[0]?.id ?? ''
  );
  const [newParentName, setNewParentName] = useState('');
  const [newParentEmail, setNewParentEmail] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newHealthNote, setNewHealthNote] = useState('');
  const [enrollError, setEnrollError] = useState<string | null>(null);
  const [showCsvDialog, setShowCsvDialog] = useState(false);
  const [csvText, setCsvText] = useState('');
  const [csvDefaultClassroomId, setCsvDefaultClassroomId] = useState(
    state.classrooms[0]?.id ?? ''
  );
  const [csvReport, setCsvReport] = useState<{
    importedCount: number;
    errors: string[];
  } | null>(null);
  const { isBusy, runLockedAction, showFeedback } = useActionFeedback();

  const isStaff = role === 'admin' || role === 'teacher';
  const locations = state.locations ?? [];

  const scopedLearners =
    role === 'parent'
      ? state.learners.filter((l) =>
          linkedLearnerIds && linkedLearnerIds.length > 0
            ? linkedLearnerIds.includes(l.id)
            : l.id === activeLearnerId
        )
      : state.learners.filter((l) => {
          const matchesClass =
            classroomFilter === 'all' || l.classroomId === classroomFilter;
          const matchesLoc =
            locationFilter === 'all' ||
            (locationFilter === 'unassigned'
              ? !l.locationId
              : l.locationId === locationFilter);
          const matchesStatus =
            statusFilter === 'all' || l.enrollmentStatus === statusFilter;
          const q = search.trim().toLowerCase();
          const matchesSearch =
            !q ||
            l.name.toLowerCase().includes(q) ||
            l.admissionNo.toLowerCase().includes(q) ||
            l.parentName.toLowerCase().includes(q);
          return matchesClass && matchesLoc && matchesStatus && matchesSearch;
        });

  const handleOpenEnroll = () => {
    const nextNum = state.learners.length + 1;
    setNewName('');
    setNewAdmissionNo(`SCH-2026-${String(nextNum).padStart(3, '0')}`);
    setNewClassroomId(
      classroomFilter !== 'all'
        ? classroomFilter
        : state.classrooms[0]?.id ?? ''
    );
    setNewLocationId(
      locationFilter !== 'all' && locationFilter !== 'unassigned'
        ? locationFilter
        : locations[0]?.id ?? ''
    );
    setNewParentName('');
    setNewParentEmail('');
    setNewPhone('');
    setNewHealthNote('');
    setEnrollError(null);
    setShowEnrollDialog(true);
  };

  const handleEnrollSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!onStateChange) return;
    void runLockedAction('Enrolling learner...', () => {
      const res = createLearner(
        state,
        {
          name: newName,
          admissionNo: newAdmissionNo,
          classroomId: newClassroomId,
          locationId: newLocationId || undefined,
          parentName: newParentName,
          parentEmail: newParentEmail,
          guardianPhone: newPhone,
          internalHealthNote: newHealthNote,
        },
        actor
      );
      if (res.error) {
        setEnrollError(res.error);
        showFeedback('error', res.error);
        return;
      }
      setEnrollError(null);
      setShowEnrollDialog(false);
      onStateChange(res.state);
      showFeedback('success', 'Learner enrolled successfully');
    });
  };

  const handleOpenCsvImport = () => {
    setCsvText('');
    setCsvDefaultClassroomId(
      classroomFilter !== 'all'
        ? classroomFilter
        : state.classrooms[0]?.id ?? ''
    );
    setCsvReport(null);
    setShowCsvDialog(true);
  };

  const handleCsvFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setCsvText(reader.result);
      }
    };
    reader.readAsText(file);
  };

  const handleCsvSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!onStateChange) return;
    void runLockedAction('Importing learners from CSV...', () => {
      const res = parseAndImportLearnersCsv(
        state,
        csvText,
        csvDefaultClassroomId,
        actor
      );
      setCsvReport({
        importedCount: res.importedCount,
        errors: res.errors,
      });
      if (res.importedCount > 0) {
        onStateChange(res.state);
        showFeedback(
          res.errors.length > 0 ? 'warning' : 'success',
          `Imported ${res.importedCount} learner${res.importedCount === 1 ? '' : 's'} successfully`
        );
        if (res.errors.length === 0) {
          setShowCsvDialog(false);
        }
      } else {
        showFeedback('error', res.errors[0] ?? 'No learners imported');
      }
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            Learners Directory
          </h2>
          <p className="mt-0.5 text-sm text-slate-600">
            Select any learner to open their longitudinal profile (since registration until now), scoped cleanly to your {role} portal.
          </p>
        </div>

        <div className="flex w-full flex-wrap items-center gap-2 sm:w-auto">
          {role !== 'parent' && (
            <>
              <div className="relative flex-1 sm:flex-initial">
                <Search
                  className="pointer-events-none absolute top-2.5 left-3 h-3.5 w-3.5 text-slate-400"
                  aria-hidden="true"
                />
                <input
                  aria-label="Search learners"
                  type="search"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search learner, adm no, or guardian..."
                  className="w-full rounded-lg border border-slate-300 bg-white py-2 pr-3 pl-8 text-xs text-slate-900 placeholder:text-slate-400 focus:border-blue-700 focus:outline-none sm:w-60"
                />
              </div>
              <select
                aria-label="Filter learners by classroom"
                value={classroomFilter}
                onChange={(e) => setClassroomFilter(e.target.value)}
                className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
              >
                <option value="all">All Classrooms</option>
                {state.classrooms.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
              <select
                aria-label="Filter learners by location"
                value={locationFilter}
                onChange={(e) => setLocationFilter(e.target.value)}
                className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
              >
                <option value="all">All Locations</option>
                {locations.map((loc) => (
                  <option key={loc.id} value={loc.id}>
                    {loc.name}
                  </option>
                ))}
                <option value="unassigned">Unassigned Location</option>
              </select>
              <select
                aria-label="Filter learners by enrollment status"
                value={statusFilter}
                onChange={(e) =>
                  setStatusFilter(
                    e.target.value as 'all' | 'Active' | 'Probation' | 'Alumni'
                  )
                }
                className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
              >
                <option value="all">All Statuses</option>
                <option value="Active">Active</option>
                <option value="Probation">Probation</option>
                <option value="Alumni">Alumni</option>
              </select>
            </>
          )}

          {role === 'admin' && onStateChange && (
            <>
              <button
                type="button"
                disabled={isBusy}
                onClick={handleOpenCsvImport}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap shrink-0 disabled:opacity-60"
              >
                <Upload className="h-3.5 w-3.5" aria-hidden="true" />
                Import CSV
              </button>
              <button
                type="button"
                disabled={isBusy}
                onClick={handleOpenEnroll}
                className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800 whitespace-nowrap shrink-0 disabled:opacity-60"
              >
                <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                Enroll Learner
              </button>
            </>
          )}
        </div>
      </div>

      {/* Bulk CSV Learner Import Dialog */}
      <AppDialog
        open={showCsvDialog}
        busy={isBusy}
        title="Bulk CSV Learner &amp; Guardian Import"
        subtitle="Paste or upload CSV rows (Name, AdmissionNo, Classroom, Location, ParentName, ParentEmail, Phone, Note)."
        onClose={() => setShowCsvDialog(false)}
      >
        <form onSubmit={handleCsvSubmit}>
          <fieldset disabled={isBusy} className="space-y-4 disabled:opacity-75">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <label
                  htmlFor="csv-default-class"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Fallback Classroom (if column empty)
                </label>
                <select
                  id="csv-default-class"
                  value={csvDefaultClassroomId}
                  onChange={(e) => setCsvDefaultClassroomId(e.target.value)}
                  className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs focus:border-blue-700 focus:outline-none"
                >
                  {state.classrooms.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex items-center gap-2">
                <label className="cursor-pointer rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50">
                  Upload .csv File
                  <input
                    type="file"
                    accept=".csv,text/csv"
                    onChange={handleCsvFileChange}
                    className="sr-only"
                  />
                </label>
                <button
                  type="button"
                  onClick={() =>
                    setCsvText(
                      `Name,AdmissionNo,Classroom,Location,ParentName,ParentEmail,Phone,Note\nAmina Yusuf,SCH-2026-${String(state.learners.length + 1).padStart(3, '0')},Grade 5A — Acacia,Kilimani,Hassan Yusuf,hassan.yusuf@family.org,+254712111222,No allergies\nDaniel Kiprop,SCH-2026-${String(state.learners.length + 2).padStart(3, '0')},Grade 6B — Baobab,Westlands,Sarah Kiprop,sarah.kiprop@family.org,+254712333444,Needs front desk`
                    )
                  }
                  className="rounded-lg border border-blue-200 bg-blue-50 px-3 py-1.5 text-xs font-semibold text-blue-700 hover:bg-blue-100"
                >
                  Load Sample CSV
                </button>
              </div>
            </div>

            <div>
              <label
                htmlFor="csv-paste-area"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                CSV Rows *
              </label>
              <textarea
                id="csv-paste-area"
                rows={6}
                value={csvText}
                onChange={(e) => setCsvText(e.target.value)}
                placeholder="Name,AdmissionNo,Classroom,Location,ParentName,ParentEmail,Phone,Note"
                className="w-full rounded-lg border border-slate-300 bg-white p-3 font-mono text-xs focus:border-blue-700 focus:outline-none"
              />
            </div>

            {csvReport && (
              <div
                className={`rounded-lg border p-3 text-xs ${
                  csvReport.errors.length > 0
                    ? 'border-amber-200 bg-amber-50 text-amber-900'
                    : 'border-emerald-200 bg-emerald-50 text-emerald-900'
                }`}
              >
                <p className="font-semibold">
                  Imported {csvReport.importedCount} learner
                  {csvReport.importedCount === 1 ? '' : 's'}.
                </p>
                {csvReport.errors.length > 0 && (
                  <ul className="mt-1 list-disc pl-4 space-y-0.5 text-red-700">
                    {csvReport.errors.slice(0, 5).map((err, idx) => (
                      <li key={idx}>{err}</li>
                    ))}
                  </ul>
                )}
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowCsvDialog(false)}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </button>
              <ActionSubmitButton
                busy={isBusy}
                busyLabel="Importing..."
                idleLabel="Import Learners"
                className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
              />
            </div>
          </fieldset>
        </form>
      </AppDialog>

      {/* Admin Enroll Learner Dialog */}
      <AppDialog
        open={showEnrollDialog}
        busy={isBusy}
        title="Enroll New Learner"
        subtitle="Creates a canonical Learner dossier linked to Classroom, Home Location, and Guardian record."
        onClose={() => setShowEnrollDialog(false)}
      >
        <form onSubmit={handleEnrollSubmit}>
          <fieldset disabled={isBusy} className="space-y-4 disabled:opacity-75">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label
                htmlFor="enroll-name"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Learner Full Name *
              </label>
              <input
                id="enroll-name"
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g. Kofi Boateng"
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>
            <div>
              <label
                htmlFor="enroll-adm"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Admission No *
              </label>
              <input
                id="enroll-adm"
                type="text"
                value={newAdmissionNo}
                onChange={(e) => setNewAdmissionNo(e.target.value)}
                placeholder="SCH-2026-005"
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label
                htmlFor="enroll-class"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Classroom *
              </label>
              <select
                id="enroll-class"
                value={newClassroomId}
                onChange={(e) => setNewClassroomId(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              >
                {state.classrooms.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.gradeLevel})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label
                htmlFor="enroll-location"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Home Location / Route
              </label>
              <select
                id="enroll-location"
                value={newLocationId}
                onChange={(e) => setNewLocationId(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              >
                <option value="">Unassigned</option>
                {locations.map((loc) => (
                  <option key={loc.id} value={loc.id}>
                    {loc.name} ({loc.zone})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div>
              <label
                htmlFor="enroll-parent"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Guardian Name *
              </label>
              <input
                id="enroll-parent"
                type="text"
                value={newParentName}
                onChange={(e) => setNewParentName(e.target.value)}
                placeholder="Abena Boateng"
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>
            <div>
              <label
                htmlFor="enroll-email"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Guardian Email *
              </label>
              <input
                id="enroll-email"
                type="email"
                value={newParentEmail}
                onChange={(e) => setNewParentEmail(e.target.value)}
                placeholder="parent@family.org"
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>
            <div>
              <label
                htmlFor="enroll-phone"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Guardian Phone
              </label>
              <input
                id="enroll-phone"
                type="text"
                value={newPhone}
                onChange={(e) => setNewPhone(e.target.value)}
                placeholder="+254 712 000 000"
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="enroll-health"
              className="mb-1 block text-xs font-medium text-slate-700"
            >
              Internal Staff Medical / Intake Note
            </label>
            <input
              id="enroll-health"
              type="text"
              value={newHealthNote}
              onChange={(e) => setNewHealthNote(e.target.value)}
              placeholder="Allergies, seating accommodations, or No alerts on intake"
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
            />
          </div>

          {enrollError && (
            <p className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs font-medium text-red-700">
              {enrollError}
            </p>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setShowEnrollDialog(false)}
              className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <ActionSubmitButton
              busy={isBusy}
              busyLabel="Enrolling..."
              idleLabel="Enroll Learner"
              className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
            />
          </div>
          </fieldset>
        </form>
      </AppDialog>

      {scopedLearners.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-8 text-center">
          <p className="text-sm font-medium text-slate-800">
            {state.learners.length === 0
              ? 'No learners enrolled yet. Add a learner or import a CSV roster to get started.'
              : 'No learners match your search or filter criteria.'}
          </p>
          <div className="mt-3 flex flex-wrap justify-center gap-2">
            {(search ||
              classroomFilter !== 'all' ||
              locationFilter !== 'all' ||
              statusFilter !== 'all') && (
              <button
                type="button"
                onClick={() => {
                  setSearch('');
                  setClassroomFilter('all');
                  setLocationFilter('all');
                  setStatusFilter('all');
                }}
                className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Clear Filters
              </button>
            )}
            {role === 'admin' && onStateChange && (
              <>
                <button
                  type="button"
                  onClick={handleOpenCsvImport}
                  className="rounded-lg border border-slate-300 bg-white px-3.5 py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-50"
                >
                  Import CSV
                </button>
                <button
                  type="button"
                  onClick={handleOpenEnroll}
                  className="rounded-lg bg-blue-700 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-blue-800"
                >
                  Enroll First Learner
                </button>
              </>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          {scopedLearners.map((learner) => {
            const classroom = state.classrooms.find(
              (c) => c.id === learner.classroomId
            );
            const location = learner.locationId
              ? locations.find((loc) => loc.id === learner.locationId)
              : undefined;
            const classTeacher = classroom?.classTeacherId
              ? state.teachers.find((t) => t.id === classroom.classTeacherId)
              : undefined;
            const summary = buildLearnerLongitudinalReport(
              state,
              learner.id,
              role,
              { preset: 'since_registration' }
            );

            const statusDotClass =
              learner.enrollmentStatus === 'Active'
                ? 'bg-emerald-600'
                : learner.enrollmentStatus === 'Probation'
                  ? 'bg-amber-600'
                  : 'bg-slate-400';

            return (
              <article
                key={learner.id}
                className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 transition-colors hover:border-slate-300"
              >
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-xs text-slate-500">
                        <span className="font-mono">{learner.admissionNo}</span> ·{' '}
                        {classroom?.name}
                        {classTeacher ? ` · Lead: ${classTeacher.name}` : ''}
                      </p>
                      <h3 className="mt-1 font-display text-base font-bold text-slate-900">
                        {learner.name}
                      </h3>
                      <p className="mt-0.5 flex flex-wrap items-center gap-x-2 text-[11px] text-slate-500">
                        <span>
                          Registered{' '}
                          <span className="font-mono tabular-nums">
                            {learner.registeredAt}
                          </span>
                        </span>
                        {location && (
                          <span className="inline-flex items-center gap-1 font-medium text-slate-700">
                            <MapPin className="h-3 w-3 text-blue-700" aria-hidden="true" />
                            {location.name} ({location.zone})
                          </span>
                        )}
                      </p>
                    </div>
                    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700 whitespace-nowrap shrink-0">
                      <span className={`h-2 w-2 rounded-full ${statusDotClass}`} />
                      {learner.enrollmentStatus}
                    </span>
                  </div>

                  <dl className="mt-4 grid grid-cols-3 gap-3 border-t border-slate-100 pt-3 text-xs">
                    <div>
                      <dt className="text-slate-500">Avg Mastery</dt>
                      <dd className="mt-0.5 font-mono font-bold text-slate-900 tabular-nums">
                        {summary?.averageScore !== null
                          ? `${summary?.averageScore}%`
                          : '—'}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-slate-500">Attendance</dt>
                      <dd className="mt-0.5 font-mono font-bold text-slate-900 tabular-nums">
                        {summary?.attendanceRate !== null
                          ? `${summary?.attendanceRate}%`
                          : '—'}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-slate-500">Diary Logs</dt>
                      <dd className="mt-0.5 font-mono font-bold text-slate-900 tabular-nums">
                        {summary?.diary.length ?? 0}
                      </dd>
                    </div>
                  </dl>
                </div>

                <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-3">
                  <span className="text-xs text-slate-500">
                    Guardian: <strong className="font-medium text-slate-700">{learner.parentName}</strong>
                  </span>
                  <div className="flex flex-wrap items-center gap-1.5">
                    {isStaff && onOpenDiaryDialog && (
                      <button
                        type="button"
                        onClick={() => onOpenDiaryDialog(learner.id)}
                        title={`Log diary for ${learner.name}`}
                        className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0"
                      >
                        <BookOpen className="h-3.5 w-3.5" aria-hidden="true" />
                        Diary
                      </button>
                    )}
                    {isStaff && onOpenAssessmentDialog && (
                      <button
                        type="button"
                        onClick={() => onOpenAssessmentDialog(learner.id)}
                        title={`Record assessment for ${learner.name}`}
                        className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0"
                      >
                        <FileSpreadsheet className="h-3.5 w-3.5" aria-hidden="true" />
                        Assess
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => onOpenLearnerPage(learner.id)}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-800 whitespace-nowrap shrink-0"
                    >
                      Open Learner Page
                      <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
