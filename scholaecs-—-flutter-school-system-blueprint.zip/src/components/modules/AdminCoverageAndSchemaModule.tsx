import { useMemo, useState, type FormEvent } from 'react';
import {
  Archive,
  ArrowDown,
  ArrowUp,
  CalendarRange,
  Code2,
  Pencil,
  Plus,
  RotateCcw,
  UserPlus,
} from 'lucide-react';
import {
  archiveDynamicField,
  assignClassTeacher,
  buildScoreCandlesticks,
  computeClassroomMatrix,
  computeSubstrandCoverage,
  computeTeacherClassMatrix,
  computeTeacherCoverageSummaries,
  getActiveAcademicTerm,
  invitePortalUserAccount,
  movePageWidget,
  registerDynamicField,
  restoreDynamicField,
  setActiveAcademicTerm,
  togglePageWidgetEnabled,
  togglePageWidgetRole,
  updateDynamicField,
  updatePortalUserAccount,
  upsertAcademicTerm,
} from '../../ecs/engine';
import type {
  AuditActor,
  DynamicFieldDefinition,
  DynamicFieldType,
  EntityType,
  PortalUserAccount,
  Role,
  SchoolECSState,
} from '../../ecs/types';
import { AdminAiBriefingCard } from '../AdminAiBriefingCard';
import {
  GroupedBarChart,
  MasteryBreakdownDonut,
  ScoreCandlestickChart,
  TrendLineChart,
} from '../AnalyticsCharts';
import { ActionSubmitButton, useActionFeedback } from '../ActionFeedback';
import { AppDialog } from '../AppDialog';
import type { SandboxModule } from '../SandboxWorkspace';

interface AdminCoverageModuleProps {
  state: SchoolECSState;
  actor?: AuditActor;
  onStateChange?: (next: SchoolECSState) => void;
  onNavigateModule?: (module: SandboxModule) => void;
  onSelectClassroom?: (classroomId: string) => void;
}

export function AdminCoverageModule({
  state,
  actor,
  onStateChange,
  onNavigateModule,
  onSelectClassroom,
}: AdminCoverageModuleProps) {
  const { isBusy, runLockedAction, showFeedback } = useActionFeedback();
  const [coverageTab, setCoverageTab] = useState<
    'class_teacher' | 'teacher_class' | 'substrand' | 'charts' | 'audit'
  >('class_teacher');
  const [substrandClassFilter, setSubstrandClassFilter] = useState('all');
  const [substrandSubjectFilter, setSubstrandSubjectFilter] = useState('all');
  const [candleBucket, setCandleBucket] = useState<'month' | 'subject' | 'teacher'>(
    'month'
  );
  const [auditEntityFilter, setAuditEntityFilter] = useState('all');
  const [auditSearch, setAuditSearch] = useState('');

  const substrandReports = useMemo(() => computeSubstrandCoverage(state), [state]);
  const teacherSummaries = useMemo(
    () => computeTeacherCoverageSummaries(state),
    [state]
  );
  const classroomMatrix = useMemo(() => computeClassroomMatrix(state), [state]);
  const teacherClassMatrix = useMemo(
    () => computeTeacherClassMatrix(state),
    [state]
  );

  const avgCoverage =
    substrandReports.length === 0
      ? 0
      : Math.round(
          substrandReports.reduce((s, r) => s + r.coveragePercent, 0) /
            substrandReports.length
        );

  const diarySignedCount = state.diaryEntries.filter(
    (d) => d.parentAcknowledged
  ).length;

  const filteredSubstrands = useMemo(
    () =>
      substrandReports.filter((r) => {
        if (
          substrandClassFilter !== 'all' &&
          r.strand?.classroomId !== substrandClassFilter
        ) {
          return false;
        }
        if (
          substrandSubjectFilter !== 'all' &&
          r.subject?.id !== substrandSubjectFilter
        ) {
          return false;
        }
        return true;
      }),
    [substrandReports, substrandClassFilter, substrandSubjectFilter]
  );

  const masteryCounts = useMemo(() => {
    const counts = { Exceeding: 0, Meeting: 0, Approaching: 0, Developing: 0 };
    for (const a of state.assessments) {
      counts[a.mastery] = (counts[a.mastery] ?? 0) + 1;
    }
    return counts;
  }, [state.assessments]);

  const candlesticks = useMemo(
    () =>
      buildScoreCandlesticks(state.assessments, {
        bucketBy: candleBucket,
        state,
      }),
    [state, candleBucket]
  );

  const scoreTrendPoints = useMemo(() => {
    return [...state.assessments]
      .sort((a, b) => a.date.localeCompare(b.date))
      .map((a) => {
        const lrn = state.learners.find((l) => l.id === a.learnerId);
        return {
          label: a.date.slice(5),
          value: a.scorePercent,
          caption: lrn?.name,
        };
      });
  }, [state.assessments, state.learners]);

  const filteredAuditLogs = useMemo(() => {
    const q = auditSearch.trim().toLowerCase();
    return (state.auditLogs ?? []).filter((entry) => {
      if (auditEntityFilter !== 'all' && entry.entityType !== auditEntityFilter) {
        return false;
      }
      if (!q) return true;
      return (
        entry.actorName.toLowerCase().includes(q) ||
        entry.action.toLowerCase().includes(q) ||
        entry.targetLabel.toLowerCase().includes(q) ||
        entry.detail.toLowerCase().includes(q)
      );
    });
  }, [state.auditLogs, auditEntityFilter, auditSearch]);

  const tabs: {
    id: 'class_teacher' | 'teacher_class' | 'substrand' | 'charts' | 'audit';
    label: string;
  }[] = [
    { id: 'class_teacher', label: 'By Class → Teacher' },
    { id: 'teacher_class', label: 'By Teacher → Class' },
    { id: 'substrand', label: 'By Substrand' },
    { id: 'charts', label: 'Charts & Score Spread' },
    { id: 'audit', label: `Who & When Audit (${(state.auditLogs ?? []).length})` },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            Admin Syllabus Coverage &amp; Activity Tracker
          </h2>
          <p className="mt-0.5 text-sm text-slate-600">
            Segmented cross-entity rollups by Classroom, Class Teacher, Substrand, OHLC Score Spread, and Who &amp; When Audit Trail.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onNavigateModule && (
            <button
              type="button"
              onClick={() => onNavigateModule('parents')}
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap"
            >
              Open Parents Directory
            </button>
          )}
          {onNavigateModule && (
            <button
              type="button"
              onClick={() => onNavigateModule('classrooms')}
              className="rounded-lg bg-blue-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-800 whitespace-nowrap"
            >
              Classroom Analytics
            </button>
          )}
        </div>
      </div>

      <AdminAiBriefingCard state={state} />

      {/* 4-column summary strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Overall Syllabus Coverage</p>
          <p className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
            {avgCoverage}%
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Registered Substrands</p>
          <p className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
            {substrandReports.length}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Lesson Plans Taught</p>
          <p className="mt-1 font-mono text-2xl font-bold text-emerald-700 tabular-nums">
            {state.lessonPlans.filter((l) => l.status === 'taught').length} /{' '}
            {state.lessonPlans.length}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Parent Diary Sign-Offs</p>
          <p className="mt-1 font-mono text-2xl font-bold text-blue-700 tabular-nums">
            {diarySignedCount} / {state.diaryEntries.length}
          </p>
        </div>
      </div>

      {/* Segmented Navigation Bar */}
      <div
        role="tablist"
        aria-label="Coverage analytics segments"
        className="flex flex-wrap gap-1.5 rounded-xl border border-slate-200 bg-white p-2"
      >
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            role="tab"
            aria-selected={coverageTab === tab.id}
            onClick={() => setCoverageTab(tab.id)}
            className={`rounded-lg px-3.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              coverageTab === tab.id
                ? 'bg-blue-700 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab 1: By Class -> Teacher */}
      {coverageTab === 'class_teacher' && (
        <div className="space-y-4">
          {classroomMatrix.map((row) => (
            <section
              key={row.classroom.id}
              className="rounded-xl border border-slate-200 bg-white p-5"
            >
              <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-4">
                <div>
                  <p className="text-xs text-slate-500">
                    {row.classroom.gradeLevel} · Room{' '}
                    <span className="font-mono">{row.classroom.roomCode}</span> ·{' '}
                    {row.learnerCount} learners · {row.strandCount} strands (
                    {row.substrandCount} substrands)
                  </p>
                  <h3 className="mt-1 font-display text-base font-bold text-slate-900">
                    {row.classroom.name}
                  </h3>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  {onStateChange && (
                    <div className="flex items-center gap-2">
                      <label
                        htmlFor={`cov-ct-${row.classroom.id}`}
                        className="text-xs font-medium text-slate-600"
                      >
                        Class Teacher
                      </label>
                      <select
                        id={`cov-ct-${row.classroom.id}`}
                        disabled={isBusy}
                        value={row.classroom.classTeacherId ?? ''}
                        onChange={(e) => {
                          const nextTeacherId = e.target.value;
                          void runLockedAction('Updating class teacher...', () => {
                            onStateChange(
                              assignClassTeacher(
                                state,
                                row.classroom.id,
                                nextTeacherId,
                                actor
                              )
                            );
                            showFeedback('info', 'Class teacher updated');
                          });
                        }}
                        className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none disabled:opacity-50"
                      >
                        <option value="">Unassigned</option>
                        {state.teachers.map((t) => (
                          <option key={t.id} value={t.id}>
                            {t.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                  {onSelectClassroom && (
                    <button
                      type="button"
                      onClick={() => onSelectClassroom(row.classroom.id)}
                      className="rounded-lg border border-blue-200 bg-blue-50 px-3 py-1.5 text-xs font-semibold text-blue-700 hover:bg-blue-100 whitespace-nowrap"
                    >
                      Inspect Class Analytics
                    </button>
                  )}
                </div>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                  <p className="text-[11px] text-slate-500">Scheme Coverage</p>
                  <p className="font-mono text-lg font-bold text-slate-900 tabular-nums">
                    {row.avgCoveragePercent}%
                  </p>
                </div>
                <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                  <p className="text-[11px] text-slate-500">Attendance Rate</p>
                  <p className="font-mono text-lg font-bold text-emerald-700 tabular-nums">
                    {row.attendanceRatePercent}%
                  </p>
                </div>
                <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                  <p className="text-[11px] text-slate-500">Avg Assessment</p>
                  <p className="font-mono text-lg font-bold text-blue-700 tabular-nums">
                    {row.averageScorePercent !== null
                      ? `${row.averageScorePercent}%`
                      : '—'}
                  </p>
                </div>
                <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                  <p className="text-[11px] text-slate-500">Lessons Taught</p>
                  <p className="font-mono text-lg font-bold text-slate-900 tabular-nums">
                    {row.taughtLessonsCount}/{row.totalPlansCount} (
                    {row.totalLessonsDelivered}p)
                  </p>
                </div>
              </div>

              <div className="mt-4 overflow-x-auto">
                <table className="w-full border-collapse text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500">
                      <th className="py-2 pr-4 font-semibold">Teacher</th>
                      <th className="py-2 pr-4 font-semibold">Role in Class</th>
                      <th className="py-2 pr-4 text-right font-semibold">
                        Taught Plans
                      </th>
                      <th className="py-2 pr-4 text-right font-semibold">
                        Periods Delivered
                      </th>
                      <th className="py-2 pr-4 text-right font-semibold">
                        Assessments
                      </th>
                      <th className="py-2 text-right font-semibold">
                        Diary Logs
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {row.teacherSlices.map((slice) => (
                      <tr key={slice.teacher.id}>
                        <td className="py-2.5 pr-4 font-semibold text-slate-900">
                          {slice.teacher.name}
                        </td>
                        <td className="py-2.5 pr-4 text-xs">
                          <span
                            className={
                              slice.isClassTeacher
                                ? 'font-semibold text-blue-700'
                                : 'text-slate-600'
                            }
                          >
                            {slice.isClassTeacher
                              ? 'Class Teacher (Homeroom)'
                              : 'Subject Teacher'}
                          </span>
                        </td>
                        <td className="py-2.5 pr-4 text-right font-mono text-emerald-700 tabular-nums">
                          {slice.taughtPlans} / {slice.totalPlans}
                        </td>
                        <td className="py-2.5 pr-4 text-right font-mono text-slate-900 tabular-nums">
                          {slice.lessonsDelivered}
                        </td>
                        <td className="py-2.5 pr-4 text-right font-mono text-slate-900 tabular-nums">
                          {slice.assessmentsLogged}
                        </td>
                        <td className="py-2.5 text-right font-mono text-slate-900 tabular-nums">
                          {slice.diaryLogged}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          ))}
        </div>
      )}

      {/* Tab 2: By Teacher -> Class */}
      {coverageTab === 'teacher_class' && (
        <div className="space-y-4">
          <section className="rounded-xl border border-slate-200 bg-white p-5">
            <h3 className="text-sm font-semibold text-slate-900">
              Teacher Syllabus Delivery &amp; Engagement Summary
            </h3>
            <div className="mt-3 overflow-x-auto">
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500">
                    <th className="py-2.5 pr-4 font-semibold">Teacher</th>
                    <th className="py-2.5 pr-4 text-right font-semibold">
                      Taught Plans
                    </th>
                    <th className="py-2.5 pr-4 text-right font-semibold">
                      In Progress
                    </th>
                    <th className="py-2.5 pr-4 text-right font-semibold">
                      Lessons Delivered
                    </th>
                    <th className="py-2.5 pr-4 text-right font-semibold">
                      Assessments
                    </th>
                    <th className="py-2.5 text-right font-semibold">
                      Diary Logs
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {teacherSummaries.map((row) => (
                    <tr key={row.teacher.id} className="hover:bg-slate-50/70">
                      <td className="py-3 pr-4 font-semibold text-slate-900">
                        {row.teacher.name}
                      </td>
                      <td className="py-3 pr-4 text-right font-mono text-emerald-700 tabular-nums">
                        {row.taughtPlans} / {row.totalPlans}
                      </td>
                      <td className="py-3 pr-4 text-right font-mono text-amber-700 tabular-nums">
                        {row.inProgressPlans}
                      </td>
                      <td className="py-3 pr-4 text-right font-mono text-slate-900 tabular-nums">
                        {row.totalLessonsDelivered}
                      </td>
                      <td className="py-3 pr-4 text-right font-mono text-slate-900 tabular-nums">
                        {row.assessmentsLogged}
                      </td>
                      <td className="py-3 text-right font-mono text-slate-900 tabular-nums">
                        {row.diaryEntriesLogged}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            {teacherClassMatrix.map((row) => (
              <section
                key={row.teacher.id}
                className="rounded-xl border border-slate-200 bg-white p-5"
              >
                <div className="flex flex-wrap items-baseline justify-between gap-2 border-b border-slate-100 pb-3">
                  <div>
                    <h4 className="font-display text-base font-bold text-slate-900">
                      {row.teacher.name}
                    </h4>
                    <p className="text-xs text-slate-500">
                      Homeroom:{' '}
                      {row.homeroomClassrooms.length > 0
                        ? row.homeroomClassrooms.map((c) => c.name).join(', ')
                        : 'Subject Specialist'}
                    </p>
                  </div>
                  <span className="font-mono text-xs font-bold text-blue-700 tabular-nums">
                    {row.coveragePercent}% Taught ({row.lessonsDelivered}p)
                  </span>
                </div>

                <div className="mt-3 divide-y divide-slate-100">
                  {row.classes.map((clsSlice) => (
                    <div
                      key={clsSlice.classroom.id}
                      className="flex flex-wrap items-center justify-between gap-2 py-2.5 text-xs"
                    >
                      <div>
                        <p className="font-semibold text-slate-900">
                          {clsSlice.classroom.name}{' '}
                          {clsSlice.isClassTeacher && (
                            <span className="font-medium text-blue-700">
                              (Class Teacher)
                            </span>
                          )}
                        </p>
                        <p className="text-[11px] text-slate-500">
                          {clsSlice.assessmentsLogged} assessments ·{' '}
                          {clsSlice.diaryLogged} diary logs
                        </p>
                      </div>
                      <span className="font-mono font-semibold text-slate-800 tabular-nums">
                        {clsSlice.taughtPlans}/{clsSlice.totalPlans} plans ·{' '}
                        {clsSlice.lessonsDelivered}p
                      </span>
                    </div>
                  ))}
                </div>
              </section>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: By Substrand */}
      {coverageTab === 'substrand' && (
        <section className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <h3 className="text-sm font-semibold text-slate-900">
              Coverage by Class-Scoped Substrand ({filteredSubstrands.length})
            </h3>
            <div className="flex flex-wrap items-center gap-2">
              <select
                aria-label="Filter substrands by classroom"
                value={substrandClassFilter}
                onChange={(e) => setSubstrandClassFilter(e.target.value)}
                className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
              >
                <option value="all">All Classrooms</option>
                {state.classrooms.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
              <select
                aria-label="Filter substrands by subject"
                value={substrandSubjectFilter}
                onChange={(e) => setSubstrandSubjectFilter(e.target.value)}
                className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
              >
                <option value="all">All Subjects</option>
                {state.subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="mt-4 space-y-4">
            {filteredSubstrands.map((rep) => (
              <div
                key={rep.substrand.id}
                className="border-b border-slate-100 pb-3 last:border-b-0 last:pb-0"
              >
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <div>
                    <p className="text-xs text-slate-500">
                      [{rep.classroom?.gradeLevel ?? rep.strand?.classroomId}]{' '}
                      {rep.subject?.name} · {rep.strand?.code}{' '}
                      {rep.strand?.title}
                      {rep.teachersInvolved.length > 0
                        ? ` · Teachers: ${rep.teachersInvolved.join(', ')}`
                        : ''}
                    </p>
                    <p className="text-sm font-semibold text-slate-900">
                      {rep.substrand.code}: {rep.substrand.title}
                    </p>
                  </div>
                  <div className="text-right font-mono text-xs tabular-nums">
                    <span className="font-bold text-slate-900">
                      {rep.coveragePercent}%
                    </span>{' '}
                    <span className="text-slate-500">
                      ({rep.deliveredLessons}/{rep.targetLessons} lessons)
                    </span>
                  </div>
                </div>
                <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                  <div
                    className={`h-full transition-all ${
                      rep.coveragePercent >= 75
                        ? 'bg-emerald-600'
                        : rep.coveragePercent > 0
                          ? 'bg-blue-700'
                          : 'bg-slate-300'
                    }`}
                    style={{ width: `${rep.coveragePercent}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Tab 4: Charts & Score Spread */}
      {coverageTab === 'charts' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <GroupedBarChart
              title="Classroom Syllabus Coverage vs Attendance"
              subtitle="Percentage comparison across active classrooms"
              primaryLabel="Syllabus Coverage %"
              secondaryLabel="Attendance %"
              maxValue={100}
              unit="%"
              data={classroomMatrix.map((c) => ({
                label: c.classroom.gradeLevel,
                sublabel: c.classTeacher?.name.split(' ')[0] ?? 'Unassigned',
                primary: c.avgCoveragePercent,
                secondary: c.attendanceRatePercent,
              }))}
            />

            <GroupedBarChart
              title="Teacher Delivery vs Assessments Logged"
              subtitle="Lessons delivered and assessment entries per teacher"
              primaryLabel="Lessons Delivered"
              secondaryLabel="Assessments Logged"
              data={teacherSummaries.map((t) => ({
                label: t.teacher.name.split(' ')[0],
                sublabel: `${t.taughtPlans}/${t.totalPlans} taught`,
                primary: t.totalLessonsDelivered,
                secondary: t.assessmentsLogged,
              }))}
            />
          </div>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <MasteryBreakdownDonut
              title="School-Wide Assessment Mastery Donut"
              subtitle="Aggregate distribution across all recorded learner assessments"
              exceedingCount={masteryCounts.Exceeding}
              meetingCount={masteryCounts.Meeting}
              approachingCount={masteryCounts.Approaching}
              developingCount={masteryCounts.Developing}
            />

            <TrendLineChart
              title="School-Wide Assessment Score Trend"
              subtitle="Chronological assessment percentages across learners"
              points={scoreTrendPoints}
            />
          </div>

          <div className="space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-semibold text-slate-600">
                Candlestick Grouping Mode
              </span>
              <div className="inline-flex rounded-lg bg-slate-100 p-1">
                {(['month', 'subject', 'teacher'] as const).map((b) => (
                  <button
                    key={b}
                    type="button"
                    onClick={() => setCandleBucket(b)}
                    className={`rounded-md px-3 py-1 text-xs font-semibold capitalize ${
                      candleBucket === b
                        ? 'bg-white text-blue-700 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    By {b}
                  </button>
                ))}
              </div>
            </div>
            <ScoreCandlestickChart
              title="School Score Spread Candlestick (Open · High · Low · Close)"
              subtitle={`Assessment % spread grouped by ${candleBucket}`}
              points={candlesticks}
            />
          </div>
        </div>
      )}

      {/* Tab 5: Who & When Audit Log */}
      {coverageTab === 'audit' && (
        <section className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Who &amp; When Activity Audit Log ({filteredAuditLogs.length})
              </h3>
              <p className="text-xs text-slate-500">
                Immutable chronological feed showing actor, role, timestamp, entity, and change summary.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <input
                type="search"
                aria-label="Search audit logs"
                value={auditSearch}
                onChange={(e) => setAuditSearch(e.target.value)}
                placeholder="Search actor, action, target..."
                className="w-52 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs focus:border-blue-700 focus:outline-none"
              />
              <select
                aria-label="Filter audit logs by entity type"
                value={auditEntityFilter}
                onChange={(e) => setAuditEntityFilter(e.target.value)}
                className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
              >
                <option value="all">All Record Types</option>
                <option value="lesson_plan">Lesson Plans</option>
                <option value="assessment_entry">Assessments</option>
                <option value="diary_entry">School Diary</option>
                <option value="scheme_strand">Scheme Strands</option>
                <option value="classroom">Classrooms</option>
                <option value="attendance_record">Class Register</option>
                <option value="school_event">Calendar Events</option>
              </select>
            </div>
          </div>

          {filteredAuditLogs.length === 0 ? (
            <div className="py-6 text-center">
              <p className="text-xs text-slate-500">
                No audit events match this filter.
              </p>
              {(auditSearch.trim() || auditEntityFilter !== 'all') && (
                <button
                  type="button"
                  onClick={() => {
                    setAuditSearch('');
                    setAuditEntityFilter('all');
                  }}
                  className="mt-2.5 rounded-lg border border-slate-300 bg-white px-3 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  Clear Filters
                </button>
              )}
            </div>
          ) : (
            <div className="mt-3 overflow-x-auto">
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500">
                    <th className="py-2 pr-4 font-semibold">When</th>
                    <th className="py-2 pr-4 font-semibold">Who (Actor &amp; Role)</th>
                    <th className="py-2 pr-4 font-semibold">Action</th>
                    <th className="py-2 pr-4 font-semibold">Target</th>
                    <th className="py-2 font-semibold">Detail</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredAuditLogs.map((entry) => (
                    <tr key={entry.id} className="hover:bg-slate-50/70">
                      <td className="py-2.5 pr-4 font-mono text-[11px] text-slate-600 whitespace-nowrap tabular-nums">
                        {entry.timestamp}
                      </td>
                      <td className="py-2.5 pr-4 font-semibold text-slate-900 whitespace-nowrap">
                        {entry.actorName}{' '}
                        <span className="font-normal text-slate-500 capitalize">
                          ({entry.actorRole})
                        </span>
                      </td>
                      <td className="py-2.5 pr-4 font-medium text-blue-700 whitespace-nowrap">
                        {entry.action}
                      </td>
                      <td className="py-2.5 pr-4 text-slate-900">
                        {entry.targetLabel}
                      </td>
                      <td className="py-2.5 text-slate-600">{entry.detail}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      )}
    </div>
  );
}

const ENTITY_TYPE_OPTIONS: { value: EntityType; label: string }[] = [
  { value: 'learner', label: 'Learner Profile (learner)' },
  { value: 'diary_entry', label: 'School Diary (diary_entry)' },
  { value: 'assessment_entry', label: 'Assessment Book (assessment_entry)' },
  { value: 'lesson_plan', label: 'Lesson Plan (lesson_plan)' },
  { value: 'attendance_record', label: 'Class Register (attendance_record)' },
  { value: 'scheme_strand', label: 'Scheme Strand (scheme_strand)' },
  { value: 'scheme_substrand', label: 'Scheme Substrand (scheme_substrand)' },
  { value: 'timetable_slot', label: 'Timetable Slot (timetable_slot)' },
];

interface SchemaStudioModuleProps {
  state: SchoolECSState;
  role: Role;
  actor?: AuditActor;
  isDevMode?: boolean;
  onToggleDevMode?: () => void;
  onStateChange: (next: SchoolECSState) => void;
}

export function SchemaStudioModule({
  state,
  role,
  actor,
  isDevMode = false,
  onToggleDevMode,
  onStateChange,
}: SchemaStudioModuleProps) {
  const { isBusy, runLockedAction, showFeedback } = useActionFeedback();
  const isAdmin = role === 'admin';
  const [showFieldDialog, setShowFieldDialog] = useState(false);
  const [editingFieldId, setEditingFieldId] = useState<string | null>(null);
  const [filterEntityType, setFilterEntityType] = useState<'all' | EntityType>('all');
  const [targetEntityType, setTargetEntityType] =
    useState<DynamicFieldDefinition['targetEntityType']>('diary_entry');
  const [label, setLabel] = useState('');
  const [fieldType, setFieldType] = useState<DynamicFieldType>('text');
  const [options, setOptions] = useState('');
  const [description, setDescription] = useState('');
  const [required, setRequired] = useState(false);
  const [visibleTo, setVisibleTo] = useState<Role[]>([
    'admin',
    'teacher',
    'parent',
  ]);
  const [editableBy, setEditableBy] = useState<Role[]>(['admin', 'teacher']);
  const [error, setError] = useState<string | null>(null);
  const [showArchivedSchemas, setShowArchivedSchemas] = useState(false);

  const [showTermDialog, setShowTermDialog] = useState(false);
  const [termName, setTermName] = useState('');
  const [termStartDate, setTermStartDate] = useState('2026-09-01');
  const [termEndDate, setTermEndDate] = useState('2026-12-05');
  const [termMakeActive, setTermMakeActive] = useState(true);
  const [termError, setTermError] = useState<string | null>(null);

  const [showUserDialog, setShowUserDialog] = useState(false);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [userEmail, setUserEmail] = useState('');
  const [userName, setUserName] = useState('');
  const [userRole, setUserRole] = useState<Role>('parent');
  const [userTeacherId, setUserTeacherId] = useState<string>(
    state.teachers[0]?.id ?? ''
  );
  const [userLinkedLearnerIds, setUserLinkedLearnerIds] = useState<string[]>(
    []
  );
  const [userError, setUserError] = useState<string | null>(null);

  const activeTerm = getActiveAcademicTerm(state);
  const academicTerms = state.academicTerms ?? [];

  const handleSaveTerm = (e: FormEvent) => {
    e.preventDefault();
    void runLockedAction('Saving academic term...', () => {
      const res = upsertAcademicTerm(
        state,
        {
          name: termName,
          startDate: termStartDate,
          endDate: termEndDate,
          isActive: termMakeActive,
        },
        actor
      );
      if (res.error) {
        setTermError(res.error);
        showFeedback('error', res.error);
        return;
      }
      setTermError(null);
      setTermName('');
      setShowTermDialog(false);
      onStateChange(res.state);
      showFeedback('success', 'Academic term saved');
    });
  };

  const openCreateUserDialog = () => {
    setEditingUserId(null);
    setUserEmail('');
    setUserName('');
    setUserRole('parent');
    setUserTeacherId(state.teachers[0]?.id ?? '');
    setUserLinkedLearnerIds([]);
    setUserError(null);
    setShowUserDialog(true);
  };

  const openEditUserDialog = (account: PortalUserAccount) => {
    setEditingUserId(account.id);
    setUserEmail(account.email);
    setUserName(account.displayName);
    setUserRole(account.role);
    setUserTeacherId(account.teacherId ?? state.teachers[0]?.id ?? '');
    setUserLinkedLearnerIds([...account.linkedLearnerIds]);
    setUserError(null);
    setShowUserDialog(true);
  };

  const toggleLinkedLearner = (learnerId: string) => {
    setUserLinkedLearnerIds((prev) =>
      prev.includes(learnerId)
        ? prev.filter((id) => id !== learnerId)
        : [...prev, learnerId]
    );
  };

  const handleSaveUser = (e: FormEvent) => {
    e.preventDefault();
    void runLockedAction('Saving user account...', () => {
      const res = editingUserId
        ? updatePortalUserAccount(state, editingUserId, {
            displayName: userName,
            role: userRole,
            teacherId: userRole === 'parent' ? undefined : userTeacherId,
            linkedLearnerIds: userLinkedLearnerIds,
          })
        : invitePortalUserAccount(state, {
            email: userEmail,
            displayName: userName,
            role: userRole,
            teacherId: userRole === 'parent' ? undefined : userTeacherId,
            linkedLearnerIds: userLinkedLearnerIds,
          });
      if (res.error) {
        setUserError(res.error);
        showFeedback('error', res.error);
        return;
      }
      setUserError(null);
      setShowUserDialog(false);
      setEditingUserId(null);
      onStateChange(res.state);
      showFeedback('success', 'User account saved');
    });
  };

  const openCreateDialog = () => {
    setEditingFieldId(null);
    setTargetEntityType('diary_entry');
    setLabel('');
    setFieldType('text');
    setOptions('');
    setDescription('');
    setRequired(false);
    setVisibleTo(['admin', 'teacher', 'parent']);
    setEditableBy(['admin', 'teacher']);
    setError(null);
    setShowFieldDialog(true);
  };

  const openEditDialog = (field: DynamicFieldDefinition) => {
    setEditingFieldId(field.id);
    setTargetEntityType(field.targetEntityType);
    setLabel(field.label);
    setFieldType(field.fieldType);
    setOptions((field.options ?? []).join(', '));
    setDescription(field.description);
    setRequired(Boolean(field.required));
    setVisibleTo(
      field.visibleTo.includes('admin')
        ? field.visibleTo
        : ['admin', ...field.visibleTo]
    );
    setEditableBy(
      field.editableBy.includes('admin')
        ? field.editableBy
        : ['admin', ...field.editableBy]
    );
    setError(null);
    setShowFieldDialog(true);
  };

  const toggleRoleVisibility = (r: Role) => {
    setVisibleTo((prev) =>
      prev.includes(r) ? prev.filter((item) => item !== r) : [...prev, r]
    );
  };

  const toggleRoleEditable = (r: Role) => {
    setEditableBy((prev) =>
      prev.includes(r) ? prev.filter((item) => item !== r) : [...prev, r]
    );
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    void runLockedAction('Saving custom field...', () => {
      const parsedOptions =
        fieldType === 'select'
          ? options
              .split(',')
              .map((s) => s.trim())
              .filter(Boolean)
          : undefined;
      if (
        fieldType === 'select' &&
        (!parsedOptions || parsedOptions.length === 0)
      ) {
        const msg = 'Select fields require at least one comma-separated option.';
        setError(msg);
        showFeedback('error', msg);
        return;
      }

      const nextVisible = visibleTo.includes('admin')
        ? visibleTo
        : (['admin', ...visibleTo] as Role[]);
      const nextEditable = editableBy.includes('admin')
        ? editableBy
        : (['admin', ...editableBy] as Role[]);

      const res = editingFieldId
        ? updateDynamicField(state, editingFieldId, {
            label,
            targetEntityType,
            fieldType,
            options: parsedOptions ?? [],
            required,
            visibleTo: nextVisible,
            editableBy: nextEditable,
            description: description.trim() || 'Custom ECS component field',
          })
        : registerDynamicField(state, {
            label,
            targetEntityType,
            fieldType,
            options: parsedOptions,
            required,
            visibleTo: nextVisible,
            editableBy: nextEditable,
            description: description.trim() || 'Custom ECS component field',
          });

      if (res.error) {
        setError(res.error);
        showFeedback('error', res.error);
        return;
      }
      setError(null);
      setShowFieldDialog(false);
      setEditingFieldId(null);
      onStateChange(res.state);
      showFeedback('success', 'Custom field saved');
    });
  };

  const visibleFields = (
    filterEntityType === 'all'
      ? state.dynamicFields
      : state.dynamicFields.filter((f) => f.targetEntityType === filterEntityType)
  ).filter((f) => (showArchivedSchemas ? Boolean(f.archived) : !f.archived));

  const archivedCount = state.dynamicFields.filter((f) => f.archived).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            Custom Fields, Terms &amp; Page Layout
          </h2>
          <p className="mt-0.5 text-sm text-slate-600">
            {isAdmin
              ? 'Configure academic term dates, custom data fields, learner profile widgets, and guardian account links.'
              : 'Read-only view of custom fields, term dates, and page widgets. Switch to Admin Side to make changes.'}
          </p>
        </div>

        {isAdmin && (
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={openCreateUserDialog}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap shrink-0"
            >
              <UserPlus className="h-3.5 w-3.5" aria-hidden="true" />
              Invite User / Link Guardian
            </button>
            <button
              type="button"
              onClick={openCreateDialog}
              className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800 whitespace-nowrap shrink-0"
            >
              <Plus className="h-3.5 w-3.5" aria-hidden="true" />
              Add Custom Field
            </button>
          </div>
        )}
      </div>

      {/* Academic Terms & Developer View Controls */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        <section className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-8">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <CalendarRange className="h-4 w-4 text-blue-700" aria-hidden="true" />
              <div>
                <h3 className="text-sm font-semibold text-slate-900">
                  Academic Terms ({academicTerms.length})
                </h3>
                <p className="text-xs text-slate-500">
                  {activeTerm
                    ? `Active Term: ${activeTerm.name} (${activeTerm.startDate} to ${activeTerm.endDate})`
                    : 'Set term date ranges used across learner progress reports.'}
                </p>
              </div>
            </div>
            {isAdmin && (
              <button
                type="button"
                onClick={() => {
                  setTermName('');
                  setTermError(null);
                  setShowTermDialog(true);
                }}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap shrink-0"
              >
                <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                Add Term
              </button>
            )}
          </div>

          <div className="mt-3 space-y-2">
            {academicTerms.map((term) => {
              const isCurrent = activeTerm?.id === term.id;
              return (
                <div
                  key={term.id}
                  className={`flex flex-wrap items-center justify-between gap-3 rounded-lg border px-3.5 py-2.5 ${
                    isCurrent
                      ? 'border-blue-300 bg-blue-50/50'
                      : 'border-slate-200 bg-slate-50/50'
                  }`}
                >
                  <div>
                    <p className="text-xs font-bold text-slate-900">
                      {term.name}
                      {isCurrent && (
                        <span className="ml-2 text-blue-700">· Active Term</span>
                      )}
                    </p>
                    <p className="font-mono text-[11px] text-slate-500 tabular-nums">
                      {term.startDate} to {term.endDate}
                    </p>
                  </div>
                  {isAdmin && !isCurrent && (
                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={() =>
                        void runLockedAction('Switching active term...', () => {
                          onStateChange(setActiveAcademicTerm(state, term.id, actor));
                          showFeedback('info', `Active term switched to ${term.name}`);
                        })
                      }
                      className="rounded-md border border-slate-300 bg-white px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-100 whitespace-nowrap shrink-0 disabled:opacity-50"
                    >
                      Set Active
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        <section className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 lg:col-span-4">
          <div>
            <div className="flex items-center gap-2">
              <Code2 className="h-4 w-4 text-slate-700" aria-hidden="true" />
              <h3 className="text-sm font-semibold text-slate-900">
                Developer &amp; Architecture Views
              </h3>
            </div>
            <p className="mt-1.5 text-xs leading-relaxed text-slate-600">
              Show or hide technical prototype tabs (Architecture Plan, Firebase &amp; Dart export, and instant role-switch toolbar) from the main header.
            </p>
          </div>
          {onToggleDevMode && (
            <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3">
              <span className="text-xs font-semibold text-slate-700">
                {isDevMode ? 'Developer Mode On' : 'Developer Mode Off'}
              </span>
              <button
                type="button"
                onClick={onToggleDevMode}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold whitespace-nowrap shrink-0 ${
                  isDevMode
                    ? 'bg-slate-900 text-white hover:bg-slate-800'
                    : 'border border-slate-300 bg-white text-slate-800 hover:bg-slate-50'
                }`}
              >
                {isDevMode ? 'Hide Dev Tools' : 'Show Dev Tools'}
              </button>
            </div>
          )}
        </section>
      </div>

      {/* Add Academic Term Dialog */}
      <AppDialog
        open={showTermDialog}
        busy={isBusy}
        title="Add Academic Term"
        subtitle="Define start and end dates for learner longitudinal reports."
        onClose={() => setShowTermDialog(false)}
      >
        <form onSubmit={handleSaveTerm} className="space-y-4">
          <fieldset disabled={isBusy} className="space-y-4">
            <div>
              <label
                htmlFor="term-name"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Term Name *
              </label>
              <input
                id="term-name"
                type="text"
                value={termName}
                onChange={(e) => setTermName(e.target.value)}
                placeholder="e.g. Term 1 2027"
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="term-start"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Start Date *
                </label>
                <input
                  id="term-start"
                  type="date"
                  value={termStartDate}
                  onChange={(e) => setTermStartDate(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-sm focus:border-blue-700 focus:outline-none"
                />
              </div>
              <div>
                <label
                  htmlFor="term-end"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  End Date *
                </label>
                <input
                  id="term-end"
                  type="date"
                  value={termEndDate}
                  onChange={(e) => setTermEndDate(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-sm focus:border-blue-700 focus:outline-none"
                />
              </div>
            </div>
            <label className="flex items-center gap-2 text-xs text-slate-700">
              <input
                type="checkbox"
                checked={termMakeActive}
                onChange={(e) => setTermMakeActive(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 text-blue-700"
              />
              Set as Active Term immediately
            </label>
            {termError && (
              <p className="text-xs font-medium text-red-600">{termError}</p>
            )}
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowTermDialog(false)}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </button>
              <ActionSubmitButton
                idleLabel="Save Term"
                busyLabel="Saving..."
                className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
              />
            </div>
          </fieldset>
        </form>
      </AppDialog>

      {/* Admin Users & Guardian Linking Dialog */}
      <AppDialog
        open={showUserDialog}
        busy={isBusy}
        title={
          editingUserId
            ? 'Edit User Role & Guardian Links'
            : 'Invite Staff or Link Guardian'
        }
        subtitle="Manage /users/{uid} roles, teacherId bindings, and multi-child linkedLearnerIds."
        onClose={() => {
          setShowUserDialog(false);
          setEditingUserId(null);
        }}
      >
        <form onSubmit={handleSaveUser} className="space-y-4">
          <fieldset disabled={isBusy} className="space-y-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label
                htmlFor="usr-email"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Email *
              </label>
              <input
                id="usr-email"
                type="email"
                disabled={Boolean(editingUserId)}
                value={userEmail}
                onChange={(e) => setUserEmail(e.target.value)}
                placeholder="guardian@family.org"
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm disabled:bg-slate-100 focus:border-blue-700 focus:outline-none"
              />
            </div>
            <div>
              <label
                htmlFor="usr-name"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Display Name *
              </label>
              <input
                id="usr-name"
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="Full Name"
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label
                htmlFor="usr-role"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Portal Role
              </label>
              <select
                id="usr-role"
                value={userRole}
                onChange={(e) => setUserRole(e.target.value as Role)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              >
                <option value="admin">Admin</option>
                <option value="teacher">Teacher</option>
                <option value="parent">Parent / Guardian</option>
              </select>
            </div>
            {userRole !== 'parent' && (
              <div>
                <label
                  htmlFor="usr-teacher"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Linked Teacher Record
                </label>
                <select
                  id="usr-teacher"
                  value={userTeacherId}
                  onChange={(e) => setUserTeacherId(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                >
                  <option value="">Unassigned</option>
                  {state.teachers.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <div>
            <span className="mb-1.5 block text-xs font-medium text-slate-700">
              Linked Learners (Multi-Child Guardian Scope)
            </span>
            <div className="grid grid-cols-1 gap-2 rounded-lg border border-slate-200 bg-slate-50 p-3 sm:grid-cols-2">
              {state.learners.map((learner) => (
                <label
                  key={learner.id}
                  className="flex items-center gap-2 text-xs text-slate-800"
                >
                  <input
                    type="checkbox"
                    checked={userLinkedLearnerIds.includes(learner.id)}
                    onChange={() => toggleLinkedLearner(learner.id)}
                    className="h-4 w-4 rounded border-slate-300 text-blue-700"
                  />
                  <span>
                    {learner.name}{' '}
                    <span className="font-mono text-[11px] text-slate-500">
                      ({learner.admissionNo})
                    </span>
                  </span>
                </label>
              ))}
            </div>
          </div>

          {userError && (
            <p className="text-xs font-medium text-red-600">{userError}</p>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => {
                setShowUserDialog(false);
                setEditingUserId(null);
              }}
              className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <ActionSubmitButton
              idleLabel={
                editingUserId ? 'Save User & Links' : 'Create User Account'
              }
              busyLabel="Saving..."
              className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
            />
          </div>
          </fieldset>
        </form>
      </AppDialog>

      <AppDialog
        open={showFieldDialog}
        busy={isBusy}
        title={
          editingFieldId
            ? 'Edit Component Field Schema'
            : 'Register New Component Field'
        }
        subtitle="Attach or update a field schema on any Firestore entity collection with role visibility and edit permissions."
        onClose={() => {
          setShowFieldDialog(false);
          setEditingFieldId(null);
        }}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <fieldset disabled={isBusy} className="space-y-4">
          <div>
            <label
              htmlFor="schema-target"
              className="mb-1 block text-xs font-medium text-slate-700"
            >
              Target Entity Type
            </label>
            <select
              id="schema-target"
              value={targetEntityType}
              onChange={(e) =>
                setTargetEntityType(
                  e.target.value as DynamicFieldDefinition['targetEntityType']
                )
              }
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
            >
              {ENTITY_TYPE_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label
                htmlFor="schema-label"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Field Label *
              </label>
              <input
                id="schema-label"
                type="text"
                value={label}
                onChange={(e) => setLabel(e.target.value)}
                placeholder="e.g. Lab Safety Score"
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>
            <div>
              <label
                htmlFor="schema-type"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Data Type
              </label>
              <select
                id="schema-type"
                value={fieldType}
                onChange={(e) =>
                  setFieldType(e.target.value as DynamicFieldType)
                }
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              >
                <option value="text">Text</option>
                <option value="number">Number</option>
                <option value="boolean">Boolean</option>
                <option value="select">Select</option>
                <option value="date">Date</option>
              </select>
            </div>
          </div>

          {fieldType === 'select' && (
            <div>
              <label
                htmlFor="schema-options"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Options (comma-separated) *
              </label>
              <input
                id="schema-options"
                type="text"
                value={options}
                onChange={(e) => setOptions(e.target.value)}
                placeholder="Option A, Option B, Option C"
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>
          )}

          <div>
            <label
              htmlFor="schema-desc"
              className="mb-1 block text-xs font-medium text-slate-700"
            >
              Description
            </label>
            <input
              id="schema-desc"
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Purpose of this component field..."
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
            />
          </div>

          <div className="space-y-3 border-t border-slate-100 pt-3">
            <div>
              <span className="block text-xs font-medium text-slate-700">
                Portal Visibility (Admin Always Included)
              </span>
              <div className="mt-1.5 flex flex-wrap gap-4 text-xs">
                {(['teacher', 'parent'] as Role[]).map((r) => (
                  <label key={r} className="flex items-center gap-1.5 capitalize">
                    <input
                      type="checkbox"
                      checked={visibleTo.includes(r)}
                      onChange={() => toggleRoleVisibility(r)}
                      className="h-4 w-4 rounded border-slate-300 text-blue-700"
                    />
                    {r}
                  </label>
                ))}
              </div>
            </div>

            <div>
              <span className="block text-xs font-medium text-slate-700">
                Editable By Role (Admin Always Included)
              </span>
              <div className="mt-1.5 flex flex-wrap gap-4 text-xs">
                {(['teacher', 'parent'] as Role[]).map((r) => (
                  <label key={r} className="flex items-center gap-1.5 capitalize">
                    <input
                      type="checkbox"
                      checked={editableBy.includes(r)}
                      onChange={() => toggleRoleEditable(r)}
                      className="h-4 w-4 rounded border-slate-300 text-blue-700"
                    />
                    {r}
                  </label>
                ))}
                <label className="flex items-center gap-1.5">
                  <input
                    type="checkbox"
                    checked={required}
                    onChange={(e) => setRequired(e.target.checked)}
                    className="h-4 w-4 rounded border-slate-300 text-blue-700"
                  />
                  Required field
                </label>
              </div>
            </div>
          </div>

          {error && <p className="text-xs font-medium text-red-600">{error}</p>}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => {
                setShowFieldDialog(false);
                setEditingFieldId(null);
              }}
              className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <ActionSubmitButton
              idleLabel={
                editingFieldId ? 'Save Field Changes' : 'Register Component Schema'
              }
              busyLabel="Saving..."
              className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
            />
          </div>
          </fieldset>
        </form>
      </AppDialog>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <section className="space-y-3 lg:col-span-6">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-sm font-semibold text-slate-900">
              {showArchivedSchemas ? 'Archived' : 'Active'} Entity Component Fields (
              {visibleFields.length})
            </h3>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowArchivedSchemas((v) => !v)}
                className={`rounded-lg border px-2.5 py-1.5 text-xs font-semibold transition-colors ${
                  showArchivedSchemas
                    ? 'border-amber-300 bg-amber-50 text-amber-800'
                    : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                {showArchivedSchemas
                  ? 'Show Active'
                  : `Archived (${archivedCount})`}
              </button>
              <select
                aria-label="Filter component fields by entity type"
                value={filterEntityType}
                onChange={(e) =>
                  setFilterEntityType(e.target.value as 'all' | EntityType)
                }
                className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-700 focus:border-blue-700 focus:outline-none"
              >
                <option value="all">All Entities</option>
                {ENTITY_TYPE_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {visibleFields.length === 0 ? (
            <div className="rounded-xl border border-slate-200 bg-white p-6 text-center text-xs text-slate-500">
              {showArchivedSchemas
                ? 'No archived schemas. Archiving hides a field from new forms while preserving historical record labels.'
                : 'No active component fields match this filter.'}
            </div>
          ) : (
            visibleFields.map((field) => (
              <div
                key={field.id}
                className="flex items-start justify-between gap-4 rounded-xl border border-slate-200 bg-white p-4"
              >
                <div className="min-w-0 flex-1">
                  <p className="font-mono text-xs text-slate-500">
                    {field.targetEntityType}.{field.key} · {field.fieldType}
                    {field.required ? ' · Required' : ''}
                    {field.archived ? ' · ARCHIVED' : ''}
                  </p>
                  <h4 className="mt-0.5 text-sm font-semibold text-slate-900">
                    {field.label}
                  </h4>
                  <p className="mt-1 text-xs text-slate-600">{field.description}</p>
                  <p className="mt-1.5 text-[11px] text-slate-500">
                    Visible: {field.visibleTo.join(', ')} · Editable:{' '}
                    {field.editableBy.join(', ')}
                  </p>
                </div>
                {isAdmin && (
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      aria-label={`Edit field ${field.label}`}
                      onClick={() => openEditDialog(field)}
                      className="rounded-lg p-2 text-slate-500 transition-colors hover:bg-blue-50 hover:text-blue-700"
                    >
                      <Pencil className="h-4 w-4" aria-hidden="true" />
                    </button>
                    {field.archived ? (
                      <button
                        type="button"
                        disabled={isBusy}
                        aria-label={`Restore field ${field.label}`}
                        title="Restore field"
                        onClick={() =>
                          void runLockedAction('Restoring custom field...', () => {
                            onStateChange(restoreDynamicField(state, field.id));
                            showFeedback('success', 'Custom field restored');
                          })
                        }
                        className="rounded-lg p-2 text-emerald-600 transition-colors hover:bg-emerald-50 disabled:opacity-50"
                      >
                        <RotateCcw className="h-4 w-4" aria-hidden="true" />
                      </button>
                    ) : (
                      <button
                        type="button"
                        disabled={isBusy}
                        aria-label={`Archive field ${field.label}`}
                        title="Safe archive (preserves historical labels)"
                        onClick={() =>
                          void runLockedAction('Archiving custom field...', () => {
                            onStateChange(archiveDynamicField(state, field.id));
                            showFeedback('warning', 'Custom field archived');
                          })
                        }
                        className="rounded-lg p-2 text-slate-400 transition-colors hover:bg-amber-50 hover:text-amber-700 disabled:opacity-50"
                      >
                        <Archive className="h-4 w-4" aria-hidden="true" />
                      </button>
                    )}
                  </div>
                )}
              </div>
            ))
          )}
        </section>

        <section className="space-y-3 lg:col-span-6">
          <h3 className="text-sm font-semibold text-slate-900">
            Loosely Coupled Learner Page Widgets ({state.pageWidgets.length})
          </h3>
          {[...state.pageWidgets]
            .sort((a, b) => a.order - b.order)
            .map((widget, idx, arr) => (
              <div
                key={widget.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-4"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <input
                      id={`studio_w_${widget.id}`}
                      type="checkbox"
                      disabled={!isAdmin || isBusy}
                      checked={widget.enabled}
                      onChange={() =>
                        void runLockedAction('Updating widget layout...', () => {
                          onStateChange(togglePageWidgetEnabled(state, widget.id));
                          showFeedback('info', 'Widget layout updated');
                        })
                      }
                      className="h-4 w-4 rounded border-slate-300 text-blue-700 disabled:opacity-50"
                    />
                    <label
                      htmlFor={`studio_w_${widget.id}`}
                      className="text-sm font-semibold text-slate-900"
                    >
                      {widget.title}
                    </label>
                  </div>
                  <p className="mt-0.5 pl-6 text-xs text-slate-600">
                    {widget.description}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-1 text-xs text-slate-700">
                    <input
                      type="checkbox"
                      disabled={!isAdmin || isBusy}
                      checked={widget.allowedRoles.includes('teacher')}
                      onChange={() =>
                        void runLockedAction('Updating widget layout...', () => {
                          onStateChange(
                            togglePageWidgetRole(state, widget.id, 'teacher')
                          );
                          showFeedback('info', 'Widget layout updated');
                        })
                      }
                      className="h-3.5 w-3.5 rounded border-slate-300 text-blue-700 disabled:opacity-50"
                    />
                    Teacher
                  </label>
                  <label className="flex items-center gap-1 text-xs text-slate-700">
                    <input
                      type="checkbox"
                      disabled={!isAdmin || isBusy}
                      checked={widget.allowedRoles.includes('parent')}
                      onChange={() =>
                        void runLockedAction('Updating widget layout...', () => {
                          onStateChange(
                            togglePageWidgetRole(state, widget.id, 'parent')
                          );
                          showFeedback('info', 'Widget layout updated');
                        })
                      }
                      className="h-3.5 w-3.5 rounded border-slate-300 text-blue-700 disabled:opacity-50"
                    />
                    Parent
                  </label>
                  {isAdmin && (
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        disabled={idx === 0 || isBusy}
                        aria-label={`Move ${widget.title} up in schema studio`}
                        onClick={() =>
                          void runLockedAction('Updating widget layout...', () => {
                            onStateChange(movePageWidget(state, widget.id, 'up'));
                            showFeedback('info', 'Widget layout updated');
                          })
                        }
                        className="rounded border border-slate-300 bg-white p-1 text-slate-600 hover:bg-slate-100 disabled:opacity-40"
                      >
                        <ArrowUp className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                      <button
                        type="button"
                        disabled={idx === arr.length - 1 || isBusy}
                        aria-label={`Move ${widget.title} down in schema studio`}
                        onClick={() =>
                          void runLockedAction('Updating widget layout...', () => {
                            onStateChange(movePageWidget(state, widget.id, 'down'));
                            showFeedback('info', 'Widget layout updated');
                          })
                        }
                        className="rounded border border-slate-300 bg-white p-1 text-slate-600 hover:bg-slate-100 disabled:opacity-40"
                      >
                        <ArrowDown className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
        </section>
      </div>

      {/* Admin Users & Guardian Linking Directory */}
      <section className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              Admin Users &amp; Guardian Linking ({state.users.length})
            </h3>
            <p className="text-xs text-slate-500">
              Bind staff accounts to Teacher entities and Parent accounts to multiple Learners.
            </p>
          </div>
          {isAdmin && (
            <button
              type="button"
              onClick={openCreateUserDialog}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-50"
            >
              <UserPlus className="h-3.5 w-3.5" aria-hidden="true" />
              Add User / Guardian
            </button>
          )}
        </div>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="py-2 pr-4 font-semibold">User</th>
                <th className="py-2 pr-4 font-semibold">Role</th>
                <th className="py-2 pr-4 font-semibold">Teacher Binding</th>
                <th className="py-2 pr-4 font-semibold">Linked Learners</th>
                {isAdmin && (
                  <th className="py-2 text-right font-semibold">Action</th>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {state.users.map((account) => {
                const teacher = state.teachers.find(
                  (t) => t.id === account.teacherId
                );
                const linkedNames = account.linkedLearnerIds
                  .map(
                    (id) => state.learners.find((l) => l.id === id)?.name ?? id
                  )
                  .join(', ');

                return (
                  <tr key={account.id} className="hover:bg-slate-50/70">
                    <td className="py-2.5 pr-4">
                      <p className="font-semibold text-slate-900">
                        {account.displayName}
                      </p>
                      <p className="font-mono text-[11px] text-slate-500">
                        {account.email}
                      </p>
                    </td>
                    <td className="py-2.5 pr-4 capitalize font-semibold text-blue-700">
                      {account.role}
                    </td>
                    <td className="py-2.5 pr-4 text-slate-700">
                      {teacher?.name ?? '—'}
                    </td>
                    <td className="py-2.5 pr-4 text-slate-700">
                      {linkedNames || '—'}
                    </td>
                    {isAdmin && (
                      <td className="py-2.5 text-right">
                        <button
                          type="button"
                          onClick={() => openEditUserDialog(account)}
                          className="rounded-md border border-slate-300 bg-white px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                        >
                          Edit Links
                        </button>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
