import { useMemo, useState, type FormEvent } from 'react';
import { CheckCircle2, Megaphone, Plus, Search } from 'lucide-react';
import {
  broadcastClassroomDiary,
  getFieldsForEntity,
  registerDynamicField,
  toggleDiaryAcknowledgment,
} from '../../ecs/engine';
import type {
  AuditActor,
  DynamicFieldType,
  Role,
  SchoolECSState,
} from '../../ecs/types';
import { ActionSubmitButton, useActionFeedback } from '../ActionFeedback';
import { AppDialog } from '../AppDialog';
import {
  DynamicFieldInputs,
  DynamicFieldReadout,
} from '../DynamicFieldsRenderer';

interface DiaryModuleProps {
  state: SchoolECSState;
  role: Role;
  activeTeacherId: string;
  activeLearnerId: string;
  actor?: AuditActor;
  onStateChange: (next: SchoolECSState) => void;
  onOpenDiaryDialog: (learnerId?: string) => void;
  onOpenLearnerPage: (learnerId: string) => void;
}

export function DiaryModule({
  state,
  role,
  activeTeacherId,
  activeLearnerId,
  actor,
  onStateChange,
  onOpenDiaryDialog,
  onOpenLearnerPage,
}: DiaryModuleProps) {
  const { isBusy, runLockedAction, showFeedback } = useActionFeedback();
  const [searchQuery, setSearchQuery] = useState('');
  const [classroomFilter, setClassroomFilter] = useState('all');
  const [signoffFilter, setSignoffFilter] = useState<'all' | 'pending' | 'signed'>('all');

  const [showFieldDialog, setShowFieldDialog] = useState(false);
  const [newFieldLabel, setNewFieldLabel] = useState('');
  const [newFieldType, setNewFieldType] = useState<DynamicFieldType>('text');
  const [newFieldOptions, setNewFieldOptions] = useState('');
  const [newFieldParentVisible, setNewFieldParentVisible] = useState(true);
  const [fieldError, setFieldError] = useState<string | null>(null);

  const [showBroadcastDialog, setShowBroadcastDialog] = useState(false);
  const [broadcastClassroomId, setBroadcastClassroomId] = useState(
    state.classrooms[0]?.id ?? ''
  );
  const [broadcastDate, setBroadcastDate] = useState('2026-11-25');
  const [broadcastHomework, setBroadcastHomework] = useState('');
  const [broadcastNote, setBroadcastNote] = useState('');
  const [broadcastCustomValues, setBroadcastCustomValues] = useState<
    Record<string, string | number | boolean>
  >({});
  const [broadcastError, setBroadcastError] = useState<string | null>(null);

  const activeDiaryFields = getFieldsForEntity(state, 'diary_entry', role, false);
  const diaryReadoutFields = getFieldsForEntity(state, 'diary_entry', role, true);

  const baseEntries = useMemo(
    () =>
      role === 'parent'
        ? state.diaryEntries.filter((d) => d.learnerId === activeLearnerId)
        : state.diaryEntries,
    [state.diaryEntries, role, activeLearnerId]
  );

  const visibleEntries = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return baseEntries.filter((entry) => {
      if (
        role !== 'parent' &&
        classroomFilter !== 'all' &&
        entry.classroomId !== classroomFilter
      ) {
        return false;
      }
      if (signoffFilter === 'signed' && !entry.parentAcknowledged) return false;
      if (signoffFilter === 'pending' && entry.parentAcknowledged) return false;
      if (!q) return true;
      const learner = state.learners.find((l) => l.id === entry.learnerId);
      const teacher = state.teachers.find((t) => t.id === entry.teacherId);
      return (
        entry.homeworkSummary.toLowerCase().includes(q) ||
        entry.teacherNote.toLowerCase().includes(q) ||
        (learner?.name.toLowerCase().includes(q) ?? false) ||
        (teacher?.name.toLowerCase().includes(q) ?? false)
      );
    });
  }, [
    baseEntries,
    role,
    classroomFilter,
    signoffFilter,
    searchQuery,
    state.learners,
    state.teachers,
  ]);

  const signedCount = baseEntries.filter((e) => e.parentAcknowledged).length;
  const pendingCount = baseEntries.length - signedCount;
  const hasActiveFilters =
    Boolean(searchQuery.trim()) ||
    (role !== 'parent' && classroomFilter !== 'all') ||
    signoffFilter !== 'all';

  const handleAddField = (e: FormEvent) => {
    e.preventDefault();
    void runLockedAction('Adding diary field...', () => {
      const res = registerDynamicField(state, {
        label: newFieldLabel,
        targetEntityType: 'diary_entry',
        fieldType: newFieldType,
        options:
          newFieldType === 'select'
            ? newFieldOptions
                .split(',')
                .map((s) => s.trim())
                .filter(Boolean)
            : undefined,
        required: false,
        visibleTo: newFieldParentVisible
          ? ['admin', 'teacher', 'parent']
          : ['admin', 'teacher'],
        editableBy: ['admin', 'teacher'],
        description: 'Custom diary component field',
      });
      if (res.error) {
        setFieldError(res.error);
        showFeedback('error', res.error);
        return;
      }
      setFieldError(null);
      setNewFieldLabel('');
      setNewFieldOptions('');
      setShowFieldDialog(false);
      onStateChange(res.state);
      showFeedback('success', 'Custom diary field added');
    });
  };

  const handleBroadcastSubmit = (e: FormEvent) => {
    e.preventDefault();
    void runLockedAction('Broadcasting diary...', () => {
      const res = broadcastClassroomDiary(
        state,
        {
          classroomId: broadcastClassroomId,
          teacherId: activeTeacherId,
          date: broadcastDate,
          homeworkSummary: broadcastHomework,
          teacherNote: broadcastNote,
          customFields: broadcastCustomValues,
          actorRole: role,
        },
        actor
      );
      if (res.error) {
        setBroadcastError(res.error);
        showFeedback('error', res.error);
        return;
      }
      setBroadcastError(null);
      setBroadcastHomework('');
      setBroadcastNote('');
      setBroadcastCustomValues({});
      setShowBroadcastDialog(false);
      onStateChange(res.state);
      showFeedback(
        'success',
        `Broadcasted diary entry to ${res.entries.length} learners`
      );
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            School Diary
          </h2>
          <p className="mt-0.5 text-sm text-slate-600">
            {role === 'parent'
              ? 'Child-scoped daily homework, teacher notes, dynamic awards, and parent acknowledgment.'
              : 'Daily homework and parent communication feed. Broadcast class homework or log individual learner entries.'}
          </p>
        </div>

        {(role === 'admin' || role === 'teacher') && (
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setShowFieldDialog(true)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 transition-colors hover:bg-slate-50 whitespace-nowrap shrink-0"
            >
              <Plus className="h-3.5 w-3.5" aria-hidden="true" />
              Add Custom Diary Field
            </button>
            <button
              type="button"
              onClick={() => {
                setBroadcastError(null);
                setShowBroadcastDialog(true);
              }}
              className="inline-flex items-center gap-1.5 rounded-lg border border-blue-200 bg-blue-50 px-3.5 py-2 text-xs font-semibold text-blue-800 transition-colors hover:bg-blue-100 whitespace-nowrap shrink-0"
            >
              <Megaphone className="h-3.5 w-3.5" aria-hidden="true" />
              Broadcast to Class
            </button>
            <button
              type="button"
              onClick={() => onOpenDiaryDialog()}
              className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white transition-colors hover:bg-blue-800 whitespace-nowrap shrink-0"
            >
              <Plus className="h-3.5 w-3.5" aria-hidden="true" />
              Log Diary Entry
            </button>
          </div>
        )}
      </div>

      {/* KPI Summary Strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Total Diary Entries</p>
          <p className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
            {baseEntries.length}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Parent Signed</p>
          <p className="mt-1 font-mono text-2xl font-bold text-emerald-700 tabular-nums">
            {signedCount}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Awaiting Sign-off</p>
          <p className="mt-1 font-mono text-2xl font-bold text-amber-700 tabular-nums">
            {pendingCount}
          </p>
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-3.5">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search
              className="pointer-events-none absolute top-2.5 left-3 h-3.5 w-3.5 text-slate-400"
              aria-hidden="true"
            />
            <input
              type="search"
              aria-label="Search diary entries"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                role === 'parent'
                  ? 'Search homework or teacher note...'
                  : 'Search learner, homework, or teacher...'
              }
              className="w-64 rounded-lg border border-slate-300 bg-white py-1.5 pr-3 pl-8 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
            />
          </div>

          {role !== 'parent' && (
            <select
              aria-label="Filter diary by classroom"
              value={classroomFilter}
              onChange={(e) => setClassroomFilter(e.target.value)}
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
            >
              <option value="all">All Classrooms</option>
              {state.classrooms.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          )}
        </div>

        <div className="inline-flex rounded-lg bg-slate-100 p-1">
          {(
            [
              { id: 'all', label: `All (${baseEntries.length})` },
              { id: 'pending', label: `Awaiting (${pendingCount})` },
              { id: 'signed', label: `Signed (${signedCount})` },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setSignoffFilter(tab.id)}
              className={`rounded-md px-3 py-1 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                signoffFilter === tab.id
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Class-Wide Broadcast Dialog */}
      <AppDialog
        open={showBroadcastDialog}
        busy={isBusy}
        title="Broadcast Diary to Classroom"
        subtitle="Assign homework once to every learner in the selected classroom."
        onClose={() => setShowBroadcastDialog(false)}
      >
        <form onSubmit={handleBroadcastSubmit} className="space-y-4">
          <fieldset disabled={isBusy} className="space-y-4">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="broadcast-classroom"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Classroom
                </label>
                <select
                  id="broadcast-classroom"
                  value={broadcastClassroomId}
                  onChange={(e) => setBroadcastClassroomId(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                >
                  {state.classrooms.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label
                  htmlFor="broadcast-date"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Date
                </label>
                <input
                  id="broadcast-date"
                  type="date"
                  value={broadcastDate}
                  onChange={(e) => setBroadcastDate(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="broadcast-homework"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Class Homework Assignment *
              </label>
              <textarea
                id="broadcast-homework"
                rows={2}
                value={broadcastHomework}
                onChange={(e) => setBroadcastHomework(e.target.value)}
                placeholder="e.g. Complete Fractions Mastery Sheet Q1-Q10..."
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>

            <div>
              <label
                htmlFor="broadcast-note"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Shared Class Note
              </label>
              <input
                id="broadcast-note"
                type="text"
                value={broadcastNote}
                onChange={(e) => setBroadcastNote(e.target.value)}
                placeholder="Reminder for all parents in this classroom..."
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>

            <DynamicFieldInputs
              fields={activeDiaryFields}
              values={broadcastCustomValues}
              role={role}
              onChange={(key, val) =>
                setBroadcastCustomValues((prev) => ({ ...prev, [key]: val }))
              }
            />

            {broadcastError && (
              <p className="text-xs font-medium text-red-600">{broadcastError}</p>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowBroadcastDialog(false)}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </button>
              <ActionSubmitButton
                idleLabel="Broadcast to Classroom"
                busyLabel="Broadcasting..."
                className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
              />
            </div>
          </fieldset>
        </form>
      </AppDialog>

      {/* Custom Field Dialog */}
      <AppDialog
        open={showFieldDialog}
        busy={isBusy}
        title="Add Custom Diary Field"
        subtitle="Dynamically attach a new ECS field to diary_entry documents without altering schemas."
        onClose={() => setShowFieldDialog(false)}
      >
        <form onSubmit={handleAddField} className="space-y-4">
          <fieldset disabled={isBusy} className="space-y-4">
            <div>
              <label
                htmlFor="quick-diary-field-label"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Field Label *
              </label>
              <input
                id="quick-diary-field-label"
                type="text"
                value={newFieldLabel}
                onChange={(e) => setNewFieldLabel(e.target.value)}
                placeholder="e.g. Citizenship Merit"
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="quick-diary-field-type"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Component Data Type
                </label>
                <select
                  id="quick-diary-field-type"
                  value={newFieldType}
                  onChange={(e) =>
                    setNewFieldType(e.target.value as DynamicFieldType)
                  }
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                >
                  <option value="text">Text</option>
                  <option value="number">Number</option>
                  <option value="boolean">Checkbox (Boolean)</option>
                  <option value="select">Select Options</option>
                </select>
              </div>

              <label className="mt-6 flex items-center gap-2 text-xs font-medium text-slate-700">
                <input
                  type="checkbox"
                  checked={newFieldParentVisible}
                  onChange={(e) => setNewFieldParentVisible(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 text-blue-700"
                />
                Visible in Parent Portal
              </label>
            </div>

            {newFieldType === 'select' && (
              <div>
                <label
                  htmlFor="quick-diary-field-opts"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Comma-Separated Options
                </label>
                <input
                  id="quick-diary-field-opts"
                  type="text"
                  value={newFieldOptions}
                  onChange={(e) => setNewFieldOptions(e.target.value)}
                  placeholder="Gold Star, Helper, Reader"
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                />
              </div>
            )}

            {fieldError && (
              <p className="text-xs font-medium text-red-600">{fieldError}</p>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowFieldDialog(false)}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </button>
              <ActionSubmitButton
                idleLabel="Register Component Field"
                busyLabel="Registering..."
                className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
              />
            </div>
          </fieldset>
        </form>
      </AppDialog>

      {visibleEntries.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-8 text-center">
          <p className="text-sm font-medium text-slate-800">
            {hasActiveFilters
              ? 'No diary entries match your current filter criteria.'
              : 'No diary entries recorded yet for this view.'}
          </p>
          {hasActiveFilters && (
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setClassroomFilter('all');
                setSignoffFilter('all');
              }}
              className="mt-3 rounded-lg border border-slate-300 bg-white px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              Clear Filters
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {visibleEntries.map((entry) => {
            const learner = state.learners.find((l) => l.id === entry.learnerId);
            const teacher = state.teachers.find((t) => t.id === entry.teacherId);
            const classroom = state.classrooms.find(
              (c) => c.id === entry.classroomId
            );

            return (
              <article
                key={entry.id}
                className="rounded-xl border border-slate-200 bg-white p-5"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="text-xs text-slate-500">
                      <span className="font-mono tabular-nums">{entry.date}</span> ·{' '}
                      {classroom?.name} · Logged by {teacher?.name}
                    </p>
                    <button
                      type="button"
                      onClick={() => learner && onOpenLearnerPage(learner.id)}
                      className="mt-1 text-left font-display text-base font-bold text-slate-900 hover:text-blue-700 hover:underline"
                    >
                      {learner?.name}
                    </button>
                  </div>

                  {role === 'parent' ? (
                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={() =>
                        void runLockedAction('Updating diary sign-off...', () => {
                          const next = toggleDiaryAcknowledgment(
                            state,
                            entry.id,
                            actor
                          );
                          onStateChange(next);
                          const updated = next.diaryEntries.find(
                            (d) => d.id === entry.id
                          );
                          if (updated?.parentAcknowledged) {
                            showFeedback('success', 'Diary signed off');
                          } else {
                            showFeedback('warning', 'Diary sign-off cleared');
                          }
                        })
                      }
                      className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 disabled:cursor-not-allowed disabled:opacity-60 ${
                        entry.parentAcknowledged
                          ? 'border border-emerald-200 bg-emerald-50 text-emerald-700'
                          : 'bg-blue-700 text-white hover:bg-blue-800'
                      }`}
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
                      {entry.parentAcknowledged
                        ? 'Acknowledged by Parent'
                        : 'Acknowledge Entry'}
                    </button>
                  ) : (
                    <span
                      className={`inline-flex items-center gap-1.5 text-xs font-semibold ${
                        entry.parentAcknowledged
                          ? 'text-emerald-700'
                          : 'text-amber-700'
                      }`}
                    >
                      <span
                        className={`h-2 w-2 rounded-full ${
                          entry.parentAcknowledged
                            ? 'bg-emerald-600'
                            : 'bg-amber-600'
                        }`}
                      />
                      {entry.parentAcknowledged
                        ? 'Parent Signed'
                        : 'Awaiting Sign-off'}
                    </span>
                  )}
                </div>

                <p className="mt-3 text-sm text-slate-800">
                  <span className="font-semibold">Homework: </span>
                  {entry.homeworkSummary}
                </p>
                {entry.teacherNote && (
                  <p className="mt-1.5 text-xs leading-relaxed text-slate-600">
                    <span className="font-semibold text-slate-700">Note: </span>
                    {entry.teacherNote}
                  </p>
                )}

                <DynamicFieldReadout
                  fields={diaryReadoutFields}
                  values={entry.customFields}
                  role={role}
                />
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
