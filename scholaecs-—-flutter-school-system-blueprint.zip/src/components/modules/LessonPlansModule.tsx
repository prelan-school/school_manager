import {
  BookOpen,
  CalendarPlus,
  Copy,
  HelpCircle,
  Pencil,
  Plus,
  Search,
  Trash2,
} from 'lucide-react';
import { useEffect, useMemo, useState, type FormEvent } from 'react';
import {
  assignLessonToTimetableSlot,
  createLessonPlan,
  deleteLessonPlan,
  duplicateLessonPlan,
  getFieldsForEntity,
  getScheduleDaysForClassroom,
  updateLessonPlan,
  updateLessonStatus,
  upsertTimetableSlot,
} from '../../ecs/engine';
import type {
  AuditActor,
  LessonPlanEntity,
  LessonStatus,
  Role,
  SchoolECSState,
} from '../../ecs/types';
import { ActionSubmitButton, useActionFeedback } from '../ActionFeedback';
import { AppDialog } from '../AppDialog';
import { AuditAttributionLine } from '../AnalyticsCharts';
import {
  DynamicFieldInputs,
  DynamicFieldReadout,
} from '../DynamicFieldsRenderer';
import type { DiaryPrefillInput, LessonPrefillDraft } from '../SandboxWorkspace';

interface LessonPlansModuleProps {
  state: SchoolECSState;
  role: Role;
  activeTeacherId: string;
  actor?: AuditActor;
  initialPrefill?: LessonPrefillDraft | null;
  onClearPrefill?: () => void;
  onOpenHomeworkDialog?: (prefill: DiaryPrefillInput) => void;
  onStateChange: (next: SchoolECSState) => void;
}

export function LessonPlansModule({
  state,
  role,
  activeTeacherId,
  actor,
  initialPrefill,
  onClearPrefill,
  onOpenHomeworkDialog,
  onStateChange,
}: LessonPlansModuleProps) {
  const { isBusy, runLockedAction, showFeedback } = useActionFeedback();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterMode, setFilterMode] = useState<'all' | 'unassigned'>('all');
  const [filterClassroomId, setFilterClassroomId] = useState<string>('all');
  const [filterSubjectId, setFilterSubjectId] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | LessonStatus>('all');
  const [recentTaughtPrompt, setRecentTaughtPrompt] =
    useState<LessonPlanEntity | null>(null);

  // Create / Edit Lesson Registry Dialog
  const [showLessonDialog, setShowLessonDialog] = useState(false);
  const [editingLessonId, setEditingLessonId] = useState<string | null>(null);
  const [teacherId, setTeacherId] = useState(activeTeacherId);
  const [classroomId, setClassroomId] = useState(state.classrooms[0]?.id ?? '');
  const [substrandId, setSubstrandId] = useState(state.substrands[0]?.id ?? '');
  const [timetableSlotId, setTimetableSlotId] = useState('');
  const [title, setTitle] = useState('');
  const [scheduledDate, setScheduledDate] = useState('2026-11-26');
  const [lessonsDelivered, setLessonsDelivered] = useState(2);
  const [status, setStatus] = useState<LessonStatus>('planned');
  const [reflectionNote, setReflectionNote] = useState('');
  const [customFields, setCustomFields] = useState<
    Record<string, string | number | boolean>
  >({});
  const [error, setError] = useState<string | null>(null);

  // Assign Registered Lesson to Timetable Dialog
  const [assigningLesson, setAssigningLesson] =
    useState<LessonPlanEntity | null>(null);
  const [assignMode, setAssignMode] = useState<'existing' | 'new_slot'>(
    'existing'
  );
  const [selectedSlotId, setSelectedSlotId] = useState('');
  const [newSlotClassroomId, setNewSlotClassroomId] = useState(
    state.classrooms[0]?.id ?? ''
  );
  const [newSlotTeacherId, setNewSlotTeacherId] = useState(
    state.teachers[0]?.id ?? ''
  );
  const [newSlotDay, setNewSlotDay] = useState('Mon');
  const [newSlotPeriod, setNewSlotPeriod] = useState(3);
  const [newSlotStartTime, setNewSlotStartTime] = useState('09:40');
  const [newSlotEndTime, setNewSlotEndTime] = useState('10:25');
  const [newSlotRoom, setNewSlotRoom] = useState('B2-04');
  const [assignError, setAssignError] = useState<string | null>(null);

  const canEdit = role === 'admin' || role === 'teacher';
  const isAdmin = role === 'admin';
  const lessonFields = getFieldsForEntity(state, 'lesson_plan', role);

  const openCreateDialog = () => {
    setEditingLessonId(null);
    setTeacherId(isAdmin ? state.teachers[0]?.id ?? activeTeacherId : activeTeacherId);
    setClassroomId(state.classrooms[0]?.id ?? '');
    setSubstrandId(state.substrands[0]?.id ?? '');
    setTimetableSlotId('');
    setTitle('');
    setScheduledDate('2026-11-26');
    setLessonsDelivered(0);
    setStatus('planned');
    setReflectionNote('');
    setCustomFields({});
    setError(null);
    setShowLessonDialog(true);
  };

  useEffect(() => {
    if (!initialPrefill) return;
    setEditingLessonId(null);
    setClassroomId(initialPrefill.classroomId);
    setTeacherId(initialPrefill.teacherId || activeTeacherId);
    setTimetableSlotId(initialPrefill.timetableSlotId || '');
    const matchingSub = state.substrands.find((sub) => {
      const st = state.strands.find((s) => s.id === sub.strandId);
      const matchesClass = !st?.classroomId || st.classroomId === initialPrefill.classroomId;
      const matchesSubj = !initialPrefill.subjectId || sub.subjectId === initialPrefill.subjectId;
      return matchesClass && matchesSubj;
    });
    if (matchingSub) {
      setSubstrandId(matchingSub.id);
    }
    setTitle('');
    setScheduledDate(initialPrefill.scheduledDate || '2026-11-25');
    setLessonsDelivered(0);
    setStatus('planned');
    setReflectionNote('');
    setCustomFields({});
    setError(null);
    setShowLessonDialog(true);
    onClearPrefill?.();
  }, [initialPrefill, activeTeacherId, state.substrands, state.strands, onClearPrefill]);

  const openEditDialog = (lp: LessonPlanEntity) => {
    setEditingLessonId(lp.id);
    setTeacherId(lp.teacherId);
    setClassroomId(lp.classroomId);
    setSubstrandId(lp.substrandId);
    setTimetableSlotId(lp.timetableSlotId ?? '');
    setTitle(lp.title);
    setScheduledDate(lp.scheduledDate);
    setLessonsDelivered(lp.lessonsDelivered);
    setStatus(lp.status);
    setReflectionNote(lp.reflectionNote);
    setCustomFields({ ...(lp.customFields ?? {}) });
    setError(null);
    setShowLessonDialog(true);
  };

  const substrandsForClassroom = state.substrands.filter((sub) => {
    const strand = state.strands.find((st) => st.id === sub.strandId);
    return !strand?.classroomId || strand.classroomId === classroomId;
  });
  const selectableSubstrands =
    substrandsForClassroom.length > 0 ? substrandsForClassroom : state.substrands;
  const resolvedSubstrandId = selectableSubstrands.some((s) => s.id === substrandId)
    ? substrandId
    : (selectableSubstrands[0]?.id ?? '');

  const handleSaveLesson = (e: FormEvent) => {
    e.preventDefault();
    void runLockedAction('Saving lesson plan...', () => {
      const resolvedTeacher = isAdmin ? teacherId : activeTeacherId;
      const res = editingLessonId
        ? updateLessonPlan(
            state,
            editingLessonId,
            {
              teacherId: resolvedTeacher,
              classroomId,
              substrandId: resolvedSubstrandId,
              timetableSlotId: timetableSlotId || null,
              title,
              scheduledDate,
              lessonsDelivered,
              status,
              reflectionNote,
              customFields,
            },
            actor
          )
        : createLessonPlan(
            state,
            {
              teacherId: resolvedTeacher,
              classroomId,
              substrandId: resolvedSubstrandId,
              timetableSlotId: timetableSlotId || undefined,
              title,
              scheduledDate,
              lessonsDelivered,
              status,
              reflectionNote,
              customFields,
            },
            actor
          );

      if (res.error) {
        setError(res.error);
        showFeedback('error', res.error);
        return;
      }
      setError(null);
      setShowLessonDialog(false);
      onStateChange(res.state);
      showFeedback('success', 'Lesson plan saved');
    });
  };

  const openAssignToTimetable = (lp: LessonPlanEntity) => {
    const mappedDays = getScheduleDaysForClassroom(state, lp.classroomId);
    const defaultDay = mappedDays[0]?.code ?? state.scheduleDays[0]?.code ?? 'Mon';
    const cls = state.classrooms.find((c) => c.id === lp.classroomId);
    setAssigningLesson(lp);
    setAssignMode(state.timetableSlots.length > 0 ? 'existing' : 'new_slot');
    setSelectedSlotId(
      lp.timetableSlotId ??
        state.timetableSlots.find((s) => s.classroomId === lp.classroomId)?.id ??
        state.timetableSlots[0]?.id ??
        ''
    );
    setNewSlotClassroomId(lp.classroomId);
    setNewSlotTeacherId(lp.teacherId);
    setNewSlotDay(defaultDay);
    setNewSlotPeriod(3);
    setNewSlotStartTime('09:40');
    setNewSlotEndTime('10:25');
    setNewSlotRoom(cls?.roomCode ?? 'B2-04');
    setAssignError(null);
  };

  const handleAssignSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!assigningLesson) return;

    void runLockedAction('Assigning lesson to timetable...', () => {
      if (assignMode === 'existing') {
        const res = assignLessonToTimetableSlot(state, {
          lessonPlanId: assigningLesson.id,
          timetableSlotId: selectedSlotId || undefined,
          syncSlotSubjectAndTeacher: Boolean(selectedSlotId),
        });
        if (res.error) {
          setAssignError(res.error);
          showFeedback('error', res.error);
          return;
        }
        setAssignError(null);
        setAssigningLesson(null);
        onStateChange(res.state);
        showFeedback('info', 'Lesson assigned to timetable');
        return;
      }

      const res = upsertTimetableSlot(state, {
        classroomId: newSlotClassroomId,
        subjectId: assigningLesson.subjectId,
        teacherId: newSlotTeacherId,
        day: newSlotDay,
        period: newSlotPeriod,
        timeRange: `${newSlotStartTime} - ${newSlotEndTime}`,
        room: newSlotRoom,
        lessonPlanId: assigningLesson.id,
      });
      if (res.error) {
        setAssignError(res.error);
        showFeedback('error', res.error);
        return;
      }
      setAssignError(null);
      setAssigningLesson(null);
      onStateChange(res.state);
      showFeedback('info', 'Lesson assigned to timetable');
    });
  };

  const filteredPlans = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return state.lessonPlans.filter((lp) => {
      if (filterMode === 'unassigned' && lp.timetableSlotId) return false;
      if (filterClassroomId !== 'all' && lp.classroomId !== filterClassroomId) {
        return false;
      }
      if (filterSubjectId !== 'all' && lp.subjectId !== filterSubjectId) {
        return false;
      }
      if (filterStatus !== 'all' && lp.status !== filterStatus) {
        return false;
      }
      if (!q) return true;
      const teacher = state.teachers.find((t) => t.id === lp.teacherId);
      const substrand = state.substrands.find((s) => s.id === lp.substrandId);
      return (
        lp.title.toLowerCase().includes(q) ||
        lp.reflectionNote.toLowerCase().includes(q) ||
        (teacher?.name.toLowerCase().includes(q) ?? false) ||
        (substrand?.title.toLowerCase().includes(q) ?? false)
      );
    });
  }, [
    state.lessonPlans,
    state.teachers,
    state.substrands,
    filterMode,
    filterClassroomId,
    filterSubjectId,
    filterStatus,
    searchQuery,
  ]);

  const unassignedCount = state.lessonPlans.filter(
    (lp) => !lp.timetableSlotId
  ).length;
  const taughtCount = state.lessonPlans.filter((lp) => lp.status === 'taught').length;
  const hasActiveFilters =
    Boolean(searchQuery.trim()) ||
    filterMode !== 'all' ||
    filterClassroomId !== 'all' ||
    filterSubjectId !== 'all' ||
    filterStatus !== 'all';

  const newSlotMappedDays = assigningLesson
    ? getScheduleDaysForClassroom(state, newSlotClassroomId)
    : [];
  const availableDaysForNewSlot =
    newSlotMappedDays.length > 0 ? newSlotMappedDays : state.scheduleDays;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            Lessons Registry &amp; Syllabus Delivery
          </h2>
          <p className="mt-0.5 text-sm text-slate-600">
            Register curriculum lessons once, assign teachers and classrooms, and track delivery status ({taughtCount}/{state.lessonPlans.length} taught).
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex rounded-lg bg-slate-100 p-1">
            <button
              type="button"
              onClick={() => setFilterMode('all')}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                filterMode === 'all'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All ({state.lessonPlans.length})
            </button>
            <button
              type="button"
              onClick={() => setFilterMode('unassigned')}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                filterMode === 'unassigned'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Unassigned ({unassignedCount})
            </button>
          </div>

          {canEdit && (
            <button
              type="button"
              onClick={openCreateDialog}
              className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800 whitespace-nowrap shrink-0"
            >
              <Plus className="h-3.5 w-3.5" aria-hidden="true" />
              Register Lesson
            </button>
          )}
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-3.5">
        <div className="relative">
          <Search
            className="pointer-events-none absolute top-2.5 left-3 h-3.5 w-3.5 text-slate-400"
            aria-hidden="true"
          />
          <input
            type="search"
            aria-label="Search lessons"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search lesson title, substrand, or teacher..."
            className="w-64 rounded-lg border border-slate-300 bg-white py-1.5 pr-3 pl-8 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            aria-label="Filter lessons by classroom"
            value={filterClassroomId}
            onChange={(e) => setFilterClassroomId(e.target.value)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
          >
            <option value="all">All Classrooms</option>
            {state.classrooms.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          <select
            aria-label="Filter lessons by subject"
            value={filterSubjectId}
            onChange={(e) => setFilterSubjectId(e.target.value)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
          >
            <option value="all">All Subjects</option>
            {state.subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>

          <select
            aria-label="Filter lessons by status"
            value={filterStatus}
            onChange={(e) =>
              setFilterStatus(e.target.value as 'all' | LessonStatus)
            }
            className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
          >
            <option value="all">All Statuses</option>
            <option value="planned">Planned</option>
            <option value="in_progress">In Progress</option>
            <option value="taught">Taught</option>
          </select>
        </div>
      </div>

      {recentTaughtPrompt && onOpenHomeworkDialog && (
        <div
          role="region"
          aria-label="Follow-up homework prompt"
          className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs text-emerald-950"
        >
          <div>
            <span className="font-bold">Lesson marked taught:</span>{' '}
            <span>
              Add follow-up homework for{' '}
              <strong>
                {state.classrooms.find((c) => c.id === recentTaughtPrompt.classroomId)?.name ??
                  recentTaughtPrompt.classroomId}
              </strong>{' '}
              to the School Diary?
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                const target = recentTaughtPrompt;
                setRecentTaughtPrompt(null);
                onOpenHomeworkDialog({
                  classroomId: target.classroomId,
                  date: '2026-11-25',
                  homeworkSummary: `Practice exercises from "${target.title}"`,
                  teacherNote: `Completed lesson: ${target.title}`,
                });
              }}
              className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800 whitespace-nowrap"
            >
              <BookOpen className="h-3.5 w-3.5" aria-hidden="true" />
              Add Homework to Diary
            </button>
            <button
              type="button"
              onClick={() => setRecentTaughtPrompt(null)}
              className="rounded-lg border border-emerald-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-emerald-900 hover:bg-emerald-100"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Create / Edit Registered Lesson Dialog */}
      <AppDialog
        open={showLessonDialog}
        busy={isBusy}
        title={editingLessonId ? 'Edit Registered Lesson' : 'Register New Lesson'}
        subtitle="Bind a Schemes Substrand, assign a Teacher & Classroom, and optionally attach a Timetable slot."
        onClose={() => setShowLessonDialog(false)}
      >
        <form onSubmit={handleSaveLesson} className="space-y-4">
          <fieldset disabled={isBusy} className="space-y-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div>
              <label
                htmlFor="lp-class"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Classroom (Scopes Schemes)
              </label>
              <select
                id="lp-class"
                value={classroomId}
                onChange={(e) => {
                  const nextCls = e.target.value;
                  setClassroomId(nextCls);
                  const matchingSubs = state.substrands.filter((sub) => {
                    const st = state.strands.find((s) => s.id === sub.strandId);
                    return st?.classroomId === nextCls;
                  });
                  if (
                    matchingSubs.length > 0 &&
                    !matchingSubs.some((s) => s.id === substrandId)
                  ) {
                    setSubstrandId(matchingSubs[0].id);
                  }
                }}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              >
                {state.classrooms.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            {isAdmin && (
              <div>
                <label
                  htmlFor="lp-teacher"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Assigned Teacher
                </label>
                <select
                  id="lp-teacher"
                  value={teacherId}
                  onChange={(e) => setTeacherId(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                >
                  {state.teachers.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>
            )}
            <div>
              <label
                htmlFor="lp-slot"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Timetable Slot
              </label>
              <select
                id="lp-slot"
                value={timetableSlotId}
                onChange={(e) => setTimetableSlotId(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              >
                <option value="">Unassigned (Hold in Registry)</option>
                {state.timetableSlots.map((slot) => {
                  const subj = state.subjects.find((s) => s.id === slot.subjectId);
                  const cls = state.classrooms.find(
                    (c) => c.id === slot.classroomId
                  );
                  return (
                    <option key={slot.id} value={slot.id}>
                      {cls?.name.split(' ')[1] ?? slot.classroomId} · {slot.day}{' '}
                      P{slot.period} ({slot.timeRange}) · {subj?.code}
                    </option>
                  );
                })}
              </select>
            </div>
          </div>

          <div>
            <label
              htmlFor="lp-substrand"
              className="mb-1 inline-flex items-center gap-1.5 text-xs font-medium text-slate-700"
            >
              <span>Class Scheme Substrand (Linked)</span>
              <span
                title="A Substrand is a specific teachable topic inside a subject Strand with a target number of lessons."
                className="inline-flex items-center text-slate-400"
              >
                <HelpCircle className="h-3.5 w-3.5" aria-hidden="true" />
              </span>
            </label>
            <select
              id="lp-substrand"
              value={resolvedSubstrandId}
              onChange={(e) => setSubstrandId(e.target.value)}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
            >
              {selectableSubstrands.map((sub) => {
                const subj = state.subjects.find((s) => s.id === sub.subjectId);
                const st = state.strands.find((s) => s.id === sub.strandId);
                return (
                  <option key={sub.id} value={sub.id}>
                    {subj?.code} · {st?.code} → {sub.code} — {sub.title}
                  </option>
                );
              })}
            </select>
          </div>

          <div>
            <label
              htmlFor="lp-title"
              className="mb-1 block text-xs font-medium text-slate-700"
            >
              Lesson Focus Title *
            </label>
            <input
              id="lp-title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Polyhedra Net Folding"
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label
                htmlFor="lp-date"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Date
              </label>
              <input
                id="lp-date"
                type="date"
                value={scheduledDate}
                onChange={(e) => setScheduledDate(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-xs focus:border-blue-700 focus:outline-none"
              />
            </div>
            <div>
              <label
                htmlFor="lp-status"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Status
              </label>
              <select
                id="lp-status"
                value={status}
                onChange={(e) => setStatus(e.target.value as LessonStatus)}
                className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-xs focus:border-blue-700 focus:outline-none"
              >
                <option value="planned">Planned</option>
                <option value="in_progress">In Progress</option>
                <option value="taught">Taught</option>
              </select>
            </div>
            <div>
              <label
                htmlFor="lp-count"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Periods Taught
              </label>
              <input
                id="lp-count"
                type="number"
                min={0}
                max={10}
                value={lessonsDelivered}
                onChange={(e) => setLessonsDelivered(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-xs tabular-nums focus:border-blue-700 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="lp-reflection"
              className="mb-1 block text-xs font-medium text-slate-700"
            >
              Teaching Reflection
            </label>
            <input
              id="lp-reflection"
              type="text"
              value={reflectionNote}
              onChange={(e) => setReflectionNote(e.target.value)}
              placeholder="Notes on pacing or learner misconceptions..."
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
            />
          </div>

          <DynamicFieldInputs
            fields={lessonFields}
            values={customFields}
            role={role}
            onChange={(key, value) =>
              setCustomFields((prev) => ({ ...prev, [key]: value }))
            }
          />

          {error && <p className="text-xs font-medium text-red-600">{error}</p>}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setShowLessonDialog(false)}
              className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <ActionSubmitButton
              idleLabel={editingLessonId ? 'Update Lesson' : 'Save Lesson Plan'}
              busyLabel="Saving..."
              className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
            />
          </div>
          </fieldset>
        </form>
      </AppDialog>

      {/* Assign Registered Lesson to Timetable Dialog */}
      <AppDialog
        open={Boolean(assigningLesson)}
        busy={isBusy}
        title={`Assign "${assigningLesson?.title ?? ''}" to Timetable`}
        subtitle="Bind to an existing Timetable period or schedule a new day, teacher, time, and room slot."
        onClose={() => setAssigningLesson(null)}
      >
        {assigningLesson && (
          <form onSubmit={handleAssignSubmit} className="space-y-4">
            <fieldset disabled={isBusy} className="space-y-4">
            <div className="inline-flex rounded-lg bg-slate-100 p-1">
              <button
                type="button"
                onClick={() => {
                  setAssignMode('existing');
                  setAssignError(null);
                }}
                className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors ${
                  assignMode === 'existing'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Use Existing Timetable Slot
              </button>
              <button
                type="button"
                onClick={() => {
                  setAssignMode('new_slot');
                  setAssignError(null);
                }}
                className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors ${
                  assignMode === 'new_slot'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Create New Slot &amp; Bind
              </button>
            </div>

            {assignMode === 'existing' ? (
              <div>
                <label
                  htmlFor="assign-existing-slot"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Select Timetable Slot
                </label>
                <select
                  id="assign-existing-slot"
                  value={selectedSlotId}
                  onChange={(e) => setSelectedSlotId(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                >
                  <option value="">Unassign from Timetable</option>
                  {state.timetableSlots.map((slot) => {
                    const cls = state.classrooms.find(
                      (c) => c.id === slot.classroomId
                    );
                    const subj = state.subjects.find(
                      (s) => s.id === slot.subjectId
                    );
                    const tch = state.teachers.find(
                      (t) => t.id === slot.teacherId
                    );
                    return (
                      <option key={slot.id} value={slot.id}>
                        {cls?.name} · {slot.day} P{slot.period} ({slot.timeRange}
                        ) · {subj?.code} · {tch?.name}
                      </option>
                    );
                  })}
                </select>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div>
                    <label
                      htmlFor="assign-cls"
                      className="mb-1 block text-xs font-medium text-slate-700"
                    >
                      Classroom (Class Comes On)
                    </label>
                    <select
                      id="assign-cls"
                      value={newSlotClassroomId}
                      onChange={(e) => {
                        const nextClsId = e.target.value;
                        setNewSlotClassroomId(nextClsId);
                        const cls = state.classrooms.find(
                          (c) => c.id === nextClsId
                        );
                        if (cls) setNewSlotRoom(cls.roomCode);
                        const days = getScheduleDaysForClassroom(
                          state,
                          nextClsId
                        );
                        if (days.length > 0) setNewSlotDay(days[0].code);
                      }}
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                    >
                      {state.classrooms.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label
                      htmlFor="assign-tch"
                      className="mb-1 block text-xs font-medium text-slate-700"
                    >
                      Assigned Teacher
                    </label>
                    <select
                      id="assign-tch"
                      value={newSlotTeacherId}
                      onChange={(e) => setNewSlotTeacherId(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                    >
                      {state.teachers.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-4">
                  <div>
                    <label
                      htmlFor="assign-day"
                      className="mb-1 block text-xs font-medium text-slate-700"
                    >
                      Mapped Day
                    </label>
                    <select
                      id="assign-day"
                      value={newSlotDay}
                      onChange={(e) => setNewSlotDay(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-sm focus:border-blue-700 focus:outline-none"
                    >
                      {availableDaysForNewSlot.map((d) => (
                        <option key={d.id} value={d.code}>
                          {d.code} — {d.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label
                      htmlFor="assign-period"
                      className="mb-1 block text-xs font-medium text-slate-700"
                    >
                      Period #
                    </label>
                    <input
                      id="assign-period"
                      type="number"
                      min={1}
                      max={12}
                      value={newSlotPeriod}
                      onChange={(e) => setNewSlotPeriod(Number(e.target.value))}
                      className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-sm tabular-nums focus:border-blue-700 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="assign-start"
                      className="mb-1 block text-xs font-medium text-slate-700"
                    >
                      Start Time
                    </label>
                    <input
                      id="assign-start"
                      type="time"
                      value={newSlotStartTime}
                      onChange={(e) => setNewSlotStartTime(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-sm focus:border-blue-700 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="assign-end"
                      className="mb-1 block text-xs font-medium text-slate-700"
                    >
                      End Time
                    </label>
                    <input
                      id="assign-end"
                      type="time"
                      value={newSlotEndTime}
                      onChange={(e) => setNewSlotEndTime(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-sm focus:border-blue-700 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="assign-room"
                    className="mb-1 block text-xs font-medium text-slate-700"
                  >
                    Room
                  </label>
                  <input
                    id="assign-room"
                    type="text"
                    value={newSlotRoom}
                    onChange={(e) => setNewSlotRoom(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                  />
                </div>
              </div>
            )}

            {assignError && (
              <p className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs font-medium text-red-700">
                {assignError}
              </p>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setAssigningLesson(null)}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </button>
              <ActionSubmitButton
                idleLabel="Save Timetable Assignment"
                busyLabel="Assigning..."
                className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
              />
            </div>
            </fieldset>
          </form>
        )}
      </AppDialog>

      {filteredPlans.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-8 text-center">
          <p className="text-sm font-medium text-slate-800">
            {state.lessonPlans.length === 0
              ? 'No lesson plans created yet. Register a lesson or create one directly from a Timetable period.'
              : 'No registered lessons match this filter.'}
          </p>
          <div className="mt-3 flex flex-wrap justify-center gap-2">
            {hasActiveFilters && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setFilterMode('all');
                  setFilterClassroomId('all');
                  setFilterSubjectId('all');
                  setFilterStatus('all');
                }}
                className="rounded-lg border border-slate-300 bg-white px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Clear Filters
              </button>
            )}
            {canEdit && (
              <button
                type="button"
                onClick={openCreateDialog}
                className="rounded-lg bg-blue-700 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-blue-800"
              >
                Register First Lesson
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {filteredPlans.map((lp) => {
            const subject = state.subjects.find((s) => s.id === lp.subjectId);
            const strand = state.strands.find((st) => st.id === lp.strandId);
            const substrand = state.substrands.find(
              (sub) => sub.id === lp.substrandId
            );
            const teacher = state.teachers.find((t) => t.id === lp.teacherId);
            const classroom = state.classrooms.find(
              (c) => c.id === lp.classroomId
            );
            const slot = state.timetableSlots.find(
              (sl) => sl.id === lp.timetableSlotId
            );

            const statusColor =
              lp.status === 'taught'
                ? 'text-emerald-700'
                : lp.status === 'in_progress'
                  ? 'text-amber-700'
                  : 'text-slate-600';
            const statusDot =
              lp.status === 'taught'
                ? 'bg-emerald-600'
                : lp.status === 'in_progress'
                  ? 'bg-amber-600'
                  : 'bg-slate-400';

            return (
              <article
                key={lp.id}
                className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5"
              >
                <div>
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs text-slate-500">
                        <span className="font-mono tabular-nums">
                          {lp.scheduledDate}
                        </span>{' '}
                        · {classroom?.name ?? lp.classroomId} · {subject?.name} ·{' '}
                        {strand?.code} &rarr; {substrand?.code} {substrand?.title}
                      </p>
                      <h3 className="mt-1 font-display text-base font-bold text-slate-900">
                        {lp.title}
                      </h3>
                      <p className="mt-1 text-xs font-medium text-blue-700">
                        {slot
                          ? `Scheduled: ${slot.day} P${slot.period} (${slot.timeRange}) · Room ${slot.room}`
                          : 'Unassigned — ready for Timetable'}
                      </p>
                    </div>

                    <div className="text-right">
                      <span
                        className={`inline-flex items-center gap-1.5 text-xs font-semibold ${statusColor}`}
                      >
                        <span className={`h-2 w-2 rounded-full ${statusDot}`} />
                        {lp.status === 'taught'
                          ? 'Taught'
                          : lp.status === 'in_progress'
                            ? 'In Progress'
                            : 'Planned'}
                      </span>
                      <p className="font-mono text-xs text-slate-600 tabular-nums">
                        {lp.lessonsDelivered} / {substrand?.targetLessons ?? 1}{' '}
                        lessons
                      </p>
                    </div>
                  </div>

                  {lp.reflectionNote && (
                    <p className="mt-2.5 text-xs leading-relaxed text-slate-600">
                      {lp.reflectionNote}
                    </p>
                  )}

                  <DynamicFieldReadout
                    fields={lessonFields}
                    values={lp.customFields ?? {}}
                    role={role}
                  />
                </div>

                <div className="mt-4 space-y-2.5 border-t border-slate-100 pt-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-col gap-0.5">
                      <span className="text-xs text-slate-500">
                        Assigned: {teacher?.name}
                      </span>
                      <AuditAttributionLine
                        who={
                          state.teachers.find((t) => t.id === lp.taughtByTeacherId)
                            ?.name ?? lp.updatedBy
                        }
                        when={lp.taughtAt ?? lp.updatedAt}
                        prefix={lp.taughtAt ? 'Taught by' : 'Updated by'}
                      />
                    </div>

                    {canEdit && (
                      <div className="flex flex-wrap items-center gap-1.5">
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() =>
                            void runLockedAction('Duplicating lesson plan...', () => {
                              const res = duplicateLessonPlan(
                                state,
                                lp.id,
                                { scheduledDate: '2026-12-01' },
                                actor
                              );
                              if (res.error) {
                                showFeedback('error', res.error);
                                return;
                              }
                              onStateChange(res.state);
                              showFeedback('success', 'Lesson plan duplicated');
                            })
                          }
                          aria-label={`Duplicate ${lp.title}`}
                          className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white px-2 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 whitespace-nowrap shrink-0 disabled:opacity-50"
                        >
                          <Copy className="h-3 w-3" aria-hidden="true" />
                          Duplicate
                        </button>
                        {isAdmin && (
                          <>
                            <button
                              type="button"
                              onClick={() => openAssignToTimetable(lp)}
                              className="inline-flex items-center gap-1 rounded-md border border-blue-200 bg-blue-50 px-2.5 py-1 text-xs font-semibold text-blue-700 hover:bg-blue-100 whitespace-nowrap shrink-0"
                            >
                              <CalendarPlus
                                className="h-3 w-3"
                                aria-hidden="true"
                              />
                              {slot ? 'Reassign Slot' : 'Assign to Timetable'}
                            </button>
                            <button
                              type="button"
                              onClick={() => openEditDialog(lp)}
                              aria-label={`Edit ${lp.title}`}
                              className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white px-2 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 whitespace-nowrap shrink-0"
                            >
                              <Pencil className="h-3 w-3" aria-hidden="true" />
                              Edit
                            </button>
                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() =>
                                void runLockedAction('Removing lesson plan...', () => {
                                  onStateChange(deleteLessonPlan(state, lp.id, actor));
                                  showFeedback('warning', 'Lesson plan removed');
                                })
                              }
                              aria-label={`Delete ${lp.title}`}
                              className="inline-flex items-center rounded-md border border-red-200 bg-white px-2 py-1 text-xs font-medium text-red-600 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50 whitespace-nowrap shrink-0"
                            >
                              <Trash2 className="h-3 w-3" aria-hidden="true" />
                            </button>
                          </>
                        )}
                      </div>
                    )}
                  </div>

                  {canEdit && (
                    <div className="flex items-center justify-between gap-2 rounded-lg bg-slate-50 px-2.5 py-1.5">
                      <span className="text-[11px] font-medium text-slate-500">
                        Delivery Progress
                      </span>
                      <div className="inline-flex items-center gap-1">
                        {(
                          ['planned', 'in_progress', 'taught'] as LessonStatus[]
                        ).map((nextStatus) => (
                          <button
                            key={nextStatus}
                            type="button"
                            disabled={isBusy}
                            onClick={() =>
                              void runLockedAction('Updating lesson status...', () => {
                                onStateChange(
                                  updateLessonStatus(
                                    state,
                                    lp.id,
                                    nextStatus,
                                    nextStatus === 'taught'
                                      ? Math.max(2, lp.lessonsDelivered)
                                      : nextStatus === 'in_progress'
                                        ? Math.max(1, lp.lessonsDelivered)
                                        : 0,
                                    activeTeacherId,
                                    actor
                                  )
                                );
                                if (nextStatus === 'taught') {
                                  setRecentTaughtPrompt(lp);
                                }
                                showFeedback(
                                  nextStatus === 'taught' ? 'success' : 'info',
                                  `Lesson marked ${nextStatus.replace('_', ' ')}`
                                );
                              })
                            }
                            className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 disabled:cursor-not-allowed disabled:opacity-60 ${
                              lp.status === nextStatus
                                ? 'bg-slate-900 text-white'
                                : 'bg-white text-slate-700 hover:bg-slate-200'
                            }`}
                          >
                            {nextStatus === 'taught'
                              ? 'Mark Taught'
                              : nextStatus === 'in_progress'
                                ? 'In Progress'
                                : 'Planned'}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
