import { HelpCircle, Pencil, Plus } from 'lucide-react';
import { useMemo, useState, type FormEvent } from 'react';
import {
  computeSubstrandCoverage,
  getFieldsForEntity,
  registerSchemeStrand,
  registerSchemeSubstrand,
  updateSchemeStrand,
  updateSchemeSubstrand,
} from '../../ecs/engine';
import type {
  AuditActor,
  Role,
  SchoolECSState,
  SchemeStrandEntity,
  SchemeSubstrandEntity,
} from '../../ecs/types';
import { ActionSubmitButton, useActionFeedback } from '../ActionFeedback';
import { AppDialog } from '../AppDialog';
import { DynamicFieldInputs } from '../DynamicFieldsRenderer';

interface SchemesModuleProps {
  state: SchoolECSState;
  role: Role;
  activeTeacherId: string;
  actor?: AuditActor;
  onStateChange: (next: SchoolECSState) => void;
}

export function SchemesModule({
  state,
  role,
  activeTeacherId,
  actor,
  onStateChange,
}: SchemesModuleProps) {
  const { isBusy, runLockedAction, showFeedback } = useActionFeedback();
  const [selectedClassroomFilter, setSelectedClassroomFilter] = useState<string>('all');
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState<string>('all');
  const [showStrandDialog, setShowStrandDialog] = useState(false);
  const [editingStrandId, setEditingStrandId] = useState<string | null>(null);
  const [showSubstrandDialog, setShowSubstrandDialog] = useState(false);
  const [editingSubstrandId, setEditingSubstrandId] = useState<string | null>(null);

  const [strandClassroomId, setStrandClassroomId] = useState(
    state.classrooms[0]?.id ?? 'cls_5a'
  );
  const [selectedSubjectId, setSelectedSubjectId] = useState(
    state.subjects[0]?.id ?? ''
  );
  const [strandCode, setStrandCode] = useState('');
  const [strandTitle, setStrandTitle] = useState('');
  const [strandTerm, setStrandTerm] = useState('Term 1');
  const [strandError, setStrandError] = useState<string | null>(null);

  const [targetStrandId, setTargetStrandId] = useState(
    state.strands[0]?.id ?? ''
  );
  const [subCode, setSubCode] = useState('');
  const [subTitle, setSubTitle] = useState('');
  const [subOutcome, setSubOutcome] = useState('');
  const [targetLessons, setTargetLessons] = useState(4);
  const [subCustomFields, setSubCustomFields] = useState<
    Record<string, string | number | boolean>
  >({});
  const [subError, setSubError] = useState<string | null>(null);

  const canEdit = role === 'admin' || role === 'teacher';
  const substrandFields = getFieldsForEntity(state, 'scheme_substrand', role);
  const coverageBySubstrandId = useMemo(() => {
    const reports = computeSubstrandCoverage(state);
    return new Map(reports.map((r) => [r.substrand.id, r]));
  }, [state]);

  const visibleClassrooms = useMemo(() => {
    if (selectedClassroomFilter === 'all') return state.classrooms;
    return state.classrooms.filter((c) => c.id === selectedClassroomFilter);
  }, [state.classrooms, selectedClassroomFilter]);

  const strandsForSubstrandPicker = useMemo(() => {
    if (selectedClassroomFilter === 'all') return state.strands;
    const filtered = state.strands.filter(
      (st) => st.classroomId === selectedClassroomFilter
    );
    return filtered.length > 0 ? filtered : state.strands;
  }, [state.strands, selectedClassroomFilter]);

  const openStrandDialogForClass = (classId?: string) => {
    setEditingStrandId(null);
    setStrandClassroomId(
      classId ??
        (selectedClassroomFilter !== 'all'
          ? selectedClassroomFilter
          : state.classrooms[0]?.id ?? 'cls_5a')
    );
    setSelectedSubjectId(
      selectedSubjectFilter !== 'all'
        ? selectedSubjectFilter
        : state.subjects[0]?.id ?? ''
    );
    setStrandCode('');
    setStrandTitle('');
    setStrandTerm('Term 1');
    setStrandError(null);
    setShowStrandDialog(true);
  };

  const openEditStrandDialog = (strand: SchemeStrandEntity) => {
    setEditingStrandId(strand.id);
    setStrandClassroomId(strand.classroomId);
    setSelectedSubjectId(strand.subjectId);
    setStrandCode(strand.code);
    setStrandTitle(strand.title);
    setStrandTerm(strand.term);
    setStrandError(null);
    setShowStrandDialog(true);
  };

  const openSubstrandDialogForStrand = (strandId?: string) => {
    const defaultStrand =
      strandId ??
      (selectedClassroomFilter !== 'all'
        ? state.strands.find((st) => st.classroomId === selectedClassroomFilter)?.id
        : undefined) ??
      state.strands[0]?.id ??
      '';
    setEditingSubstrandId(null);
    setTargetStrandId(defaultStrand);
    setSubCode('');
    setSubTitle('');
    setSubOutcome('');
    setTargetLessons(4);
    setSubCustomFields({});
    setSubError(null);
    setShowSubstrandDialog(true);
  };

  const openEditSubstrandDialog = (sub: SchemeSubstrandEntity) => {
    setEditingSubstrandId(sub.id);
    setTargetStrandId(sub.strandId);
    setSubCode(sub.code);
    setSubTitle(sub.title);
    setSubOutcome(sub.learningOutcome);
    setTargetLessons(sub.targetLessons);
    setSubCustomFields({ ...(sub.customFields ?? {}) });
    setSubError(null);
    setShowSubstrandDialog(true);
  };

  const handleSaveStrand = (e: FormEvent) => {
    e.preventDefault();
    void runLockedAction('Saving scheme strand...', () => {
      const res = editingStrandId
        ? updateSchemeStrand(
            state,
            editingStrandId,
            {
              classroomId: strandClassroomId,
              subjectId: selectedSubjectId,
              code: strandCode,
              title: strandTitle,
              term: strandTerm,
            },
            actor
          )
        : registerSchemeStrand(
            state,
            {
              classroomId: strandClassroomId,
              subjectId: selectedSubjectId,
              code: strandCode,
              title: strandTitle,
              term: strandTerm,
              createdByTeacherId: activeTeacherId,
            },
            actor
          );
      if (res.error) {
        setStrandError(res.error);
        showFeedback('error', res.error);
        return;
      }
      setStrandError(null);
      setEditingStrandId(null);
      setStrandCode('');
      setStrandTitle('');
      if (res.strand) {
        setTargetStrandId(res.strand.id);
      }
      onStateChange(res.state);
      setShowStrandDialog(false);
      showFeedback('success', 'Scheme strand saved');
    });
  };

  const handleSaveSubstrand = (e: FormEvent) => {
    e.preventDefault();
    void runLockedAction('Saving scheme substrand...', () => {
      const res = editingSubstrandId
        ? updateSchemeSubstrand(
            state,
            editingSubstrandId,
            {
              code: subCode,
              title: subTitle,
              learningOutcome: subOutcome,
              targetLessons,
            },
            actor
          )
        : registerSchemeSubstrand(
            state,
            {
              strandId: targetStrandId,
              code: subCode,
              title: subTitle,
              learningOutcome: subOutcome,
              targetLessons,
              customFields: subCustomFields,
            },
            actor
          );
      if (res.error) {
        setSubError(res.error);
        showFeedback('error', res.error);
        return;
      }
      setSubError(null);
      setEditingSubstrandId(null);
      setSubCode('');
      setSubTitle('');
      setSubOutcome('');
      setTargetLessons(4);
      setSubCustomFields({});
      onStateChange(res.state);
      setShowSubstrandDialog(false);
      showFeedback('success', 'Scheme substrand saved');
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            Schemes of Work
          </h2>
          <p className="mt-0.5 text-sm text-slate-600">
            Organize curriculum{' '}
            <span
              title="A Strand is a major subject unit (for example, Numbers or Geometry)."
              className="inline-flex items-center gap-0.5 font-medium text-slate-800 underline decoration-dotted"
            >
              Strands
              <HelpCircle className="h-3 w-3 text-slate-400" aria-hidden="true" />
            </span>{' '}
            and{' '}
            <span
              title="A Substrand is a specific teachable topic inside a strand with a target number of lessons."
              className="inline-flex items-center gap-0.5 font-medium text-slate-800 underline decoration-dotted"
            >
              Substrands
              <HelpCircle className="h-3 w-3 text-slate-400" aria-hidden="true" />
            </span>{' '}
            per classroom so Assessments and Lesson Plans stay aligned.
          </p>
        </div>

        {canEdit && (
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => openStrandDialogForClass()}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap shrink-0"
            >
              <Plus className="h-3.5 w-3.5" aria-hidden="true" />
              Register Class Strand
            </button>
            <button
              type="button"
              onClick={() => openSubstrandDialogForStrand()}
              className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800 whitespace-nowrap shrink-0"
            >
              <Plus className="h-3.5 w-3.5" aria-hidden="true" />
              Add Substrand
            </button>
          </div>
        )}
      </div>

      {/* Classroom & Subject Filters */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-3.5">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => setSelectedClassroomFilter('all')}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              selectedClassroomFilter === 'all'
                ? 'bg-blue-700 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            All Classes ({state.strands.length} strands)
          </button>
          {state.classrooms.map((cls) => {
            const count = state.strands.filter(
              (st) => st.classroomId === cls.id
            ).length;
            return (
              <button
                key={cls.id}
                type="button"
                onClick={() => setSelectedClassroomFilter(cls.id)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  selectedClassroomFilter === cls.id
                    ? 'bg-blue-700 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {cls.name} ({count})
              </button>
            );
          })}
        </div>

        <select
          aria-label="Filter schemes by subject"
          value={selectedSubjectFilter}
          onChange={(e) => setSelectedSubjectFilter(e.target.value)}
          className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
        >
          <option value="all">All Subjects</option>
          {state.subjects.map((subj) => (
            <option key={subj.id} value={subj.id}>
              {subj.name} ({subj.code})
            </option>
          ))}
        </select>
      </div>

      {/* Register / Edit Strand Dialog */}
      <AppDialog
        open={showStrandDialog}
        busy={isBusy}
        title={
          editingStrandId
            ? 'Edit Class Curriculum Strand'
            : 'Register Class-Scoped Curriculum Strand'
        }
        subtitle="Strands belong to a specific Classroom and are shared with Assessment Books and Lesson Plans for that class."
        onClose={() => {
          setShowStrandDialog(false);
          setEditingStrandId(null);
        }}
      >
        <form onSubmit={handleSaveStrand} className="space-y-4">
          <fieldset disabled={isBusy} className="space-y-4">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="scheme-classroom"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Target Classroom *
                </label>
                <select
                  id="scheme-classroom"
                  value={strandClassroomId}
                  onChange={(e) => setStrandClassroomId(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                >
                  {state.classrooms.map((cls) => (
                    <option key={cls.id} value={cls.id}>
                      {cls.name} ({cls.gradeLevel})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label
                  htmlFor="scheme-subject"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Subject
                </label>
                <select
                  id="scheme-subject"
                  value={selectedSubjectId}
                  onChange={(e) => setSelectedSubjectId(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                >
                  {state.subjects.map((sub) => (
                    <option key={sub.id} value={sub.id}>
                      {sub.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="strand-code"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Strand Code *
                </label>
                <input
                  id="strand-code"
                  type="text"
                  value={strandCode}
                  onChange={(e) => setStrandCode(e.target.value)}
                  placeholder="STR-M3"
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                />
              </div>
              <div>
                <label
                  htmlFor="strand-term"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Term
                </label>
                <select
                  id="strand-term"
                  value={strandTerm}
                  onChange={(e) => setStrandTerm(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                >
                  <option value="Term 1">Term 1</option>
                  <option value="Term 2">Term 2</option>
                  <option value="Term 3">Term 3</option>
                </select>
              </div>
            </div>

            <div>
              <label
                htmlFor="strand-title"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Strand Title *
              </label>
              <input
                id="strand-title"
                type="text"
                value={strandTitle}
                onChange={(e) => setStrandTitle(e.target.value)}
                placeholder="e.g. Geometry & Polyhedra"
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>

            {strandError && (
              <p className="text-xs font-medium text-red-600">{strandError}</p>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowStrandDialog(false);
                  setEditingStrandId(null);
                }}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </button>
              <ActionSubmitButton
                idleLabel={editingStrandId ? 'Save Strand Changes' : 'Register Strand'}
                busyLabel="Saving..."
                className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800"
              />
            </div>
          </fieldset>
        </form>
      </AppDialog>

      {/* Add / Edit Substrand Dialog */}
      <AppDialog
        open={showSubstrandDialog}
        busy={isBusy}
        title={
          editingSubstrandId
            ? 'Edit Scheme Substrand'
            : 'Add Substrand Under Class Strand'
        }
        subtitle="Assessment Books and Lesson Plans pull this Substrand directly by classroom and strand reference."
        onClose={() => {
          setShowSubstrandDialog(false);
          setEditingSubstrandId(null);
        }}
      >
        <form onSubmit={handleSaveSubstrand} className="space-y-4">
          <fieldset disabled={isBusy} className="space-y-4">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div className="sm:col-span-2">
                <label
                  htmlFor="parent-strand"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Parent Strand
                </label>
                <select
                  id="parent-strand"
                  disabled={Boolean(editingSubstrandId)}
                  value={targetStrandId}
                  onChange={(e) => setTargetStrandId(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm disabled:bg-slate-100 focus:border-blue-700 focus:outline-none"
                >
                  {strandsForSubstrandPicker.map((st) => {
                    const subj = state.subjects.find((s) => s.id === st.subjectId);
                    const cls = state.classrooms.find((c) => c.id === st.classroomId);
                    return (
                      <option key={st.id} value={st.id}>
                        [{cls?.gradeLevel ?? st.classroomId}] {subj?.code} · {st.code} — {st.title}
                      </option>
                    );
                  })}
                </select>
              </div>
              <div>
                <label
                  htmlFor="sub-code"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Substrand Code *
                </label>
                <input
                  id="sub-code"
                  type="text"
                  value={subCode}
                  onChange={(e) => setSubCode(e.target.value)}
                  placeholder="3.1"
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-4">
              <div className="sm:col-span-3">
                <label
                  htmlFor="sub-title"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Substrand Title *
                </label>
                <input
                  id="sub-title"
                  type="text"
                  value={subTitle}
                  onChange={(e) => setSubTitle(e.target.value)}
                  placeholder="e.g. 3D Solid Nets"
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                />
              </div>
              <div>
                <label
                  htmlFor="sub-lessons"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Target Lessons
                </label>
                <input
                  id="sub-lessons"
                  type="number"
                  min={1}
                  max={30}
                  value={targetLessons}
                  onChange={(e) => setTargetLessons(Number(e.target.value))}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm tabular-nums focus:border-blue-700 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="sub-outcome"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Learning Outcome
              </label>
              <input
                id="sub-outcome"
                type="text"
                value={subOutcome}
                onChange={(e) => setSubOutcome(e.target.value)}
                placeholder="Measurable competency learners demonstrate..."
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>

            {!editingSubstrandId && (
              <DynamicFieldInputs
                fields={substrandFields}
                values={subCustomFields}
                role={role}
                onChange={(key, value) =>
                  setSubCustomFields((prev) => ({ ...prev, [key]: value }))
                }
              />
            )}

            {subError && (
              <p className="text-xs font-medium text-red-600">{subError}</p>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowSubstrandDialog(false);
                  setEditingSubstrandId(null);
                }}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </button>
              <ActionSubmitButton
                idleLabel={
                  editingSubstrandId
                    ? 'Save Substrand Changes'
                    : 'Add Substrand to Scheme'
                }
                busyLabel="Saving..."
                className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
              />
            </div>
          </fieldset>
        </form>
      </AppDialog>

      {/* Classroom-Grouped Strands & Substrands Tree */}
      <div className="space-y-6">
        {visibleClassrooms.map((classroom) => {
          const classTeacher = classroom.classTeacherId
            ? state.teachers.find((t) => t.id === classroom.classTeacherId)
            : undefined;
          const classStrands = state.strands.filter(
            (st) =>
              st.classroomId === classroom.id &&
              (selectedSubjectFilter === 'all' ||
                st.subjectId === selectedSubjectFilter)
          );

          return (
            <div key={classroom.id} className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-slate-100/70 px-4 py-3">
                <div>
                  <h3 className="font-display text-sm font-bold text-slate-900">
                    {classroom.name}{' '}
                    <span className="font-mono text-xs font-normal text-slate-600">
                      · Room {classroom.roomCode}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-600">
                    Class Teacher:{' '}
                    <span className="font-semibold text-slate-800">
                      {classTeacher?.name ?? 'Unassigned'}
                    </span>{' '}
                    · <span className="tabular-nums">{classStrands.length}</span> strand
                    {classStrands.length === 1 ? '' : 's'}
                  </p>
                </div>
                {canEdit && (
                  <button
                    type="button"
                    onClick={() => openStrandDialogForClass(classroom.id)}
                    className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap shrink-0"
                  >
                    <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                    Add Strand for {classroom.gradeLevel}
                  </button>
                )}
              </div>

              {classStrands.length === 0 ? (
                <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-5 text-xs text-slate-500">
                  <span>
                    No curriculum strands registered for {classroom.name} under this filter yet.
                  </span>
                  {canEdit && (
                    <button
                      type="button"
                      onClick={() => openStrandDialogForClass(classroom.id)}
                      className="rounded-lg bg-blue-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-800"
                    >
                      + Add First Strand
                    </button>
                  )}
                </div>
              ) : (
                classStrands.map((strand) => {
                  const subject = state.subjects.find(
                    (s) => s.id === strand.subjectId
                  );
                  const creator = state.teachers.find(
                    (t) => t.id === strand.createdByTeacherId
                  );
                  const childSubstrands = state.substrands.filter(
                    (sub) => sub.strandId === strand.id
                  );

                  return (
                    <section
                      key={strand.id}
                      className="rounded-xl border border-slate-200 bg-white p-5"
                    >
                      <div className="flex flex-wrap items-baseline justify-between gap-2 border-b border-slate-100 pb-3">
                        <div>
                          <p className="text-xs text-slate-500">
                            {subject?.name} ({subject?.code}) · {strand.term} ·{' '}
                            {creator ? `Created by ${creator.name}` : strand.id}
                          </p>
                          <h4 className="mt-1 font-display text-base font-bold text-slate-900">
                            {strand.code}: {strand.title}
                          </h4>
                        </div>
                        <div className="flex items-center gap-2.5">
                          <span className="font-mono text-xs text-slate-600 tabular-nums">
                            {childSubstrands.length} substrands
                          </span>
                          {canEdit && (
                            <>
                              <button
                                type="button"
                                aria-label={`Edit strand ${strand.title}`}
                                onClick={() => openEditStrandDialog(strand)}
                                className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white px-2 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50"
                              >
                                <Pencil className="h-3 w-3" aria-hidden="true" />
                                Edit
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  openSubstrandDialogForStrand(strand.id)
                                }
                                className="text-xs font-semibold text-blue-700 hover:text-blue-800 whitespace-nowrap"
                              >
                                + Add Substrand
                              </button>
                            </>
                          )}
                        </div>
                      </div>

                      {childSubstrands.length === 0 ? (
                        <p className="mt-3 text-xs text-slate-500">
                          No substrands registered under this strand yet.
                        </p>
                      ) : (
                        <div className="mt-3 overflow-x-auto">
                          <table className="w-full border-collapse text-left text-xs">
                            <thead>
                              <tr className="border-b border-slate-200 text-slate-500">
                                <th className="py-2 pr-4 font-semibold">Code</th>
                                <th className="py-2 pr-4 font-semibold">
                                  <span
                                    title="A teachable sub-topic inside this strand."
                                    className="inline-flex items-center gap-1"
                                  >
                                    Substrand
                                    <HelpCircle className="h-3 w-3 text-slate-400" aria-hidden="true" />
                                  </span>
                                </th>
                                <th className="py-2 pr-4 font-semibold">
                                  Learning Outcome
                                </th>
                                <th className="py-2 pr-4 font-semibold">
                                  Coverage
                                </th>
                                <th className="py-2 pr-4 text-right font-semibold">
                                  Target
                                </th>
                                <th className="py-2 pr-4 text-right font-semibold">
                                  Plans
                                </th>
                                <th className="py-2 pr-3 text-right font-semibold">
                                  Assessments
                                </th>
                                {canEdit && (
                                  <th className="py-2 text-right font-semibold">
                                    Edit
                                  </th>
                                )}
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                              {childSubstrands.map((sub) => {
                                const cov = coverageBySubstrandId.get(sub.id);
                                const covPct = cov?.coveragePercent ?? 0;
                                const planCount = state.lessonPlans.filter(
                                  (lp) =>
                                    lp.substrandId === sub.id &&
                                    lp.classroomId === classroom.id
                                ).length;
                                const assessCount = state.assessments.filter(
                                  (a) => a.substrandId === sub.id
                                ).length;
                                return (
                                  <tr key={sub.id} className="hover:bg-slate-50/70">
                                    <td className="py-2.5 pr-4 font-mono text-slate-700 tabular-nums">
                                      {sub.code}
                                    </td>
                                    <td className="py-2.5 pr-4 font-semibold text-slate-900">
                                      {sub.title}
                                    </td>
                                    <td className="py-2.5 pr-4 text-slate-600">
                                      {sub.learningOutcome || '—'}
                                    </td>
                                    <td className="py-2.5 pr-4 min-w-[120px]">
                                      <div className="flex items-center gap-2">
                                        <div className="h-1.5 w-16 overflow-hidden rounded-full bg-slate-100">
                                          <div
                                            className={`h-full ${
                                              covPct >= 75
                                                ? 'bg-emerald-600'
                                                : covPct > 0
                                                  ? 'bg-blue-700'
                                                  : 'bg-slate-300'
                                            }`}
                                            style={{ width: `${covPct}%` }}
                                          />
                                        </div>
                                        <span className="font-mono text-[11px] font-semibold text-slate-700 tabular-nums">
                                          {covPct}%
                                        </span>
                                      </div>
                                    </td>
                                    <td className="py-2.5 pr-4 text-right font-mono text-slate-800 tabular-nums">
                                      {sub.targetLessons}
                                    </td>
                                    <td className="py-2.5 pr-4 text-right font-mono text-blue-700 tabular-nums">
                                      {planCount}
                                    </td>
                                    <td className="py-2.5 pr-3 text-right font-mono text-emerald-700 tabular-nums">
                                      {assessCount}
                                    </td>
                                    {canEdit && (
                                      <td className="py-2.5 text-right">
                                        <button
                                          type="button"
                                          aria-label={`Edit substrand ${sub.title}`}
                                          onClick={() =>
                                            openEditSubstrandDialog(sub)
                                          }
                                          className="inline-flex items-center rounded border border-slate-200 bg-white p-1 text-slate-600 hover:bg-slate-100 hover:text-blue-700"
                                        >
                                          <Pencil
                                            className="h-3 w-3"
                                            aria-hidden="true"
                                          />
                                        </button>
                                      </td>
                                    )}
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </section>
                  );
                })
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
