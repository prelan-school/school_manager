import { useMemo, useState, type FormEvent } from 'react';
import {
  AlertCircle,
  ArrowRight,
  BookOpen,
  Calendar as CalendarIcon,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ClipboardCheck,
  Clock,
  Edit3,
  FileSpreadsheet,
  GitBranch,
  GraduationCap,
  LineChart,
  Pencil,
  Plus,
  RotateCcw,
  School,
  Settings2,
  Trash2,
  Users,
} from 'lucide-react';
import {
  clearSampleData,
  computeAdminAttentionItems,
  computeOnboardingChecklist,
  computeParentChildDigests,
  computeSubstrandCoverage,
  computeTeacherTodaySchedule,
  deleteSchoolEvent,
  getActiveAcademicTerm,
  getTeacherPendingLessonPlans,
  toggleDiaryAcknowledgment,
  updateLessonStatus,
  upsertSchoolEvent,
} from '../../ecs/engine';
import { INITIAL_ECS_STATE } from '../../ecs/initialData';
import type {
  AuditActor,
  Role,
  SchoolECSState,
  SchoolEventEntity,
  SchoolEventKind,
} from '../../ecs/types';
import { ActionSubmitButton, useActionFeedback } from '../ActionFeedback';
import { AdminAiBriefingCard } from '../AdminAiBriefingCard';
import { MasteryBreakdownDonut } from '../AnalyticsCharts';
import { AppDialog } from '../AppDialog';
import type { LessonPrefillDraft, SandboxModule } from '../SandboxWorkspace';

interface HomeDashboardModuleProps {
  state: SchoolECSState;
  role: Role;
  actor?: AuditActor;
  activeTeacherId?: string;
  activeLearnerId?: string;
  linkedLearnerIds?: string[];
  onNavigateModule: (module: SandboxModule) => void;
  onNavigateRegister?: (classroomId: string) => void;
  onCreateLessonFromSlot?: (draft: LessonPrefillDraft) => void;
  onOpenLearnerPage?: (learnerId: string) => void;
  onStateChange: (next: SchoolECSState) => void;
}

const EVENT_KIND_META: Record<
  SchoolEventKind,
  { label: string; badgeClass: string; dotClass: string }
> = {
  event: {
    label: 'School Event',
    badgeClass: 'bg-blue-100 text-blue-800 border-blue-200',
    dotClass: 'bg-blue-600',
  },
  holiday: {
    label: 'National Holiday / Assembly',
    badgeClass: 'bg-violet-100 text-violet-800 border-violet-200',
    dotClass: 'bg-violet-600',
  },
  exam: {
    label: 'Examination',
    badgeClass: 'bg-red-100 text-red-800 border-red-200',
    dotClass: 'bg-red-600',
  },
  meeting: {
    label: 'Staff Meeting',
    badgeClass: 'bg-amber-100 text-amber-800 border-amber-200',
    dotClass: 'bg-amber-600',
  },
  sports: {
    label: 'Sports & Athletics',
    badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    dotClass: 'bg-emerald-600',
  },
};

function formatDateYmd(year: number, monthIndex: number, day: number): string {
  return `${year}-${String(monthIndex + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

export function HomeDashboardModule({
  state,
  role,
  actor,
  activeTeacherId,
  activeLearnerId,
  linkedLearnerIds,
  onNavigateModule,
  onNavigateRegister,
  onCreateLessonFromSlot,
  onOpenLearnerPage,
  onStateChange,
}: HomeDashboardModuleProps) {
  const { isBusy, runLockedAction, showFeedback } = useActionFeedback();
  const isAdmin = role === 'admin';
  const isTeacher = role === 'teacher';
  const isParent = role === 'parent';
  const [cursorMonth, setCursorMonth] = useState(() => new Date(2026, 10, 1));
  const [selectedDate, setSelectedDate] = useState('2026-11-28');
  const todayYmd = '2026-11-25';
  const [teacherDayFilter, setTeacherDayFilter] = useState('Wed');
  const [checklistOpen, setChecklistOpen] = useState(false);
  const [confirmClearOpen, setConfirmClearOpen] = useState(false);

  const [eventDialogOpen, setEventDialogOpen] = useState(false);
  const [editingEventId, setEditingEventId] = useState<string | null>(null);
  const [eventDate, setEventDate] = useState('2026-11-28');
  const [eventTitle, setEventTitle] = useState('');
  const [eventDescription, setEventDescription] = useState('');
  const [eventKind, setEventKind] = useState<SchoolEventKind>('event');
  const [eventError, setEventError] = useState<string | null>(null);

  const activeTerm = useMemo(() => getActiveAcademicTerm(state), [state]);
  const adminAttentionItems = useMemo(
    () => (isAdmin ? computeAdminAttentionItems(state, todayYmd) : []),
    [isAdmin, state, todayYmd]
  );
  const onboardingChecklist = useMemo(
    () => (isAdmin ? computeOnboardingChecklist(state) : []),
    [isAdmin, state]
  );
  const completedChecklistCount = onboardingChecklist.filter((c) => c.completed).length;

  const resolvedTeacherId = activeTeacherId || state.teachers[0]?.id || '';
  const teacherTodayPeriods = useMemo(
    () =>
      isTeacher
        ? computeTeacherTodaySchedule(state, resolvedTeacherId, teacherDayFilter)
        : [],
    [isTeacher, state, resolvedTeacherId, teacherDayFilter]
  );
  const teacherPendingPlans = useMemo(
    () =>
      isTeacher ? getTeacherPendingLessonPlans(state, resolvedTeacherId) : [],
    [isTeacher, state, resolvedTeacherId]
  );

  const parentChildDigests = useMemo(
    () =>
      isParent
        ? computeParentChildDigests(state, linkedLearnerIds, activeLearnerId, todayYmd)
        : [],
    [isParent, state, linkedLearnerIds, activeLearnerId, todayYmd]
  );

  const year = cursorMonth.getFullYear();
  const monthIndex = cursorMonth.getMonth();
  const monthLabel = cursorMonth.toLocaleString('en-US', {
    month: 'long',
    year: 'numeric',
  });

  const calendarCells = useMemo(() => {
    const firstWeekday = new Date(year, monthIndex, 1).getDay();
    const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();
    const cells: ({ day: number; ymd: string } | null)[] = [];
    for (let i = 0; i < firstWeekday; i++) {
      cells.push(null);
    }
    for (let d = 1; d <= daysInMonth; d++) {
      cells.push({ day: d, ymd: formatDateYmd(year, monthIndex, d) });
    }
    return cells;
  }, [year, monthIndex]);

  const eventsByDate = useMemo(() => {
    const map = new Map<string, SchoolEventEntity[]>();
    for (const evt of state.schoolEvents) {
      const list = map.get(evt.date) ?? [];
      list.push(evt);
      map.set(evt.date, list);
    }
    return map;
  }, [state.schoolEvents]);

  const selectedDayEvents = eventsByDate.get(selectedDate) ?? [];

  const substrandCoverage = useMemo(() => computeSubstrandCoverage(state), [state]);
  const avgCoverage =
    substrandCoverage.length === 0
      ? 0
      : Math.round(
          substrandCoverage.reduce((sum, r) => sum + r.coveragePercent, 0) /
            substrandCoverage.length
        );

  const attendanceRate =
    state.attendanceRecords.length === 0
      ? 100
      : Math.round(
          (state.attendanceRecords.filter((a) => a.status === 'present').length /
            state.attendanceRecords.length) *
            100
        );

  const lessonCompletionRate =
    state.lessonPlans.length === 0
      ? 0
      : Math.round(
          (state.lessonPlans.filter((l) => l.status === 'taught').length /
            state.lessonPlans.length) *
            100
        );

  const masteryCounts = useMemo(() => {
    const counts = { Exceeding: 0, Meeting: 0, Approaching: 0, Developing: 0 };
    for (const a of state.assessments) {
      counts[a.mastery] = (counts[a.mastery] ?? 0) + 1;
    }
    return counts;
  }, [state.assessments]);

  const totalAssessments = state.assessments.length;

  const parentChildren = useMemo(() => {
    if (!isParent) return [];
    return state.learners.filter((l) =>
      linkedLearnerIds && linkedLearnerIds.length > 0
        ? linkedLearnerIds.includes(l.id)
        : l.id === activeLearnerId
    );
  }, [isParent, state.learners, linkedLearnerIds, activeLearnerId]);

  const activeChild = useMemo(() => {
    if (!isParent) return undefined;
    return (
      parentChildren.find((l) => l.id === activeLearnerId) ??
      parentChildren[0] ??
      state.learners[0]
    );
  }, [isParent, parentChildren, activeLearnerId, state.learners]);

  const parentPendingSignOffs = useMemo(() => {
    if (!isParent) return 0;
    const childIds = parentChildren.map((c) => c.id);
    return state.diaryEntries.filter(
      (d) => childIds.includes(d.learnerId) && !d.parentAcknowledged
    ).length;
  }, [isParent, parentChildren, state.diaryEntries]);

  const parentChildAttendance = useMemo(() => {
    if (!isParent) return { rate: 100, present: 0, total: 0 };
    const childIds = parentChildren.map((c) => c.id);
    const recs = state.attendanceRecords.filter((a) =>
      childIds.includes(a.learnerId)
    );
    if (recs.length === 0) return { rate: 100, present: 0, total: 0 };
    const present = recs.filter((a) => a.status === 'present').length;
    return {
      rate: Math.round((present / recs.length) * 100),
      present,
      total: recs.length,
    };
  }, [isParent, parentChildren, state.attendanceRecords]);

  const parentChildAssessments = useMemo(() => {
    if (!isParent || !activeChild) return [];
    return state.assessments.filter((a) => a.learnerId === activeChild.id);
  }, [isParent, activeChild, state.assessments]);

  const parentChildMasteryCounts = useMemo(() => {
    const counts = { Exceeding: 0, Meeting: 0, Approaching: 0, Developing: 0 };
    for (const a of parentChildAssessments) {
      counts[a.mastery] = (counts[a.mastery] ?? 0) + 1;
    }
    return counts;
  }, [parentChildAssessments]);

  const upcomingEvents = useMemo(() => {
    return [...state.schoolEvents]
      .sort((a, b) => a.date.localeCompare(b.date))
      .slice(0, 5);
  }, [state.schoolEvents]);

  const openCreateEvent = (prefillDate?: string) => {
    setEditingEventId(null);
    setEventDate(prefillDate ?? selectedDate);
    setEventTitle('');
    setEventDescription('');
    setEventKind('event');
    setEventError(null);
    setEventDialogOpen(true);
  };

  const openEditEvent = (evt: SchoolEventEntity) => {
    setEditingEventId(evt.id);
    setEventDate(evt.date);
    setEventTitle(evt.title);
    setEventDescription(evt.description);
    setEventKind(evt.kind);
    setEventError(null);
    setEventDialogOpen(true);
  };

  const monthPrefix = `${year}-${String(monthIndex + 1).padStart(2, '0')}`;
  const eventsThisMonthCount = useMemo(
    () => state.schoolEvents.filter((e) => e.date.startsWith(monthPrefix)).length,
    [state.schoolEvents, monthPrefix]
  );

  const handleSaveEvent = (e: FormEvent) => {
    e.preventDefault();
    void runLockedAction('Saving calendar event...', () => {
      const res = upsertSchoolEvent(
        state,
        {
          id: editingEventId ?? undefined,
          date: eventDate,
          title: eventTitle,
          description: eventDescription,
          kind: eventKind,
          actorRole: role,
        },
        actor
      );
      if (res.error) {
        setEventError(res.error);
        showFeedback('error', res.error);
        return;
      }
      onStateChange(res.state);
      setSelectedDate(eventDate);
      setEventDialogOpen(false);
      setEditingEventId(null);
      showFeedback('success', 'Calendar event saved');
    });
  };

  const handleDeleteEvent = (eventId: string) => {
    void runLockedAction('Removing calendar event...', () => {
      const res = deleteSchoolEvent(state, eventId, role, actor);
      if (res.error) {
        showFeedback('error', res.error);
        return;
      }
      onStateChange(res.state);
      showFeedback('warning', 'Calendar event removed');
    });
  };

  const handleQuickParentSignOff = (diaryId: string) => {
    void runLockedAction('Signing homework note...', () => {
      const nextState = toggleDiaryAcknowledgment(state, diaryId, actor);
      onStateChange(nextState);
      showFeedback('success', 'Diary signed off');
    });
  };

  const handleTeacherMarkTaught = (lessonPlanId: string) => {
    void runLockedAction('Marking lesson taught...', () => {
      const nextState = updateLessonStatus(
        state,
        lessonPlanId,
        'taught',
        2,
        resolvedTeacherId,
        actor
      );
      onStateChange(nextState);
      showFeedback('success', 'Lesson marked taught');
    });
  };

  const handleClearSampleData = () => {
    void runLockedAction('Clearing sample data...', () => {
      const nextState = clearSampleData(state, actor);
      onStateChange(nextState);
      setConfirmClearOpen(false);
      showFeedback('warning', 'Sample data cleared — ready for school onboarding');
    });
  };

  const handleRestoreDemoData = () => {
    void runLockedAction('Restoring demo workspace...', () => {
      onStateChange(INITIAL_ECS_STATE);
      showFeedback('info', 'Sample school workspace restored');
    });
  };

  const quickModules: {
    id: SandboxModule;
    title: string;
    subtitle: string;
    Icon: typeof Users;
    roles: Role[];
    accent: string;
  }[] = [
    {
      id: 'learners',
      title: 'Learners Directory',
      subtitle: 'Profiles, enrollment, and bulk CSV import',
      Icon: Users,
      roles: ['admin', 'teacher', 'parent'],
      accent: 'text-blue-700 bg-blue-50',
    },
    {
      id: 'diary',
      title: 'School Diary',
      subtitle: 'Daily homework & parent acknowledgments',
      Icon: BookOpen,
      roles: ['admin', 'teacher', 'parent'],
      accent: 'text-emerald-700 bg-emerald-50',
    },
    {
      id: 'schemes',
      title: 'Schemes of Work',
      subtitle: 'Strands, substrands & target lessons by class',
      Icon: GitBranch,
      roles: ['admin', 'teacher'],
      accent: 'text-violet-700 bg-violet-50',
    },
    {
      id: 'assessments',
      title: 'Assessments',
      subtitle: 'Substrand mastery & performance comments',
      Icon: FileSpreadsheet,
      roles: ['admin', 'teacher', 'parent'],
      accent: 'text-amber-700 bg-amber-50',
    },
    {
      id: 'lessons',
      title: 'Lesson Plans',
      subtitle: 'Lesson registry, delivery status & duplication',
      Icon: Edit3,
      roles: ['admin', 'teacher'],
      accent: 'text-pink-700 bg-pink-50',
    },
    {
      id: 'timetable',
      title: 'Timetable',
      subtitle: 'Weekly schedules & conflict validation',
      Icon: CalendarIcon,
      roles: ['admin', 'teacher', 'parent'],
      accent: 'text-cyan-700 bg-cyan-50',
    },
    {
      id: 'register',
      title: 'Class Register',
      subtitle: 'Daily roll call & Same as Yesterday shortcut',
      Icon: ClipboardCheck,
      roles: ['admin', 'teacher', 'parent'],
      accent: 'text-sky-700 bg-sky-50',
    },
    {
      id: 'classrooms',
      title: 'Classrooms',
      subtitle: 'Homeroom teachers, streams & score spread',
      Icon: School,
      roles: ['admin'],
      accent: 'text-teal-700 bg-teal-50',
    },
    {
      id: 'parents',
      title: 'Parents & Zones',
      subtitle: 'Families, siblings & transport locations',
      Icon: Users,
      roles: ['admin'],
      accent: 'text-rose-700 bg-rose-50',
    },
    {
      id: 'coverage',
      title: 'Coverage & Audit',
      subtitle: 'Syllabus delivery rollup, charts & audit log',
      Icon: LineChart,
      roles: ['admin'],
      accent: 'text-indigo-700 bg-indigo-50',
    },
    {
      id: 'schema',
      title: 'Custom Fields & Terms',
      subtitle: 'Custom fields, page layout, users & academic terms',
      Icon: Settings2,
      roles: ['admin'],
      accent: 'text-slate-700 bg-slate-100',
    },
  ];

  const visibleModules = quickModules.filter((m) => m.roles.includes(role));

  return (
    <div className="space-y-6">
      {/* Plain-Language Role Hero */}
      <section className="rounded-xl border border-slate-800 bg-slate-900 p-6 text-white">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-xs font-semibold text-blue-300">
              {isParent
                ? 'Family & Guardian Portal'
                : `${role === 'admin' ? 'School Administration' : 'Teacher Workspace'}${activeTerm ? ` · ${activeTerm.name}` : ''}`}
            </p>
            <h1 className="mt-1.5 font-display text-2xl font-bold tracking-tight text-balance">
              {isParent ? 'Family Calendar & Child Updates' : 'Today at School'}
            </h1>
            <p className="mt-1 text-sm text-slate-300">
              {isParent
                ? 'View upcoming school dates, today’s attendance, and homework notes needing your signature.'
                : role === 'teacher'
                  ? 'Your scheduled periods, registers to complete, and lesson plans ready to teach.'
                  : 'Unresolved school tasks, daily attendance health, upcoming events, and curriculum pacing.'}
            </p>
          </div>
          {isAdmin && (
            <button
              type="button"
              onClick={() => openCreateEvent(selectedDate)}
              className="inline-flex items-center gap-2 rounded-lg bg-white px-4 py-2 text-xs font-semibold text-slate-900 transition-colors hover:bg-slate-100 whitespace-nowrap shrink-0"
            >
              <Plus className="h-4 w-4" aria-hidden="true" />
              Add Event / Holiday
            </button>
          )}
          {isTeacher && (
            <button
              type="button"
              onClick={() => onNavigateModule('register')}
              className="inline-flex items-center gap-2 rounded-lg bg-white px-4 py-2 text-xs font-semibold text-slate-900 transition-colors hover:bg-slate-100 whitespace-nowrap shrink-0"
            >
              <ClipboardCheck className="h-4 w-4 text-blue-700" aria-hidden="true" />
              Open Class Register
            </button>
          )}
          {isParent && activeChild && (
            <button
              type="button"
              onClick={() => onNavigateModule('learners')}
              className="inline-flex items-center gap-2 rounded-lg bg-white px-4 py-2 text-xs font-semibold text-slate-900 transition-colors hover:bg-slate-100 whitespace-nowrap shrink-0"
            >
              <GraduationCap className="h-4 w-4 text-blue-700" aria-hidden="true" />
              Open {activeChild.name}&apos;s Details
            </button>
          )}
        </div>
      </section>

      {/* Role-Specific Task-First Section ("What Needs Me Today") */}
      {isAdmin && (
        <section
          aria-label="Needs Attention Today"
          className="rounded-xl border border-slate-200 bg-white p-5 space-y-4"
        >
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h2 className="font-display text-sm font-bold text-slate-900">
                What Needs Attention Today
              </h2>
              <p className="text-xs text-slate-500">
                Prioritized follow-ups across attendance, homework sign-offs, and syllabus pacing.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setChecklistOpen((prev) => !prev)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0"
              >
                <span>
                  Setup Checklist ({completedChecklistCount}/{onboardingChecklist.length})
                </span>
                <ChevronDown
                  className={`h-3.5 w-3.5 transition-transform ${
                    checklistOpen ? 'rotate-180' : ''
                  }`}
                  aria-hidden="true"
                />
              </button>
              {state.learners.length === 0 ? (
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={handleRestoreDemoData}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-blue-200 bg-blue-50 px-3 py-1.5 text-xs font-semibold text-blue-700 hover:bg-blue-100 whitespace-nowrap shrink-0 disabled:opacity-50"
                >
                  <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                  Restore Sample Data
                </button>
              ) : (
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() => setConfirmClearOpen(true)}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-600 hover:border-red-200 hover:bg-red-50 hover:text-red-700 whitespace-nowrap shrink-0 disabled:opacity-50"
                >
                  <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                  Clear Sample Data
                </button>
              )}
            </div>
          </div>

          {checklistOpen && (
            <div className="grid grid-cols-1 gap-2.5 rounded-lg border border-slate-200 bg-slate-50/70 p-3.5 sm:grid-cols-2 lg:grid-cols-4">
              {onboardingChecklist.map((step) => (
                <button
                  key={step.id}
                  type="button"
                  onClick={() => onNavigateModule(step.targetModule as SandboxModule)}
                  className="flex items-start gap-2.5 rounded-lg border border-slate-200 bg-white p-3 text-left transition-colors hover:border-blue-300"
                >
                  <CheckCircle2
                    className={`mt-0.5 h-4 w-4 shrink-0 ${
                      step.completed ? 'text-emerald-600' : 'text-slate-300'
                    }`}
                    aria-hidden="true"
                  />
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-900">
                      {step.label}
                    </p>
                    <p className="mt-0.5 text-[11px] text-slate-500">
                      {step.description}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          )}

          {adminAttentionItems.length === 0 ? (
            <div className="flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50/60 px-4 py-3 text-xs font-medium text-emerald-900">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" aria-hidden="true" />
              All registers, diary sign-offs, and syllabus targets are up to date today.
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              {adminAttentionItems.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between gap-3 rounded-lg border border-slate-200 bg-slate-50/60 p-3.5"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <AlertCircle
                        className={`h-4 w-4 shrink-0 ${
                          item.severity === 'high'
                            ? 'text-red-600'
                            : item.severity === 'medium'
                              ? 'text-amber-600'
                              : 'text-blue-600'
                        }`}
                        aria-hidden="true"
                      />
                      <p className="truncate text-xs font-bold text-slate-900">
                        {item.title}
                      </p>
                    </div>
                    <p className="mt-0.5 pl-6 text-[11px] text-slate-600 truncate">
                      {item.detail}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onNavigateModule(item.targetModule as SandboxModule)}
                    className="rounded-lg border border-blue-200 bg-white px-3 py-1.5 text-xs font-semibold text-blue-700 hover:bg-blue-50 whitespace-nowrap shrink-0"
                  >
                    {item.actionLabel}
                  </button>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {isTeacher && (
        <section
          aria-label="My Teaching Day"
          className="grid grid-cols-1 gap-4 lg:grid-cols-12"
        >
          <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-7">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div>
                <h2 className="font-display text-sm font-bold text-slate-900">
                  Scheduled Periods ({teacherDayFilter})
                </h2>
                <p className="text-xs text-slate-500">
                  Open a period&apos;s lesson plan or jump directly to that class register.
                </p>
              </div>
              <div className="inline-flex rounded-lg bg-slate-100 p-1">
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setTeacherDayFilter(d)}
                    className={`rounded-md px-2.5 py-1 text-xs font-semibold transition-colors ${
                      teacherDayFilter === d
                        ? 'bg-white text-blue-700 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>

            {teacherTodayPeriods.length === 0 ? (
              <div className="mt-4 rounded-lg border border-slate-200 bg-slate-50 p-4 text-center text-xs text-slate-600">
                No timetable periods assigned on {teacherDayFilter}.
              </div>
            ) : (
              <div className="mt-3 space-y-2.5">
                {teacherTodayPeriods.map(({ slot, classroom, subject, lessonPlan }) => (
                  <div
                    key={slot.id}
                    className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-200 bg-slate-50/70 p-3.5"
                  >
                    <div className="min-w-0">
                      <p className="font-mono text-[11px] text-slate-500 tabular-nums">
                        P{slot.period} · {slot.timeRange} · Room {slot.room}
                      </p>
                      <p className="mt-0.5 text-sm font-bold text-slate-900">
                        {subject?.name} — {classroom?.name}
                      </p>
                      <p className="text-xs text-slate-600">
                        {lessonPlan
                          ? `Lesson: ${lessonPlan.title} (${lessonPlan.status.replace('_', ' ')})`
                          : 'No lesson plan linked yet'}
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      {lessonPlan ? (
                        <button
                          type="button"
                          onClick={() => onNavigateModule('lessons')}
                          className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 whitespace-nowrap"
                        >
                          Open Lesson
                        </button>
                      ) : (
                        onCreateLessonFromSlot && (
                          <button
                            type="button"
                            onClick={() =>
                              onCreateLessonFromSlot({
                                classroomId: slot.classroomId,
                                subjectId: slot.subjectId,
                                teacherId: slot.teacherId,
                                timetableSlotId: slot.id,
                                scheduledDate: todayYmd,
                              })
                            }
                            className="rounded-lg border border-blue-200 bg-blue-50 px-2.5 py-1.5 text-xs font-semibold text-blue-700 hover:bg-blue-100 whitespace-nowrap"
                          >
                            + Create Lesson
                          </button>
                        )
                      )}
                      <button
                        type="button"
                        onClick={() =>
                          onNavigateRegister
                            ? onNavigateRegister(slot.classroomId)
                            : onNavigateModule('register')
                        }
                        className="rounded-lg bg-blue-700 px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-blue-800 whitespace-nowrap"
                      >
                        Take Register
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-5">
            <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div>
                <h2 className="font-display text-sm font-bold text-slate-900">
                  Plans Not Yet Marked Taught ({teacherPendingPlans.length})
                </h2>
                <p className="text-xs text-slate-500">
                  Finish delivery and mark taught in one click.
                </p>
              </div>
              <Clock className="h-4 w-4 text-slate-400" aria-hidden="true" />
            </div>

            {teacherPendingPlans.length === 0 ? (
              <p className="mt-4 text-xs text-emerald-700">
                All of your registered lesson plans are marked taught.
              </p>
            ) : (
              <div className="mt-3 space-y-2.5">
                {teacherPendingPlans.slice(0, 4).map((lp) => {
                  const cls = state.classrooms.find((c) => c.id === lp.classroomId);
                  return (
                    <div
                      key={lp.id}
                      className="flex items-center justify-between gap-2 rounded-lg border border-slate-200 bg-slate-50/60 p-3"
                    >
                      <div className="min-w-0">
                        <p className="truncate text-xs font-bold text-slate-900">
                          {lp.title}
                        </p>
                        <p className="text-[11px] text-slate-500">
                          {cls?.name} ·{' '}
                          <span className="font-mono">{lp.scheduledDate}</span>
                        </p>
                      </div>
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => handleTeacherMarkTaught(lp.id)}
                        className="rounded-lg border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-800 hover:bg-emerald-100 whitespace-nowrap shrink-0 disabled:opacity-50"
                      >
                        Mark Taught
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </section>
      )}

      {isParent && parentChildDigests.length > 0 && (
        <section aria-label="My Children Today" className="space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-base font-bold text-slate-900">
                Needs Your Attention Today
              </h2>
              <p className="text-xs text-slate-500">
                Daily attendance, recent assessment scores, and one-tap homework sign-off for each child.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            {parentChildDigests.map(
              ({
                learner,
                classroom,
                todayAttendance,
                pendingDiaryEntries,
                latestAssessment,
              }) => (
                <article
                  key={learner.id}
                  className="rounded-xl border border-slate-200 bg-white p-5 space-y-4"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 pb-3">
                    <div>
                      <p className="text-xs text-slate-500">
                        <span className="font-mono">{learner.admissionNo}</span> ·{' '}
                        {classroom?.name ?? learner.classroomId}
                      </p>
                      <h3 className="mt-0.5 font-display text-base font-bold text-slate-900">
                        {learner.name}
                      </h3>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        onOpenLearnerPage
                          ? onOpenLearnerPage(learner.id)
                          : onNavigateModule('learners')
                      }
                      className="inline-flex items-center gap-1 rounded-lg border border-blue-200 bg-blue-50 px-3 py-1.5 text-xs font-semibold text-blue-700 hover:bg-blue-100 whitespace-nowrap shrink-0"
                    >
                      View Child Details
                      <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
                    </button>
                  </div>

                  <dl className="grid grid-cols-3 gap-3 text-xs">
                    <div>
                      <dt className="text-slate-500">Today&apos;s Roll</dt>
                      <dd className="mt-0.5 font-semibold capitalize text-slate-900">
                        {todayAttendance ? todayAttendance.status : 'Not recorded'}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-slate-500">Latest Score</dt>
                      <dd className="mt-0.5 font-mono font-bold text-slate-900 tabular-nums">
                        {latestAssessment
                          ? `${latestAssessment.scorePercent}% (${latestAssessment.mastery})`
                          : '—'}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-slate-500">Needs Sign-Off</dt>
                      <dd
                        className={`mt-0.5 font-mono font-bold tabular-nums ${
                          pendingDiaryEntries.length > 0
                            ? 'text-amber-700'
                            : 'text-emerald-700'
                        }`}
                      >
                        {pendingDiaryEntries.length} pending
                      </dd>
                    </div>
                  </dl>

                  {pendingDiaryEntries.length === 0 ? (
                    <div className="flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50/50 px-3.5 py-2.5 text-xs font-medium text-emerald-900">
                      <CheckCircle2
                        className="h-4 w-4 text-emerald-600"
                        aria-hidden="true"
                      />
                      All diary notes signed for {learner.name}.
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {pendingDiaryEntries.slice(0, 2).map((entry) => (
                        <div
                          key={entry.id}
                          className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-amber-200 bg-amber-50/60 p-3"
                        >
                          <div className="min-w-0 flex-1">
                            <p className="font-mono text-[11px] text-amber-800">
                              {entry.date}
                            </p>
                            <p className="text-xs font-semibold text-slate-900">
                              {entry.homeworkSummary}
                            </p>
                            {entry.teacherNote && (
                              <p className="mt-0.5 text-[11px] text-slate-600">
                                {entry.teacherNote}
                              </p>
                            )}
                          </div>
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => handleQuickParentSignOff(entry.id)}
                            className="rounded-lg bg-emerald-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800 whitespace-nowrap shrink-0 disabled:cursor-not-allowed disabled:opacity-50"
                          >
                            Sign Off
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </article>
              )
            )}
          </div>
        </section>
      )}

      {/* Auto-generated & Cached Admin Executive Briefing */}
      {isAdmin && <AdminAiBriefingCard state={state} />}

      {/* KPI Strip */}
      {isParent ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="flex items-center gap-4 rounded-xl border border-slate-200 bg-white p-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-blue-700">
              <Users className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Enrolled Children</p>
              <p className="font-mono text-lg font-bold text-slate-900 tabular-nums">
                {parentChildren.length} {parentChildren.length === 1 ? 'Child' : 'Children'}
              </p>
              <p className="truncate text-[11px] text-slate-500 max-w-[180px]">
                {parentChildren.map((c) => c.name).join(', ')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 rounded-xl border border-slate-200 bg-white p-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-violet-50 text-violet-700">
              <CalendarIcon className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">School Events</p>
              <p className="font-mono text-lg font-bold text-slate-900 tabular-nums">
                {eventsThisMonthCount} in {monthLabel}
              </p>
              <p className="text-[11px] text-slate-500">
                {state.schoolEvents.length} total events &amp; holidays
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onNavigateModule('learners')}
            className="flex items-center gap-4 rounded-xl border border-slate-200 bg-white p-4 text-left transition-colors hover:border-blue-300 hover:bg-slate-50"
          >
            <div
              className={`flex h-11 w-11 items-center justify-center rounded-xl ${
                parentPendingSignOffs > 0
                  ? 'bg-amber-50 text-amber-700'
                  : 'bg-emerald-50 text-emerald-700'
              }`}
            >
              <BookOpen className="h-5 w-5" aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-medium text-slate-500">Homework Diary</p>
              <p
                className={`font-mono text-lg font-bold tabular-nums ${
                  parentPendingSignOffs > 0 ? 'text-amber-700' : 'text-emerald-700'
                }`}
              >
                {parentPendingSignOffs > 0
                  ? `${parentPendingSignOffs} Awaiting Sign-off`
                  : 'Up to Date'}
              </p>
              <p className="truncate text-[11px] text-slate-500">
                {parentPendingSignOffs > 0
                  ? 'Sign off above or open Child Details'
                  : 'All assigned homework acknowledged'}
              </p>
            </div>
          </button>

          <div className="flex items-center gap-4 rounded-xl border border-slate-200 bg-white p-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700">
              <GraduationCap className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Child Attendance</p>
              <p className="font-mono text-lg font-bold text-emerald-700 tabular-nums">
                {parentChildAttendance.rate}% Present
              </p>
              <p className="text-[11px] text-slate-500">
                {parentChildAttendance.present} of {parentChildAttendance.total} roll calls
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="flex items-center gap-4 rounded-xl border border-slate-200 bg-white p-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-blue-700">
              <Users className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Total Learners</p>
              <p className="font-mono text-lg font-bold text-slate-900 tabular-nums">
                {state.learners.length} Enrolled
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4 rounded-xl border border-slate-200 bg-white p-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700">
              <School className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Classrooms</p>
              <p className="font-mono text-lg font-bold text-slate-900 tabular-nums">
                {state.classrooms.length} Streams
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4 rounded-xl border border-slate-200 bg-white p-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-50 text-amber-700">
              <GraduationCap className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Faculty</p>
              <p className="font-mono text-lg font-bold text-slate-900 tabular-nums">
                {state.teachers.length} Teachers
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4 rounded-xl border border-slate-200 bg-white p-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-violet-50 text-violet-700">
              <CalendarIcon className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Calendar Dates</p>
              <p className="font-mono text-lg font-bold text-slate-900 tabular-nums">
                {state.schoolEvents.length} Events
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Interactive School Calendar & Overview Analytics */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <section className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-7">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h2 className="font-display text-base font-bold text-slate-900">
                School Calendar &amp; National Holidays
              </h2>
              <p className="text-xs text-slate-500">
                <span className="font-mono font-semibold text-slate-700 tabular-nums">
                  {eventsThisMonthCount}
                </span>{' '}
                event{eventsThisMonthCount === 1 ? '' : 's'} scheduled in {monthLabel}. Select any date to inspect.
              </p>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => {
                  setCursorMonth(new Date(2026, 10, 1));
                  setSelectedDate(todayYmd);
                }}
                className="rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100"
              >
                Today
              </button>
              <button
                type="button"
                aria-label="Previous month"
                onClick={() =>
                  setCursorMonth(new Date(year, monthIndex - 1, 1))
                }
                className="rounded-lg border border-slate-200 p-1.5 text-slate-600 hover:bg-slate-50"
              >
                <ChevronLeft className="h-4 w-4" aria-hidden="true" />
              </button>
              <span className="min-w-[120px] text-center text-xs font-bold text-slate-900">
                {monthLabel}
              </span>
              <button
                type="button"
                aria-label="Next month"
                onClick={() =>
                  setCursorMonth(new Date(year, monthIndex + 1, 1))
                }
                className="rounded-lg border border-slate-200 p-1.5 text-slate-600 hover:bg-slate-50"
              >
                <ChevronRight className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-7 gap-1 text-center text-[11px] font-semibold text-slate-500">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
              <div key={d} className="py-1">
                {d}
              </div>
            ))}
          </div>

          <div className="mt-1 grid grid-cols-7 gap-1.5">
            {calendarCells.map((cell, idx) => {
              if (!cell) {
                return <div key={`empty_${idx}`} className="h-16 rounded-lg sm:h-[72px]" />;
              }
              const dayEvents = eventsByDate.get(cell.ymd) ?? [];
              const isSelected = cell.ymd === selectedDate;
              const isToday = cell.ymd === todayYmd;
              return (
                <button
                  key={cell.ymd}
                  type="button"
                  onClick={() => setSelectedDate(cell.ymd)}
                  className={`flex h-16 flex-col items-start justify-between rounded-lg border p-1.5 text-left transition-colors sm:h-[72px] ${
                    isSelected
                      ? 'border-blue-700 bg-blue-50/70 ring-1 ring-blue-700'
                      : dayEvents.length > 0
                        ? 'border-slate-200 bg-slate-50/70 hover:border-blue-300'
                        : 'border-slate-100 bg-white hover:bg-slate-50'
                  }`}
                >
                  <div className="flex w-full items-center justify-between gap-1">
                    <span
                      className={`font-mono text-xs font-semibold tabular-nums ${
                        isSelected
                          ? 'text-blue-800'
                          : isToday
                            ? 'text-blue-700'
                            : 'text-slate-700'
                      }`}
                    >
                      {cell.day}
                    </span>
                    {isToday && (
                      <span
                        title="Current school day"
                        className="h-1.5 w-1.5 rounded-full bg-blue-700"
                      />
                    )}
                  </div>
                  {dayEvents.length > 0 && (
                    <div className="w-full space-y-0.5 overflow-hidden">
                      <div className="flex items-center gap-1 sm:hidden">
                        {dayEvents.slice(0, 3).map((evt) => (
                          <span
                            key={evt.id}
                            title={evt.title}
                            className={`h-1.5 w-1.5 rounded-full ${EVENT_KIND_META[evt.kind].dotClass}`}
                          />
                        ))}
                      </div>
                      <div className="hidden sm:block space-y-0.5">
                        {dayEvents.slice(0, 1).map((evt) => (
                          <p
                            key={evt.id}
                            className="flex items-center gap-1 truncate text-[10px] font-medium text-slate-700"
                          >
                            <span
                              className={`h-1.5 w-1.5 shrink-0 rounded-full ${EVENT_KIND_META[evt.kind].dotClass}`}
                            />
                            <span className="truncate">{evt.title}</span>
                          </p>
                        ))}
                        {dayEvents.length > 1 && (
                          <p className="text-[9px] font-semibold text-slate-500">
                            +{dayEvents.length - 1} more
                          </p>
                        )}
                      </div>
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          <div className="mt-5 border-t border-slate-100 pt-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-xs font-bold text-slate-900">
                Events on{' '}
                <span className="font-mono text-blue-700 tabular-nums">
                  {selectedDate}
                </span>{' '}
                ({selectedDayEvents.length})
              </h3>
              {isAdmin && (
                <button
                  type="button"
                  onClick={() => openCreateEvent(selectedDate)}
                  className="inline-flex items-center gap-1 rounded-lg border border-blue-200 bg-blue-50 px-2.5 py-1 text-xs font-semibold text-blue-800 hover:bg-blue-100"
                >
                  <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                  Add on {selectedDate}
                </button>
              )}
            </div>

            {selectedDayEvents.length === 0 ? (
              <p className="mt-2.5 text-xs text-slate-500">
                No scheduled events or national holidays on this date.
              </p>
            ) : (
              <div className="mt-3 space-y-2.5">
                {selectedDayEvents.map((evt) => {
                  const meta = EVENT_KIND_META[evt.kind];
                  return (
                    <div
                      key={evt.id}
                      className="flex items-start justify-between gap-3 rounded-lg border border-slate-200 bg-slate-50/70 p-3.5"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span
                            className={`h-2 w-2 shrink-0 rounded-full ${meta.dotClass}`}
                          />
                          <span className="text-xs font-bold text-slate-900">
                            {evt.title}
                          </span>
                          <span className="text-[11px] font-medium text-slate-500">
                            · {meta.label}
                          </span>
                        </div>
                        {evt.description && (
                          <p className="mt-1 pl-4 text-xs text-slate-600">
                            {evt.description}
                          </p>
                        )}
                      </div>
                      {isAdmin && (
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            aria-label={`Edit ${evt.title}`}
                            onClick={() => openEditEvent(evt)}
                            className="rounded-lg border border-slate-200 bg-white p-1.5 text-slate-600 hover:bg-slate-100"
                          >
                            <Pencil className="h-3.5 w-3.5" aria-hidden="true" />
                          </button>
                          <button
                            type="button"
                            disabled={isBusy}
                            aria-label={`Delete ${evt.title}`}
                            onClick={() => handleDeleteEvent(evt.id)}
                            className="rounded-lg border border-red-200 bg-white p-1.5 text-red-600 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50"
                          >
                            <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </section>

        <section className="space-y-4 lg:col-span-5">
          {isParent ? (
            <>
              <div className="rounded-xl border border-slate-200 bg-white p-5">
                <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-3">
                  <div>
                    <h2 className="font-display text-sm font-bold text-slate-900">
                      Upcoming School Events &amp; Holidays
                    </h2>
                    <p className="text-xs text-slate-500">
                      Key dates to mark on your family calendar
                    </p>
                  </div>
                </div>
                <div className="mt-3 divide-y divide-slate-100">
                  {upcomingEvents.map((evt) => {
                    const meta = EVENT_KIND_META[evt.kind];
                    return (
                      <div key={evt.id} className="py-2.5 first:pt-0 last:pb-0">
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <span className={`h-2 w-2 shrink-0 rounded-full ${meta.dotClass}`} />
                            <span className="truncate text-xs font-semibold text-slate-900">
                              {evt.title}
                            </span>
                          </div>
                          <span className="font-mono text-[11px] text-slate-500 tabular-nums shrink-0">
                            {evt.date}
                          </span>
                        </div>
                        <p className="mt-0.5 pl-3.5 text-[11px] text-slate-500 truncate">
                          {meta.label} {evt.description ? `· ${evt.description}` : ''}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {activeChild && (
                <div className="rounded-xl border border-slate-200 bg-white p-5">
                  <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-3">
                    <div>
                      <p className="text-xs text-slate-500">
                        {activeChild.admissionNo} ·{' '}
                        {state.classrooms.find((c) => c.id === activeChild.classroomId)?.name}
                      </p>
                      <h3 className="font-display text-base font-bold text-slate-900">
                        {activeChild.name}
                      </h3>
                      <p className="mt-0.5 text-xs text-slate-500">
                        Class Lead:{' '}
                        <span className="font-medium text-slate-700">
                          {(() => {
                            const cls = state.classrooms.find(
                              (c) => c.id === activeChild.classroomId
                            );
                            const t = state.teachers.find(
                              (tc) => tc.id === cls?.classTeacherId
                            );
                            return t?.name ?? 'Assigned Lead';
                          })()}
                        </span>
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => onNavigateModule('learners')}
                      className="inline-flex items-center gap-1 rounded-lg bg-blue-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-800 whitespace-nowrap shrink-0"
                    >
                      Open Child Details
                      <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
                    </button>
                  </div>

                  <div className="mt-4">
                    <MasteryBreakdownDonut
                      title="Academic Mastery Progress"
                      subtitle={`Across ${parentChildAssessments.length} evaluations for ${activeChild.name}`}
                      exceedingCount={parentChildMasteryCounts.Exceeding}
                      meetingCount={parentChildMasteryCounts.Meeting}
                      approachingCount={parentChildMasteryCounts.Approaching}
                      developingCount={parentChildMasteryCounts.Developing}
                    />
                  </div>
                </div>
              )}
            </>
          ) : (
            <>
              <MasteryBreakdownDonut
                title="Mastery Level Distribution"
                subtitle={`Across ${totalAssessments} recorded substrand assessments`}
                exceedingCount={masteryCounts.Exceeding}
                meetingCount={masteryCounts.Meeting}
                approachingCount={masteryCounts.Approaching}
                developingCount={masteryCounts.Developing}
              />

              <div className="rounded-xl border border-slate-200 bg-white p-5">
                <h2 className="text-sm font-bold text-slate-900">
                  Curriculum &amp; Attendance Health
                </h2>
                <div className="mt-4 space-y-4">
                  {[
                    {
                      title: 'Schemes of Work Coverage',
                      pct: avgCoverage,
                      bar: 'bg-emerald-600',
                    },
                    {
                      title: 'Average Daily Attendance Rate',
                      pct: attendanceRate,
                      bar: 'bg-blue-700',
                    },
                    {
                      title: 'Lesson Plan Delivery Completion',
                      pct: lessonCompletionRate,
                      bar: 'bg-violet-600',
                    },
                  ].map((row) => (
                    <div key={row.title}>
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-medium text-slate-700">
                          {row.title}
                        </span>
                        <span className="font-mono font-bold text-slate-900 tabular-nums">
                          {row.pct}%
                        </span>
                      </div>
                      <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                        <div
                          className={`h-full transition-all ${row.bar}`}
                          style={{ width: `${row.pct}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </section>
      </div>

      {/* Quick Access Hub */}
      <section>
        <h2 className="text-base font-bold text-slate-900">
          {isParent ? 'Parent Portal Navigation' : 'School Modules'}
        </h2>
        <p className="mt-0.5 text-xs text-slate-500">
          {isParent
            ? 'Switch between school calendar dates and your child’s detailed progress.'
            : 'Jump directly to any workflow for your role.'}
        </p>
        {isParent ? (
          <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="flex items-center gap-3 rounded-xl border border-blue-200 bg-blue-50/50 p-4">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-100 text-blue-700">
                <CalendarIcon className="h-5 w-5" aria-hidden="true" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold text-slate-900">
                  School Calendar &amp; Events (Active)
                </p>
                <p className="text-xs text-slate-600">
                  School-wide term events, national holidays, assemblies, and exams.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onNavigateModule('learners')}
              className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white p-4 text-left transition-colors hover:border-blue-300 hover:bg-blue-50/30"
            >
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700">
                <GraduationCap className="h-5 w-5" aria-hidden="true" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold text-slate-900">
                  {activeChild?.name ?? 'My Child'}&apos;s Details &amp; Diary
                </p>
                <p className="text-xs text-slate-500">
                  Mastery charts, homework diary sign-off, attendance log, and term report.
                </p>
              </div>
              <ArrowRight
                className="h-4 w-4 shrink-0 text-slate-400"
                aria-hidden="true"
              />
            </button>
          </div>
        ) : (
          <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {visibleModules.map(({ id, title, subtitle, Icon, accent }) => (
              <button
                key={id}
                type="button"
                onClick={() => onNavigateModule(id)}
                className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white p-4 text-left transition-colors hover:border-blue-300 hover:bg-blue-50/30"
              >
                <div
                  className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${accent}`}
                >
                  <Icon className="h-5 w-5" aria-hidden="true" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-bold text-slate-900">
                    {title}
                  </p>
                  <p className="truncate text-xs text-slate-500">{subtitle}</p>
                </div>
                <ArrowRight
                  className="h-4 w-4 shrink-0 text-slate-400"
                  aria-hidden="true"
                />
              </button>
            ))}
          </div>
        )}
      </section>

      {/* Clear Sample Data Confirmation Dialog */}
      <AppDialog
        open={confirmClearOpen}
        busy={isBusy}
        title="Clear Sample School Data?"
        subtitle="Removes demo learners, diary logs, assessments, lesson plans, and register records while keeping classrooms, teachers, and Schemes of Work."
        onClose={() => setConfirmClearOpen(false)}
      >
        <div className="space-y-4">
          <p className="text-xs leading-relaxed text-slate-600">
            Use this when starting fresh with real enrollment via CSV import. You can restore the sample workspace at any time from the Home checklist bar.
          </p>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setConfirmClearOpen(false)}
              className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={isBusy}
              onClick={handleClearSampleData}
              className="rounded-lg bg-red-600 px-4 py-2 text-xs font-semibold text-white hover:bg-red-700 disabled:opacity-50"
            >
              {isBusy ? 'Clearing...' : 'Confirm Clear Sample Data'}
            </button>
          </div>
        </div>
      </AppDialog>

      {/* Admin Event / Holiday CRUD Dialog */}
      <AppDialog
        open={eventDialogOpen}
        busy={isBusy}
        title={
          editingEventId
            ? 'Edit School Event / Holiday'
            : 'Add School Event or Holiday'
        }
        subtitle="Manage school-wide events, national holidays, exams, and staff meetings."
        onClose={() => {
          setEventDialogOpen(false);
          setEditingEventId(null);
        }}
      >
        <form onSubmit={handleSaveEvent} className="space-y-4">
          <fieldset disabled={isBusy} className="space-y-4">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="evt-date"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Date (YYYY-MM-DD) *
                </label>
                <input
                  id="evt-date"
                  type="date"
                  value={eventDate}
                  onChange={(e) => setEventDate(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                />
              </div>
              <div>
                <label
                  htmlFor="evt-kind"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Kind *
                </label>
                <select
                  id="evt-kind"
                  value={eventKind}
                  onChange={(e) => setEventKind(e.target.value as SchoolEventKind)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
                >
                  <option value="event">School Event</option>
                  <option value="holiday">National Holiday / Assembly</option>
                  <option value="exam">Examination</option>
                  <option value="meeting">Staff Meeting</option>
                  <option value="sports">Sports &amp; Athletics</option>
                </select>
              </div>
            </div>

            <div>
              <label
                htmlFor="evt-title"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Event Title *
              </label>
              <input
                id="evt-title"
                type="text"
                value={eventTitle}
                onChange={(e) => setEventTitle(e.target.value)}
                placeholder="e.g. Jamhuri Day National Holiday"
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>

            <div>
              <label
                htmlFor="evt-desc"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Description / Notes
              </label>
              <textarea
                id="evt-desc"
                rows={3}
                value={eventDescription}
                onChange={(e) => setEventDescription(e.target.value)}
                placeholder="Details visible to teachers and staff..."
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>

            {eventError && (
              <p className="text-xs font-medium text-red-600">{eventError}</p>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setEventDialogOpen(false);
                  setEditingEventId(null);
                }}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </button>
              <ActionSubmitButton
                idleLabel={editingEventId ? 'Save Changes' : 'Save Event'}
                busyLabel="Saving..."
                className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
              />
            </div>
          </fieldset>
        </form>
      </AppDialog>
    </div>
  );
}
