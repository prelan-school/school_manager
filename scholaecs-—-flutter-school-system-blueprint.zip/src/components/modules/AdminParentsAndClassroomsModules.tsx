import {
  ArrowRight,
  BookOpen,
  Edit3,
  GitBranch,
  GraduationCap,
  MapPin,
  Plus,
  Search,
  Trash2,
  UserCheck,
  Users,
} from 'lucide-react';
import { useMemo, useState, type FormEvent } from 'react';
import {
  assignClassTeacher,
  buildScoreCandlesticks,
  computeClassroomMatrix,
  computeLocationSummaries,
  computeParentSummaries,
  computeSubstrandCoverage,
  deleteLocation,
  upsertLocation,
} from '../../ecs/engine';
import type { AuditActor, LocationEntity, SchoolECSState } from '../../ecs/types';
import { ActionSubmitButton, useActionFeedback } from '../ActionFeedback';
import {
  AuditAttributionLine,
  GroupedBarChart,
  MasteryBreakdownDonut,
  ScoreCandlestickChart,
  TrendLineChart,
} from '../AnalyticsCharts';
import { AppDialog } from '../AppDialog';

interface AdminParentsModuleProps {
  state: SchoolECSState;
  actor?: AuditActor;
  onStateChange?: (next: SchoolECSState) => void;
  onOpenLearnerPage: (learnerId: string) => void;
  onOpenClassroom: (classroomId: string) => void;
}

export function AdminParentsModule({
  state,
  actor,
  onStateChange,
  onOpenLearnerPage,
  onOpenClassroom,
}: AdminParentsModuleProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [classroomFilter, setClassroomFilter] = useState('all');
  const [locationFilter, setLocationFilter] = useState('all');

  const [locationDialogOpen, setLocationDialogOpen] = useState(false);
  const [editingLocationId, setEditingLocationId] = useState<string | null>(null);
  const [locName, setLocName] = useState('');
  const [locZone, setLocZone] = useState('');
  const [locNotes, setLocNotes] = useState('');
  const [locError, setLocError] = useState<string | null>(null);

  const { isBusy, runLockedAction, showFeedback } = useActionFeedback();

  const summaries = useMemo(() => computeParentSummaries(state), [state]);
  const locationSummaries = useMemo(
    () => computeLocationSummaries(state),
    [state]
  );
  const locations = state.locations ?? [];

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return summaries.filter((p) => {
      if (
        classroomFilter !== 'all' &&
        !p.classrooms.some((c) => c.id === classroomFilter)
      ) {
        return false;
      }
      if (
        locationFilter !== 'all' &&
        !p.locations.some((loc) => loc.id === locationFilter)
      ) {
        return false;
      }
      if (!q) return true;
      return (
        p.parentName.toLowerCase().includes(q) ||
        p.parentEmail.toLowerCase().includes(q) ||
        p.guardianPhone.toLowerCase().includes(q) ||
        p.locations.some(
          (loc) =>
            loc.name.toLowerCase().includes(q) ||
            loc.zone.toLowerCase().includes(q)
        ) ||
        p.children.some(
          (c) =>
            c.name.toLowerCase().includes(q) ||
            c.admissionNo.toLowerCase().includes(q)
        )
      );
    });
  }, [summaries, searchQuery, classroomFilter, locationFilter]);

  const totalPendingSignoffs = summaries.reduce(
    (s, p) => s + p.pendingSignOffCount,
    0
  );
  const linkedAccountsCount = summaries.filter((p) => Boolean(p.portalUser)).length;

  const openAddLocation = () => {
    setEditingLocationId(null);
    setLocName('');
    setLocZone('');
    setLocNotes('');
    setLocError(null);
    setLocationDialogOpen(true);
  };

  const openEditLocation = (loc: LocationEntity) => {
    setEditingLocationId(loc.id);
    setLocName(loc.name);
    setLocZone(loc.zone);
    setLocNotes(loc.notes);
    setLocError(null);
    setLocationDialogOpen(true);
  };

  const handleSaveLocation = (e: FormEvent) => {
    e.preventDefault();
    if (!onStateChange) return;
    void runLockedAction(
      editingLocationId ? 'Updating location...' : 'Saving location...',
      () => {
        const res = upsertLocation(
          state,
          {
            id: editingLocationId ?? undefined,
            name: locName,
            zone: locZone,
            notes: locNotes,
          },
          actor
        );
        if (res.error) {
          setLocError(res.error);
          showFeedback('error', res.error);
          return;
        }
        setLocError(null);
        setLocationDialogOpen(false);
        onStateChange(res.state);
        showFeedback('success', 'Location saved');
      }
    );
  };

  const handleDeleteLocation = (loc: LocationEntity) => {
    if (!onStateChange) return;
    void runLockedAction(`Deleting ${loc.name}...`, () => {
      onStateChange(deleteLocation(state, loc.id, actor));
      if (locationFilter === loc.id) {
        setLocationFilter('all');
      }
      showFeedback('warning', `Location deleted (${loc.name})`);
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            Parents, Families &amp; Catchments Directory
          </h2>
          <p className="mt-0.5 text-sm text-slate-600">
            Inspect guardian households, transport locations, linked portal accounts, siblings across classrooms, and drill into learner profiles.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search
              className="pointer-events-none absolute top-2.5 left-3 h-3.5 w-3.5 text-slate-400"
              aria-hidden="true"
            />
            <input
              type="search"
              aria-label="Search parents, locations, or children"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search parent, child, or location..."
              className="w-60 rounded-lg border border-slate-300 bg-white py-2 pr-3 pl-8 text-xs focus:border-blue-700 focus:outline-none"
            />
          </div>
          <select
            aria-label="Filter parents by classroom"
            value={classroomFilter}
            onChange={(e) => setClassroomFilter(e.target.value)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
          >
            <option value="all">All Classrooms</option>
            {state.classrooms.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
          <select
            aria-label="Filter parents by location"
            value={locationFilter}
            onChange={(e) => setLocationFilter(e.target.value)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
          >
            <option value="all">All Locations</option>
            {locations.map((loc) => (
              <option key={loc.id} value={loc.id}>
                {loc.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* KPI Summary Strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Registered Families</p>
          <p className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
            {summaries.length}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Portal-Linked Parents</p>
          <p className="mt-1 font-mono text-2xl font-bold text-blue-700 tabular-nums">
            {linkedAccountsCount} / {summaries.length}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Transport Locations</p>
          <p className="mt-1 font-mono text-2xl font-bold text-emerald-700 tabular-nums">
            {locations.length}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Pending Diary Sign-offs</p>
          <p className="mt-1 font-mono text-2xl font-bold text-amber-700 tabular-nums">
            {totalPendingSignoffs}
          </p>
        </div>
      </div>

      {/* Locations & Transport Zones Registry + Analytics */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-7">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h3 className="flex items-center gap-2 text-sm font-bold text-slate-900">
                <MapPin className="h-4 w-4 text-blue-700" aria-hidden="true" />
                Locations &amp; Transport Zones
              </h3>
              <p className="mt-0.5 text-xs text-slate-500">
                Canonical pickup neighborhoods linked directly to learners and parent households.
              </p>
            </div>
            {onStateChange && (
              <button
                type="button"
                disabled={isBusy}
                onClick={openAddLocation}
                className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-800 whitespace-nowrap shrink-0 disabled:opacity-60"
              >
                <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                Add Location
              </button>
            )}
          </div>

          {locationSummaries.length === 0 ? (
            <p className="py-6 text-center text-xs text-slate-500">
              No transport locations registered yet. Add a neighborhood or bus zone to track families by area.
            </p>
          ) : (
            <div className="mt-3 divide-y divide-slate-100">
              {locationSummaries.map((item) => (
                <div
                  key={item.location.id}
                  className="flex flex-wrap items-center justify-between gap-3 py-3"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-semibold text-slate-900">
                        {item.location.name}
                      </p>
                      <span className="text-xs font-medium text-blue-700">
                        · {item.location.zone}
                      </span>
                    </div>
                    <p className="mt-0.5 text-xs text-slate-500">
                      {item.location.notes || 'Standard school catchment zone'}
                    </p>
                    <p className="mt-1 font-mono text-[11px] text-slate-600 tabular-nums">
                      {item.learnerCount} learner{item.learnerCount === 1 ? '' : 's'} ·{' '}
                      {item.familyCount} household{item.familyCount === 1 ? '' : 's'} ·{' '}
                      Avg {item.averageScorePercent !== null ? `${item.averageScorePercent}%` : '—'} ·{' '}
                      Att {item.attendanceRatePercent !== null ? `${item.attendanceRatePercent}%` : '—'}
                    </p>
                  </div>

                  {onStateChange && (
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        disabled={isBusy}
                        aria-label={`Edit ${item.location.name}`}
                        onClick={() => openEditLocation(item.location)}
                        className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50"
                      >
                        <Edit3 className="h-3 w-3" aria-hidden="true" />
                        Edit
                      </button>
                      <button
                        type="button"
                        disabled={isBusy}
                        aria-label={`Delete ${item.location.name}`}
                        onClick={() => handleDeleteLocation(item.location)}
                        className="inline-flex items-center gap-1 rounded-md border border-red-200 bg-white px-2.5 py-1 text-xs font-medium text-red-700 hover:bg-red-50 disabled:opacity-50"
                      >
                        <Trash2 className="h-3 w-3" aria-hidden="true" />
                        Delete
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="lg:col-span-5">
          <GroupedBarChart
            title="Learners & Mastery by Location"
            subtitle="Active learners vs average mastery % across neighborhoods"
            primaryLabel="Learners"
            secondaryLabel="Avg Score %"
            data={locationSummaries.map((s) => ({
              label: s.location.name.split(' ')[0],
              sublabel: s.location.zone,
              primary: s.learnerCount,
              secondary: s.averageScorePercent ?? 0,
            }))}
          />
        </div>
      </section>

      <AppDialog
        open={locationDialogOpen}
        busy={isBusy}
        title={editingLocationId ? 'Edit Location' : 'Add Location / Transport Zone'}
        subtitle="Locations bind learners and families for bus routing and catchment reporting."
        onClose={() => setLocationDialogOpen(false)}
      >
        <form onSubmit={handleSaveLocation}>
          <fieldset disabled={isBusy} className="space-y-4 disabled:opacity-75">
            <div>
              <label
                htmlFor="loc-name"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Neighborhood / Location Name *
              </label>
              <input
                id="loc-name"
                type="text"
                value={locName}
                onChange={(e) => setLocName(e.target.value)}
                placeholder="e.g. Lavington"
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>
            <div>
              <label
                htmlFor="loc-zone"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Bus Route / Catchment Zone
              </label>
              <input
                id="loc-zone"
                type="text"
                value={locZone}
                onChange={(e) => setLocZone(e.target.value)}
                placeholder="e.g. West Shuttle Route E"
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>
            <div>
              <label
                htmlFor="loc-notes"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Pickup / Logistics Notes
              </label>
              <input
                id="loc-notes"
                type="text"
                value={locNotes}
                onChange={(e) => setLocNotes(e.target.value)}
                placeholder="e.g. Morning pickup 06:55 · Drop-off 15:45"
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>

            {locError && (
              <p className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs font-medium text-red-700">
                {locError}
              </p>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setLocationDialogOpen(false)}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </button>
              <ActionSubmitButton
                busy={isBusy}
                busyLabel="Saving..."
                idleLabel={editingLocationId ? 'Save Changes' : 'Save Location'}
                className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
              />
            </div>
          </fieldset>
        </form>
      </AppDialog>

      {filtered.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-8 text-center">
          <p className="text-sm font-medium text-slate-800">
            No guardian households match your filter criteria.
          </p>
          {(searchQuery.trim() ||
            classroomFilter !== 'all' ||
            locationFilter !== 'all') && (
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setClassroomFilter('all');
                setLocationFilter('all');
              }}
              className="mt-3 rounded-lg border border-slate-300 bg-white px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              Clear Filters
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {filtered.map((family) => (
            <section
              key={family.parentKey}
              className="rounded-xl border border-slate-200 bg-white p-5"
            >
              <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 pb-3">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-display text-base font-bold text-slate-900">
                      {family.parentName}
                    </h3>
                    <span
                      className={`text-[11px] font-semibold ${
                        family.portalUser ? 'text-emerald-700' : 'text-slate-500'
                      }`}
                    >
                      · {family.portalUser ? 'Portal Active' : 'Directory Record'}
                    </span>
                  </div>
                  <p className="mt-0.5 font-mono text-xs text-slate-500">
                    {family.parentEmail} · {family.guardianPhone}
                  </p>
                  {family.locations.length > 0 && (
                    <p className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] font-medium text-slate-700">
                      <MapPin className="h-3 w-3 text-blue-700" aria-hidden="true" />
                      {family.locations
                        .map((loc) => `${loc.name} (${loc.zone})`)
                        .join(', ')}
                    </p>
                  )}
                </div>

                <div className="text-right font-mono text-xs tabular-nums">
                  <p className="font-bold text-slate-900">
                    Avg {family.avgScorePercent !== null ? `${family.avgScorePercent}%` : '—'}
                  </p>
                  <p className="text-slate-500">
                    Att {family.attendanceRatePercent !== null ? `${family.attendanceRatePercent}%` : '—'} ·{' '}
                    {family.pendingSignOffCount} pending sign-off
                  </p>
                </div>
              </div>

              {/* Linked Classrooms */}
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <span className="text-[11px] font-medium text-slate-500">
                  Classrooms:
                </span>
                {family.classrooms.map((cls) => (
                  <button
                    key={cls.id}
                    type="button"
                    onClick={() => onOpenClassroom(cls.id)}
                    className="rounded-md border border-slate-200 bg-slate-50 px-2 py-0.5 text-[11px] font-semibold text-blue-700 hover:border-blue-400 hover:bg-blue-50"
                  >
                    {cls.name}
                  </button>
                ))}
              </div>

              {/* Children Rows */}
              <div className="mt-4 divide-y divide-slate-100 rounded-lg border border-slate-200 bg-slate-50/50">
                {family.children.map((child) => {
                  const cls = state.classrooms.find(
                    (c) => c.id === child.classroomId
                  );
                  const childLoc = child.locationId
                    ? locations.find((loc) => loc.id === child.locationId)
                    : undefined;
                  const classTeacher = cls?.classTeacherId
                    ? state.teachers.find((t) => t.id === cls.classTeacherId)
                    : undefined;
                  const childAssessments = state.assessments.filter(
                    (a) => a.learnerId === child.id
                  );
                  const childAvg =
                    childAssessments.length === 0
                      ? null
                      : Math.round(
                          childAssessments.reduce(
                            (s, a) => s + a.scorePercent,
                            0
                          ) / childAssessments.length
                        );
                  const childAttendance = state.attendanceRecords.filter(
                    (r) => r.learnerId === child.id
                  );
                  const presentCount = childAttendance.filter(
                    (r) => r.status === 'present' || r.status === 'late'
                  ).length;
                  const attRate =
                    childAttendance.length === 0
                      ? null
                      : Math.round((presentCount / childAttendance.length) * 100);

                  return (
                    <div
                      key={child.id}
                      className="flex flex-wrap items-center justify-between gap-3 px-3.5 py-2.5"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-semibold text-slate-900">
                          {child.name}
                        </p>
                        <p className="text-[11px] text-slate-500">
                          <span className="font-mono">{child.admissionNo}</span> ·{' '}
                          {cls?.name ?? child.classroomId}
                          {childLoc ? ` · ${childLoc.name}` : ''}
                          {classTeacher
                            ? ` · Class Teacher: ${classTeacher.name}`
                            : ''}
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right font-mono text-[11px] text-slate-600 tabular-nums">
                          <span>
                            Score: {childAvg !== null ? `${childAvg}%` : '—'}
                          </span>
                          {' · '}
                          <span>
                            Att: {attRate !== null ? `${attRate}%` : '—'}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => onOpenLearnerPage(child.id)}
                          className="inline-flex items-center gap-1 rounded-md border border-blue-200 bg-white px-2.5 py-1 text-xs font-semibold text-blue-700 hover:bg-blue-50 whitespace-nowrap shrink-0"
                        >
                          View Profile
                          <ArrowRight className="h-3 w-3" aria-hidden="true" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}

interface ClassroomAnalyticsModuleProps {
  state: SchoolECSState;
  selectedClassroomId: string;
  onSelectClassroom: (classroomId: string) => void;
  onStateChange: (next: SchoolECSState) => void;
  onOpenLearnerPage: (learnerId: string) => void;
  onOpenSchemes: () => void;
  actor?: AuditActor;
}

export function ClassroomAnalyticsModule({
  state,
  selectedClassroomId,
  onSelectClassroom,
  onStateChange,
  onOpenLearnerPage,
  onOpenSchemes,
  actor,
}: ClassroomAnalyticsModuleProps) {
  const [candleBucket, setCandleBucket] = useState<'subject' | 'month' | 'teacher'>(
    'subject'
  );
  const { isBusy, runLockedAction, showFeedback } = useActionFeedback();

  const resolvedClassId = state.classrooms.some(
    (c) => c.id === selectedClassroomId
  )
    ? selectedClassroomId
    : (state.classrooms[0]?.id ?? '');

  const classroomMatrix = useMemo(() => computeClassroomMatrix(state), [state]);
  const activeRow =
    classroomMatrix.find((r) => r.classroom.id === resolvedClassId) ??
    classroomMatrix[0];

  const classLearners = useMemo(
    () => state.learners.filter((l) => l.classroomId === resolvedClassId),
    [state.learners, resolvedClassId]
  );
  const classLearnerIds = useMemo(
    () => new Set(classLearners.map((l) => l.id)),
    [classLearners]
  );
  const classAssessments = useMemo(
    () => state.assessments.filter((a) => classLearnerIds.has(a.learnerId)),
    [state.assessments, classLearnerIds]
  );
  const classLessons = useMemo(
    () => state.lessonPlans.filter((lp) => lp.classroomId === resolvedClassId),
    [state.lessonPlans, resolvedClassId]
  );
  const classSubstrands = useMemo(
    () =>
      computeSubstrandCoverage(state).filter(
        (rep) => rep.strand?.classroomId === resolvedClassId
      ),
    [state, resolvedClassId]
  );
  const classAuditLogs = useMemo(
    () =>
      (state.auditLogs ?? []).filter(
        (a) => a.classroomId === resolvedClassId
      ),
    [state.auditLogs, resolvedClassId]
  );

  const masteryCounts = useMemo(() => {
    const counts = { Exceeding: 0, Meeting: 0, Approaching: 0, Developing: 0 };
    for (const a of classAssessments) {
      counts[a.mastery] = (counts[a.mastery] ?? 0) + 1;
    }
    return counts;
  }, [classAssessments]);

  const candlesticks = useMemo(
    () =>
      buildScoreCandlesticks(classAssessments, {
        bucketBy: candleBucket,
        state,
      }),
    [classAssessments, candleBucket, state]
  );

  const trendPoints = useMemo(() => {
    const sorted = [...classAssessments].sort((a, b) =>
      a.date.localeCompare(b.date)
    );
    return sorted.map((a) => {
      const learner = state.learners.find((l) => l.id === a.learnerId);
      return {
        label: a.date.slice(5),
        value: a.scorePercent,
        caption: learner?.name,
      };
    });
  }, [classAssessments, state.learners]);

  if (!activeRow) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500">
        No classrooms configured yet.
      </div>
    );
  }

  const cls = activeRow.classroom;

  return (
    <div className="space-y-6">
      {/* Header & Classroom Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            Classroom Granular Analytics &amp; Homeroom Control
          </h2>
          <p className="mt-0.5 text-sm text-slate-600">
            Per-class teacher delivery, connected Schemes of Work, assessment candlesticks, and Who &amp; When audit log.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {state.classrooms.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => onSelectClassroom(c.id)}
              className={`rounded-lg px-3.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                c.id === resolvedClassId
                  ? 'bg-blue-700 text-white'
                  : 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              {c.name}
            </button>
          ))}
        </div>
      </div>

      {/* Class Teacher Assignment Banner */}
      <section className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-4">
        <div>
          <p className="text-xs text-slate-500">
            {cls.gradeLevel} · Home Room <span className="font-mono">{cls.roomCode}</span>
          </p>
          <h3 className="mt-0.5 font-display text-base font-bold text-slate-900">
            {cls.name}
          </h3>
          <div className="mt-1">
            <AuditAttributionLine
              who={cls.updatedBy}
              when={cls.updatedAt}
              prefix="Last updated by"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <label
              htmlFor="class-teacher-assign"
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700"
            >
              <UserCheck className="h-3.5 w-3.5 text-blue-700" aria-hidden="true" />
              Class Teacher (Homeroom)
            </label>
            <select
              id="class-teacher-assign"
              disabled={isBusy}
              value={cls.classTeacherId ?? ''}
              onChange={(e) => {
                const teacherId = e.target.value;
                void runLockedAction('Updating class teacher...', () => {
                  onStateChange(
                    assignClassTeacher(state, cls.id, teacherId, actor)
                  );
                  showFeedback('info', 'Class teacher updated');
                });
              }}
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none disabled:opacity-60"
            >
              <option value="">Unassigned</option>
              {state.teachers.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>
          <button
            type="button"
            onClick={onOpenSchemes}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap shrink-0"
          >
            <GitBranch className="h-3.5 w-3.5" aria-hidden="true" />
            Open Class Schemes
          </button>
        </div>
      </section>

      {/* 4-Card KPI Strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Enrolled Learners</p>
          <p className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
            {activeRow.learnerCount}
          </p>
          <p className="mt-0.5 text-xs text-slate-500">
            Active roster in {cls.gradeLevel}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Class Attendance Rate</p>
          <p className="mt-1 font-mono text-2xl font-bold text-emerald-700 tabular-nums">
            {activeRow.attendanceRatePercent}%
          </p>
          <p className="mt-0.5 text-xs text-slate-500">
            Morning roll call average
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Class Average Score</p>
          <p className="mt-1 font-mono text-2xl font-bold text-blue-700 tabular-nums">
            {activeRow.averageScorePercent !== null
              ? `${activeRow.averageScorePercent}%`
              : '—'}
          </p>
          <p className="mt-0.5 text-xs text-slate-500">
            {classAssessments.length} logged assessments
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Scheme Coverage</p>
          <p className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
            {activeRow.avgCoveragePercent}%
          </p>
          <p className="mt-0.5 font-mono text-xs text-slate-500 tabular-nums">
            {activeRow.taughtLessonsCount}/{activeRow.totalPlansCount} plans ·{' '}
            {activeRow.totalLessonsDelivered} lessons
          </p>
        </div>
      </div>

      {/* Granular SVG Charts Grid */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <GroupedBarChart
          title="Teachers Contributing in This Classroom"
          subtitle="Periods delivered vs assessments logged per teacher"
          primaryLabel="Lessons Delivered"
          secondaryLabel="Assessments Logged"
          data={activeRow.teacherSlices.map((s) => ({
            label: s.teacher.name.split(' ')[0],
            sublabel: s.isClassTeacher ? 'Class Teacher' : 'Subject Teacher',
            primary: s.lessonsDelivered,
            secondary: s.assessmentsLogged,
          }))}
        />

        <MasteryBreakdownDonut
          title={`${cls.gradeLevel} Assessment Mastery Split`}
          subtitle="Distribution across Exceeding, Meeting, Approaching, and Developing"
          exceedingCount={masteryCounts.Exceeding}
          meetingCount={masteryCounts.Meeting}
          approachingCount={masteryCounts.Approaching}
          developingCount={masteryCounts.Developing}
        />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">
              Candlestick Grouping
            </span>
            <div className="inline-flex rounded-lg bg-slate-100 p-0.5">
              {(['subject', 'month', 'teacher'] as const).map((b) => (
                <button
                  key={b}
                  type="button"
                  onClick={() => setCandleBucket(b)}
                  className={`rounded-md px-2.5 py-1 text-[11px] font-semibold capitalize ${
                    candleBucket === b
                      ? 'bg-white text-blue-700 shadow-xs'
                      : 'text-slate-600'
                  }`}
                >
                  {b}
                </button>
              ))}
            </div>
          </div>
          <ScoreCandlestickChart
            title="Score Spread Candlestick (OHLC)"
            subtitle={`Open/Close/High/Low % score spread grouped by ${candleBucket}`}
            points={candlesticks}
          />
        </div>

        <TrendLineChart
          title="Assessment Score Trajectory"
          subtitle="Chronological assessment scores across class learners"
          points={trendPoints}
        />
      </div>

      {/* Connected Schemes of Work */}
      <section className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Connected Schemes of Work ({classSubstrands.length} substrands)
            </h3>
            <p className="text-xs text-slate-500">
              Schemes strictly scoped to {cls.name}
            </p>
          </div>
          <button
            type="button"
            onClick={onOpenSchemes}
            className="text-xs font-semibold text-blue-700 hover:underline"
          >
            Manage in Schemes DB &rarr;
          </button>
        </div>
        {classSubstrands.length === 0 ? (
          <p className="py-4 text-xs text-slate-500">
            No scheme strands registered for {cls.name} yet.
          </p>
        ) : (
          <div className="mt-4 space-y-3">
            {classSubstrands.map((rep) => (
              <div key={rep.substrand.id}>
                <div className="flex flex-wrap items-baseline justify-between gap-2 text-xs">
                  <span className="font-semibold text-slate-900">
                    {rep.subject?.code} · {rep.strand?.code} &rarr;{' '}
                    {rep.substrand.code}: {rep.substrand.title}
                  </span>
                  <span className="font-mono text-slate-600 tabular-nums">
                    {rep.coveragePercent}% ({rep.deliveredLessons}/
                    {rep.targetLessons} lessons)
                  </span>
                </div>
                <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                  <div
                    className={`h-full transition-all ${
                      rep.coveragePercent >= 75
                        ? 'bg-emerald-600'
                        : rep.coveragePercent > 0
                          ? 'bg-blue-700'
                          : 'bg-slate-300'
                    }`}
                    style={{ width: `${rep.coveragePercent}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Enrolled Learners & Lessons Attribution */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <section className="rounded-xl border border-slate-200 bg-white p-5">
          <h3 className="flex items-center gap-2 text-sm font-bold text-slate-900">
            <Users className="h-4 w-4 text-blue-700" aria-hidden="true" />
            Enrolled Learners ({classLearners.length})
          </h3>
          <div className="mt-3 divide-y divide-slate-100">
            {classLearners.map((lrn) => {
              const lrnAsm = classAssessments.filter(
                (a) => a.learnerId === lrn.id
              );
              const avg =
                lrnAsm.length === 0
                  ? null
                  : Math.round(
                      lrnAsm.reduce((s, a) => s + a.scorePercent, 0) /
                        lrnAsm.length
                    );
              return (
                <div
                  key={lrn.id}
                  className="flex items-center justify-between gap-3 py-2.5"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-900">
                      {lrn.name}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      <span className="font-mono">{lrn.admissionNo}</span> ·
                      Guardian: {lrn.parentName}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs font-semibold text-slate-700 tabular-nums">
                      {avg !== null ? `${avg}%` : '—'}
                    </span>
                    <button
                      type="button"
                      onClick={() => onOpenLearnerPage(lrn.id)}
                      className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs font-semibold text-blue-700 hover:bg-blue-50 whitespace-nowrap shrink-0"
                    >
                      Inspect
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        <section className="rounded-xl border border-slate-200 bg-white p-5">
          <h3 className="flex items-center gap-2 text-sm font-bold text-slate-900">
            <GraduationCap
              className="h-4 w-4 text-emerald-700"
              aria-hidden="true"
            />
            Lessons Delivered (Who &amp; When)
          </h3>
          {classLessons.length === 0 ? (
            <p className="py-4 text-xs text-slate-500">
              No lessons registered in this classroom yet.
            </p>
          ) : (
            <div className="mt-3 divide-y divide-slate-100">
              {classLessons.map((lp) => {
                const who = state.teachers.find(
                  (t) => t.id === (lp.taughtByTeacherId || lp.teacherId)
                );
                const subj = state.subjects.find((s) => s.id === lp.subjectId);
                return (
                  <div key={lp.id} className="py-2.5">
                    <div className="flex items-baseline justify-between gap-2">
                      <p className="text-sm font-semibold text-slate-900">
                        {lp.title}
                      </p>
                      <span
                        className={`text-[11px] font-semibold capitalize ${
                          lp.status === 'taught'
                            ? 'text-emerald-700'
                            : lp.status === 'in_progress'
                              ? 'text-amber-700'
                              : 'text-slate-500'
                        }`}
                      >
                        {lp.status.replace('_', ' ')} ({lp.lessonsDelivered}p)
                      </span>
                    </div>
                    <p className="text-xs text-slate-500">
                      {subj?.name} · Scheduled{' '}
                      <span className="font-mono">{lp.scheduledDate}</span>
                    </p>
                    <div className="mt-1">
                      <AuditAttributionLine
                        who={who?.name ?? lp.updatedBy}
                        when={lp.taughtAt ?? lp.updatedAt}
                        prefix={lp.taughtAt ? 'Taught by' : 'Updated by'}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>

      {/* Classroom Audit Trail */}
      <section className="rounded-xl border border-slate-200 bg-white p-5">
        <h3 className="flex items-center gap-2 text-sm font-bold text-slate-900">
          <BookOpen className="h-4 w-4 text-slate-700" aria-hidden="true" />
          Classroom Who &amp; When Audit Log ({classAuditLogs.length})
        </h3>
        {classAuditLogs.length === 0 ? (
          <p className="py-4 text-xs text-slate-500">
            No audit activity recorded for {cls.name} yet.
          </p>
        ) : (
          <div className="mt-3 overflow-x-auto">
            <table className="w-full border-collapse text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="py-2 pr-4 font-semibold">When</th>
                  <th className="py-2 pr-4 font-semibold">Who</th>
                  <th className="py-2 pr-4 font-semibold">Action</th>
                  <th className="py-2 pr-4 font-semibold">Target</th>
                  <th className="py-2 font-semibold">Detail</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {classAuditLogs.slice(0, 12).map((entry) => (
                  <tr key={entry.id}>
                    <td className="py-2 pr-4 font-mono text-[11px] text-slate-600 whitespace-nowrap tabular-nums">
                      {entry.timestamp}
                    </td>
                    <td className="py-2 pr-4 font-semibold text-slate-900 whitespace-nowrap">
                      {entry.actorName}{' '}
                      <span className="font-normal text-slate-500 capitalize">
                        ({entry.actorRole})
                      </span>
                    </td>
                    <td className="py-2 pr-4 text-blue-700 font-medium">
                      {entry.action}
                    </td>
                    <td className="py-2 pr-4 text-slate-800">
                      {entry.targetLabel}
                    </td>
                    <td className="py-2 text-slate-600">{entry.detail}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
