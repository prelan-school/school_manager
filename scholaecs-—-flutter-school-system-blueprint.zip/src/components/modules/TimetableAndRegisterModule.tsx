import { useMemo, useState, type FormEvent } from 'react';
import {
  CalendarDays,
  CheckCheck,
  Pencil,
  Plus,
  School,
  Search,
  Trash2,
} from 'lucide-react';
import {
  assignLessonToTimetableSlot,
  copyClassroomAttendanceFromDate,
  deleteScheduleDay,
  deleteTimetableSlot,
  getFieldsForEntity,
  getScheduleDaysForClassroom,
  markClassroomAllPresent,
  toggleDayClassroomMapping,
  updateLessonStatus,
  upsertAttendanceRecord,
  upsertClassroom,
  upsertScheduleDay,
  upsertTimetableSlot,
} from '../../ecs/engine';
import type {
  AttendanceStatus,
  AuditActor,
  LessonPlanEntity,
  LessonStatus,
  Role,
  ScheduleDayEntity,
  SchoolECSState,
  TimetableSlotEntity,
} from '../../ecs/types';
import { ActionSubmitButton, useActionFeedback } from '../ActionFeedback';
import { AppDialog } from '../AppDialog';
import type { DiaryPrefillInput, LessonPrefillDraft } from '../SandboxWorkspace';

interface TimetableModuleProps {
  state: SchoolECSState;
  role: Role;
  activeTeacherId?: string;
  actor?: AuditActor;
  onCreateLessonFromSlot?: (draft: LessonPrefillDraft) => void;
  onOpenHomeworkDialog?: (prefill: DiaryPrefillInput) => void;
  onStateChange: (next: SchoolECSState) => void;
}

function splitTimeRange(timeRange: string): { start: string; end: string } {
  const m = timeRange.match(/(\d{1,2}:\d{2})\s*[-–—]\s*(\d{1,2}:\d{2})/);
  if (!m) return { start: '08:00', end: '08:45' };
  const pad = (t: string) => (t.length === 4 ? `0${t}` : t);
  return { start: pad(m[1]), end: pad(m[2]) };
}

export function TimetableModule({
  state,
  role,
  activeTeacherId,
  actor,
  onCreateLessonFromSlot,
  onOpenHomeworkDialog,
  onStateChange,
}: TimetableModuleProps) {
  const { isBusy, runLockedAction, showFeedback } = useActionFeedback();
  const [viewMode, setViewMode] = useState<'classroom' | 'matrix'>('classroom');
  const [selectedClassroomId, setSelectedClassroomId] = useState(
    state.classrooms[0]?.id ?? ''
  );
  const [activeSlotId, setActiveSlotId] = useState<string | null>(null);

  // Add / Edit Timetable Slot Dialog state
  const [showSlotDialog, setShowSlotDialog] = useState(false);
  const [editingSlotId, setEditingSlotId] = useState<string | null>(null);
  const [slotClassroomId, setSlotClassroomId] = useState(
    state.classrooms[0]?.id ?? ''
  );
  const [slotSubjectId, setSlotSubjectId] = useState(
    state.subjects[0]?.id ?? ''
  );
  const [slotTeacherId, setSlotTeacherId] = useState(
    state.teachers[0]?.id ?? ''
  );
  const [slotDay, setSlotDay] = useState(
    state.scheduleDays[0]?.code ?? 'Mon'
  );
  const [slotPeriod, setSlotPeriod] = useState(3);
  const [slotStartTime, setSlotStartTime] = useState('09:40');
  const [slotEndTime, setSlotEndTime] = useState('10:25');
  const [slotRoom, setSlotRoom] = useState('B2-04');
  const [slotLessonPlanId, setSlotLessonPlanId] = useState('');
  const [slotError, setSlotError] = useState<string | null>(null);

  // Manage Schedule Days & Class Mapping Dialog state
  const [showDaysDialog, setShowDaysDialog] = useState(false);
  const [editingDayId, setEditingDayId] = useState<string | null>(null);
  const [dayCode, setDayCode] = useState('');
  const [dayLabel, setDayLabel] = useState('');
  const [dayOrder, setDayOrder] = useState(6);
  const [dayDefaultTime, setDayDefaultTime] = useState('08:30 - 09:30');
  const [dayClassroomIds, setDayClassroomIds] = useState<string[]>(
    state.classrooms.map((c) => c.id)
  );
  const [dayError, setDayError] = useState<string | null>(null);

  // Add Classroom Dialog state
  const [showClassDialog, setShowClassDialog] = useState(false);
  const [className, setClassName] = useState('');
  const [classGrade, setClassGrade] = useState('Grade 7');
  const [classRoom, setClassRoom] = useState('C1-02');
  const [classTeacherId, setClassTeacherId] = useState(
    state.teachers[0]?.id ?? ''
  );
  const [classDayIds, setClassDayIds] = useState<string[]>(
    state.scheduleDays.slice(0, 5).map((d) => d.id)
  );
  const [classError, setClassError] = useState<string | null>(null);

  const resolvedClassroomId = state.classrooms.some(
    (c) => c.id === selectedClassroomId
  )
    ? selectedClassroomId
    : (state.classrooms[0]?.id ?? '');

  const classroomDays = getScheduleDaysForClassroom(state, resolvedClassroomId);
  const slots = state.timetableSlots.filter(
    (s) => s.classroomId === resolvedClassroomId
  );
  const unassignedLessons = state.lessonPlans.filter(
    (lp) => !lp.timetableSlotId
  );

  const activeSlot = activeSlotId
    ? state.timetableSlots.find((s) => s.id === activeSlotId) ?? null
    : null;
  const activeSlotSubject = activeSlot
    ? state.subjects.find((s) => s.id === activeSlot.subjectId)
    : null;
  const activeSlotTeacher = activeSlot
    ? state.teachers.find((t) => t.id === activeSlot.teacherId)
    : null;
  const activeSlotPlan = activeSlot
    ? state.lessonPlans.find(
        (lp) =>
          lp.id === activeSlot.lessonPlanId || lp.timetableSlotId === activeSlot.id
      )
    : null;
  const activeSlotSubstrand = activeSlotPlan
    ? state.substrands.find((sub) => sub.id === activeSlotPlan.substrandId)
    : null;

  const canEdit = role === 'admin' || role === 'teacher';
  const isAdmin = role === 'admin';

  const openCreateSlotDialog = (opts?: {
    classroomId?: string;
    dayCode?: string;
    lessonPlan?: LessonPlanEntity;
  }) => {
    const clsId = opts?.lessonPlan?.classroomId ?? opts?.classroomId ?? resolvedClassroomId;
    const cls = state.classrooms.find((c) => c.id === clsId);
    const mapped = getScheduleDaysForClassroom(state, clsId);
    const chosenDay =
      opts?.dayCode ?? mapped[0]?.code ?? state.scheduleDays[0]?.code ?? 'Mon';
    const dayObj = state.scheduleDays.find((d) => d.code === chosenDay);
    const parsedTime = splitTimeRange(dayObj?.defaultTimeRange ?? '09:40 - 10:25');

    setEditingSlotId(null);
    setSlotClassroomId(clsId);
    setSlotSubjectId(opts?.lessonPlan?.subjectId ?? state.subjects[0]?.id ?? '');
    setSlotTeacherId(opts?.lessonPlan?.teacherId ?? state.teachers[0]?.id ?? '');
    setSlotDay(chosenDay);
    setSlotPeriod(3);
    setSlotStartTime(parsedTime.start);
    setSlotEndTime(parsedTime.end);
    setSlotRoom(cls?.roomCode ?? 'B2-04');
    setSlotLessonPlanId(opts?.lessonPlan?.id ?? '');
    setSlotError(null);
    setShowSlotDialog(true);
  };

  const openEditSlotDialog = (slot: TimetableSlotEntity) => {
    const parsed = splitTimeRange(slot.timeRange);
    const linkedPlan = state.lessonPlans.find(
      (lp) => lp.id === slot.lessonPlanId || lp.timetableSlotId === slot.id
    );
    setEditingSlotId(slot.id);
    setSlotClassroomId(slot.classroomId);
    setSlotSubjectId(slot.subjectId);
    setSlotTeacherId(slot.teacherId);
    setSlotDay(slot.day);
    setSlotPeriod(slot.period);
    setSlotStartTime(parsed.start);
    setSlotEndTime(parsed.end);
    setSlotRoom(slot.room);
    setSlotLessonPlanId(linkedPlan?.id ?? '');
    setSlotError(null);
    setShowSlotDialog(true);
  };

  const handleLessonPickerChange = (nextPlanId: string) => {
    setSlotLessonPlanId(nextPlanId);
    if (!nextPlanId) return;
    const lp = state.lessonPlans.find((item) => item.id === nextPlanId);
    if (lp) {
      setSlotSubjectId(lp.subjectId);
      setSlotTeacherId(lp.teacherId);
    }
  };

  const handleSaveSlot = (e: FormEvent) => {
    e.preventDefault();
    void runLockedAction('Saving timetable slot...', () => {
      const res = upsertTimetableSlot(state, {
        id: editingSlotId ?? undefined,
        classroomId: slotClassroomId,
        subjectId: slotSubjectId,
        teacherId: slotTeacherId,
        day: slotDay,
        period: slotPeriod,
        timeRange: `${slotStartTime} - ${slotEndTime}`,
        room: slotRoom,
        lessonPlanId: slotLessonPlanId,
      });
      if (res.error) {
        setSlotError(res.error);
        showFeedback('error', res.error);
        return;
      }
      setSlotError(null);
      setShowSlotDialog(false);
      setSelectedClassroomId(slotClassroomId);
      onStateChange(res.state);
      showFeedback('success', 'Timetable slot saved');
    });
  };

  const openDaysModal = () => {
    setEditingDayId(null);
    setDayCode('');
    setDayLabel('');
    setDayOrder(state.scheduleDays.length + 1);
    setDayDefaultTime('09:00 - 10:00');
    setDayClassroomIds(state.classrooms.map((c) => c.id));
    setDayError(null);
    setShowDaysDialog(true);
  };

  const startEditDay = (day: ScheduleDayEntity) => {
    setEditingDayId(day.id);
    setDayCode(day.code);
    setDayLabel(day.label);
    setDayOrder(day.order);
    setDayDefaultTime(day.defaultTimeRange);
    setDayClassroomIds(day.classroomIds);
    setDayError(null);
  };

  const handleSaveDay = (e: FormEvent) => {
    e.preventDefault();
    void runLockedAction('Saving schedule day...', () => {
      const res = upsertScheduleDay(state, {
        id: editingDayId ?? undefined,
        code: dayCode,
        label: dayLabel,
        order: dayOrder,
        classroomIds: dayClassroomIds,
        defaultTimeRange: dayDefaultTime,
      });
      if (res.error) {
        setDayError(res.error);
        showFeedback('error', res.error);
        return;
      }
      setEditingDayId(null);
      setDayCode('');
      setDayLabel('');
      setDayOrder(res.state.scheduleDays.length + 1);
      setDayError(null);
      onStateChange(res.state);
      showFeedback('success', 'Schedule day saved');
    });
  };

  const handleSaveClassroom = (e: FormEvent) => {
    e.preventDefault();
    void runLockedAction('Saving classroom...', () => {
      const res = upsertClassroom(
        state,
        {
          name: className,
          gradeLevel: classGrade,
          roomCode: classRoom,
          classTeacherId: classTeacherId || undefined,
          defaultDayIds: classDayIds,
        },
        actor
      );
      if (res.error) {
        setClassError(res.error);
        showFeedback('error', res.error);
        return;
      }
      setClassError(null);
      setClassName('');
      setShowClassDialog(false);
      if (res.classroom) setSelectedClassroomId(res.classroom.id);
      onStateChange(res.state);
      showFeedback('success', 'Classroom saved');
    });
  };

  const dialogDayOptions = (() => {
    const mapped = getScheduleDaysForClassroom(state, slotClassroomId);
    const list = mapped.length > 0 ? mapped : state.scheduleDays;
    if (!list.some((d) => d.code === slotDay) && slotDay) {
      return [
        ...list,
        {
          id: `temp_${slotDay}`,
          code: slotDay,
          label: slotDay,
          order: 99,
          classroomIds: [slotClassroomId],
          defaultTimeRange: '08:00 - 08:45',
        },
      ];
    }
    return list;
  })();

  const sortedAllDays = [...(state.scheduleDays ?? [])].sort(
    (a, b) => a.order - b.order
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            Master Timetable &amp; Class-Day Scheduler
          </h2>
          <p className="mt-0.5 text-sm text-slate-600">
            Map active days to classrooms, assign teachers and specific time blocks, and bind registered lessons directly onto the schedule.
          </p>
          {(() => {
            const cls = state.classrooms.find((c) => c.id === resolvedClassroomId);
            const homeroom = cls?.classTeacherId
              ? state.teachers.find((t) => t.id === cls.classTeacherId)
              : undefined;
            if (!cls) return null;
            return (
              <p className="mt-1 text-xs text-slate-500">
                Active Class: <span className="font-semibold text-slate-800">{cls.name}</span> · Class Teacher:{' '}
                <span className="font-semibold text-blue-700">
                  {homeroom?.name ?? 'Unassigned'}
                </span>
                {cls.updatedBy && cls.updatedAt
                  ? ` · Updated ${cls.updatedBy} (${cls.updatedAt})`
                  : ''}
              </p>
            );
          })()}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex rounded-lg bg-slate-100 p-1">
            <button
              type="button"
              onClick={() => setViewMode('classroom')}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors ${
                viewMode === 'classroom'
                  ? 'bg-white text-blue-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Class View
            </button>
            <button
              type="button"
              onClick={() => setViewMode('matrix')}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors ${
                viewMode === 'matrix'
                  ? 'bg-white text-blue-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Classes Active
            </button>
          </div>

          {viewMode === 'classroom' && (
            <select
              aria-label="Filter timetable by classroom"
              value={resolvedClassroomId}
              onChange={(e) => setSelectedClassroomId(e.target.value)}
              className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
            >
              {state.classrooms.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          )}

          {isAdmin && (
            <>
              <button
                type="button"
                onClick={openDaysModal}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap shrink-0"
              >
                <CalendarDays className="h-3.5 w-3.5" aria-hidden="true" />
                Manage Days
              </button>
              <button
                type="button"
                onClick={() => {
                  setClassError(null);
                  setClassDayIds(state.scheduleDays.map((d) => d.id));
                  setShowClassDialog(true);
                }}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap shrink-0"
              >
                <School className="h-3.5 w-3.5" aria-hidden="true" />
                Add Class
              </button>
              <button
                type="button"
                onClick={() => openCreateSlotDialog()}
                className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800 whitespace-nowrap shrink-0"
              >
                <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                Add Slot
              </button>
            </>
          )}
        </div>
      </div>

      {viewMode === 'classroom' ? (
        classroomDays.length === 0 ? (
          <div className="rounded-xl border border-slate-200 bg-white p-8 text-center">
            <p className="text-sm font-medium text-slate-700">
              No active days are mapped to this classroom yet.
            </p>
            {isAdmin && (
              <button
                type="button"
                onClick={openDaysModal}
                className="mt-3 rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
              >
                Map Schedule Days to Classroom
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-5">
            {classroomDays.map((day) => {
              const daySlots = slots
                .filter((s) => s.day.toLowerCase() === day.code.toLowerCase())
                .sort((a, b) => a.period - b.period);

              return (
                <section
                  key={day.id}
                  className="rounded-xl border border-slate-200 bg-white p-4"
                >
                  <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-2">
                    <div>
                      <h3 className="font-display text-sm font-bold text-slate-900">
                        {day.code} · {day.label}
                      </h3>
                      <p className="text-[11px] text-slate-500">
                        Default {day.defaultTimeRange}
                      </p>
                    </div>
                    {isAdmin && (
                      <button
                        type="button"
                        aria-label={`Add slot on ${day.code}`}
                        onClick={() =>
                          openCreateSlotDialog({
                            classroomId: resolvedClassroomId,
                            dayCode: day.code,
                          })
                        }
                        className="rounded-md border border-slate-200 p-1 text-slate-600 hover:border-blue-600 hover:text-blue-700"
                      >
                        <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                    )}
                  </div>

                  {daySlots.length === 0 ? (
                    <p className="mt-4 text-xs text-slate-400">
                      No periods scheduled
                    </p>
                  ) : (
                    <div className="mt-3 space-y-3">
                      {daySlots.map((slot) => {
                        const subj = state.subjects.find(
                          (s) => s.id === slot.subjectId
                        );
                        const teacher = state.teachers.find(
                          (t) => t.id === slot.teacherId
                        );
                        const linkedPlan = state.lessonPlans.find(
                          (lp) =>
                            lp.id === slot.lessonPlanId ||
                            lp.timetableSlotId === slot.id
                        );

                        return (
                          <div
                            key={slot.id}
                            className="rounded-lg border border-slate-200 bg-slate-50/70 p-3 transition-colors hover:border-blue-700 hover:bg-white"
                          >
                            <button
                              type="button"
                              onClick={() => setActiveSlotId(slot.id)}
                              className="w-full text-left"
                            >
                              <p className="font-mono text-[11px] text-slate-500 tabular-nums">
                                P{slot.period} · {slot.timeRange}
                              </p>
                              <p className="mt-1 text-sm font-semibold text-slate-900">
                                {subj?.name}
                              </p>
                              <p className="mt-0.5 text-xs text-slate-600">
                                {teacher?.name} · {slot.room}
                              </p>
                              {linkedPlan ? (
                                <p className="mt-2 border-t border-slate-200 pt-2 text-[11px] font-medium text-blue-700">
                                  Lesson: {linkedPlan.title} ({linkedPlan.status})
                                </p>
                              ) : (
                                <p className="mt-2 border-t border-slate-200 pt-2 text-[11px] text-slate-400">
                                  Open slot (no registered lesson bound)
                                </p>
                              )}
                            </button>
                            {isAdmin && (
                              <div className="mt-2 flex items-center justify-end gap-1 border-t border-slate-100 pt-2">
                                <button
                                  type="button"
                                  onClick={() => openEditSlotDialog(slot)}
                                  className="inline-flex items-center gap-1 rounded border border-slate-200 bg-white px-2 py-0.5 text-[11px] font-medium text-slate-700 hover:bg-slate-100"
                                >
                                  <Pencil
                                    className="h-3 w-3"
                                    aria-hidden="true"
                                  />
                                  Edit
                                </button>
                                <button
                                  type="button"
                                  disabled={isBusy}
                                  aria-label={`Delete slot ${slot.day} P${slot.period}`}
                                  onClick={() =>
                                    void runLockedAction('Deleting timetable slot...', () => {
                                      onStateChange(
                                        deleteTimetableSlot(state, slot.id)
                                      );
                                      showFeedback('warning', 'Timetable slot deleted');
                                    })
                                  }
                                  className="inline-flex items-center rounded border border-red-200 bg-white px-1.5 py-0.5 text-[11px] font-medium text-red-600 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50"
                                >
                                  <Trash2
                                    className="h-3 w-3"
                                    aria-hidden="true"
                                  />
                                </button>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </section>
              );
            })}
          </div>
        )
      ) : (
        /* School-wide All Classes Active ("Classes Come On") Matrix */
        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                <th className="px-4 py-3 font-semibold">Day</th>
                {state.classrooms.map((cls) => (
                  <th key={cls.id} className="px-4 py-3 font-semibold">
                    {cls.name} ({cls.roomCode})
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {sortedAllDays.map((day) => (
                <tr key={day.id} className="align-top">
                  <td className="px-4 py-3 font-semibold text-slate-900 whitespace-nowrap">
                    <div>{day.code}</div>
                    <div className="font-normal text-[11px] text-slate-500">
                      {day.label}
                    </div>
                  </td>
                  {state.classrooms.map((cls) => {
                    const isMapped = day.classroomIds.includes(cls.id);
                    const cellSlots = state.timetableSlots
                      .filter(
                        (s) =>
                          s.classroomId === cls.id &&
                          s.day.toLowerCase() === day.code.toLowerCase()
                      )
                      .sort((a, b) => a.period - b.period);

                    return (
                      <td key={cls.id} className="min-w-[220px] px-4 py-3">
                        {!isMapped ? (
                          <div className="flex items-center justify-between gap-2 text-slate-400">
                            <span>Class off</span>
                            {isAdmin && (
                              <button
                                type="button"
                                disabled={isBusy}
                                onClick={() =>
                                  void runLockedAction('Updating class day schedule...', () => {
                                    onStateChange(
                                      toggleDayClassroomMapping(
                                        state,
                                        day.id,
                                        cls.id
                                      )
                                    );
                                    showFeedback('info', 'Class day schedule updated');
                                  })
                                }
                                className="rounded border border-slate-200 px-2 py-0.5 text-[11px] font-medium text-blue-700 hover:bg-blue-50 disabled:cursor-not-allowed disabled:opacity-50"
                              >
                                Turn Class On
                              </button>
                            )}
                          </div>
                        ) : (
                          <div className="space-y-2">
                            {cellSlots.map((slot) => {
                              const subj = state.subjects.find(
                                (s) => s.id === slot.subjectId
                              );
                              const teacher = state.teachers.find(
                                (t) => t.id === slot.teacherId
                              );
                              const plan = state.lessonPlans.find(
                                (lp) =>
                                  lp.id === slot.lessonPlanId ||
                                  lp.timetableSlotId === slot.id
                              );
                              return (
                                <button
                                  key={slot.id}
                                  type="button"
                                  onClick={() =>
                                    isAdmin
                                      ? openEditSlotDialog(slot)
                                      : setActiveSlotId(slot.id)
                                  }
                                  className="block w-full rounded-lg border border-slate-200 bg-slate-50 p-2 text-left hover:border-blue-600 hover:bg-white"
                                >
                                  <div className="font-mono text-[10px] text-slate-500">
                                    P{slot.period} · {slot.timeRange} ·{' '}
                                    {slot.room}
                                  </div>
                                  <div className="font-semibold text-slate-900">
                                    {subj?.name} — {teacher?.name}
                                  </div>
                                  {plan && (
                                    <div className="truncate text-[11px] text-blue-700">
                                      {plan.title}
                                    </div>
                                  )}
                                </button>
                              );
                            })}
                            {isAdmin && (
                              <button
                                type="button"
                                onClick={() =>
                                  openCreateSlotDialog({
                                    classroomId: cls.id,
                                    dayCode: day.code,
                                  })
                                }
                                className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-700 hover:underline"
                              >
                                <Plus className="h-3 w-3" aria-hidden="true" />
                                Add Slot
                              </button>
                            )}
                          </div>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Unassigned Registered Lessons Queue */}
      {isAdmin && (
        <section className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h3 className="font-display text-sm font-bold text-slate-900">
                Unassigned Registered Lessons ({unassignedLessons.length})
              </h3>
              <p className="text-xs text-slate-600">
                Registered lessons from the Lessons Registry ready to assign onto a Timetable slot with teacher and time.
              </p>
            </div>
          </div>
          {unassignedLessons.length === 0 ? (
            <p className="pt-3 text-xs text-slate-500">
              All registered lessons are currently scheduled on the Timetable.
            </p>
          ) : (
            <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
              {unassignedLessons.map((lp) => {
                const cls = state.classrooms.find(
                  (c) => c.id === lp.classroomId
                );
                const subj = state.subjects.find((s) => s.id === lp.subjectId);
                const tch = state.teachers.find((t) => t.id === lp.teacherId);
                return (
                  <div
                    key={lp.id}
                    className="flex items-start justify-between gap-3 rounded-lg border border-slate-200 bg-slate-50 p-3"
                  >
                    <div className="min-w-0">
                      <p className="text-[11px] text-slate-500">
                        {cls?.name} · {subj?.code}
                      </p>
                      <p className="truncate text-xs font-bold text-slate-900">
                        {lp.title}
                      </p>
                      <p className="text-[11px] text-slate-600">
                        {tch?.name} · {lp.scheduledDate}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => openCreateSlotDialog({ lessonPlan: lp })}
                      className="rounded-md bg-blue-700 px-2.5 py-1.5 text-[11px] font-semibold text-white hover:bg-blue-800 whitespace-nowrap shrink-0"
                    >
                      Assign Slot
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      )}

      {/* Period & Linked Lesson Plan Dialog */}
      <AppDialog
        open={Boolean(activeSlot)}
        busy={isBusy}
        title={
          activeSlot
            ? `${activeSlot.day} Period ${activeSlot.period} · ${activeSlotSubject?.name}`
            : ''
        }
        subtitle={
          activeSlot
            ? `${activeSlot.timeRange} · Room ${activeSlot.room} · ${activeSlotTeacher?.name}`
            : ''
        }
        onClose={() => setActiveSlotId(null)}
      >
        {activeSlot && (
          <div className="space-y-4">
            {activeSlotPlan ? (
              <>
                <div>
                  <p className="text-xs text-slate-500">
                    Linked Schemes Substrand: {activeSlotSubstrand?.code}{' '}
                    {activeSlotSubstrand?.title}
                  </p>
                  <h4 className="mt-1 font-display text-base font-bold text-slate-900">
                    {activeSlotPlan.title}
                  </h4>
                  {activeSlotPlan.reflectionNote && (
                    <p className="mt-1.5 text-xs text-slate-600">
                      {activeSlotPlan.reflectionNote}
                    </p>
                  )}
                </div>

                <div className="flex items-center justify-between border-t border-slate-200 pt-3 text-xs">
                  <span className="font-medium text-slate-700">
                    Current Status:{' '}
                    <strong className="capitalize text-slate-900">
                      {activeSlotPlan.status.replace('_', ' ')}
                    </strong>
                  </span>
                  <span className="font-mono text-slate-600 tabular-nums">
                    {activeSlotPlan.lessonsDelivered} /{' '}
                    {activeSlotSubstrand?.targetLessons ?? 1} lessons
                  </span>
                </div>

                {canEdit && (
                  <div className="space-y-3 pt-1">
                    <div className="flex flex-wrap gap-2">
                      {(['planned', 'in_progress', 'taught'] as LessonStatus[]).map(
                        (nextStatus) => (
                          <button
                            key={nextStatus}
                            type="button"
                            disabled={isBusy}
                            onClick={() =>
                              void runLockedAction('Updating lesson status...', () => {
                                onStateChange(
                                  updateLessonStatus(
                                    state,
                                    activeSlotPlan.id,
                                    nextStatus,
                                    nextStatus === 'taught'
                                      ? Math.max(2, activeSlotPlan.lessonsDelivered)
                                      : nextStatus === 'in_progress'
                                        ? Math.max(
                                            1,
                                            activeSlotPlan.lessonsDelivered
                                          )
                                        : 0,
                                    activeTeacherId || activeSlotPlan.teacherId,
                                    actor
                                  )
                                );
                                showFeedback(
                                  nextStatus === 'taught' ? 'success' : 'info',
                                  `Lesson marked ${nextStatus.replace('_', ' ')}`
                                );
                              })
                            }
                            className={`rounded-lg px-3 py-1.5 text-xs font-semibold disabled:cursor-not-allowed disabled:opacity-60 ${
                              activeSlotPlan.status === nextStatus
                                ? 'bg-blue-700 text-white'
                                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                            }`}
                          >
                            {nextStatus === 'taught'
                              ? 'Mark Taught'
                              : nextStatus === 'in_progress'
                                ? 'In Progress'
                                : 'Planned'}
                          </button>
                        )
                      )}
                    </div>

                    {activeSlotPlan.status === 'taught' && onOpenHomeworkDialog && (
                      <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2.5">
                        <span className="text-xs font-medium text-emerald-900">
                          Lesson taught — add homework to the class diary?
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            const targetSlot = activeSlot;
                            const targetPlan = activeSlotPlan;
                            setActiveSlotId(null);
                            onOpenHomeworkDialog({
                              classroomId: targetSlot.classroomId,
                              date: '2026-11-25',
                              homeworkSummary: `Practice exercises from "${targetPlan.title}"`,
                              teacherNote: `Completed lesson: ${targetPlan.title}`,
                            });
                          }}
                          className="rounded-md bg-emerald-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800 whitespace-nowrap shrink-0"
                        >
                          Add Homework to Diary
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </>
            ) : (
              <div className="space-y-3">
                <p className="text-sm text-slate-600">
                  No lesson plan is linked to this period yet.
                </p>
                {canEdit && onCreateLessonFromSlot && (
                  <button
                    type="button"
                    disabled={isBusy}
                    onClick={() => {
                      const slot = activeSlot;
                      setActiveSlotId(null);
                      onCreateLessonFromSlot({
                        classroomId: slot.classroomId,
                        subjectId: slot.subjectId,
                        teacherId: slot.teacherId,
                        timetableSlotId: slot.id,
                        scheduledDate: '2026-11-25',
                      });
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800 whitespace-nowrap shrink-0"
                  >
                    <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                    Create Prefilled Lesson
                  </button>
                )}
                {isAdmin && state.lessonPlans.length > 0 && (
                  <div>
                    <label
                      htmlFor="quick-bind-lesson"
                      className="mb-1 block text-xs font-medium text-slate-700"
                    >
                      Or Quick-Assign Existing Lesson Plan
                    </label>
                    <select
                      id="quick-bind-lesson"
                      disabled={isBusy}
                      defaultValue=""
                      onChange={(e) => {
                        const chosen = e.target.value;
                        if (!chosen) return;
                        void runLockedAction('Binding lesson to period...', () => {
                          const res = assignLessonToTimetableSlot(state, {
                            lessonPlanId: chosen,
                            timetableSlotId: activeSlot.id,
                            syncSlotSubjectAndTeacher: true,
                          });
                          if (res.error) {
                            showFeedback('error', res.error);
                            return;
                          }
                          onStateChange(res.state);
                          showFeedback('info', 'Lesson bound to period');
                        });
                      }}
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none disabled:opacity-60"
                    >
                      <option value="">Choose registered lesson...</option>
                      {state.lessonPlans.map((lp) => (
                        <option key={lp.id} value={lp.id}>
                          {lp.title}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
            )}

            {isAdmin && (
              <div className="flex justify-end gap-2 border-t border-slate-200 pt-3">
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() => {
                    const target = activeSlot;
                    setActiveSlotId(null);
                    openEditSlotDialog(target);
                  }}
                  className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-50 disabled:opacity-50"
                >
                  Edit / Reassign Slot
                </button>
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() =>
                    void runLockedAction('Deleting timetable slot...', () => {
                      const id = activeSlot.id;
                      setActiveSlotId(null);
                      onStateChange(deleteTimetableSlot(state, id));
                      showFeedback('warning', 'Timetable slot deleted');
                    })
                  }
                  className="rounded-lg border border-red-200 bg-red-50 px-3 py-1.5 text-xs font-semibold text-red-700 hover:bg-red-100 disabled:opacity-50"
                >
                  Delete Slot
                </button>
              </div>
            )}
          </div>
        )}
      </AppDialog>

      {/* Admin Add / Edit Timetable Slot Dialog */}
      <AppDialog
        open={showSlotDialog}
        busy={isBusy}
        title={editingSlotId ? 'Edit Timetable Slot' : 'Schedule Timetable Slot'}
        subtitle="Assign classroom, mapped day, specific time, teacher, room, and optionally bind a registered lesson."
        onClose={() => setShowSlotDialog(false)}
      >
        <form onSubmit={handleSaveSlot} className="space-y-4">
          <fieldset disabled={isBusy} className="space-y-4">
          <div>
            <label
              htmlFor="tt-lesson-plan"
              className="mb-1 block text-xs font-medium text-slate-700"
            >
              Bind Registered Lesson (Optional — auto-fills Subject &amp; Teacher)
            </label>
            <select
              id="tt-lesson-plan"
              value={slotLessonPlanId}
              onChange={(e) => handleLessonPickerChange(e.target.value)}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
            >
              <option value="">Open Period Slot (No Lesson Assigned)</option>
              {state.lessonPlans.map((lp) => {
                const subj = state.subjects.find((s) => s.id === lp.subjectId);
                return (
                  <option key={lp.id} value={lp.id}>
                    {lp.title} ({subj?.code ?? lp.subjectId}
                    {lp.timetableSlotId && lp.timetableSlotId !== editingSlotId
                      ? ' — currently scheduled'
                      : ''}
                    )
                  </option>
                );
              })}
            </select>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label
                htmlFor="tt-classroom"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Classroom
              </label>
              <select
                id="tt-classroom"
                value={slotClassroomId}
                onChange={(e) => {
                  const nextCls = e.target.value;
                  setSlotClassroomId(nextCls);
                  const cls = state.classrooms.find((c) => c.id === nextCls);
                  if (cls && !editingSlotId) setSlotRoom(cls.roomCode);
                  const mapped = getScheduleDaysForClassroom(state, nextCls);
                  if (
                    mapped.length > 0 &&
                    !mapped.some((d) => d.code === slotDay)
                  ) {
                    setSlotDay(mapped[0].code);
                  }
                }}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              >
                {state.classrooms.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label
                htmlFor="tt-subject"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Subject
              </label>
              <select
                id="tt-subject"
                value={slotSubjectId}
                onChange={(e) => setSlotSubjectId(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              >
                {state.subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div>
              <label
                htmlFor="tt-teacher"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Teacher
              </label>
              <select
                id="tt-teacher"
                value={slotTeacherId}
                onChange={(e) => setSlotTeacherId(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              >
                {state.teachers.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label
                htmlFor="tt-day"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Mapped Day
              </label>
              <select
                id="tt-day"
                value={slotDay}
                onChange={(e) => setSlotDay(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              >
                {dialogDayOptions.map((d) => (
                  <option key={d.id} value={d.code}>
                    {d.code} — {d.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label
                htmlFor="tt-period"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Period #
              </label>
              <input
                id="tt-period"
                type="number"
                min={1}
                max={12}
                value={slotPeriod}
                onChange={(e) => setSlotPeriod(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm tabular-nums focus:border-blue-700 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div>
              <label
                htmlFor="tt-start-time"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Start Time
              </label>
              <input
                id="tt-start-time"
                type="time"
                value={slotStartTime}
                onChange={(e) => setSlotStartTime(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>
            <div>
              <label
                htmlFor="tt-end-time"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                End Time
              </label>
              <input
                id="tt-end-time"
                type="time"
                value={slotEndTime}
                onChange={(e) => setSlotEndTime(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>
            <div>
              <label
                htmlFor="tt-room"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Room
              </label>
              <input
                id="tt-room"
                type="text"
                value={slotRoom}
                onChange={(e) => setSlotRoom(e.target.value)}
                placeholder="B2-04"
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>
          </div>

          {slotError && (
            <p className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs font-medium text-red-700">
              {slotError}
            </p>
          )}

          <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
            <div>
              {editingSlotId && (
                <button
                  type="button"
                  onClick={() =>
                    void runLockedAction('Deleting timetable slot...', () => {
                      onStateChange(deleteTimetableSlot(state, editingSlotId));
                      setShowSlotDialog(false);
                      showFeedback('warning', 'Timetable slot deleted');
                    })
                  }
                  className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs font-semibold text-red-700 hover:bg-red-100"
                >
                  Delete Slot
                </button>
              )}
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setShowSlotDialog(false)}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </button>
              <ActionSubmitButton
                idleLabel={editingSlotId ? 'Update Slot' : 'Save Timetable Slot'}
                busyLabel="Saving..."
                className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
              />
            </div>
          </div>
          </fieldset>
        </form>
      </AppDialog>

      {/* Admin Manage Schedule Days & Classroom Mapping Dialog */}
      <AppDialog
        open={showDaysDialog}
        busy={isBusy}
        title="Schedule Days & Class Mapping"
        subtitle="Add custom instructional days (e.g., Sat Clinic, Sun Lab) and choose which classes come on each day."
        onClose={() => setShowDaysDialog(false)}
        maxWidthClass="max-w-2xl"
      >
        <div className="space-y-5">
          <div className="space-y-2">
            {sortedAllDays.map((day) => (
              <div
                key={day.id}
                className="rounded-lg border border-slate-200 bg-slate-50 p-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="font-mono text-xs font-bold text-slate-900">
                      #{day.order} {day.code}
                    </span>{' '}
                    <span className="text-xs font-semibold text-slate-800">
                      — {day.label}
                    </span>{' '}
                    <span className="text-[11px] text-slate-500">
                      ({day.defaultTimeRange})
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={() => startEditDay(day)}
                      className="rounded border border-slate-200 bg-white px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 disabled:opacity-50"
                    >
                      Edit
                    </button>
                    {state.scheduleDays.length > 1 && (
                      <button
                        type="button"
                        disabled={isBusy}
                        aria-label={`Delete day ${day.code}`}
                        onClick={() =>
                          void runLockedAction('Removing schedule day...', () => {
                            onStateChange(deleteScheduleDay(state, day.id));
                            showFeedback('warning', 'Schedule day removed');
                          })
                        }
                        className="rounded border border-red-200 bg-white px-2 py-1 text-[11px] font-medium text-red-600 hover:bg-red-50 disabled:opacity-50"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                </div>
                <div className="mt-2 flex flex-wrap gap-2">
                  {state.classrooms.map((cls) => {
                    const active = day.classroomIds.includes(cls.id);
                    return (
                      <label
                        key={cls.id}
                        className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-2.5 py-1 text-[11px] font-medium text-slate-700"
                      >
                        <input
                          type="checkbox"
                          disabled={isBusy}
                          checked={active}
                          onChange={() =>
                            void runLockedAction('Updating class day schedule...', () => {
                              onStateChange(
                                toggleDayClassroomMapping(state, day.id, cls.id)
                              );
                              showFeedback('info', 'Class day schedule updated');
                            })
                          }
                          className="h-3.5 w-3.5 rounded border-slate-300 text-blue-700 disabled:opacity-50"
                        />
                        {cls.name}
                      </label>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          <form
            onSubmit={handleSaveDay}
            className="space-y-3 rounded-lg border border-slate-200 bg-white p-4"
          >
            <fieldset disabled={isBusy} className="space-y-3">
            <h4 className="text-xs font-bold text-slate-900">
              {editingDayId ? 'Edit Schedule Day' : 'Add New Schedule Day'}
            </h4>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-4">
              <div>
                <label
                  htmlFor="day-code"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Short Code *
                </label>
                <input
                  id="day-code"
                  type="text"
                  value={dayCode}
                  onChange={(e) => setDayCode(e.target.value)}
                  placeholder="Sat"
                  className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs focus:border-blue-700 focus:outline-none"
                />
              </div>
              <div>
                <label
                  htmlFor="day-label"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Day Name
                </label>
                <input
                  id="day-label"
                  type="text"
                  value={dayLabel}
                  onChange={(e) => setDayLabel(e.target.value)}
                  placeholder="Saturday Clinic"
                  className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs focus:border-blue-700 focus:outline-none"
                />
              </div>
              <div>
                <label
                  htmlFor="day-order"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Order
                </label>
                <input
                  id="day-order"
                  type="number"
                  min={1}
                  max={14}
                  value={dayOrder}
                  onChange={(e) => setDayOrder(Number(e.target.value))}
                  className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs tabular-nums focus:border-blue-700 focus:outline-none"
                />
              </div>
              <div>
                <label
                  htmlFor="day-time"
                  className="mb-1 block text-xs font-medium text-slate-700"
                >
                  Default Time
                </label>
                <input
                  id="day-time"
                  type="text"
                  value={dayDefaultTime}
                  onChange={(e) => setDayDefaultTime(e.target.value)}
                  placeholder="09:00 - 10:00"
                  className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs focus:border-blue-700 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <p className="mb-1.5 text-xs font-medium text-slate-700">
                Map to Classes (Classes Coming On This Day)
              </p>
              <div className="flex flex-wrap gap-2">
                {state.classrooms.map((cls) => (
                  <label
                    key={cls.id}
                    className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs text-slate-800"
                  >
                    <input
                      type="checkbox"
                      checked={dayClassroomIds.includes(cls.id)}
                      onChange={() =>
                        setDayClassroomIds((prev) =>
                          prev.includes(cls.id)
                            ? prev.filter((id) => id !== cls.id)
                            : [...prev, cls.id]
                        )
                      }
                      className="h-3.5 w-3.5 rounded border-slate-300 text-blue-700"
                    />
                    {cls.name}
                  </label>
                ))}
              </div>
            </div>

            {dayError && (
              <p className="text-xs font-medium text-red-600">{dayError}</p>
            )}

            <div className="flex justify-end gap-2">
              {editingDayId && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingDayId(null);
                    setDayCode('');
                    setDayLabel('');
                  }}
                  className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700"
                >
                  Cancel Edit
                </button>
              )}
              <ActionSubmitButton
                idleLabel={editingDayId ? 'Update Day' : 'Add Day & Map Classes'}
                busyLabel="Saving..."
                className="rounded-lg bg-blue-700 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-blue-800"
              />
            </div>
            </fieldset>
          </form>
        </div>
      </AppDialog>

      {/* Admin Add Classroom Dialog */}
      <AppDialog
        open={showClassDialog}
        busy={isBusy}
        title="Add New Classroom"
        subtitle="Create a class and map which schedule days it runs on."
        onClose={() => setShowClassDialog(false)}
      >
        <form onSubmit={handleSaveClassroom} className="space-y-4">
          <fieldset disabled={isBusy} className="space-y-4">
          <div>
            <label
              htmlFor="cls-name"
              className="mb-1 block text-xs font-medium text-slate-700"
            >
              Classroom Name *
            </label>
            <input
              id="cls-name"
              type="text"
              value={className}
              onChange={(e) => setClassName(e.target.value)}
              placeholder="e.g. Grade 7A — Savannah"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="cls-grade"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Grade Level *
              </label>
              <input
                id="cls-grade"
                type="text"
                value={classGrade}
                onChange={(e) => setClassGrade(e.target.value)}
                placeholder="Grade 7"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>
            <div>
              <label
                htmlFor="cls-room"
                className="mb-1 block text-xs font-medium text-slate-700"
              >
                Home Room Code *
              </label>
              <input
                id="cls-room"
                type="text"
                value={classRoom}
                onChange={(e) => setClassRoom(e.target.value)}
                placeholder="C1-02"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="cls-teacher"
              className="mb-1 block text-xs font-medium text-slate-700"
            >
              Class Teacher (Homeroom Lead)
            </label>
            <select
              id="cls-teacher"
              value={classTeacherId}
              onChange={(e) => setClassTeacherId(e.target.value)}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-blue-700 focus:outline-none"
            >
              <option value="">Unassigned</option>
              {state.teachers.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <p className="mb-1.5 text-xs font-medium text-slate-700">
              Active Schedule Days
            </p>
            <div className="flex flex-wrap gap-2">
              {sortedAllDays.map((d) => (
                <label
                  key={d.id}
                  className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs text-slate-800"
                >
                  <input
                    type="checkbox"
                    checked={classDayIds.includes(d.id)}
                    onChange={() =>
                      setClassDayIds((prev) =>
                        prev.includes(d.id)
                          ? prev.filter((id) => id !== d.id)
                          : [...prev, d.id]
                      )
                    }
                    className="h-3.5 w-3.5 rounded border-slate-300 text-blue-700"
                  />
                  {d.code}
                </label>
              ))}
            </div>
          </div>

          {classError && (
            <p className="text-xs font-medium text-red-600">{classError}</p>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setShowClassDialog(false)}
              className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700"
            >
              Cancel
            </button>
            <ActionSubmitButton
              idleLabel="Save Classroom"
              busyLabel="Saving..."
              className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
            />
          </div>
          </fieldset>
        </form>
      </AppDialog>
    </div>
  );
}

interface RegisterModuleProps {
  state: SchoolECSState;
  role: Role;
  activeTeacherId: string;
  activeLearnerId: string;
  stickyClassroomId?: string;
  stickyDate?: string;
  onChangeRegisterPrefs?: (next: { classroomId: string; date: string }) => void;
  actor?: AuditActor;
  onStateChange: (next: SchoolECSState) => void;
  onOpenLearnerPage: (learnerId: string) => void;
}

export function ClassRegisterModule({
  state,
  role,
  activeTeacherId,
  activeLearnerId,
  stickyClassroomId,
  stickyDate,
  onChangeRegisterPrefs,
  actor,
  onStateChange,
  onOpenLearnerPage,
}: RegisterModuleProps) {
  const { isBusy, runLockedAction, showFeedback } = useActionFeedback();
  const [date, setDate] = useState(stickyDate || '2026-11-25');
  const [selectedClassroomId, setSelectedClassroomId] = useState(
    stickyClassroomId && state.classrooms.some((c) => c.id === stickyClassroomId)
      ? stickyClassroomId
      : (state.classrooms[0]?.id ?? '')
  );
  const [searchQuery, setSearchQuery] = useState('');

  const resolvedClassroomId = state.classrooms.some(
    (c) => c.id === selectedClassroomId
  )
    ? selectedClassroomId
    : (state.classrooms[0]?.id ?? '');

  const handleSelectClassroom = (nextClassroomId: string) => {
    setSelectedClassroomId(nextClassroomId);
    onChangeRegisterPrefs?.({ classroomId: nextClassroomId, date });
  };

  const handleSelectDate = (nextDate: string) => {
    setDate(nextDate);
    onChangeRegisterPrefs?.({ classroomId: resolvedClassroomId, date: nextDate });
  };

  const registerFields = getFieldsForEntity(state, 'attendance_record', role);
  const canEdit = role === 'admin' || role === 'teacher';

  const baseLearners = useMemo(
    () =>
      role === 'parent'
        ? state.learners.filter((l) => l.id === activeLearnerId)
        : state.learners.filter((l) => l.classroomId === resolvedClassroomId),
    [state.learners, role, activeLearnerId, resolvedClassroomId]
  );

  const learners = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return baseLearners;
    return baseLearners.filter(
      (l) =>
        l.name.toLowerCase().includes(q) ||
        l.admissionNo.toLowerCase().includes(q)
    );
  }, [baseLearners, searchQuery]);

  const rollCounts = useMemo(() => {
    let present = 0;
    let late = 0;
    let absent = 0;
    let excused = 0;
    let uniformCompliant = 0;
    for (const learner of baseLearners) {
      const rec = state.attendanceRecords.find(
        (r) => r.learnerId === learner.id && r.date === date
      );
      const st = rec?.status ?? 'present';
      if (st === 'present') present += 1;
      else if (st === 'late') late += 1;
      else if (st === 'absent') absent += 1;
      else excused += 1;
      if (rec?.customFields?.uniform_compliant ?? true) {
        uniformCompliant += 1;
      }
    }
    return { present, late, absent, excused, uniformCompliant };
  }, [baseLearners, state.attendanceRecords, date]);

  const handleMarkAllPresent = () => {
    void runLockedAction('Marking class attendance...', () => {
      const res = markClassroomAllPresent(
        state,
        {
          classroomId: resolvedClassroomId,
          teacherId: activeTeacherId,
          date,
        },
        actor
      );
      if (res.error) {
        showFeedback('error', res.error);
        return;
      }
      onStateChange(res.state);
      showFeedback('success', `Marked ${res.count} learners present`);
    });
  };

  const handleCopySameAsYesterday = () => {
    void runLockedAction('Copying previous register...', () => {
      const res = copyClassroomAttendanceFromDate(
        state,
        {
          classroomId: resolvedClassroomId,
          teacherId: activeTeacherId,
          toDate: date,
        },
        actor
      );
      if (res.error) {
        showFeedback('error', res.error);
        return;
      }
      onStateChange(res.state);
      showFeedback(
        'success',
        `Copied ${res.count} attendance marks from ${res.sourceDate}`
      );
    });
  };

  const handleMark = (learnerId: string, status: AttendanceStatus) => {
    void runLockedAction('Saving attendance...', () => {
      const existing = state.attendanceRecords.find(
        (r) => r.learnerId === learnerId && r.date === date
      );
      const res = upsertAttendanceRecord(
        state,
        {
          learnerId,
          teacherId: activeTeacherId,
          date,
          status,
          remark: existing?.remark || 'Updated via Class Register.',
          customFields: existing?.customFields ?? { uniform_compliant: true },
        },
        actor
      );
      if (res.error) {
        showFeedback('error', res.error);
        return;
      }
      onStateChange(res.state);
      const learnerName =
        state.learners.find((l) => l.id === learnerId)?.name ?? 'Learner';
      const variant =
        status === 'present' || status === 'excused' ? 'success' : 'info';
      showFeedback(variant, `Attendance marked: ${learnerName} (${status})`);
    });
  };

  const handleToggleUniform = (learnerId: string, currentVal: boolean) => {
    void runLockedAction('Updating uniform check...', () => {
      const existing = state.attendanceRecords.find(
        (r) => r.learnerId === learnerId && r.date === date
      );
      const res = upsertAttendanceRecord(
        state,
        {
          learnerId,
          teacherId: activeTeacherId,
          date,
          status: existing?.status ?? 'present',
          remark: existing?.remark || '',
          customFields: {
            ...(existing?.customFields ?? {}),
            uniform_compliant: !currentVal,
          },
        },
        actor
      );
      if (res.error) {
        showFeedback('error', res.error);
        return;
      }
      onStateChange(res.state);
      showFeedback('info', 'Uniform compliance updated');
    });
  };

  const showUniformColumn = registerFields.some(
    (f) => f.key === 'uniform_compliant'
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            Class Register
          </h2>
          <p className="mt-0.5 text-sm text-slate-600">
            {role === 'parent'
              ? 'Child attendance history. Internal staff flags are automatically hidden.'
              : 'Daily roll call with one-tap Mark All Present and role-scoped uniform tracking.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {role !== 'parent' && (
            <div className="relative">
              <Search
                className="pointer-events-none absolute top-2.5 left-3 h-3.5 w-3.5 text-slate-400"
                aria-hidden="true"
              />
              <input
                type="search"
                aria-label="Search learner in register"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search learner or ID..."
                className="w-full rounded-lg border border-slate-300 bg-white py-2 pr-3 pl-8 text-xs text-slate-900 focus:border-blue-700 focus:outline-none sm:w-60"
              />
            </div>
          )}
          {role !== 'parent' && (
            <select
              aria-label="Filter register by classroom"
              value={resolvedClassroomId}
              onChange={(e) => handleSelectClassroom(e.target.value)}
              className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
            >
              {state.classrooms.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          )}
          <input
            aria-label="Register date"
            type="date"
            value={date}
            onChange={(e) => handleSelectDate(e.target.value)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-mono text-slate-900 focus:border-blue-700 focus:outline-none"
          />
          {canEdit && (
            <>
              <button
                type="button"
                disabled={isBusy}
                onClick={handleCopySameAsYesterday}
                className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap shrink-0 disabled:cursor-not-allowed disabled:opacity-60"
              >
                Same as Yesterday
              </button>
              <ActionSubmitButton
                type="button"
                busy={isBusy}
                disabled={isBusy}
                onClick={handleMarkAllPresent}
                idleLabel="Mark All Present"
                busyLabel="Marking..."
                icon={<CheckCheck className="h-3.5 w-3.5" aria-hidden="true" />}
                className="rounded-lg bg-emerald-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-800"
              />
            </>
          )}
        </div>
      </div>

      {/* Live Daily Roll-Call Summary */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <p className="text-[11px] text-slate-500">Present</p>
          <p className="mt-1 font-mono text-xl font-bold text-emerald-700 tabular-nums">
            {rollCounts.present}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <p className="text-[11px] text-slate-500">Late</p>
          <p className="mt-1 font-mono text-xl font-bold text-amber-700 tabular-nums">
            {rollCounts.late}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <p className="text-[11px] text-slate-500">Absent</p>
          <p className="mt-1 font-mono text-xl font-bold text-red-700 tabular-nums">
            {rollCounts.absent}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <p className="text-[11px] text-slate-500">Excused</p>
          <p className="mt-1 font-mono text-xl font-bold text-slate-700 tabular-nums">
            {rollCounts.excused}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-3.5 col-span-2 sm:col-span-1">
          <p className="text-[11px] text-slate-500">Uniform Compliant</p>
          <p className="mt-1 font-mono text-xl font-bold text-blue-700 tabular-nums">
            {rollCounts.uniformCompliant}/{baseLearners.length}
          </p>
        </div>
      </div>

      {learners.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-8 text-center">
          <p className="text-sm font-medium text-slate-800">
            No learners match your search in this register.
          </p>
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="mt-3 rounded-lg border border-slate-300 bg-white px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              Clear Search
            </button>
          )}
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
          {canEdit && (
            <p className="border-b border-slate-100 bg-slate-50/70 px-4 py-2 text-[11px] text-slate-500">
              Keyboard shortcut: focus any learner row and press <kbd className="rounded border border-slate-300 bg-white px-1 font-mono text-[10px]">P</kbd>, <kbd className="rounded border border-slate-300 bg-white px-1 font-mono text-[10px]">L</kbd>, <kbd className="rounded border border-slate-300 bg-white px-1 font-mono text-[10px]">A</kbd>, or <kbd className="rounded border border-slate-300 bg-white px-1 font-mono text-[10px]">E</kbd>.
            </p>
          )}
          <table className="w-full border-collapse text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                <th className="px-4 py-3">Admission No</th>
                <th className="px-4 py-3">Learner</th>
                <th className="px-4 py-3">Status</th>
                {showUniformColumn && (
                  <th className="px-4 py-3">Uniform Check (Staff Only)</th>
                )}
                <th className="px-4 py-3">Remark</th>
                {canEdit && <th className="px-4 py-3 text-right">Mark Roll</th>}
              </tr>
            </thead>
              <tbody className="divide-y divide-slate-200">
                {learners.map((learner) => {
                  const rec = state.attendanceRecords.find(
                    (r) => r.learnerId === learner.id && r.date === date
                  );
                  const status = rec?.status ?? 'present';
                  const uniformOk = Boolean(
                    rec?.customFields?.uniform_compliant ?? true
                  );

                  const statusColor =
                    status === 'present'
                      ? 'text-emerald-700'
                      : status === 'late'
                        ? 'text-amber-700'
                        : status === 'absent'
                          ? 'text-red-700'
                          : 'text-slate-600';
                  const statusDot =
                    status === 'present'
                      ? 'bg-emerald-600'
                      : status === 'late'
                        ? 'bg-amber-600'
                        : status === 'absent'
                          ? 'bg-red-600'
                          : 'bg-slate-400';

                  return (
                    <tr
                      key={learner.id}
                      tabIndex={canEdit ? 0 : undefined}
                      onKeyDown={(e) => {
                        if (!canEdit || isBusy) return;
                        if (
                          e.target instanceof HTMLElement &&
                          ['INPUT', 'TEXTAREA', 'SELECT', 'BUTTON'].includes(
                            e.target.tagName
                          )
                        ) {
                          return;
                        }
                        const key = e.key.toLowerCase();
                        const map: Record<string, AttendanceStatus> = {
                          p: 'present',
                          l: 'late',
                          a: 'absent',
                          e: 'excused',
                        };
                        if (map[key]) {
                          e.preventDefault();
                          handleMark(learner.id, map[key]);
                        }
                      }}
                      className="hover:bg-slate-50/70 focus:bg-blue-50/40 focus:outline-none"
                    >
                      <td className="px-4 py-3 font-mono text-xs text-slate-500 tabular-nums">
                        {learner.admissionNo}
                      </td>
                      <td className="px-4 py-3 font-semibold text-slate-900">
                        <button
                          type="button"
                          onClick={() => onOpenLearnerPage(learner.id)}
                          className="text-left hover:text-blue-700 hover:underline"
                        >
                          {learner.name}
                        </button>
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`inline-flex items-center gap-1.5 text-xs font-semibold capitalize ${statusColor}`}
                        >
                          <span className={`h-2 w-2 rounded-full ${statusDot}`} />
                          {status}
                        </span>
                      </td>
                      {showUniformColumn && (
                        <td className="px-4 py-3">
                          <button
                            type="button"
                            disabled={!canEdit || isBusy}
                            onClick={() =>
                              handleToggleUniform(learner.id, uniformOk)
                            }
                            className={`rounded-md border px-2.5 py-1 text-xs font-medium whitespace-nowrap disabled:cursor-not-allowed disabled:opacity-60 ${
                              uniformOk
                                ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                                : 'border-amber-200 bg-amber-50 text-amber-700'
                            }`}
                          >
                            {uniformOk ? 'Compliant' : 'Needs Follow-up'}
                          </button>
                        </td>
                      )}
                      <td className="px-4 py-3 text-xs text-slate-600">
                        {rec?.remark || '—'}
                      </td>
                      {canEdit && (
                        <td className="px-4 py-3 text-right">
                          <div className="inline-flex items-center gap-1">
                            {(
                              ['present', 'late', 'absent', 'excused'] as AttendanceStatus[]
                            ).map((st) => (
                              <button
                                key={st}
                                type="button"
                                disabled={isBusy}
                                onClick={() => handleMark(learner.id, st)}
                                className={`rounded-md px-2.5 py-1 text-xs font-medium capitalize transition-colors whitespace-nowrap shrink-0 disabled:cursor-not-allowed disabled:opacity-60 ${
                                  status === st
                                    ? 'bg-slate-900 text-white'
                                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                                }`}
                              >
                                {st}
                              </button>
                            ))}
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          )}
    </div>
  );
}
