/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from 'react';
import { ActionFeedbackProvider } from './components/ActionFeedback';
import { ArchitecturePlanView } from './components/ArchitecturePlanView';
import { AuthGate } from './components/AuthGate';
import { AssessmentEntryDialog } from './components/dialogs/AssessmentEntryDialog';
import { DiaryEntryDialog } from './components/dialogs/DiaryEntryDialog';
import { OfflineIndicator } from './components/PWAInstallButton';
import {
  SandboxWorkspace,
  type DiaryPrefillInput,
  type LessonPrefillDraft,
  type SandboxModule,
} from './components/SandboxWorkspace';
import { SpecsAndInspectorView } from './components/SpecsAndInspectorView';
import { TopBar, type MainSection } from './components/TopBar';
import { INITIAL_ECS_STATE, INITIAL_PORTAL_ACCOUNTS } from './ecs/initialData';
import { buildFullPlanMarkdown } from './ecs/planData';
import type {
  AuditActor,
  PortalAccount,
  Role,
  SchoolECSState,
} from './ecs/types';

const STORAGE_KEY = 'schola_ecs_state_v2';
const ACCOUNTS_STORAGE_KEY = 'schola_ecs_accounts_v1';
const SESSION_STORAGE_KEY = 'schola_ecs_session_uid_v1';
const DEV_MODE_STORAGE_KEY = 'schola_ecs_dev_mode_v1';

function loadSavedState(): SchoolECSState {
  if (typeof window === 'undefined') {
    return INITIAL_ECS_STATE;
  }
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return INITIAL_ECS_STATE;
    }
    const parsed = JSON.parse(raw) as Partial<SchoolECSState>;
    if (
      parsed &&
      Array.isArray(parsed.learners) &&
      Array.isArray(parsed.pageWidgets) &&
      Array.isArray(parsed.dynamicFields) &&
      Array.isArray(parsed.diaryEntries)
    ) {
      const defaultClassTeacherById = new Map(
        INITIAL_ECS_STATE.classrooms.map((c) => [c.id, c.classTeacherId])
      );
      const classrooms = Array.isArray(parsed.classrooms)
        ? parsed.classrooms.map((cls) => ({
            ...cls,
            classTeacherId:
              cls.classTeacherId !== undefined
                ? cls.classTeacherId
                : defaultClassTeacherById.get(cls.id),
          }))
        : INITIAL_ECS_STATE.classrooms;

      const strands = Array.isArray(parsed.strands)
        ? parsed.strands.map((st) => ({
            ...st,
            classroomId: st.classroomId || 'cls_5a',
          }))
        : INITIAL_ECS_STATE.strands;

      const locations =
        Array.isArray(parsed.locations) && parsed.locations.length > 0
          ? parsed.locations
          : INITIAL_ECS_STATE.locations;

      const defaultLocationById = new Map(
        INITIAL_ECS_STATE.learners.map((l) => [l.id, l.locationId])
      );
      const learners = parsed.learners.map((l) => ({
        ...l,
        locationId:
          l.locationId !== undefined
            ? l.locationId
            : defaultLocationById.get(l.id),
      }));

      const academicTerms =
        Array.isArray(parsed.academicTerms) && parsed.academicTerms.length > 0
          ? parsed.academicTerms
          : INITIAL_ECS_STATE.academicTerms;

      const activeTermId =
        typeof parsed.activeTermId === 'string' && parsed.activeTermId.length > 0
          ? parsed.activeTermId
          : INITIAL_ECS_STATE.activeTermId;

      return {
        ...INITIAL_ECS_STATE,
        ...parsed,
        classrooms,
        locations,
        learners,
        strands,
        academicTerms,
        activeTermId,
        auditLogs: Array.isArray(parsed.auditLogs)
          ? parsed.auditLogs
          : INITIAL_ECS_STATE.auditLogs,
        users:
          Array.isArray(parsed.users) && parsed.users.length > 0
            ? parsed.users
            : INITIAL_ECS_STATE.users,
        scheduleDays:
          Array.isArray(parsed.scheduleDays) && parsed.scheduleDays.length > 0
            ? parsed.scheduleDays
            : INITIAL_ECS_STATE.scheduleDays,
        schoolEvents: Array.isArray(parsed.schoolEvents)
          ? parsed.schoolEvents
          : INITIAL_ECS_STATE.schoolEvents,
      } as SchoolECSState;
    }
  } catch {
    // Ignore corrupted cache and fall back to deterministic initial data
  }
  return INITIAL_ECS_STATE;
}

function loadSavedAccounts(): PortalAccount[] {
  if (typeof window === 'undefined') {
    return INITIAL_PORTAL_ACCOUNTS;
  }
  try {
    const raw = window.localStorage.getItem(ACCOUNTS_STORAGE_KEY);
    if (!raw) return INITIAL_PORTAL_ACCOUNTS;
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed as PortalAccount[];
    }
  } catch {
    // Fallback to deterministic seed accounts
  }
  return INITIAL_PORTAL_ACCOUNTS;
}

function loadSavedSessionUid(): string | null {
  if (typeof window === 'undefined') {
    return null;
  }
  try {
    const val = window.localStorage.getItem(SESSION_STORAGE_KEY);
    return val && val.trim().length > 0 ? val : null;
  } catch {
    return null;
  }
}

function resolveInitialPreviewRole(): Role | null {
  if (typeof window === 'undefined') {
    return null;
  }
  const param = new URLSearchParams(window.location.search).get('autostart');
  if (param === 'admin' || param === '1') return 'admin';
  if (param === 'teacher') return 'teacher';
  if (param === 'parent') return 'parent';
  return null;
}

function resolveInitialDevMode(): boolean {
  if (typeof window === 'undefined') {
    return false;
  }
  const params = new URLSearchParams(window.location.search);
  const devParam = params.get('dev');
  const sectionParam = params.get('section');
  if (devParam === '1' || sectionParam === 'plan' || sectionParam === 'specs') {
    return true;
  }
  if (devParam === '0') {
    return false;
  }
  try {
    return window.localStorage.getItem(DEV_MODE_STORAGE_KEY) === '1';
  } catch {
    return false;
  }
}

export default function App() {
  const [isDevMode, setIsDevMode] = useState<boolean>(resolveInitialDevMode);
  const [activeSection, setActiveSection] = useState<MainSection>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('section') === 'plan') {
        return 'plan';
      }
      if (params.get('section') === 'specs') {
        return 'specs';
      }
    }
    return 'sandbox';
  });

  const [ecsState, setEcsState] = useState<SchoolECSState>(loadSavedState);
  const [accounts, setAccounts] = useState<PortalAccount[]>(loadSavedAccounts);
  const [sessionUid, setSessionUid] = useState<string | null>(loadSavedSessionUid);
  const [previewRole, setPreviewRole] = useState<Role | null>(
    resolveInitialPreviewRole
  );
  const [role, setRole] = useState<Role>(() => resolveInitialPreviewRole() ?? 'admin');
  const [activeModule, setActiveModule] = useState<SandboxModule>('home');
  const [activeTeacherId, setActiveTeacherId] = useState<string>(
    INITIAL_ECS_STATE.teachers[0].id
  );
  const [activeParentUserId, setActiveParentUserId] = useState<string>(
    INITIAL_ECS_STATE.users.find((u) => u.role === 'parent')?.id ?? 'usr_grace'
  );
  const [activeLearnerId, setActiveLearnerId] = useState<string>(
    INITIAL_ECS_STATE.learners[0].id
  );
  const [selectedLearnerId, setSelectedLearnerId] = useState<string | null>(null);
  const [quickJumpOpen, setQuickJumpOpen] = useState(false);
  const [lessonPrefill, setLessonPrefill] = useState<LessonPrefillDraft | null>(
    null
  );
  const [diaryDialog, setDiaryDialog] = useState<
    { open: boolean } & DiaryPrefillInput
  >({ open: false });
  const [assessmentDialog, setAssessmentDialog] = useState<{
    open: boolean;
    learnerId?: string;
  }>({ open: false });
  const [exportConfirmed, setExportConfirmed] = useState(false);

  const currentAccount =
    accounts.find((a) => a.uid === sessionUid) ?? null;
  const isAuthenticated = Boolean(currentAccount || previewRole);

  const activeTeacherRecord = ecsState.teachers.find(
    (t) => t.id === activeTeacherId
  );
  const activeGuardianRecord = ecsState.users.find(
    (u) => u.id === activeParentUserId
  );
  const currentActor: AuditActor = currentAccount
    ? {
        actorId: currentAccount.uid,
        actorName: currentAccount.displayName,
        actorRole: currentAccount.role,
      }
    : role === 'teacher'
      ? {
          actorId: activeTeacherRecord?.id ?? activeTeacherId,
          actorName: activeTeacherRecord?.name ?? 'Teacher',
          actorRole: 'teacher',
        }
      : role === 'parent'
        ? {
            actorId: activeGuardianRecord?.id ?? activeParentUserId,
            actorName: activeGuardianRecord?.displayName ?? 'Parent',
            actorRole: 'parent',
          }
        : {
            actorId: 'usr_admin',
            actorName: 'Portal Admin',
            actorRole: 'admin',
          };

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(ecsState));
    } catch {
      // Ignore storage quota errors
    }
  }, [ecsState]);

  useEffect(() => {
    try {
      window.localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(accounts));
    } catch {
      // Ignore storage quota errors
    }
  }, [accounts]);

  useEffect(() => {
    try {
      if (sessionUid) {
        window.localStorage.setItem(SESSION_STORAGE_KEY, sessionUid);
      } else {
        window.localStorage.removeItem(SESSION_STORAGE_KEY);
      }
    } catch {
      // Ignore storage quota errors
    }
  }, [sessionUid]);

  useEffect(() => {
    try {
      window.localStorage.setItem(DEV_MODE_STORAGE_KEY, isDevMode ? '1' : '0');
    } catch {
      // Ignore storage quota errors
    }
  }, [isDevMode]);

  useEffect(() => {
    if (!isAuthenticated || activeSection !== 'sandbox') return;
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setQuickJumpOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isAuthenticated, activeSection]);

  const applyPersonaForAccount = (account: PortalAccount, nextState: SchoolECSState) => {
    setRole(account.role);
    if (account.teacherId) {
      setActiveTeacherId(account.teacherId);
    }
    if (account.role === 'parent') {
      const matchedUser = nextState.users.find(
        (u) => u.id === account.uid || u.email.toLowerCase() === account.email.toLowerCase()
      );
      if (matchedUser) {
        setActiveParentUserId(matchedUser.id);
      }
      const firstChild =
        account.linkedLearnerIds[0] ?? matchedUser?.linkedLearnerIds[0];
      if (firstChild) {
        setActiveLearnerId(firstChild);
      }
    }
  };

  const handleAuthenticated = (
    account: PortalAccount,
    nextAccounts: PortalAccount[],
    nextState: SchoolECSState
  ) => {
    setAccounts(nextAccounts);
    setEcsState(nextState);
    setSessionUid(account.uid);
    setPreviewRole(null);
    setSelectedLearnerId(null);
    setActiveModule('home');
    applyPersonaForAccount(account, nextState);
  };

  const handleQuickPreviewRole = (nextRole: Role) => {
    setSessionUid(null);
    setPreviewRole(nextRole);
    setSelectedLearnerId(null);
    setActiveModule('home');
    handleRoleChange(nextRole);
  };

  const handleSignOut = () => {
    setSessionUid(null);
    setPreviewRole(null);
    setSelectedLearnerId(null);
    setQuickJumpOpen(false);
    setActiveModule('home');
    setActiveSection('sandbox');
  };

  const handleRoleChange = (nextRole: Role) => {
    setRole(nextRole);
    if (nextRole === 'parent') {
      const guardian = ecsState.users.find((u) => u.id === activeParentUserId);
      const allowedChildIds = guardian?.linkedLearnerIds ?? [];
      const resolvedChildId = allowedChildIds.includes(activeLearnerId)
        ? activeLearnerId
        : (allowedChildIds[0] ?? activeLearnerId);
      setActiveLearnerId(resolvedChildId);
      if (selectedLearnerId) {
        setSelectedLearnerId(resolvedChildId);
      }
    }
  };

  const handleParentUserChange = (nextParentUserId: string) => {
    setActiveParentUserId(nextParentUserId);
    const guardian = ecsState.users.find((u) => u.id === nextParentUserId);
    const firstChild = guardian?.linkedLearnerIds[0];
    if (firstChild) {
      setActiveLearnerId(firstChild);
      if (role === 'parent' && selectedLearnerId) {
        setSelectedLearnerId(firstChild);
      }
    }
  };

  const handleLearnerScopeChange = (nextLearnerId: string) => {
    setActiveLearnerId(nextLearnerId);
    if (role === 'parent' && selectedLearnerId) {
      setSelectedLearnerId(nextLearnerId);
    }
  };

  const handleLaunchSandbox = (module: SandboxModule = 'learners') => {
    setSelectedLearnerId(null);
    setActiveModule(module);
    setActiveSection('sandbox');
  };

  const handleExportPlan = () => {
    const markdown = buildFullPlanMarkdown();
    const blob = new Blob([markdown], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'schola-ecs-firebase-architecture-plan.md';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setExportConfirmed(true);
    setTimeout(() => setExportConfirmed(false), 2500);
  };

  const openDiaryWithPrefill = (input?: string | DiaryPrefillInput) => {
    if (!input) {
      setDiaryDialog({ open: true });
      return;
    }
    if (typeof input === 'string') {
      setDiaryDialog({ open: true, learnerId: input });
      return;
    }
    setDiaryDialog({ open: true, ...input });
  };

  return (
    <ActionFeedbackProvider>
      <div className="min-h-screen bg-slate-50 text-slate-900">
        <TopBar
          activeSection={activeSection}
          onNavigate={setActiveSection}
          onExportPlan={handleExportPlan}
          exportConfirmed={exportConfirmed}
          isDevMode={isDevMode}
          showQuickJump={isAuthenticated}
          onOpenQuickJump={() => setQuickJumpOpen(true)}
          showSignOut={isAuthenticated}
          onSignOut={handleSignOut}
        />

        {isDevMode && activeSection === 'plan' && (
          <ArchitecturePlanView
            onLaunchSandbox={handleLaunchSandbox}
            onViewSpecs={() => setActiveSection('specs')}
          />
        )}

        {activeSection === 'sandbox' &&
          (isAuthenticated ? (
            <SandboxWorkspace
              state={ecsState}
              role={role}
              activeModule={activeModule}
              activeTeacherId={activeTeacherId}
              activeParentUserId={activeParentUserId}
              activeLearnerId={activeLearnerId}
              selectedLearnerId={selectedLearnerId}
              currentAccount={currentAccount}
              actor={currentActor}
              isDevMode={isDevMode}
              quickJumpOpen={quickJumpOpen}
              lessonPrefill={lessonPrefill}
              onToggleDevMode={() => setIsDevMode((prev) => !prev)}
              onSetQuickJumpOpen={setQuickJumpOpen}
              onClearLessonPrefill={() => setLessonPrefill(null)}
              onCreateLessonFromSlot={(draft) => {
                setLessonPrefill(draft);
                setSelectedLearnerId(null);
                setActiveModule('lessons');
              }}
              onRoleChange={handleRoleChange}
              onModuleChange={setActiveModule}
              onTeacherChange={setActiveTeacherId}
              onParentUserChange={handleParentUserChange}
              onLearnerChange={handleLearnerScopeChange}
              onOpenLearnerPage={(lid) => setSelectedLearnerId(lid)}
              onCloseLearnerPage={() => setSelectedLearnerId(null)}
              onOpenDiaryDialog={openDiaryWithPrefill}
              onOpenAssessmentDialog={(lid) =>
                setAssessmentDialog({ open: true, learnerId: lid })
              }
              onStateChange={setEcsState}
            />
          ) : (
            <AuthGate
              accounts={accounts}
              state={ecsState}
              onAuthenticated={handleAuthenticated}
              onAccountsChange={setAccounts}
              onQuickPreviewRole={handleQuickPreviewRole}
            />
          ))}

        {isDevMode && activeSection === 'specs' && (
          <SpecsAndInspectorView state={ecsState} />
        )}

        <DiaryEntryDialog
          open={diaryDialog.open}
          state={ecsState}
          role={role}
          activeTeacherId={activeTeacherId}
          actor={currentActor}
          initialLearnerId={diaryDialog.learnerId}
          initialClassroomId={diaryDialog.classroomId}
          initialDate={diaryDialog.date}
          initialHomeworkSummary={diaryDialog.homeworkSummary}
          initialTeacherNote={diaryDialog.teacherNote}
          onClose={() => setDiaryDialog({ open: false })}
          onStateChange={setEcsState}
        />

        <AssessmentEntryDialog
          open={assessmentDialog.open}
          state={ecsState}
          role={role}
          activeTeacherId={activeTeacherId}
          actor={currentActor}
          initialLearnerId={assessmentDialog.learnerId}
          onClose={() => setAssessmentDialog({ open: false })}
          onStateChange={setEcsState}
        />

        <OfflineIndicator />
      </div>
    </ActionFeedbackProvider>
  );
}
