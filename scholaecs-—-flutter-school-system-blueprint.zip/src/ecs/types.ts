export type Role = 'admin' | 'teacher' | 'parent';

export type EntityType =
  | 'classroom'
  | 'teacher'
  | 'learner'
  | 'subject'
  | 'schedule_day'
  | 'scheme_strand'
  | 'scheme_substrand'
  | 'diary_entry'
  | 'assessment_entry'
  | 'lesson_plan'
  | 'timetable_slot'
  | 'attendance_record'
  | 'location';

export type DynamicFieldType = 'text' | 'number' | 'boolean' | 'select' | 'date';

export interface DynamicFieldDefinition {
  id: string;
  key: string;
  label: string;
  targetEntityType: Extract<
    EntityType,
    | 'learner'
    | 'diary_entry'
    | 'scheme_strand'
    | 'scheme_substrand'
    | 'assessment_entry'
    | 'lesson_plan'
    | 'timetable_slot'
    | 'attendance_record'
  >;
  fieldType: DynamicFieldType;
  options?: string[];
  required: boolean;
  visibleTo: Role[];
  editableBy: Role[];
  description: string;
  archived?: boolean;
}

export interface PortalUserAccount {
  id: string;
  email: string;
  displayName: string;
  role: Role;
  teacherId?: string;
  linkedLearnerIds: string[];
}

export interface PortalAccount {
  uid: string;
  email: string;
  password: string;
  displayName: string;
  role: Role;
  teacherId?: string;
  linkedLearnerIds: string[];
  emailVerified: boolean;
}

export interface AuditActor {
  actorId?: string;
  actorName?: string;
  actorRole?: Role;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  actorId: string;
  actorName: string;
  actorRole: Role;
  action: string;
  entityType: EntityType | 'school_event' | 'portal_account';
  entityId: string;
  targetLabel: string;
  detail: string;
  classroomId?: string;
  teacherId?: string;
  learnerId?: string;
}

export interface ClassroomEntity {
  id: string;
  name: string;
  gradeLevel: string;
  roomCode: string;
  classTeacherId?: string;
  updatedBy?: string;
  updatedAt?: string;
}

export interface TeacherEntity {
  id: string;
  name: string;
  email: string;
  subjectIds: string[];
  classroomIds: string[];
}

export interface LocationEntity {
  id: string;
  name: string;
  zone: string;
  notes: string;
  updatedBy?: string;
  updatedAt?: string;
}

export interface LearnerEntity {
  id: string;
  name: string;
  admissionNo: string;
  classroomId: string;
  locationId?: string;
  registeredAt: string;
  enrollmentStatus: 'Active' | 'Probation' | 'Alumni';
  parentName: string;
  parentEmail: string;
  guardianPhone: string;
  internalHealthNote: string;
  customFields: Record<string, string | number | boolean>;
}

export type PageWidgetId =
  | 'learner_overview'
  | 'learner_timeline'
  | 'learner_diary'
  | 'learner_assessments'
  | 'learner_attendance'
  | 'learner_timetable'
  | 'learner_enrollment';

export interface PageWidgetDefinition {
  id: PageWidgetId;
  pageId: 'learner_profile';
  title: string;
  description: string;
  allowedRoles: Role[];
  enabled: boolean;
  order: number;
}

export type TimeframePreset = 'since_registration' | 'this_term' | 'last_30_days' | 'custom';

export interface LearnerTimeframe {
  preset: TimeframePreset;
  fromDate?: string;
  toDate?: string;
}

export interface LearnerTimelineEvent {
  id: string;
  date: string;
  category: 'registration' | 'diary' | 'assessment' | 'attendance';
  title: string;
  detail: string;
  meta: string;
}

export interface SubjectEntity {
  id: string;
  code: string;
  name: string;
  gradeLevel: string;
}

export interface SchemeStrandEntity {
  id: string;
  classroomId: string;
  subjectId: string;
  code: string;
  title: string;
  term: string;
  createdByTeacherId: string;
}

export interface SchemeSubstrandEntity {
  id: string;
  strandId: string;
  subjectId: string;
  code: string;
  title: string;
  learningOutcome: string;
  targetLessons: number;
  customFields: Record<string, string | number | boolean>;
}

export interface DiaryEntryEntity {
  id: string;
  learnerId: string;
  classroomId: string;
  teacherId: string;
  date: string;
  homeworkSummary: string;
  teacherNote: string;
  parentAcknowledged: boolean;
  customFields: Record<string, string | number | boolean>;
}

export type MasteryLevel = 'Exceeding' | 'Meeting' | 'Approaching' | 'Developing';

export interface AssessmentEntryEntity {
  id: string;
  learnerId: string;
  subjectId: string;
  strandId: string;
  substrandId: string;
  teacherId: string;
  date: string;
  mastery: MasteryLevel;
  scorePercent: number;
  performanceComment: string;
  customFields: Record<string, string | number | boolean>;
}

export type LessonStatus = 'planned' | 'in_progress' | 'taught';

export interface LessonPlanEntity {
  id: string;
  teacherId: string;
  taughtByTeacherId?: string;
  taughtAt?: string;
  updatedBy?: string;
  updatedAt?: string;
  classroomId: string;
  subjectId: string;
  strandId: string;
  substrandId: string;
  timetableSlotId?: string;
  title: string;
  scheduledDate: string;
  lessonsDelivered: number;
  status: LessonStatus;
  reflectionNote: string;
  customFields: Record<string, string | number | boolean>;
}

export type Weekday = string;

export interface ScheduleDayEntity {
  id: string;
  code: string;
  label: string;
  order: number;
  classroomIds: string[];
  defaultTimeRange: string;
}

export interface TimetableSlotEntity {
  id: string;
  classroomId: string;
  subjectId: string;
  teacherId: string;
  day: Weekday;
  period: number;
  timeRange: string;
  room: string;
  lessonPlanId?: string;
}

export type AttendanceStatus = 'present' | 'late' | 'absent' | 'excused';

export interface AttendanceRecordEntity {
  id: string;
  learnerId: string;
  classroomId: string;
  teacherId: string;
  date: string;
  status: AttendanceStatus;
  remark: string;
  customFields: Record<string, string | number | boolean>;
}

export type SchoolEventKind = 'holiday' | 'exam' | 'event' | 'meeting' | 'sports';

export interface SchoolEventEntity {
  id: string;
  date: string; // YYYY-MM-DD
  title: string;
  description: string;
  kind: SchoolEventKind;
  classroomId?: string;
}

export interface AcademicTermEntity {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
}

export interface SchoolECSState {
  users: PortalUserAccount[];
  dynamicFields: DynamicFieldDefinition[];
  pageWidgets: PageWidgetDefinition[];
  classrooms: ClassroomEntity[];
  locations: LocationEntity[];
  teachers: TeacherEntity[];
  learners: LearnerEntity[];
  subjects: SubjectEntity[];
  scheduleDays: ScheduleDayEntity[];
  strands: SchemeStrandEntity[];
  substrands: SchemeSubstrandEntity[];
  diaryEntries: DiaryEntryEntity[];
  assessments: AssessmentEntryEntity[];
  lessonPlans: LessonPlanEntity[];
  timetableSlots: TimetableSlotEntity[];
  attendanceRecords: AttendanceRecordEntity[];
  schoolEvents: SchoolEventEntity[];
  auditLogs: AuditLogEntry[];
  academicTerms?: AcademicTermEntity[];
  activeTermId?: string;
}

export interface AdminAttentionItem {
  id: string;
  severity: 'high' | 'medium' | 'info';
  title: string;
  detail: string;
  count: number;
  actionLabel: string;
  targetModule: 'diary' | 'register' | 'coverage' | 'lessons' | 'learners' | 'parents';
}

export interface TeacherTodayPeriod {
  slot: TimetableSlotEntity;
  classroom?: ClassroomEntity;
  subject?: SubjectEntity;
  lessonPlan?: LessonPlanEntity;
}

export interface ParentChildDigest {
  learner: LearnerEntity;
  classroom?: ClassroomEntity;
  todayAttendance?: AttendanceRecordEntity;
  pendingDiaryEntries: DiaryEntryEntity[];
  latestAssessment?: AssessmentEntryEntity;
}

export interface QuickJumpItem {
  id: string;
  category: 'module' | 'learner' | 'classroom' | 'lesson' | 'scheme';
  title: string;
  subtitle: string;
  targetModule:
    | 'home'
    | 'learners'
    | 'diary'
    | 'schemes'
    | 'assessments'
    | 'lessons'
    | 'timetable'
    | 'register'
    | 'classrooms'
    | 'parents'
    | 'coverage'
    | 'schema';
  learnerId?: string;
  classroomId?: string;
}

export interface OnboardingChecklistItem {
  id: string;
  label: string;
  description: string;
  completed: boolean;
  targetModule: 'classrooms' | 'learners' | 'parents' | 'schemes' | 'schema';
}

export interface SubjectMasteryPoint {
  date: string;
  scorePercent: number;
  mastery: MasteryLevel;
  substrandTitle: string;
}

export interface SubjectMasterySeries {
  subject: SubjectEntity;
  points: SubjectMasteryPoint[];
  latestScore: number;
  deltaFromFirst: number;
}

export interface SubstrandCoverageReport {
  substrand: SchemeSubstrandEntity;
  strand: SchemeStrandEntity;
  subject: SubjectEntity;
  classroom?: ClassroomEntity;
  targetLessons: number;
  deliveredLessons: number;
  taughtPlanCount: number;
  plannedCount: number;
  coveragePercent: number;
  teachersInvolved: string[];
}

export interface TeacherCoverageSummary {
  teacher: TeacherEntity;
  totalPlans: number;
  taughtPlans: number;
  inProgressPlans: number;
  plannedOnly: number;
  totalLessonsDelivered: number;
  diaryEntriesLogged: number;
  assessmentsLogged: number;
  coverageRatePercent: number;
}

export interface ScoreCandlestickPoint {
  label: string;
  open: number;
  high: number;
  low: number;
  close: number;
  average: number;
  sampleCount: number;
}

export interface TeacherClassSlice {
  classroom: ClassroomEntity;
  isClassTeacher: boolean;
  totalPlans: number;
  taughtPlans: number;
  lessonsDelivered: number;
  assessmentsLogged: number;
  diaryLogged: number;
  coveragePercent: number;
}

export interface TeacherClassMatrixRow {
  teacher: TeacherEntity;
  homeroomClassrooms: ClassroomEntity[];
  classes: TeacherClassSlice[];
  totalPlans: number;
  taughtPlans: number;
  lessonsDelivered: number;
  coveragePercent: number;
}

export interface ClassroomTeacherSlice {
  teacher: TeacherEntity;
  isClassTeacher: boolean;
  totalPlans: number;
  taughtPlans: number;
  lessonsDelivered: number;
  assessmentsLogged: number;
  diaryLogged: number;
}

export interface ClassroomMatrixRow {
  classroom: ClassroomEntity;
  classTeacher?: TeacherEntity;
  learnerCount: number;
  attendanceRatePercent: number;
  averageScorePercent: number | null;
  strandCount: number;
  substrandCount: number;
  avgCoveragePercent: number;
  taughtLessonsCount: number;
  totalPlansCount: number;
  totalLessonsDelivered: number;
  teacherSlices: ClassroomTeacherSlice[];
}

export interface ParentSummary {
  parentKey: string;
  parentName: string;
  parentEmail: string;
  guardianPhone: string;
  portalUser?: PortalUserAccount;
  children: LearnerEntity[];
  classrooms: ClassroomEntity[];
  locations: LocationEntity[];
  avgScorePercent: number | null;
  attendanceRatePercent: number | null;
  diaryCount: number;
  pendingSignOffCount: number;
  assessmentCount: number;
}

export interface LocationSummary {
  location: LocationEntity;
  learnerCount: number;
  familyCount: number;
  classroomCount: number;
  averageScorePercent: number | null;
  attendanceRatePercent: number | null;
}
