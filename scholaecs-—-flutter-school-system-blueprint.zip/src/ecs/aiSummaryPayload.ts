import {
  computeSubstrandCoverage,
  computeTeacherCoverageSummaries,
} from './engine';
import type { SchoolECSState } from './types';

export interface AdminAiAlertItem {
  severity: 'high' | 'medium' | 'low';
  area: string;
  summary: string;
  recommendedAction: string;
}

export interface AdminAiHighlightItem {
  area: string;
  comment: string;
}

export interface AdminAiWorkflowStatus {
  workflow: string;
  status: 'smooth' | 'attention' | 'blocked';
  summary: string;
}

export interface AdminAiSummaryPayload {
  executiveOverview: string;
  urgentAlerts: AdminAiAlertItem[];
  positiveHighlights: AdminAiHighlightItem[];
  workflowStatuses: AdminAiWorkflowStatus[];
}

export interface AdminAiApiResponse {
  model: string;
  generatedAt: string;
  summary: AdminAiSummaryPayload;
}

/**
 * Pure compact operational snapshot builder so Gemini summarization tokens stay
 * minimal, fast, and cost-efficient while capturing all alerts & positive highlights.
 */
export function buildAdminAiSnapshot(state: SchoolECSState) {
  const substrandCoverage = computeSubstrandCoverage(state);
  const teacherRollups = computeTeacherCoverageSummaries(state);

  const pendingDiaries = state.diaryEntries
    .filter((d) => !d.parentAcknowledged)
    .map((d) => ({
      date: d.date,
      learner: state.learners.find((l) => l.id === d.learnerId)?.name ?? d.learnerId,
      homework: d.homeworkSummary,
      note: d.teacherNote,
    }));

  const signedDiariesCount = state.diaryEntries.filter((d) => d.parentAcknowledged).length;

  const lowMasteryAssessments = state.assessments
    .filter((a) => a.mastery === 'Approaching' || a.mastery === 'Developing')
    .map((a) => ({
      learner: state.learners.find((l) => l.id === a.learnerId)?.name ?? a.learnerId,
      subject: state.subjects.find((s) => s.id === a.subjectId)?.name ?? a.subjectId,
      mastery: a.mastery,
      scorePercent: a.scorePercent,
      comment: a.performanceComment,
    }));

  const topMasteryAssessments = state.assessments
    .filter((a) => a.mastery === 'Exceeding' || a.mastery === 'Meeting')
    .map((a) => ({
      learner: state.learners.find((l) => l.id === a.learnerId)?.name ?? a.learnerId,
      subject: state.subjects.find((s) => s.id === a.subjectId)?.name ?? a.subjectId,
      mastery: a.mastery,
      scorePercent: a.scorePercent,
      comment: a.performanceComment,
    }));

  const attendanceIssues = state.attendanceRecords
    .filter((r) => r.status !== 'present' || r.customFields.uniform_compliant === false)
    .map((r) => ({
      date: r.date,
      learner: state.learners.find((l) => l.id === r.learnerId)?.name ?? r.learnerId,
      status: r.status,
      uniformCompliant: r.customFields.uniform_compliant !== false,
      remark: r.remark,
    }));

  const unscheduledPlans = state.lessonPlans
    .filter((lp) => !lp.timetableSlotId && lp.status !== 'taught')
    .map((lp) => ({
      title: lp.title,
      teacher: state.teachers.find((t) => t.id === lp.teacherId)?.name ?? lp.teacherId,
      classroom: state.classrooms.find((c) => c.id === lp.classroomId)?.name ?? lp.classroomId,
      scheduledDate: lp.scheduledDate,
    }));

  return {
    counts: {
      learners: state.learners.length,
      classrooms: state.classrooms.length,
      teachers: state.teachers.length,
      strands: state.strands.length,
      substrands: state.substrands.length,
      lessonPlansTotal: state.lessonPlans.length,
      lessonPlansTaught: state.lessonPlans.filter((l) => l.status === 'taught').length,
      diaryEntriesTotal: state.diaryEntries.length,
      diarySignedCount: signedDiariesCount,
      attendanceRecordsTotal: state.attendanceRecords.length,
      attendancePresentCount: state.attendanceRecords.filter((a) => a.status === 'present').length,
    },
    upcomingCalendarEvents: state.schoolEvents.map((e) => ({
      date: e.date,
      title: e.title,
      kind: e.kind,
      description: e.description,
    })),
    teacherRollups: teacherRollups.map((t) => ({
      teacher: t.teacher.name,
      taughtPlans: t.taughtPlans,
      totalPlans: t.totalPlans,
      lessonsDelivered: t.totalLessonsDelivered,
      assessmentsLogged: t.assessmentsLogged,
      diaryEntriesLogged: t.diaryEntriesLogged,
    })),
    substrandCoverage: substrandCoverage.map((s) => ({
      subject: s.subject.name,
      substrand: `${s.substrand.code} ${s.substrand.title}`,
      coveragePercent: s.coveragePercent,
      deliveredLessons: s.deliveredLessons,
      targetLessons: s.targetLessons,
    })),
    alertsContext: {
      pendingParentDiarySignoffs: pendingDiaries,
      lowMasteryAssessments,
      attendanceOrUniformFlags: attendanceIssues,
      unscheduledLessonPlans: unscheduledPlans,
    },
    highlightsContext: {
      strongAssessments: topMasteryAssessments,
      recentReflections: state.lessonPlans
        .filter((lp) => lp.status === 'taught' && lp.reflectionNote)
        .map((lp) => ({
          title: lp.title,
          reflection: lp.reflectionNote,
        })),
    },
  };
}
