import type {
  AcademicTermEntity,
  AdminAttentionItem,
  AssessmentEntryEntity,
  AttendanceRecordEntity,
  AttendanceStatus,
  AuditActor,
  AuditLogEntry,
  ClassroomEntity,
  ClassroomMatrixRow,
  ClassroomTeacherSlice,
  DiaryEntryEntity,
  DynamicFieldDefinition,
  EntityType,
  LearnerEntity,
  LearnerTimeframe,
  LearnerTimelineEvent,
  LessonPlanEntity,
  LessonStatus,
  LocationEntity,
  LocationSummary,
  MasteryLevel,
  OnboardingChecklistItem,
  PageWidgetDefinition,
  PageWidgetId,
  ParentChildDigest,
  ParentSummary,
  PortalAccount,
  PortalUserAccount,
  QuickJumpItem,
  Role,
  ScheduleDayEntity,
  SchemeStrandEntity,
  SchemeSubstrandEntity,
  SchoolECSState,
  SchoolEventEntity,
  SchoolEventKind,
  ScoreCandlestickPoint,
  SubjectMasteryPoint,
  SubjectMasterySeries,
  SubstrandCoverageReport,
  TeacherClassMatrixRow,
  TeacherClassSlice,
  TeacherCoverageSummary,
  TeacherTodayPeriod,
  TimetableSlotEntity,
  Weekday,
} from './types';

function formatAuditTimestamp(d: Date = new Date()): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function appendAudit(
  state: SchoolECSState,
  entry: Omit<AuditLogEntry, 'id' | 'timestamp'> & { timestamp?: string }
): AuditLogEntry[] {
  const created: AuditLogEntry = {
    ...entry,
    id: `aud_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    timestamp: entry.timestamp ?? formatAuditTimestamp(),
  };
  return [created, ...(state.auditLogs ?? [])].slice(0, 150);
}

export function validateWebAuthInputs(input: {
  email: string;
  password: string;
  confirmPassword?: string;
  displayName?: string;
  isSignUp: boolean;
}): string | null {
  const cleanEmail = input.email.trim();
  if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
    return 'Please enter a valid email address.';
  }
  if (input.password.length < 6) {
    return 'Password must be at least 6 characters.';
  }
  if (input.isSignUp) {
    if (!input.displayName || input.displayName.trim().length < 2) {
      return 'Please enter your full name (at least 2 characters).';
    }
    if ((input.confirmPassword ?? '') !== input.password) {
      return 'Passwords do not match.';
    }
  }
  return null;
}

export function authenticatePortalAccount(
  accounts: PortalAccount[],
  email: string,
  password: string
): { account?: PortalAccount; error?: string } {
  const err = validateWebAuthInputs({ email, password, isSignUp: false });
  if (err) return { error: err };
  const normalized = email.trim().toLowerCase();
  const found = accounts.find((a) => a.email.toLowerCase() === normalized);
  if (!found) {
    return {
      error: `No portal account found for "${normalized}". Switch to Sign Up or use a quick account chip.`,
    };
  }
  if (found.password !== password) {
    return { error: 'Incorrect password. Please try again or reset it.' };
  }
  return { account: found };
}

export function registerPortalAccount(
  accounts: PortalAccount[],
  state: SchoolECSState,
  input: {
    email: string;
    password: string;
    confirmPassword: string;
    displayName: string;
    role: Role;
    teacherId?: string;
    linkedLearnerIds?: string[];
    emailVerified?: boolean;
  }
): {
  accounts: PortalAccount[];
  state: SchoolECSState;
  account?: PortalAccount;
  error?: string;
} {
  const err = validateWebAuthInputs({
    email: input.email,
    password: input.password,
    confirmPassword: input.confirmPassword,
    displayName: input.displayName,
    isSignUp: true,
  });
  if (err) return { accounts, state, error: err };

  const normalized = input.email.trim().toLowerCase();
  if (accounts.some((a) => a.email.toLowerCase() === normalized)) {
    return {
      accounts,
      state,
      error: `An account for "${normalized}" already exists. Please Sign In instead.`,
    };
  }

  const isEmailVerified = input.emailVerified ?? true;
  const matchedTeacher =
    input.teacherId?.trim() ||
    state.teachers.find((t) => t.email.toLowerCase() === normalized)?.id;

  const autoMatchedByEmail = isEmailVerified
    ? state.learners
        .filter((l) => l.parentEmail.trim().toLowerCase() === normalized)
        .map((l) => l.id)
    : [];

  const matchedLearners = isEmailVerified
    ? Array.from(
        new Set([...(input.linkedLearnerIds ?? []), ...autoMatchedByEmail])
      )
    : [];

  const resolvedLinked =
    input.role === 'parent'
      ? matchedLearners
      : isEmailVerified
        ? (input.linkedLearnerIds ?? [])
        : [];

  const uid = `usr_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const account: PortalAccount = {
    uid,
    email: normalized,
    password: input.password,
    displayName: input.displayName.trim(),
    role: input.role,
    teacherId: input.role === 'parent' ? undefined : matchedTeacher || state.teachers[0]?.id,
    linkedLearnerIds: Array.from(new Set(resolvedLinked)),
    emailVerified: isEmailVerified,
  };

  const directoryUser: PortalUserAccount = {
    id: uid,
    email: account.email,
    displayName: account.displayName,
    role: account.role,
    teacherId: account.teacherId,
    linkedLearnerIds: account.linkedLearnerIds,
  };

  const nextUsers = state.users.some((u) => u.email.toLowerCase() === normalized)
    ? state.users
    : [...state.users, directoryUser];

  return {
    accounts: [...accounts, account],
    state: {
      ...state,
      users: nextUsers,
      auditLogs: appendAudit(state, {
        actorId: uid,
        actorName: account.displayName,
        actorRole: account.role,
        action: 'Registered Portal Account',
        entityType: 'portal_account',
        entityId: uid,
        targetLabel: `${account.displayName} (${account.role})`,
        detail: account.email,
        teacherId: account.teacherId,
      }),
    },
    account,
  };
}

export function resetPortalAccountPassword(
  accounts: PortalAccount[],
  email: string,
  newPassword: string
): { accounts: PortalAccount[]; error?: string } {
  const normalized = email.trim().toLowerCase();
  if (!normalized || !normalized.includes('@')) {
    return { accounts, error: 'Please enter a valid email address.' };
  }
  if (newPassword.length < 6) {
    return { accounts, error: 'New password must be at least 6 characters.' };
  }
  const idx = accounts.findIndex((a) => a.email.toLowerCase() === normalized);
  if (idx === -1) {
    return { accounts, error: `No portal account found for "${normalized}".` };
  }
  return {
    accounts: accounts.map((a, i) =>
      i === idx ? { ...a, password: newPassword } : a
    ),
  };
}

export function sanitizeFieldKey(label: string): string {
  return label
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}

export function registerDynamicField(
  state: SchoolECSState,
  input: Omit<DynamicFieldDefinition, 'id' | 'key'> & { key?: string }
): { state: SchoolECSState; field?: DynamicFieldDefinition; error?: string } {
  const cleanLabel = input.label.trim();
  if (!cleanLabel) {
    return { state, error: 'Field label is required.' };
  }
  const key = sanitizeFieldKey(input.key || cleanLabel);
  if (!key) {
    return { state, error: 'Field key must contain alphanumeric characters.' };
  }
  const exists = state.dynamicFields.some(
    (f) => f.targetEntityType === input.targetEntityType && f.key === key
  );
  if (exists) {
    return {
      state,
      error: `Field "${key}" is already registered on ${input.targetEntityType}.`,
    };
  }
  const field: DynamicFieldDefinition = {
    ...input,
    id: `df_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    key,
    label: cleanLabel,
  };
  return {
    state: {
      ...state,
      dynamicFields: [...state.dynamicFields, field],
    },
    field,
  };
}

export function updateDynamicField(
  state: SchoolECSState,
  fieldId: string,
  updates: Partial<
    Pick<
      DynamicFieldDefinition,
      | 'label'
      | 'targetEntityType'
      | 'fieldType'
      | 'options'
      | 'required'
      | 'visibleTo'
      | 'editableBy'
      | 'description'
    >
  >
): { state: SchoolECSState; field?: DynamicFieldDefinition; error?: string } {
  const existing = state.dynamicFields.find((f) => f.id === fieldId);
  if (!existing) {
    return { state, error: 'Component field not found.' };
  }
  const nextLabel = (updates.label ?? existing.label).trim();
  if (!nextLabel) {
    return { state, error: 'Field label is required.' };
  }
  const nextTarget = updates.targetEntityType ?? existing.targetEntityType;
  const nextKey = sanitizeFieldKey(nextLabel);
  if (!nextKey) {
    return { state, error: 'Field label must contain alphanumeric characters.' };
  }
  const duplicate = state.dynamicFields.some(
    (f) =>
      f.id !== fieldId &&
      f.targetEntityType === nextTarget &&
      f.key === nextKey
  );
  if (duplicate) {
    return {
      state,
      error: `Another field "${nextKey}" already exists on ${nextTarget}.`,
    };
  }

  const nextField: DynamicFieldDefinition = {
    ...existing,
    ...updates,
    label: nextLabel,
    key: nextKey,
    targetEntityType: nextTarget,
    visibleTo: updates.visibleTo
      ? updates.visibleTo.includes('admin')
        ? updates.visibleTo
        : ['admin', ...updates.visibleTo]
      : existing.visibleTo,
    editableBy: updates.editableBy
      ? updates.editableBy.includes('admin')
        ? updates.editableBy
        : ['admin', ...updates.editableBy]
      : existing.editableBy,
  };

  return {
    state: {
      ...state,
      dynamicFields: state.dynamicFields.map((f) =>
        f.id === fieldId ? nextField : f
      ),
    },
    field: nextField,
  };
}

export function removeDynamicField(
  state: SchoolECSState,
  fieldId: string
): SchoolECSState {
  return {
    ...state,
    dynamicFields: state.dynamicFields.filter((f) => f.id !== fieldId),
  };
}

export function archiveDynamicField(
  state: SchoolECSState,
  fieldId: string
): SchoolECSState {
  return {
    ...state,
    dynamicFields: state.dynamicFields.map((f) =>
      f.id === fieldId ? { ...f, archived: true } : f
    ),
  };
}

export function restoreDynamicField(
  state: SchoolECSState,
  fieldId: string
): SchoolECSState {
  return {
    ...state,
    dynamicFields: state.dynamicFields.map((f) =>
      f.id === fieldId ? { ...f, archived: false } : f
    ),
  };
}

export function updateLearnerProfile(
  state: SchoolECSState,
  learnerId: string,
  updates: {
    name?: string;
    classroomId?: string;
    locationId?: string;
    enrollmentStatus?: 'Active' | 'Probation' | 'Alumni';
    parentName?: string;
    parentEmail?: string;
    guardianPhone?: string;
    internalHealthNote?: string;
    customFields?: Record<string, string | number | boolean>;
  },
  actor?: AuditActor
): { state: SchoolECSState; error?: string } {
  const existing = state.learners.find((l) => l.id === learnerId);
  if (!existing) {
    return { state, error: 'Learner not found.' };
  }
  const nextName = (updates.name ?? existing.name).trim();
  if (!nextName) {
    return { state, error: 'Learner name is required.' };
  }
  const nextClassroomId = updates.classroomId ?? existing.classroomId;
  if (!state.classrooms.some((c) => c.id === nextClassroomId)) {
    return { state, error: 'Please select a valid classroom.' };
  }

  let nextLocationId = existing.locationId;
  if (updates.locationId !== undefined) {
    const cleanLoc = updates.locationId.trim();
    if (!cleanLoc) {
      nextLocationId = undefined;
    } else {
      if (!(state.locations ?? []).some((loc) => loc.id === cleanLoc)) {
        return { state, error: 'Please select a valid home location.' };
      }
      nextLocationId = cleanLoc;
    }
  }

  const nextParentEmail =
    updates.parentEmail !== undefined
      ? updates.parentEmail.trim().toLowerCase()
      : existing.parentEmail;
  if (!nextParentEmail || !nextParentEmail.includes('@')) {
    return { state, error: 'A valid guardian email address is required.' };
  }

  const learnerFields = getFieldsForEntity(state, 'learner', 'admin');
  const nextCustom = {
    ...existing.customFields,
    ...(updates.customFields ?? {}),
  };
  const err = validateCustomFields(learnerFields, nextCustom, 'admin');
  if (err) {
    return { state, error: err };
  }
  const nextLearners = state.learners.map((l) =>
    l.id === learnerId
      ? {
          ...l,
          ...updates,
          name: nextName,
          classroomId: nextClassroomId,
          locationId: nextLocationId,
          parentEmail: nextParentEmail,
          customFields: nextCustom,
        }
      : l
  );

  // Sync existing verified guardian portal user links if guardian email changed
  const prevEmail = existing.parentEmail.trim().toLowerCase();
  const nextUsers =
    updates.parentEmail !== undefined && nextParentEmail !== prevEmail
      ? state.users.map((u) => {
          if (u.role !== 'parent') return u;
          const uEmail = u.email.trim().toLowerCase();
          if (uEmail === nextParentEmail) {
            return {
              ...u,
              linkedLearnerIds: Array.from(
                new Set([...u.linkedLearnerIds, learnerId])
              ),
            };
          }
          if (uEmail === prevEmail) {
            return {
              ...u,
              linkedLearnerIds: u.linkedLearnerIds.filter((id) => id !== learnerId),
            };
          }
          return u;
        })
      : state.users;

  return {
    state: {
      ...state,
      users: nextUsers,
      learners: nextLearners,
      auditLogs: appendAudit(state, {
        actorId: actor?.actorId ?? 'usr_admin',
        actorName: actor?.actorName ?? 'Portal Admin',
        actorRole: actor?.actorRole ?? 'admin',
        action: 'Updated Learner Profile',
        entityType: 'learner',
        entityId: learnerId,
        targetLabel: nextName,
        detail: `Status: ${updates.enrollmentStatus ?? existing.enrollmentStatus}`,
        classroomId: nextClassroomId,
        learnerId,
      }),
    },
  };
}

export function createLearner(
  state: SchoolECSState,
  input: {
    name: string;
    admissionNo: string;
    classroomId: string;
    locationId?: string;
    parentName: string;
    parentEmail: string;
    guardianPhone: string;
    enrollmentStatus?: 'Active' | 'Probation' | 'Alumni';
    internalHealthNote?: string;
    registeredAt?: string;
  },
  actor?: AuditActor
): { state: SchoolECSState; learner?: LearnerEntity; error?: string } {
  const name = input.name.trim();
  const admissionNo = input.admissionNo.trim().toUpperCase();
  const parentName = input.parentName.trim();
  const parentEmail = input.parentEmail.trim().toLowerCase();
  const guardianPhone = input.guardianPhone.trim();
  const cleanLocationId = input.locationId?.trim() || undefined;

  if (!name || !admissionNo) {
    return { state, error: 'Learner full name and admission number are required.' };
  }
  if (!state.classrooms.some((c) => c.id === input.classroomId)) {
    return { state, error: 'Please assign the learner to a valid classroom.' };
  }
  if (
    cleanLocationId &&
    !(state.locations ?? []).some((loc) => loc.id === cleanLocationId)
  ) {
    return { state, error: 'Please select a valid home location.' };
  }
  if (
    state.learners.some(
      (l) => l.admissionNo.trim().toUpperCase() === admissionNo
    )
  ) {
    return {
      state,
      error: `Admission number "${admissionNo}" is already assigned to another learner.`,
    };
  }
  if (!parentName || !parentEmail || !parentEmail.includes('@')) {
    return { state, error: 'Valid guardian name and email are required.' };
  }

  const learner: LearnerEntity = {
    id: `lrn_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
    name,
    admissionNo,
    classroomId: input.classroomId,
    locationId: cleanLocationId,
    registeredAt: input.registeredAt?.trim() || '2026-11-25',
    enrollmentStatus: input.enrollmentStatus ?? 'Active',
    parentName,
    parentEmail,
    guardianPhone: guardianPhone || '+254 700 000 000',
    internalHealthNote:
      input.internalHealthNote?.trim() || 'No alerts on intake.',
    customFields: {},
  };

  const nextUsers = state.users.map((u) =>
    u.role === 'parent' && u.email.trim().toLowerCase() === parentEmail
      ? {
          ...u,
          linkedLearnerIds: Array.from(new Set([...u.linkedLearnerIds, learner.id])),
        }
      : u
  );

  const classroom = state.classrooms.find((c) => c.id === learner.classroomId);

  return {
    state: {
      ...state,
      users: nextUsers,
      learners: [learner, ...state.learners],
      auditLogs: appendAudit(state, {
        actorId: actor?.actorId ?? 'usr_admin',
        actorName: actor?.actorName ?? 'Portal Admin',
        actorRole: actor?.actorRole ?? 'admin',
        action: 'Enrolled New Learner',
        entityType: 'learner',
        entityId: learner.id,
        targetLabel: `${learner.name} (${learner.admissionNo})`,
        detail: `${classroom?.name ?? learner.classroomId} · Guardian: ${learner.parentName}`,
        classroomId: learner.classroomId,
        learnerId: learner.id,
      }),
    },
    learner,
  };
}

export function getFieldsForEntity(
  state: SchoolECSState,
  entityType: DynamicFieldDefinition['targetEntityType'],
  role: Role,
  includeArchived = false
): DynamicFieldDefinition[] {
  return state.dynamicFields.filter(
    (f) =>
      f.targetEntityType === entityType &&
      (includeArchived || !f.archived) &&
      (role === 'admin' || f.visibleTo.includes(role))
  );
}

export function registerSchemeStrand(
  state: SchoolECSState,
  input: {
    classroomId?: string;
    subjectId: string;
    code: string;
    title: string;
    term: string;
    createdByTeacherId: string;
  },
  actor?: AuditActor
): { state: SchoolECSState; strand?: SchemeStrandEntity; error?: string } {
  if (!input.title.trim() || !input.code.trim()) {
    return { state, error: 'Strand code and title are required.' };
  }
  const resolvedClassroomId =
    input.classroomId?.trim() || state.classrooms[0]?.id || 'cls_5a';
  const classroom = state.classrooms.find((c) => c.id === resolvedClassroomId);
  const teacher = state.teachers.find((t) => t.id === input.createdByTeacherId);
  const strand: SchemeStrandEntity = {
    id: `str_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    classroomId: resolvedClassroomId,
    subjectId: input.subjectId,
    code: input.code.trim().toUpperCase(),
    title: input.title.trim(),
    term: input.term.trim() || 'Term 1',
    createdByTeacherId: input.createdByTeacherId,
  };
  return {
    state: {
      ...state,
      strands: [...state.strands, strand],
      auditLogs: appendAudit(state, {
        actorId: actor?.actorId ?? input.createdByTeacherId,
        actorName: actor?.actorName ?? teacher?.name ?? 'Staff',
        actorRole: actor?.actorRole ?? 'teacher',
        action: 'Registered Scheme Strand',
        entityType: 'scheme_strand',
        entityId: strand.id,
        targetLabel: `${strand.code}: ${strand.title}`,
        detail: `Class: ${classroom?.name ?? resolvedClassroomId} · ${strand.term}`,
        classroomId: resolvedClassroomId,
        teacherId: input.createdByTeacherId,
      }),
    },
    strand,
  };
}

export function registerSchemeSubstrand(
  state: SchoolECSState,
  input: {
    strandId: string;
    code: string;
    title: string;
    learningOutcome: string;
    targetLessons: number;
    customFields?: Record<string, string | number | boolean>;
  },
  actor?: AuditActor
): { state: SchoolECSState; substrand?: SchemeSubstrandEntity; error?: string } {
  const parentStrand = state.strands.find((s) => s.id === input.strandId);
  if (!parentStrand) {
    return { state, error: 'Selected parent strand does not exist.' };
  }
  if (!input.title.trim() || !input.code.trim()) {
    return { state, error: 'Substrand code and title are required.' };
  }
  const substrand: SchemeSubstrandEntity = {
    id: `sub_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    strandId: parentStrand.id,
    subjectId: parentStrand.subjectId,
    code: input.code.trim().toUpperCase(),
    title: input.title.trim(),
    learningOutcome: input.learningOutcome.trim(),
    targetLessons: Math.max(1, Number(input.targetLessons) || 1),
    customFields: input.customFields ?? {},
  };
  return {
    state: {
      ...state,
      substrands: [...state.substrands, substrand],
      auditLogs: appendAudit(state, {
        actorId: actor?.actorId ?? parentStrand.createdByTeacherId,
        actorName: actor?.actorName ?? 'Curriculum Staff',
        actorRole: actor?.actorRole ?? 'teacher',
        action: 'Added Scheme Substrand',
        entityType: 'scheme_substrand',
        entityId: substrand.id,
        targetLabel: `${substrand.code}: ${substrand.title}`,
        detail: `Under ${parentStrand.code} · Target ${substrand.targetLessons} lessons`,
        classroomId: parentStrand.classroomId,
      }),
    },
    substrand,
  };
}

export function updateSchemeStrand(
  state: SchoolECSState,
  strandId: string,
  updates: {
    classroomId?: string;
    subjectId?: string;
    code?: string;
    title?: string;
    term?: string;
  },
  actor?: AuditActor
): { state: SchoolECSState; strand?: SchemeStrandEntity; error?: string } {
  const existing = state.strands.find((s) => s.id === strandId);
  if (!existing) {
    return { state, error: 'Scheme strand not found.' };
  }
  const code = (updates.code ?? existing.code).trim().toUpperCase();
  const title = (updates.title ?? existing.title).trim();
  if (!code || !title) {
    return { state, error: 'Strand code and title are required.' };
  }
  const updated: SchemeStrandEntity = {
    ...existing,
    classroomId: updates.classroomId ?? existing.classroomId,
    subjectId: updates.subjectId ?? existing.subjectId,
    code,
    title,
    term: (updates.term ?? existing.term).trim() || existing.term,
  };
  return {
    state: {
      ...state,
      strands: state.strands.map((s) => (s.id === strandId ? updated : s)),
      substrands: state.substrands.map((sub) =>
        sub.strandId === strandId ? { ...sub, subjectId: updated.subjectId } : sub
      ),
      auditLogs: appendAudit(state, {
        actorId: actor?.actorId ?? existing.createdByTeacherId,
        actorName: actor?.actorName ?? 'Curriculum Staff',
        actorRole: actor?.actorRole ?? 'admin',
        action: 'Updated Scheme Strand',
        entityType: 'scheme_strand',
        entityId: strandId,
        targetLabel: `${updated.code}: ${updated.title}`,
        detail: `${updated.term}`,
        classroomId: updated.classroomId,
      }),
    },
    strand: updated,
  };
}

export function updateSchemeSubstrand(
  state: SchoolECSState,
  substrandId: string,
  updates: {
    code?: string;
    title?: string;
    learningOutcome?: string;
    targetLessons?: number;
  },
  actor?: AuditActor
): { state: SchoolECSState; substrand?: SchemeSubstrandEntity; error?: string } {
  const existing = state.substrands.find((s) => s.id === substrandId);
  if (!existing) {
    return { state, error: 'Scheme substrand not found.' };
  }
  const code = (updates.code ?? existing.code).trim().toUpperCase();
  const title = (updates.title ?? existing.title).trim();
  if (!code || !title) {
    return { state, error: 'Substrand code and title are required.' };
  }
  const updated: SchemeSubstrandEntity = {
    ...existing,
    code,
    title,
    learningOutcome:
      updates.learningOutcome !== undefined
        ? updates.learningOutcome.trim()
        : existing.learningOutcome,
    targetLessons:
      updates.targetLessons !== undefined
        ? Math.max(1, Number(updates.targetLessons) || 1)
        : existing.targetLessons,
  };
  const strand = state.strands.find((s) => s.id === updated.strandId);
  return {
    state: {
      ...state,
      substrands: state.substrands.map((s) => (s.id === substrandId ? updated : s)),
      auditLogs: appendAudit(state, {
        actorId: actor?.actorId ?? 'usr_admin',
        actorName: actor?.actorName ?? 'Curriculum Staff',
        actorRole: actor?.actorRole ?? 'admin',
        action: 'Updated Scheme Substrand',
        entityType: 'scheme_substrand',
        entityId: substrandId,
        targetLabel: `${updated.code}: ${updated.title}`,
        detail: `Target ${updated.targetLessons} lessons`,
        classroomId: strand?.classroomId,
      }),
    },
    substrand: updated,
  };
}

export function validateCustomFields(
  fields: DynamicFieldDefinition[],
  values: Record<string, string | number | boolean>,
  role: Role
): string | null {
  for (const def of fields) {
    const canEdit = role === 'admin' || def.editableBy.includes(role);
    if (!canEdit || !def.required) continue;
    const val = values[def.key];
    if (val === undefined || val === null || String(val).trim() === '') {
      return `"${def.label}" is required.`;
    }
  }
  return null;
}

export function createDiaryEntry(
  state: SchoolECSState,
  input: {
    learnerId: string;
    teacherId: string;
    date: string;
    homeworkSummary: string;
    teacherNote: string;
    customFields: Record<string, string | number | boolean>;
    actorRole: Role;
  },
  actor?: AuditActor
): { state: SchoolECSState; entry?: DiaryEntryEntity; error?: string } {
  const learner = state.learners.find((l) => l.id === input.learnerId);
  if (!learner) {
    return { state, error: 'Selected learner not found.' };
  }
  if (!input.homeworkSummary.trim()) {
    return { state, error: 'Homework summary is required.' };
  }
  const defs = getFieldsForEntity(state, 'diary_entry', input.actorRole);
  const validationError = validateCustomFields(defs, input.customFields, input.actorRole);
  if (validationError) {
    return { state, error: validationError };
  }

  const entry: DiaryEntryEntity = {
    id: `dia_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    learnerId: learner.id,
    classroomId: learner.classroomId,
    teacherId: input.teacherId,
    date: input.date,
    homeworkSummary: input.homeworkSummary.trim(),
    teacherNote: input.teacherNote.trim(),
    parentAcknowledged: false,
    customFields: { ...input.customFields },
  };
  const teacher = state.teachers.find((t) => t.id === input.teacherId);
  return {
    state: {
      ...state,
      diaryEntries: [entry, ...state.diaryEntries],
      auditLogs: appendAudit(state, {
        actorId: actor?.actorId ?? input.teacherId,
        actorName: actor?.actorName ?? teacher?.name ?? 'Teacher',
        actorRole: actor?.actorRole ?? input.actorRole,
        action: 'Logged School Diary',
        entityType: 'diary_entry',
        entityId: entry.id,
        targetLabel: learner.name,
        detail: entry.homeworkSummary,
        classroomId: learner.classroomId,
        teacherId: input.teacherId,
        learnerId: learner.id,
      }),
    },
    entry,
  };
}

export function broadcastClassroomDiary(
  state: SchoolECSState,
  input: {
    classroomId: string;
    teacherId: string;
    date: string;
    homeworkSummary: string;
    teacherNote: string;
    customFields: Record<string, string | number | boolean>;
    actorRole: Role;
  },
  actor?: AuditActor
): { state: SchoolECSState; entries: DiaryEntryEntity[]; error?: string } {
  const classroomLearners = state.learners.filter(
    (l) => l.classroomId === input.classroomId
  );
  if (classroomLearners.length === 0) {
    return {
      state,
      entries: [],
      error: 'No learners enrolled in the selected classroom.',
    };
  }
  if (!input.homeworkSummary.trim()) {
    return { state, entries: [], error: 'Homework summary is required.' };
  }
  const defs = getFieldsForEntity(state, 'diary_entry', input.actorRole);
  const validationError = validateCustomFields(
    defs,
    input.customFields,
    input.actorRole
  );
  if (validationError) {
    return { state, entries: [], error: validationError };
  }

  const stamp = Date.now();
  const entries: DiaryEntryEntity[] = classroomLearners.map((learner, idx) => ({
    id: `dia_${stamp}_${idx}_${Math.random().toString(36).slice(2, 5)}`,
    learnerId: learner.id,
    classroomId: learner.classroomId,
    teacherId: input.teacherId,
    date: input.date,
    homeworkSummary: input.homeworkSummary.trim(),
    teacherNote: input.teacherNote.trim(),
    parentAcknowledged: false,
    customFields: { ...input.customFields },
  }));

  const teacher = state.teachers.find((t) => t.id === input.teacherId);
  const classroom = state.classrooms.find((c) => c.id === input.classroomId);

  return {
    state: {
      ...state,
      diaryEntries: [...entries, ...state.diaryEntries],
      auditLogs: appendAudit(state, {
        actorId: actor?.actorId ?? input.teacherId,
        actorName: actor?.actorName ?? teacher?.name ?? 'Teacher',
        actorRole: actor?.actorRole ?? input.actorRole,
        action: 'Broadcast Classroom Diary',
        entityType: 'diary_entry',
        entityId: entries[0]?.id ?? input.classroomId,
        targetLabel: `${classroom?.name ?? input.classroomId} (${entries.length} learners)`,
        detail: input.homeworkSummary.trim(),
        classroomId: input.classroomId,
        teacherId: input.teacherId,
      }),
    },
    entries,
  };
}

export function toggleDiaryAcknowledgment(
  state: SchoolECSState,
  entryId: string,
  actor?: AuditActor
): SchoolECSState {
  const target = state.diaryEntries.find((d) => d.id === entryId);
  const learner = target
    ? state.learners.find((l) => l.id === target.learnerId)
    : undefined;
  const nextAck = target ? !target.parentAcknowledged : true;
  return {
    ...state,
    diaryEntries: state.diaryEntries.map((d) =>
      d.id === entryId ? { ...d, parentAcknowledged: !d.parentAcknowledged } : d
    ),
    auditLogs: target
      ? appendAudit(state, {
          actorId: actor?.actorId ?? 'usr_parent',
          actorName: actor?.actorName ?? learner?.parentName ?? 'Parent',
          actorRole: actor?.actorRole ?? 'parent',
          action: nextAck ? 'Signed School Diary' : 'Cleared Diary Sign-off',
          entityType: 'diary_entry',
          entityId: entryId,
          targetLabel: learner?.name ?? target.learnerId,
          detail: target.homeworkSummary,
          classroomId: target.classroomId,
          teacherId: target.teacherId,
          learnerId: target.learnerId,
        })
      : state.auditLogs,
  };
}

export function createAssessmentEntry(
  state: SchoolECSState,
  input: {
    learnerId: string;
    substrandId: string;
    teacherId: string;
    date: string;
    mastery: MasteryLevel;
    scorePercent: number;
    performanceComment: string;
    customFields: Record<string, string | number | boolean>;
    actorRole: Role;
  },
  actor?: AuditActor
): { state: SchoolECSState; entry?: AssessmentEntryEntity; error?: string } {
  const learner = state.learners.find((l) => l.id === input.learnerId);
  if (!learner) {
    return { state, error: 'Selected learner not found.' };
  }
  const substrand = state.substrands.find((s) => s.id === input.substrandId);
  if (!substrand) {
    return { state, error: 'Selected substrand not found in Schemes DB.' };
  }
  if (!input.performanceComment.trim()) {
    return { state, error: 'Performance comment is required.' };
  }
  const defs = getFieldsForEntity(state, 'assessment_entry', input.actorRole);
  const validationError = validateCustomFields(defs, input.customFields, input.actorRole);
  if (validationError) {
    return { state, error: validationError };
  }

  const entry: AssessmentEntryEntity = {
    id: `asm_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    learnerId: learner.id,
    subjectId: substrand.subjectId,
    strandId: substrand.strandId,
    substrandId: substrand.id,
    teacherId: input.teacherId,
    date: input.date,
    mastery: input.mastery,
    scorePercent: Math.min(100, Math.max(0, Number(input.scorePercent) || 0)),
    performanceComment: input.performanceComment.trim(),
    customFields: { ...input.customFields },
  };
  const teacher = state.teachers.find((t) => t.id === input.teacherId);
  return {
    state: {
      ...state,
      assessments: [entry, ...state.assessments],
      auditLogs: appendAudit(state, {
        actorId: actor?.actorId ?? input.teacherId,
        actorName: actor?.actorName ?? teacher?.name ?? 'Teacher',
        actorRole: actor?.actorRole ?? input.actorRole,
        action: 'Recorded Assessment',
        entityType: 'assessment_entry',
        entityId: entry.id,
        targetLabel: `${learner.name} · ${substrand.title}`,
        detail: `${entry.mastery} (${entry.scorePercent}%)`,
        classroomId: learner.classroomId,
        teacherId: input.teacherId,
        learnerId: learner.id,
      }),
    },
    entry,
  };
}

function syncLessonSlotBinding(
  lessonPlans: LessonPlanEntity[],
  timetableSlots: TimetableSlotEntity[],
  planId: string | undefined,
  slotId: string | undefined
): { lessonPlans: LessonPlanEntity[]; timetableSlots: TimetableSlotEntity[] } {
  const nextPlans = lessonPlans.map((lp) => {
    if (planId && lp.id === planId) {
      return { ...lp, timetableSlotId: slotId || undefined };
    }
    // Detach any other plan that previously held this same slot
    if (slotId && lp.timetableSlotId === slotId && lp.id !== planId) {
      return { ...lp, timetableSlotId: undefined };
    }
    return lp;
  });

  const nextSlots = timetableSlots.map((sl) => {
    if (slotId && sl.id === slotId) {
      return { ...sl, lessonPlanId: planId || undefined };
    }
    // Clear lessonPlanId from any other slot previously linked to this plan
    if (planId && sl.lessonPlanId === planId && sl.id !== slotId) {
      return { ...sl, lessonPlanId: undefined };
    }
    return sl;
  });

  return { lessonPlans: nextPlans, timetableSlots: nextSlots };
}

export function createLessonPlan(
  state: SchoolECSState,
  input: {
    teacherId: string;
    classroomId: string;
    substrandId: string;
    timetableSlotId?: string;
    title: string;
    scheduledDate: string;
    lessonsDelivered: number;
    status: LessonStatus;
    reflectionNote: string;
    customFields?: Record<string, string | number | boolean>;
  },
  actor?: AuditActor
): { state: SchoolECSState; plan?: LessonPlanEntity; error?: string } {
  const substrand = state.substrands.find((s) => s.id === input.substrandId);
  if (!substrand) {
    return { state, error: 'Substrand must exist in the Schemes database.' };
  }
  if (!input.title.trim()) {
    return { state, error: 'Lesson title is required.' };
  }
  const slotId = input.timetableSlotId?.trim() || undefined;
  const nowStamp = formatAuditTimestamp();
  const teacher = state.teachers.find((t) => t.id === input.teacherId);
  const actorName = actor?.actorName ?? teacher?.name ?? 'Teacher';
  const plan: LessonPlanEntity = {
    id: `lsn_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    teacherId: input.teacherId,
    taughtByTeacherId: input.status === 'planned' ? undefined : input.teacherId,
    taughtAt: input.status === 'planned' ? undefined : nowStamp,
    updatedBy: actorName,
    updatedAt: nowStamp,
    classroomId: input.classroomId,
    subjectId: substrand.subjectId,
    strandId: substrand.strandId,
    substrandId: substrand.id,
    timetableSlotId: slotId,
    title: input.title.trim(),
    scheduledDate: input.scheduledDate,
    lessonsDelivered: Math.max(
      0,
      input.status === 'planned' ? 0 : Number(input.lessonsDelivered) || 1
    ),
    status: input.status,
    reflectionNote: input.reflectionNote.trim(),
    customFields: input.customFields ?? {},
  };

  const synced = syncLessonSlotBinding(
    [plan, ...state.lessonPlans],
    state.timetableSlots,
    plan.id,
    slotId
  );
  const classroom = state.classrooms.find((c) => c.id === input.classroomId);

  return {
    state: {
      ...state,
      lessonPlans: synced.lessonPlans,
      timetableSlots: synced.timetableSlots,
      auditLogs: appendAudit(state, {
        actorId: actor?.actorId ?? input.teacherId,
        actorName,
        actorRole: actor?.actorRole ?? 'teacher',
        action: 'Registered Lesson Plan',
        entityType: 'lesson_plan',
        entityId: plan.id,
        targetLabel: plan.title,
        detail: `${classroom?.name ?? input.classroomId} · ${plan.status} (${plan.lessonsDelivered} lessons)`,
        classroomId: input.classroomId,
        teacherId: input.teacherId,
      }),
    },
    plan,
  };
}

export function updateLessonPlan(
  state: SchoolECSState,
  lessonPlanId: string,
  updates: {
    teacherId?: string;
    classroomId?: string;
    substrandId?: string;
    timetableSlotId?: string | null;
    title?: string;
    scheduledDate?: string;
    lessonsDelivered?: number;
    status?: LessonStatus;
    reflectionNote?: string;
    customFields?: Record<string, string | number | boolean>;
  },
  actor?: AuditActor
): { state: SchoolECSState; plan?: LessonPlanEntity; error?: string } {
  const existing = state.lessonPlans.find((lp) => lp.id === lessonPlanId);
  if (!existing) {
    return { state, error: 'Registered lesson not found.' };
  }
  const nextTitle = (updates.title ?? existing.title).trim();
  if (!nextTitle) {
    return { state, error: 'Lesson title is required.' };
  }
  const substrand = updates.substrandId
    ? state.substrands.find((s) => s.id === updates.substrandId)
    : state.substrands.find((s) => s.id === existing.substrandId);
  if (!substrand) {
    return { state, error: 'Selected Substrand not found in Schemes DB.' };
  }

  const nextStatus = updates.status ?? existing.status;
  const nextDelivered =
    nextStatus === 'planned'
      ? 0
      : updates.lessonsDelivered !== undefined
        ? Math.max(0, Number(updates.lessonsDelivered) || 0)
        : Math.max(1, existing.lessonsDelivered);

  const resolvedSlotId =
    updates.timetableSlotId === null
      ? undefined
      : updates.timetableSlotId !== undefined
        ? updates.timetableSlotId.trim() || undefined
        : existing.timetableSlotId;

  const nowStamp = formatAuditTimestamp();
  const nextTeacherId = updates.teacherId ?? existing.teacherId;
  const teacher = state.teachers.find((t) => t.id === nextTeacherId);
  const actorName = actor?.actorName ?? teacher?.name ?? 'Teacher';

  const updatedPlan: LessonPlanEntity = {
    ...existing,
    teacherId: nextTeacherId,
    taughtByTeacherId:
      nextStatus === 'planned'
        ? undefined
        : existing.taughtByTeacherId ?? nextTeacherId,
    taughtAt:
      nextStatus === 'planned' ? undefined : existing.taughtAt ?? nowStamp,
    updatedBy: actorName,
    updatedAt: nowStamp,
    classroomId: updates.classroomId ?? existing.classroomId,
    subjectId: substrand.subjectId,
    strandId: substrand.strandId,
    substrandId: substrand.id,
    timetableSlotId: resolvedSlotId,
    title: nextTitle,
    scheduledDate: updates.scheduledDate ?? existing.scheduledDate,
    lessonsDelivered: nextDelivered,
    status: nextStatus,
    reflectionNote:
      updates.reflectionNote !== undefined
        ? updates.reflectionNote.trim()
        : existing.reflectionNote,
    customFields: updates.customFields ?? existing.customFields,
  };

  const replacedPlans = state.lessonPlans.map((lp) =>
    lp.id === lessonPlanId ? updatedPlan : lp
  );
  const synced =
    updates.timetableSlotId !== undefined
      ? syncLessonSlotBinding(
          replacedPlans,
          state.timetableSlots,
          lessonPlanId,
          resolvedSlotId
        )
      : { lessonPlans: replacedPlans, timetableSlots: state.timetableSlots };

  return {
    state: {
      ...state,
      lessonPlans: synced.lessonPlans,
      timetableSlots: synced.timetableSlots,
      auditLogs: appendAudit(state, {
        actorId: actor?.actorId ?? nextTeacherId,
        actorName,
        actorRole: actor?.actorRole ?? 'teacher',
        action: 'Edited Lesson Plan',
        entityType: 'lesson_plan',
        entityId: updatedPlan.id,
        targetLabel: updatedPlan.title,
        detail: `${updatedPlan.status} · ${updatedPlan.lessonsDelivered} lessons`,
        classroomId: updatedPlan.classroomId,
        teacherId: nextTeacherId,
      }),
    },
    plan: updatedPlan,
  };
}

export function deleteLessonPlan(
  state: SchoolECSState,
  lessonPlanId: string,
  actor?: AuditActor
): SchoolECSState {
  const existing = state.lessonPlans.find((lp) => lp.id === lessonPlanId);
  return {
    ...state,
    lessonPlans: state.lessonPlans.filter((lp) => lp.id !== lessonPlanId),
    timetableSlots: state.timetableSlots.map((sl) =>
      sl.lessonPlanId === lessonPlanId ? { ...sl, lessonPlanId: undefined } : sl
    ),
    auditLogs: existing
      ? appendAudit(state, {
          actorId: actor?.actorId ?? existing.teacherId,
          actorName: actor?.actorName ?? 'Staff',
          actorRole: actor?.actorRole ?? 'admin',
          action: 'Deleted Lesson Plan',
          entityType: 'lesson_plan',
          entityId: lessonPlanId,
          targetLabel: existing.title,
          detail: `Removed from ${existing.classroomId}`,
          classroomId: existing.classroomId,
          teacherId: existing.teacherId,
        })
      : state.auditLogs,
  };
}

export function assignLessonToTimetableSlot(
  state: SchoolECSState,
  input: {
    lessonPlanId: string;
    timetableSlotId?: string;
    syncSlotSubjectAndTeacher?: boolean;
  }
): { state: SchoolECSState; error?: string } {
  const plan = state.lessonPlans.find((lp) => lp.id === input.lessonPlanId);
  if (!plan) {
    return { state, error: 'Registered lesson not found.' };
  }
  const slotId = input.timetableSlotId?.trim() || undefined;
  if (!slotId) {
    const synced = syncLessonSlotBinding(
      state.lessonPlans,
      state.timetableSlots,
      plan.id,
      undefined
    );
    return {
      state: {
        ...state,
        lessonPlans: synced.lessonPlans,
        timetableSlots: synced.timetableSlots,
      },
    };
  }
  const targetSlot = state.timetableSlots.find((s) => s.id === slotId);
  if (!targetSlot) {
    return { state, error: 'Target timetable slot not found.' };
  }

  let nextSlots = state.timetableSlots;
  if (input.syncSlotSubjectAndTeacher) {
    // Validate teacher availability on that day/period if changing slot teacher
    const conflict = detectTimetableConflict(
      state.timetableSlots,
      {
        classroomId: targetSlot.classroomId,
        teacherId: plan.teacherId,
        day: targetSlot.day,
        period: targetSlot.period,
        timeRange: targetSlot.timeRange,
        room: targetSlot.room,
      },
      targetSlot.id
    );
    if (conflict) {
      return { state, error: conflict };
    }
    nextSlots = nextSlots.map((s) =>
      s.id === targetSlot.id
        ? { ...s, subjectId: plan.subjectId, teacherId: plan.teacherId }
        : s
    );
  }

  const nextPlans = state.lessonPlans.map((lp) =>
    lp.id === plan.id
      ? {
          ...lp,
          classroomId: targetSlot.classroomId,
          timetableSlotId: targetSlot.id,
        }
      : lp
  );
  const synced = syncLessonSlotBinding(nextPlans, nextSlots, plan.id, targetSlot.id);
  return {
    state: {
      ...state,
      lessonPlans: synced.lessonPlans,
      timetableSlots: synced.timetableSlots,
    },
  };
}

export function updateLessonStatus(
  state: SchoolECSState,
  lessonPlanId: string,
  status: LessonStatus,
  lessonsDelivered?: number,
  taughtByTeacherId?: string,
  actor?: AuditActor
): SchoolECSState {
  const existing = state.lessonPlans.find((lp) => lp.id === lessonPlanId);
  if (!existing) return state;
  const delivered =
    status === 'planned'
      ? 0
      : lessonsDelivered !== undefined
        ? lessonsDelivered
        : Math.max(1, existing.lessonsDelivered);
  const nowStamp = formatAuditTimestamp();
  const deliveringTeacherId = taughtByTeacherId || existing.teacherId;
  const teacher = state.teachers.find((t) => t.id === deliveringTeacherId);
  const classroom = state.classrooms.find((c) => c.id === existing.classroomId);
  const actorName = actor?.actorName ?? teacher?.name ?? 'Teacher';

  return {
    ...state,
    lessonPlans: state.lessonPlans.map((lp) => {
      if (lp.id !== lessonPlanId) return lp;
      return {
        ...lp,
        status,
        lessonsDelivered: delivered,
        taughtByTeacherId: status === 'planned' ? undefined : deliveringTeacherId,
        taughtAt: status === 'planned' ? undefined : nowStamp,
        updatedBy: actorName,
        updatedAt: nowStamp,
      };
    }),
    auditLogs: appendAudit(state, {
      actorId: actor?.actorId ?? deliveringTeacherId,
      actorName,
      actorRole: actor?.actorRole ?? 'teacher',
      action:
        status === 'taught'
          ? 'Taught Lesson Plan'
          : status === 'in_progress'
            ? 'Marked Lesson In Progress'
            : 'Reset Lesson to Planned',
      entityType: 'lesson_plan',
      entityId: lessonPlanId,
      targetLabel: existing.title,
      detail: `${classroom?.name ?? existing.classroomId} · ${delivered} periods delivered`,
      classroomId: existing.classroomId,
      teacherId: deliveringTeacherId,
    }),
  };
}

export function upsertAttendanceRecord(
  state: SchoolECSState,
  input: {
    learnerId: string;
    teacherId: string;
    date: string;
    status: AttendanceStatus;
    remark: string;
    customFields?: Record<string, string | number | boolean>;
  },
  actor?: AuditActor
): { state: SchoolECSState; record?: AttendanceRecordEntity; error?: string } {
  const learner = state.learners.find((l) => l.id === input.learnerId);
  if (!learner) {
    return { state, error: 'Learner not found.' };
  }
  const teacher = state.teachers.find((t) => t.id === input.teacherId);
  const existing = state.attendanceRecords.find(
    (r) => r.learnerId === learner.id && r.date === input.date
  );
  if (existing) {
    const updated: AttendanceRecordEntity = {
      ...existing,
      status: input.status,
      remark: input.remark.trim(),
      teacherId: input.teacherId,
      customFields: {
        ...existing.customFields,
        ...(input.customFields ?? {}),
      },
    };
    return {
      state: {
        ...state,
        attendanceRecords: state.attendanceRecords.map((r) =>
          r.id === existing.id ? updated : r
        ),
        auditLogs: appendAudit(state, {
          actorId: actor?.actorId ?? input.teacherId,
          actorName: actor?.actorName ?? teacher?.name ?? 'Teacher',
          actorRole: actor?.actorRole ?? 'teacher',
          action: `Marked Attendance (${input.status})`,
          entityType: 'attendance_record',
          entityId: updated.id,
          targetLabel: `${learner.name} · ${input.date}`,
          detail: input.remark.trim() || input.status,
          classroomId: learner.classroomId,
          teacherId: input.teacherId,
          learnerId: learner.id,
        }),
      },
      record: updated,
    };
  }

  const record: AttendanceRecordEntity = {
    id: `att_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    learnerId: learner.id,
    classroomId: learner.classroomId,
    teacherId: input.teacherId,
    date: input.date,
    status: input.status,
    remark: input.remark.trim(),
    customFields: input.customFields ?? {},
  };
  return {
    state: {
      ...state,
      attendanceRecords: [record, ...state.attendanceRecords],
      auditLogs: appendAudit(state, {
        actorId: actor?.actorId ?? input.teacherId,
        actorName: actor?.actorName ?? teacher?.name ?? 'Teacher',
        actorRole: actor?.actorRole ?? 'teacher',
        action: `Marked Attendance (${input.status})`,
        entityType: 'attendance_record',
        entityId: record.id,
        targetLabel: `${learner.name} · ${input.date}`,
        detail: input.remark.trim() || input.status,
        classroomId: learner.classroomId,
        teacherId: input.teacherId,
        learnerId: learner.id,
      }),
    },
    record,
  };
}

export function markClassroomAllPresent(
  state: SchoolECSState,
  input: {
    classroomId: string;
    teacherId: string;
    date: string;
  },
  actor?: AuditActor
): { state: SchoolECSState; count: number; error?: string } {
  const learners = state.learners.filter(
    (l) => l.classroomId === input.classroomId
  );
  if (learners.length === 0) {
    return {
      state,
      count: 0,
      error: 'No learners enrolled in the selected classroom.',
    };
  }
  let nextState = state;
  for (const learner of learners) {
    const existing = nextState.attendanceRecords.find(
      (r) => r.learnerId === learner.id && r.date === input.date
    );
    const res = upsertAttendanceRecord(
      nextState,
      {
        learnerId: learner.id,
        teacherId: input.teacherId,
        date: input.date,
        status: 'present',
        remark: existing?.remark || 'Batch roll call: Present.',
        customFields: existing?.customFields ?? { uniform_compliant: true },
      },
      actor
    );
    if (!res.error) {
      nextState = res.state;
    }
  }
  return { state: nextState, count: learners.length };
}

export function getScheduleDaysForClassroom(
  state: SchoolECSState,
  classroomId: string
): ScheduleDayEntity[] {
  return [...(state.scheduleDays ?? [])]
    .filter((d) => d.classroomIds.includes(classroomId))
    .sort((a, b) => a.order - b.order);
}

export function upsertScheduleDay(
  state: SchoolECSState,
  input: {
    id?: string;
    code: string;
    label: string;
    order?: number;
    classroomIds: string[];
    defaultTimeRange?: string;
  }
): { state: SchoolECSState; day?: ScheduleDayEntity; error?: string } {
  const code = input.code.trim();
  const label = input.label.trim() || code;
  if (!code) {
    return { state, error: 'Day short code (e.g. Sat, Fri) is required.' };
  }
  const existingDays = state.scheduleDays ?? [];
  const existing = input.id
    ? existingDays.find((d) => d.id === input.id)
    : undefined;
  const duplicateCode = existingDays.some(
    (d) =>
      d.id !== input.id && d.code.toLowerCase() === code.toLowerCase()
  );
  if (duplicateCode) {
    return { state, error: `Schedule day "${code}" already exists.` };
  }

  const nextOrder =
    input.order !== undefined && Number.isFinite(input.order)
      ? Math.max(1, Math.round(input.order))
      : existing?.order ?? existingDays.length + 1;

  const day: ScheduleDayEntity = {
    id:
      existing?.id ??
      `day_${code.toLowerCase().replace(/[^a-z0-9]+/g, '_')}_${Date.now().toString(36)}`,
    code,
    label,
    order: nextOrder,
    classroomIds: Array.from(new Set(input.classroomIds)),
    defaultTimeRange:
      input.defaultTimeRange?.trim() ||
      existing?.defaultTimeRange ||
      '08:00 - 08:45',
  };

  // If renaming day code on edit, migrate timetable slots referencing old code
  const nextSlots =
    existing && existing.code !== day.code
      ? state.timetableSlots.map((s) =>
          s.day === existing.code ? { ...s, day: day.code } : s
        )
      : state.timetableSlots;

  const nextDays = existing
    ? existingDays.map((d) => (d.id === day.id ? day : d))
    : [...existingDays, day];

  nextDays.sort((a, b) => a.order - b.order);

  return {
    state: {
      ...state,
      scheduleDays: nextDays,
      timetableSlots: nextSlots,
    },
    day,
  };
}

export function toggleDayClassroomMapping(
  state: SchoolECSState,
  dayId: string,
  classroomId: string
): SchoolECSState {
  return {
    ...state,
    scheduleDays: (state.scheduleDays ?? []).map((d) => {
      if (d.id !== dayId) return d;
      const mapped = d.classroomIds.includes(classroomId)
        ? d.classroomIds.filter((c) => c !== classroomId)
        : [...d.classroomIds, classroomId];
      return { ...d, classroomIds: mapped };
    }),
  };
}

export function deleteScheduleDay(
  state: SchoolECSState,
  dayId: string
): SchoolECSState {
  const target = (state.scheduleDays ?? []).find((d) => d.id === dayId);
  if (!target) return state;
  const removedSlotIds = new Set(
    state.timetableSlots
      .filter((s) => s.day === target.code)
      .map((s) => s.id)
  );
  return {
    ...state,
    scheduleDays: (state.scheduleDays ?? []).filter((d) => d.id !== dayId),
    timetableSlots: state.timetableSlots.filter((s) => s.day !== target.code),
    lessonPlans: state.lessonPlans.map((lp) =>
      lp.timetableSlotId && removedSlotIds.has(lp.timetableSlotId)
        ? { ...lp, timetableSlotId: undefined }
        : lp
    ),
  };
}

export function upsertClassroom(
  state: SchoolECSState,
  input: {
    id?: string;
    name: string;
    gradeLevel: string;
    roomCode: string;
    classTeacherId?: string;
    defaultDayIds?: string[];
  },
  actor?: AuditActor
): { state: SchoolECSState; classroom?: ClassroomEntity; error?: string } {
  const name = input.name.trim();
  const gradeLevel = input.gradeLevel.trim();
  const roomCode = input.roomCode.trim();
  if (!name || !gradeLevel || !roomCode) {
    return {
      state,
      error: 'Classroom name, grade level, and home room code are required.',
    };
  }
  const existing = input.id
    ? state.classrooms.find((c) => c.id === input.id)
    : undefined;
  const nowStamp = formatAuditTimestamp();
  const actorName = actor?.actorName ?? 'Portal Admin';
  const resolvedClassTeacherId =
    input.classTeacherId !== undefined
      ? input.classTeacherId || undefined
      : existing?.classTeacherId;

  const classroom: ClassroomEntity = {
    id:
      existing?.id ??
      `cls_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
    name,
    gradeLevel,
    roomCode,
    classTeacherId: resolvedClassTeacherId,
    updatedBy: actorName,
    updatedAt: nowStamp,
  };
  const nextClassrooms = existing
    ? state.classrooms.map((c) => (c.id === classroom.id ? classroom : c))
    : [...state.classrooms, classroom];

  let nextDays = state.scheduleDays ?? [];
  if (!existing && input.defaultDayIds && input.defaultDayIds.length > 0) {
    nextDays = nextDays.map((d) =>
      input.defaultDayIds!.includes(d.id) &&
      !d.classroomIds.includes(classroom.id)
        ? { ...d, classroomIds: [...d.classroomIds, classroom.id] }
        : d
    );
  }

  const teacher = state.teachers.find((t) => t.id === resolvedClassTeacherId);
  return {
    state: {
      ...state,
      classrooms: nextClassrooms,
      scheduleDays: nextDays,
      auditLogs: appendAudit(state, {
        actorId: actor?.actorId ?? 'usr_admin',
        actorName,
        actorRole: actor?.actorRole ?? 'admin',
        action: existing ? 'Updated Classroom' : 'Created Classroom',
        entityType: 'classroom',
        entityId: classroom.id,
        targetLabel: classroom.name,
        detail: `Room ${classroom.roomCode}${teacher ? ` · Class Teacher: ${teacher.name}` : ''}`,
        classroomId: classroom.id,
        teacherId: resolvedClassTeacherId,
      }),
    },
    classroom,
  };
}

export function assignClassTeacher(
  state: SchoolECSState,
  classroomId: string,
  teacherId?: string,
  actor?: AuditActor
): SchoolECSState {
  const existing = state.classrooms.find((c) => c.id === classroomId);
  if (!existing) return state;
  const nowStamp = formatAuditTimestamp();
  const actorName = actor?.actorName ?? 'Portal Admin';
  const cleanTeacherId = teacherId?.trim() || undefined;
  const teacher = state.teachers.find((t) => t.id === cleanTeacherId);

  return {
    ...state,
    classrooms: state.classrooms.map((c) =>
      c.id === classroomId
        ? {
            ...c,
            classTeacherId: cleanTeacherId,
            updatedBy: actorName,
            updatedAt: nowStamp,
          }
        : c
    ),
    auditLogs: appendAudit(state, {
      actorId: actor?.actorId ?? 'usr_admin',
      actorName,
      actorRole: actor?.actorRole ?? 'admin',
      action: 'Assigned Class Teacher',
      entityType: 'classroom',
      entityId: classroomId,
      targetLabel: existing.name,
      detail: teacher ? `Homeroom lead: ${teacher.name}` : 'Unassigned homeroom lead',
      classroomId,
      teacherId: cleanTeacherId,
    }),
  };
}

function parseTimeRangeMinutes(
  timeRange?: string
): { start: number; end: number } | null {
  if (!timeRange) return null;
  const match = timeRange.match(/(\d{1,2}):(\d{2})\s*[-–—]\s*(\d{1,2}):(\d{2})/);
  if (!match) return null;
  const start = Number(match[1]) * 60 + Number(match[2]);
  const end = Number(match[3]) * 60 + Number(match[4]);
  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) {
    return null;
  }
  return { start, end };
}

function timesConflict(
  periodA: number,
  timeRangeA: string | undefined,
  periodB: number,
  timeRangeB: string | undefined
): boolean {
  if (periodA === periodB) return true;
  const a = parseTimeRangeMinutes(timeRangeA);
  const b = parseTimeRangeMinutes(timeRangeB);
  if (!a || !b) return false;
  return a.start < b.end && b.start < a.end;
}

export function detectTimetableConflict(
  slots: TimetableSlotEntity[],
  candidate: {
    classroomId: string;
    teacherId: string;
    day: Weekday;
    period: number;
    timeRange?: string;
    room: string;
  },
  ignoreSlotId?: string
): string | null {
  const normalizedRoom = candidate.room.trim().toLowerCase();
  const normalizedDay = candidate.day.trim().toLowerCase();
  for (const slot of slots) {
    if (ignoreSlotId && slot.id === ignoreSlotId) continue;
    if (slot.day.trim().toLowerCase() !== normalizedDay) continue;
    if (
      !timesConflict(
        slot.period,
        slot.timeRange,
        candidate.period,
        candidate.timeRange
      )
    ) {
      continue;
    }
    if (slot.classroomId === candidate.classroomId) {
      return `Classroom already has a scheduled period on ${candidate.day} (${candidate.timeRange || `P${candidate.period}`}).`;
    }
    if (slot.teacherId === candidate.teacherId) {
      return `Teacher is already double-booked on ${candidate.day} (${candidate.timeRange || `P${candidate.period}`}).`;
    }
    if (
      normalizedRoom &&
      slot.room.trim().toLowerCase() === normalizedRoom
    ) {
      return `Room "${candidate.room.trim()}" is already booked on ${candidate.day} (${candidate.timeRange || `P${candidate.period}`}).`;
    }
  }
  return null;
}

export function upsertTimetableSlot(
  state: SchoolECSState,
  input: {
    id?: string;
    classroomId: string;
    subjectId: string;
    teacherId: string;
    day: Weekday;
    period: number;
    timeRange: string;
    room: string;
    lessonPlanId?: string;
  }
): { state: SchoolECSState; slot?: TimetableSlotEntity; error?: string } {
  if (!input.classroomId || !input.subjectId || !input.teacherId) {
    return { state, error: 'Classroom, subject, and teacher are required.' };
  }
  const cleanDay = input.day.trim();
  const cleanRoom = input.room.trim();
  const cleanTime = input.timeRange.trim();
  if (!cleanDay || !cleanRoom || !cleanTime) {
    return { state, error: 'Day, time range, and room code are required.' };
  }
  const period = Math.max(1, Math.min(12, Math.round(Number(input.period) || 1)));
  const conflict = detectTimetableConflict(
    state.timetableSlots,
    {
      classroomId: input.classroomId,
      teacherId: input.teacherId,
      day: cleanDay,
      period,
      timeRange: cleanTime,
      room: cleanRoom,
    },
    input.id
  );
  if (conflict) {
    return { state, error: conflict };
  }

  const lessonPlanId = input.lessonPlanId?.trim() || undefined;
  const slot: TimetableSlotEntity = {
    id:
      input.id ??
      `tt_${cleanDay.toLowerCase().replace(/[^a-z0-9]+/g, '_')}_${period}_${Date.now().toString(36)}`,
    classroomId: input.classroomId,
    subjectId: input.subjectId,
    teacherId: input.teacherId,
    day: cleanDay,
    period,
    timeRange: cleanTime,
    room: cleanRoom,
    lessonPlanId,
  };

  const exists = Boolean(
    input.id && state.timetableSlots.some((s) => s.id === input.id)
  );
  const baseSlots = exists
    ? state.timetableSlots.map((s) => (s.id === slot.id ? slot : s))
    : [...state.timetableSlots, slot];

  const preUpdatedPlans = lessonPlanId
    ? state.lessonPlans.map((lp) =>
        lp.id === lessonPlanId
          ? { ...lp, classroomId: slot.classroomId, teacherId: slot.teacherId }
          : lp
      )
    : state.lessonPlans;

  const synced =
    input.lessonPlanId !== undefined
      ? syncLessonSlotBinding(preUpdatedPlans, baseSlots, lessonPlanId, slot.id)
      : { lessonPlans: preUpdatedPlans, timetableSlots: baseSlots };

  return {
    state: {
      ...state,
      timetableSlots: synced.timetableSlots,
      lessonPlans: synced.lessonPlans,
    },
    slot,
  };
}

export function deleteTimetableSlot(
  state: SchoolECSState,
  slotId: string
): SchoolECSState {
  return {
    ...state,
    timetableSlots: state.timetableSlots.filter((s) => s.id !== slotId),
    lessonPlans: state.lessonPlans.map((lp) =>
      lp.timetableSlotId === slotId ? { ...lp, timetableSlotId: undefined } : lp
    ),
  };
}

export function invitePortalUserAccount(
  state: SchoolECSState,
  input: {
    email: string;
    displayName: string;
    role: Role;
    teacherId?: string;
    linkedLearnerIds: string[];
  }
): { state: SchoolECSState; user?: PortalUserAccount; error?: string } {
  const email = input.email.trim().toLowerCase();
  const displayName = input.displayName.trim();
  if (!email || !email.includes('@')) {
    return { state, error: 'Valid user email is required.' };
  }
  if (!displayName) {
    return { state, error: 'Display name is required.' };
  }
  if (state.users.some((u) => u.email.toLowerCase() === email)) {
    return { state, error: `A user account with ${email} already exists.` };
  }
  const user: PortalUserAccount = {
    id: `usr_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    email,
    displayName,
    role: input.role,
    teacherId: input.role === 'parent' ? undefined : input.teacherId || undefined,
    linkedLearnerIds: Array.from(new Set(input.linkedLearnerIds)),
  };
  return {
    state: {
      ...state,
      users: [...state.users, user],
    },
    user,
  };
}

export function updatePortalUserAccount(
  state: SchoolECSState,
  userId: string,
  updates: Partial<
    Pick<
      PortalUserAccount,
      'displayName' | 'role' | 'teacherId' | 'linkedLearnerIds'
    >
  >
): { state: SchoolECSState; user?: PortalUserAccount; error?: string } {
  const existing = state.users.find((u) => u.id === userId);
  if (!existing) {
    return { state, error: 'User account not found.' };
  }
  const nextRole = updates.role ?? existing.role;
  const nextName = (updates.displayName ?? existing.displayName).trim();
  if (!nextName) {
    return { state, error: 'Display name is required.' };
  }
  const updated: PortalUserAccount = {
    ...existing,
    ...updates,
    displayName: nextName,
    role: nextRole,
    teacherId:
      nextRole === 'parent'
        ? undefined
        : updates.teacherId !== undefined
          ? updates.teacherId || undefined
          : existing.teacherId,
    linkedLearnerIds: Array.from(
      new Set(updates.linkedLearnerIds ?? existing.linkedLearnerIds)
    ),
  };
  return {
    state: {
      ...state,
      users: state.users.map((u) => (u.id === userId ? updated : u)),
    },
    user: updated,
  };
}

export function computeSubstrandCoverage(
  state: SchoolECSState
): SubstrandCoverageReport[] {
  return state.substrands.map((substrand) => {
    const strand = state.strands.find((s) => s.id === substrand.strandId)!;
    const subject = state.subjects.find((s) => s.id === substrand.subjectId)!;
    const classroom = state.classrooms.find(
      (c) => c.id === strand?.classroomId
    );
    const plans = state.lessonPlans.filter(
      (lp) =>
        lp.substrandId === substrand.id &&
        (!strand?.classroomId || lp.classroomId === strand.classroomId)
    );
    const taughtPlans = plans.filter((lp) => lp.status === 'taught');
    const deliveredLessons = plans.reduce(
      (sum, lp) => sum + (lp.status === 'planned' ? 0 : lp.lessonsDelivered),
      0
    );
    const coveragePercent = Math.min(
      100,
      Math.round((deliveredLessons / Math.max(1, substrand.targetLessons)) * 100)
    );
    const teacherIds = Array.from(
      new Set(plans.map((p) => p.taughtByTeacherId || p.teacherId))
    );
    const teachersInvolved = teacherIds
      .map((id) => state.teachers.find((t) => t.id === id)?.name)
      .filter((n): n is string => Boolean(n));

    return {
      substrand,
      strand,
      subject,
      classroom,
      targetLessons: substrand.targetLessons,
      deliveredLessons,
      taughtPlanCount: taughtPlans.length,
      plannedCount: plans.length,
      coveragePercent,
      teachersInvolved,
    };
  });
}

export function computeTeacherCoverageSummaries(
  state: SchoolECSState
): TeacherCoverageSummary[] {
  return state.teachers.map((teacher) => {
    const plans = state.lessonPlans.filter(
      (lp) => (lp.taughtByTeacherId || lp.teacherId) === teacher.id
    );
    const taughtPlans = plans.filter((lp) => lp.status === 'taught').length;
    const inProgressPlans = plans.filter((lp) => lp.status === 'in_progress').length;
    const plannedOnly = plans.filter((lp) => lp.status === 'planned').length;
    const totalLessonsDelivered = plans.reduce(
      (sum, lp) => sum + (lp.status === 'planned' ? 0 : lp.lessonsDelivered),
      0
    );
    const diaryEntriesLogged = state.diaryEntries.filter(
      (d) => d.teacherId === teacher.id
    ).length;
    const assessmentsLogged = state.assessments.filter(
      (a) => a.teacherId === teacher.id
    ).length;
    const coverageRatePercent =
      plans.length === 0 ? 0 : Math.round((taughtPlans / plans.length) * 100);

    return {
      teacher,
      totalPlans: plans.length,
      taughtPlans,
      inProgressPlans,
      plannedOnly,
      totalLessonsDelivered,
      diaryEntriesLogged,
      assessmentsLogged,
      coverageRatePercent,
    };
  });
}

export function buildScoreCandlesticks(
  assessments: AssessmentEntryEntity[],
  options: {
    bucketBy: 'month' | 'subject' | 'teacher';
    state: SchoolECSState;
  }
): ScoreCandlestickPoint[] {
  const groups = new Map<string, AssessmentEntryEntity[]>();
  const sorted = [...assessments].sort((a, b) => a.date.localeCompare(b.date));

  for (const item of sorted) {
    let key = item.date.slice(0, 7);
    if (options.bucketBy === 'subject') {
      key =
        options.state.subjects.find((s) => s.id === item.subjectId)?.code ??
        item.subjectId;
    } else if (options.bucketBy === 'teacher') {
      key =
        options.state.teachers
          .find((t) => t.id === item.teacherId)
          ?.name.split(' ')[0] ?? item.teacherId;
    }
    const list = groups.get(key) ?? [];
    list.push(item);
    groups.set(key, list);
  }

  const points: ScoreCandlestickPoint[] = [];
  for (const [label, items] of groups.entries()) {
    const scores = items.map((i) => i.scorePercent);
    const open = scores[0];
    const close = scores[scores.length - 1];
    const high = Math.max(...scores);
    const low = Math.min(...scores);
    const average = Math.round(
      scores.reduce((sum, s) => sum + s, 0) / scores.length
    );
    points.push({
      label,
      open,
      high,
      low,
      close,
      average,
      sampleCount: scores.length,
    });
  }
  return points;
}

export function computeTeacherClassMatrix(
  state: SchoolECSState
): TeacherClassMatrixRow[] {
  return state.teachers.map((teacher) => {
    const homeroomClassrooms = state.classrooms.filter(
      (c) => c.classTeacherId === teacher.id
    );
    const classes: TeacherClassSlice[] = state.classrooms
      .map((classroom) => {
        const plans = state.lessonPlans.filter(
          (lp) =>
            lp.classroomId === classroom.id &&
            (lp.taughtByTeacherId || lp.teacherId) === teacher.id
        );
        const taughtPlans = plans.filter((p) => p.status === 'taught').length;
        const lessonsDelivered = plans.reduce(
          (sum, p) => sum + (p.status === 'planned' ? 0 : p.lessonsDelivered),
          0
        );
        const classLearnerIds = new Set(
          state.learners
            .filter((l) => l.classroomId === classroom.id)
            .map((l) => l.id)
        );
        const assessmentsLogged = state.assessments.filter(
          (a) => a.teacherId === teacher.id && classLearnerIds.has(a.learnerId)
        ).length;
        const diaryLogged = state.diaryEntries.filter(
          (d) => d.teacherId === teacher.id && d.classroomId === classroom.id
        ).length;
        const isClassTeacher = classroom.classTeacherId === teacher.id;
        return {
          classroom,
          isClassTeacher,
          totalPlans: plans.length,
          taughtPlans,
          lessonsDelivered,
          assessmentsLogged,
          diaryLogged,
          coveragePercent:
            plans.length === 0 ? 0 : Math.round((taughtPlans / plans.length) * 100),
        };
      })
      .filter(
        (s) =>
          s.isClassTeacher ||
          s.totalPlans > 0 ||
          s.assessmentsLogged > 0 ||
          s.diaryLogged > 0
      );

    const allPlans = state.lessonPlans.filter(
      (lp) => (lp.taughtByTeacherId || lp.teacherId) === teacher.id
    );
    const taughtPlans = allPlans.filter((p) => p.status === 'taught').length;
    const lessonsDelivered = allPlans.reduce(
      (sum, p) => sum + (p.status === 'planned' ? 0 : p.lessonsDelivered),
      0
    );

    return {
      teacher,
      homeroomClassrooms,
      classes,
      totalPlans: allPlans.length,
      taughtPlans,
      lessonsDelivered,
      coveragePercent:
        allPlans.length === 0
          ? 0
          : Math.round((taughtPlans / allPlans.length) * 100),
    };
  });
}

export function computeClassroomMatrix(
  state: SchoolECSState
): ClassroomMatrixRow[] {
  const substrandReports = computeSubstrandCoverage(state);
  return state.classrooms.map((classroom) => {
    const classTeacher = state.teachers.find(
      (t) => t.id === classroom.classTeacherId
    );
    const classLearners = state.learners.filter(
      (l) => l.classroomId === classroom.id
    );
    const learnerIds = new Set(classLearners.map((l) => l.id));
    const classAttendance = state.attendanceRecords.filter(
      (r) => r.classroomId === classroom.id
    );
    const presentOrLate = classAttendance.filter(
      (r) => r.status === 'present' || r.status === 'late'
    ).length;
    const attendanceRatePercent =
      classAttendance.length === 0
        ? 100
        : Math.round((presentOrLate / classAttendance.length) * 100);

    const classAssessments = state.assessments.filter((a) =>
      learnerIds.has(a.learnerId)
    );
    const averageScorePercent =
      classAssessments.length === 0
        ? null
        : Math.round(
            classAssessments.reduce((s, a) => s + a.scorePercent, 0) /
              classAssessments.length
          );

    const classStrands = state.strands.filter(
      (s) => s.classroomId === classroom.id
    );
    const classSubstrandReports = substrandReports.filter(
      (r) => r.strand?.classroomId === classroom.id
    );
    const avgCoveragePercent =
      classSubstrandReports.length === 0
        ? 0
        : Math.round(
            classSubstrandReports.reduce((s, r) => s + r.coveragePercent, 0) /
              classSubstrandReports.length
          );

    const classPlans = state.lessonPlans.filter(
      (lp) => lp.classroomId === classroom.id
    );
    const taughtLessonsCount = classPlans.filter(
      (lp) => lp.status === 'taught'
    ).length;
    const totalLessonsDelivered = classPlans.reduce(
      (sum, lp) => sum + (lp.status === 'planned' ? 0 : lp.lessonsDelivered),
      0
    );

    const teacherSlices: ClassroomTeacherSlice[] = state.teachers
      .map((teacher) => {
        const plans = classPlans.filter(
          (lp) => (lp.taughtByTeacherId || lp.teacherId) === teacher.id
        );
        const taught = plans.filter((lp) => lp.status === 'taught').length;
        const delivered = plans.reduce(
          (sum, lp) => sum + (lp.status === 'planned' ? 0 : lp.lessonsDelivered),
          0
        );
        const assessmentsLogged = classAssessments.filter(
          (a) => a.teacherId === teacher.id
        ).length;
        const diaryLogged = state.diaryEntries.filter(
          (d) => d.classroomId === classroom.id && d.teacherId === teacher.id
        ).length;
        const isClassTeacher = classroom.classTeacherId === teacher.id;
        return {
          teacher,
          isClassTeacher,
          totalPlans: plans.length,
          taughtPlans: taught,
          lessonsDelivered: delivered,
          assessmentsLogged,
          diaryLogged,
        };
      })
      .filter(
        (s) =>
          s.isClassTeacher ||
          s.totalPlans > 0 ||
          s.assessmentsLogged > 0 ||
          s.diaryLogged > 0
      );

    return {
      classroom,
      classTeacher,
      learnerCount: classLearners.length,
      attendanceRatePercent,
      averageScorePercent,
      strandCount: classStrands.length,
      substrandCount: classSubstrandReports.length,
      avgCoveragePercent,
      taughtLessonsCount,
      totalPlansCount: classPlans.length,
      totalLessonsDelivered,
      teacherSlices,
    };
  });
}

export function computeParentSummaries(state: SchoolECSState): ParentSummary[] {
  const byEmail = new Map<
    string,
    {
      parentKey: string;
      parentName: string;
      parentEmail: string;
      guardianPhone: string;
      children: typeof state.learners;
    }
  >();

  for (const learner of state.learners) {
    const emailKey = learner.parentEmail.trim().toLowerCase() || learner.id;
    const existing = byEmail.get(emailKey);
    if (existing) {
      existing.children.push(learner);
    } else {
      byEmail.set(emailKey, {
        parentKey: emailKey,
        parentName: learner.parentName,
        parentEmail: learner.parentEmail,
        guardianPhone: learner.guardianPhone,
        children: [learner],
      });
    }
  }

  for (const user of state.users.filter((u) => u.role === 'parent')) {
    const emailKey = user.email.trim().toLowerCase();
    const linked = state.learners.filter((l) =>
      user.linkedLearnerIds.includes(l.id)
    );
    const existing = byEmail.get(emailKey);
    if (existing) {
      for (const child of linked) {
        if (!existing.children.some((c) => c.id === child.id)) {
          existing.children.push(child);
        }
      }
    } else {
      byEmail.set(emailKey, {
        parentKey: emailKey,
        parentName: user.displayName,
        parentEmail: user.email,
        guardianPhone: linked[0]?.guardianPhone ?? '—',
        children: linked,
      });
    }
  }

  return Array.from(byEmail.values()).map((group) => {
    const childIds = new Set(group.children.map((c) => c.id));
    const classIds = new Set(group.children.map((c) => c.classroomId));
    const classrooms = state.classrooms.filter((c) => classIds.has(c.id));
    const childAssessments = state.assessments.filter((a) =>
      childIds.has(a.learnerId)
    );
    const avgScorePercent =
      childAssessments.length === 0
        ? null
        : Math.round(
            childAssessments.reduce((s, a) => s + a.scorePercent, 0) /
              childAssessments.length
          );
    const childAttendance = state.attendanceRecords.filter((r) =>
      childIds.has(r.learnerId)
    );
    const presentCount = childAttendance.filter(
      (r) => r.status === 'present' || r.status === 'late'
    ).length;
    const attendanceRatePercent =
      childAttendance.length === 0
        ? null
        : Math.round((presentCount / childAttendance.length) * 100);
    const childDiary = state.diaryEntries.filter((d) =>
      childIds.has(d.learnerId)
    );
    const pendingSignOffCount = childDiary.filter(
      (d) => !d.parentAcknowledged
    ).length;

    const locationIds = new Set(
      group.children
        .map((c) => c.locationId)
        .filter((id): id is string => Boolean(id))
    );
    const locations = (state.locations ?? []).filter((loc) =>
      locationIds.has(loc.id)
    );

    const portalUser = state.users.find(
      (u) => u.email.toLowerCase() === group.parentKey
    );

    return {
      ...group,
      portalUser,
      classrooms,
      locations,
      avgScorePercent,
      attendanceRatePercent,
      diaryCount: childDiary.length,
      pendingSignOffCount,
      assessmentCount: childAssessments.length,
    };
  });
}

export function upsertLocation(
  state: SchoolECSState,
  input: {
    id?: string;
    name: string;
    zone?: string;
    notes?: string;
  },
  actor?: AuditActor
): { state: SchoolECSState; location?: LocationEntity; error?: string } {
  const name = input.name.trim();
  const zone = (input.zone ?? '').trim() || 'General Catchment';
  const notes = (input.notes ?? '').trim();
  if (!name) {
    return { state, error: 'Location name is required.' };
  }

  const currentLocations = state.locations ?? [];
  const duplicate = currentLocations.some(
    (loc) =>
      loc.id !== input.id && loc.name.trim().toLowerCase() === name.toLowerCase()
  );
  if (duplicate) {
    return {
      state,
      error: `Location "${name}" already exists.`,
    };
  }

  const existing = input.id
    ? currentLocations.find((loc) => loc.id === input.id)
    : undefined;
  const nowStamp = formatAuditTimestamp();
  const actorName = actor?.actorName ?? 'Portal Admin';

  const location: LocationEntity = {
    id:
      existing?.id ??
      `loc_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
    name,
    zone,
    notes,
    updatedBy: actorName,
    updatedAt: nowStamp,
  };

  const nextLocations = existing
    ? currentLocations.map((loc) => (loc.id === location.id ? location : loc))
    : [...currentLocations, location];

  return {
    state: {
      ...state,
      locations: nextLocations,
      auditLogs: appendAudit(state, {
        actorId: actor?.actorId ?? 'usr_admin',
        actorName,
        actorRole: actor?.actorRole ?? 'admin',
        action: existing ? 'Updated Location' : 'Created Location',
        entityType: 'location',
        entityId: location.id,
        targetLabel: location.name,
        detail: `${location.zone}${location.notes ? ` · ${location.notes}` : ''}`,
      }),
    },
    location,
  };
}

export function deleteLocation(
  state: SchoolECSState,
  locationId: string,
  actor?: AuditActor
): SchoolECSState {
  const currentLocations = state.locations ?? [];
  const existing = currentLocations.find((loc) => loc.id === locationId);
  if (!existing) return state;

  return {
    ...state,
    locations: currentLocations.filter((loc) => loc.id !== locationId),
    learners: state.learners.map((l) =>
      l.locationId === locationId ? { ...l, locationId: undefined } : l
    ),
    auditLogs: appendAudit(state, {
      actorId: actor?.actorId ?? 'usr_admin',
      actorName: actor?.actorName ?? 'Portal Admin',
      actorRole: actor?.actorRole ?? 'admin',
      action: 'Deleted Location',
      entityType: 'location',
      entityId: locationId,
      targetLabel: existing.name,
      detail: `Removed from ${existing.zone}`,
    }),
  };
}

export function computeLocationSummaries(
  state: SchoolECSState
): LocationSummary[] {
  return (state.locations ?? []).map((location) => {
    const locLearners = state.learners.filter(
      (l) => l.locationId === location.id
    );
    const learnerIds = new Set(locLearners.map((l) => l.id));
    const familyCount = new Set(
      locLearners.map((l) => l.parentEmail.trim().toLowerCase() || l.id)
    ).size;
    const classroomCount = new Set(locLearners.map((l) => l.classroomId)).size;

    const assessments = state.assessments.filter((a) =>
      learnerIds.has(a.learnerId)
    );
    const averageScorePercent =
      assessments.length === 0
        ? null
        : Math.round(
            assessments.reduce((sum, a) => sum + a.scorePercent, 0) /
              assessments.length
          );

    const attendance = state.attendanceRecords.filter((r) =>
      learnerIds.has(r.learnerId)
    );
    const presentCount = attendance.filter(
      (r) => r.status === 'present' || r.status === 'late'
    ).length;
    const attendanceRatePercent =
      attendance.length === 0
        ? null
        : Math.round((presentCount / attendance.length) * 100);

    return {
      location,
      learnerCount: locLearners.length,
      familyCount,
      classroomCount,
      averageScorePercent,
      attendanceRatePercent,
    };
  });
}

export function getEntityGraphSnapshot(
  state: SchoolECSState,
  entityType: EntityType
): unknown[] {
  switch (entityType) {
    case 'classroom':
      return state.classrooms;
    case 'location':
      return state.locations ?? [];
    case 'teacher':
      return state.teachers;
    case 'learner':
      return state.learners;
    case 'subject':
      return state.subjects;
    case 'schedule_day':
      return state.scheduleDays ?? [];
    case 'scheme_strand':
      return state.strands;
    case 'scheme_substrand':
      return state.substrands;
    case 'diary_entry':
      return state.diaryEntries;
    case 'assessment_entry':
      return state.assessments;
    case 'lesson_plan':
      return state.lessonPlans;
    case 'timetable_slot':
      return state.timetableSlots;
    case 'attendance_record':
      return state.attendanceRecords;
  }
}

export function getPageWidgetsForRole(
  state: SchoolECSState,
  pageId: PageWidgetDefinition['pageId'],
  role: Role
): PageWidgetDefinition[] {
  return [...state.pageWidgets]
    .filter(
      (w) =>
        w.pageId === pageId &&
        w.enabled &&
        (role === 'admin' || w.allowedRoles.includes(role))
    )
    .sort((a, b) => a.order - b.order);
}

export function togglePageWidgetEnabled(
  state: SchoolECSState,
  widgetId: PageWidgetId
): SchoolECSState {
  return {
    ...state,
    pageWidgets: state.pageWidgets.map((w) =>
      w.id === widgetId ? { ...w, enabled: !w.enabled } : w
    ),
  };
}

export function togglePageWidgetRole(
  state: SchoolECSState,
  widgetId: PageWidgetId,
  role: Exclude<Role, 'admin'>
): SchoolECSState {
  return {
    ...state,
    pageWidgets: state.pageWidgets.map((w) => {
      if (w.id !== widgetId) return w;
      const hasRole = w.allowedRoles.includes(role);
      const nextRoles = hasRole
        ? w.allowedRoles.filter((r) => r !== role)
        : [...w.allowedRoles, role];
      return { ...w, allowedRoles: nextRoles };
    }),
  };
}

export function movePageWidget(
  state: SchoolECSState,
  widgetId: PageWidgetId,
  direction: 'up' | 'down'
): SchoolECSState {
  const sorted = [...state.pageWidgets].sort((a, b) => a.order - b.order);
  const idx = sorted.findIndex((w) => w.id === widgetId);
  if (idx === -1) return state;
  const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
  if (swapIdx < 0 || swapIdx >= sorted.length) return state;

  const current = sorted[idx];
  const neighbor = sorted[swapIdx];
  return {
    ...state,
    pageWidgets: state.pageWidgets.map((w) => {
      if (w.id === current.id) return { ...w, order: neighbor.order };
      if (w.id === neighbor.id) return { ...w, order: current.order };
      return w;
    }),
  };
}

export function resolveTimeframeBounds(
  registeredAt: string,
  timeframe: LearnerTimeframe,
  referenceToday = '2026-11-25',
  activeTerm?: AcademicTermEntity
): { from: string; to: string } {
  switch (timeframe.preset) {
    case 'since_registration':
      return { from: registeredAt, to: referenceToday };
    case 'this_term':
      return {
        from: activeTerm?.startDate ?? '2026-09-01',
        to: activeTerm?.endDate && activeTerm.endDate < referenceToday
          ? activeTerm.endDate
          : referenceToday,
      };
    case 'last_30_days':
      return { from: '2026-10-26', to: referenceToday };
    case 'custom':
      return {
        from: timeframe.fromDate || registeredAt,
        to: timeframe.toDate || referenceToday,
      };
  }
}

export function buildLearnerLongitudinalReport(
  state: SchoolECSState,
  learnerId: string,
  role: Role,
  timeframe: LearnerTimeframe,
  referenceToday = '2026-11-25'
) {
  const learner = state.learners.find((l) => l.id === learnerId);
  if (!learner) return null;

  const bounds = resolveTimeframeBounds(
    learner.registeredAt,
    timeframe,
    referenceToday,
    getActiveAcademicTerm(state)
  );
  const inRange = (d: string) => d >= bounds.from && d <= bounds.to;

  const diary = state.diaryEntries
    .filter((d) => d.learnerId === learnerId && inRange(d.date))
    .sort((a, b) => b.date.localeCompare(a.date));

  const assessments = state.assessments
    .filter((a) => a.learnerId === learnerId && inRange(a.date))
    .sort((a, b) => b.date.localeCompare(a.date));

  const attendance = state.attendanceRecords
    .filter((r) => r.learnerId === learnerId && inRange(r.date))
    .sort((a, b) => b.date.localeCompare(a.date));

  const averageScore =
    assessments.length === 0
      ? null
      : Math.round(
          assessments.reduce((s, a) => s + a.scorePercent, 0) / assessments.length
        );

  const presentOrLate = attendance.filter(
    (r) => r.status === 'present' || r.status === 'late'
  ).length;
  const attendanceRate =
    attendance.length === 0
      ? null
      : Math.round((presentOrLate / attendance.length) * 100);

  const awardsCount = diary.filter(
    (d) =>
      typeof d.customFields.awards === 'string' &&
      d.customFields.awards.trim().length > 0
  ).length;

  const timeline: LearnerTimelineEvent[] = [];

  if (inRange(learner.registeredAt)) {
    timeline.push({
      id: `reg_${learner.id}`,
      date: learner.registeredAt,
      category: 'registration',
      title: `Enrolled (${learner.admissionNo})`,
      detail: `Registered in ${
        state.classrooms.find((c) => c.id === learner.classroomId)?.name ??
        learner.classroomId
      }`,
      meta: `Status: ${learner.enrollmentStatus}`,
    });
  }

  for (const d of diary) {
    const award = d.customFields.awards
      ? ` · Award: ${String(d.customFields.awards)}`
      : '';
    timeline.push({
      id: d.id,
      date: d.date,
      category: 'diary',
      title: `Diary: ${d.homeworkSummary}`,
      detail: `${d.teacherNote || 'Daily log'}${award}`,
      meta: d.parentAcknowledged ? 'Parent signed' : 'Pending sign-off',
    });
  }

  for (const a of assessments) {
    const sub = state.substrands.find((s) => s.id === a.substrandId);
    const subj = state.subjects.find((s) => s.id === a.subjectId);
    timeline.push({
      id: a.id,
      date: a.date,
      category: 'assessment',
      title: `Assessment: ${subj?.name ?? ''} — ${sub?.title ?? a.substrandId}`,
      detail: a.performanceComment,
      meta: `${a.mastery} (${a.scorePercent}%)`,
    });
  }

  for (const r of attendance) {
    const staffNote =
      role !== 'parent' && r.customFields.uniform_compliant !== undefined
        ? ` · Uniform: ${r.customFields.uniform_compliant ? 'Compliant' : 'Follow-up'}`
        : '';
    timeline.push({
      id: r.id,
      date: r.date,
      category: 'attendance',
      title: `Register: ${r.status.toUpperCase()}`,
      detail: `${r.remark || 'Daily roll call'}${staffNote}`,
      meta: r.status,
    });
  }

  timeline.sort((a, b) => b.date.localeCompare(a.date));

  return {
    learner,
    bounds,
    diary,
    assessments,
    attendance,
    averageScore,
    attendanceRate,
    awardsCount,
    timeline,
  };
}

export function computeSubjectMasteryProgression(
  state: SchoolECSState,
  learnerId: string,
  fromDate?: string,
  toDate?: string
): SubjectMasterySeries[] {
  const filtered = state.assessments
    .filter((a) => {
      if (a.learnerId !== learnerId) return false;
      if (fromDate && a.date < fromDate) return false;
      if (toDate && a.date > toDate) return false;
      return true;
    })
    .sort((a, b) => a.date.localeCompare(b.date));

  const bySubject = new Map<string, SubjectMasteryPoint[]>();
  for (const entry of filtered) {
    const sub = state.substrands.find((s) => s.id === entry.substrandId);
    const pt: SubjectMasteryPoint = {
      date: entry.date,
      scorePercent: entry.scorePercent,
      mastery: entry.mastery,
      substrandTitle: sub ? `${sub.code}: ${sub.title}` : entry.substrandId,
    };
    const arr = bySubject.get(entry.subjectId) ?? [];
    arr.push(pt);
    bySubject.set(entry.subjectId, arr);
  }

  const series: SubjectMasterySeries[] = [];
  for (const subject of state.subjects) {
    const points = bySubject.get(subject.id);
    if (!points || points.length === 0) continue;
    const latestScore = points[points.length - 1].scorePercent;
    const deltaFromFirst = latestScore - points[0].scorePercent;
    series.push({
      subject,
      points,
      latestScore,
      deltaFromFirst,
    });
  }
  return series;
}

export function escapeHtml(raw: string): string {
  return raw
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function buildLearnerPrintableReportHtml(
  state: SchoolECSState,
  learnerId: string,
  role: Role,
  timeframe: LearnerTimeframe,
  referenceToday = '2026-11-25'
): string | null {
  const report = buildLearnerLongitudinalReport(
    state,
    learnerId,
    role,
    timeframe,
    referenceToday
  );
  if (!report) return null;

  const { learner, bounds } = report;
  const classroom = state.classrooms.find((c) => c.id === learner.classroomId);
  const progression = computeSubjectMasteryProgression(
    state,
    learnerId,
    bounds.from,
    bounds.to
  );

  const subjectRows = progression
    .map((s) => {
      const deltaSign = s.deltaFromFirst >= 0 ? '+' : '';
      return `<tr>
        <td>${escapeHtml(s.subject.name)}</td>
        <td>${s.points.length}</td>
        <td>${s.latestScore}%</td>
        <td>${deltaSign}${s.deltaFromFirst}%</td>
      </tr>`;
    })
    .join('');

  const assessmentRows = report.assessments
    .map((a) => {
      const subj = state.subjects.find((s) => s.id === a.subjectId);
      const sub = state.substrands.find((s) => s.id === a.substrandId);
      return `<tr>
        <td>${escapeHtml(a.date)}</td>
        <td>${escapeHtml(subj?.name ?? a.subjectId)}</td>
        <td>${escapeHtml(sub ? `${sub.code}: ${sub.title}` : a.substrandId)}</td>
        <td>${escapeHtml(a.mastery)} (${a.scorePercent}%)</td>
        <td>${escapeHtml(a.performanceComment)}</td>
      </tr>`;
    })
    .join('');

  const diaryRows = report.diary
    .map(
      (d) => `<tr>
        <td>${escapeHtml(d.date)}</td>
        <td>${escapeHtml(d.homeworkSummary)}</td>
        <td>${escapeHtml(d.teacherNote || '—')}</td>
        <td>${d.parentAcknowledged ? 'Signed' : 'Pending'}</td>
      </tr>`
    )
    .join('');

  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Learner Report — ${escapeHtml(learner.name)}</title>
  <style>
    body { font-family: system-ui, -apple-system, sans-serif; color: #0f172a; margin: 32px; line-height: 1.5; }
    h1 { margin: 0 0 4px; font-size: 22px; }
    h2 { margin: 24px 0 8px; font-size: 15px; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px; }
    .meta { color: #475569; font-size: 13px; margin-bottom: 16px; }
    .kpis { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px; margin: 16px 0; }
    .kpi { border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px 12px; }
    .kpi-label { font-size: 11px; color: #64748b; }
    .kpi-value { font-size: 18px; font-weight: 700; margin-top: 2px; }
    table { width: 100%; border-collapse: collapse; font-size: 12px; margin-top: 8px; }
    th, td { border: 1px solid #e2e8f0; padding: 6px 8px; text-align: left; vertical-align: top; }
    th { background: #f8fafc; font-weight: 600; }
    @media print { body { margin: 16px; } }
  </style>
</head>
<body>
  <h1>${escapeHtml(learner.name)} — Longitudinal Learner Report</h1>
  <div class="meta">
    Admission: ${escapeHtml(learner.admissionNo)} · Classroom: ${escapeHtml(classroom?.name ?? learner.classroomId)} · Window: ${escapeHtml(bounds.from)} to ${escapeHtml(bounds.to)} · Portal View: ${escapeHtml(role.toUpperCase())}
  </div>
  <div class="kpis">
    <div class="kpi"><div class="kpi-label">Registered</div><div class="kpi-value">${escapeHtml(learner.registeredAt)}</div></div>
    <div class="kpi"><div class="kpi-label">Average Assessment</div><div class="kpi-value">${report.averageScore !== null ? `${report.averageScore}%` : '—'}</div></div>
    <div class="kpi"><div class="kpi-label">Attendance Rate</div><div class="kpi-value">${report.attendanceRate !== null ? `${report.attendanceRate}%` : '—'}</div></div>
    <div class="kpi"><div class="kpi-label">Diary Awards</div><div class="kpi-value">${report.awardsCount} / ${report.diary.length}</div></div>
  </div>
  <h2>Subject Mastery Progression</h2>
  <table><thead><tr><th>Subject</th><th>Assessments</th><th>Latest Score</th><th>Progression</th></tr></thead><tbody>${subjectRows || '<tr><td colspan="4">No subject assessments in range.</td></tr>'}</tbody></table>
  <h2>Assessment Book</h2>
  <table><thead><tr><th>Date</th><th>Subject</th><th>Substrand</th><th>Mastery</th><th>Comment</th></tr></thead><tbody>${assessmentRows || '<tr><td colspan="5">No assessments in range.</td></tr>'}</tbody></table>
  <h2>School Diary</h2>
  <table><thead><tr><th>Date</th><th>Homework</th><th>Teacher Note</th><th>Parent Sign-off</th></tr></thead><tbody>${diaryRows || '<tr><td colspan="4">No diary entries in range.</td></tr>'}</tbody></table>
</body>
</html>`;
}

export function upsertSchoolEvent(
  state: SchoolECSState,
  input: {
    id?: string;
    date: string;
    title: string;
    description: string;
    kind: SchoolEventKind;
    classroomId?: string;
    actorRole: Role;
  },
  actor?: AuditActor
): { state: SchoolECSState; event?: SchoolEventEntity; error?: string } {
  if (input.actorRole !== 'admin') {
    return { state, error: 'Only administrators can create or edit school calendar events.' };
  }
  const cleanTitle = input.title.trim();
  if (!cleanTitle) {
    return { state, error: 'Event title is required.' };
  }
  const cleanDate = input.date.trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(cleanDate)) {
    return { state, error: 'Date must be formatted as YYYY-MM-DD.' };
  }
  const event: SchoolEventEntity = {
    id: input.id?.trim() || `evt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    date: cleanDate,
    title: cleanTitle,
    description: input.description.trim(),
    kind: input.kind,
    classroomId: input.classroomId?.trim() || undefined,
  };
  const exists = state.schoolEvents.some((e) => e.id === event.id);
  const nextEvents = (
    exists
      ? state.schoolEvents.map((e) => (e.id === event.id ? event : e))
      : [...state.schoolEvents, event]
  ).sort((a, b) => a.date.localeCompare(b.date));

  return {
    state: {
      ...state,
      schoolEvents: nextEvents,
      auditLogs: appendAudit(state, {
        actorId: actor?.actorId ?? 'usr_admin',
        actorName: actor?.actorName ?? 'Portal Admin',
        actorRole: actor?.actorRole ?? 'admin',
        action: exists ? 'Updated Calendar Event' : 'Added Calendar Event',
        entityType: 'school_event',
        entityId: event.id,
        targetLabel: `${event.date} · ${event.title}`,
        detail: `${event.kind}: ${event.description || 'School calendar entry'}`,
      }),
    },
    event,
  };
}

export function deleteSchoolEvent(
  state: SchoolECSState,
  eventId: string,
  actorRole: Role,
  actor?: AuditActor
): { state: SchoolECSState; error?: string } {
  if (actorRole !== 'admin') {
    return { state, error: 'Only administrators can delete school calendar events.' };
  }
  const existing = state.schoolEvents.find((e) => e.id === eventId);
  return {
    state: {
      ...state,
      schoolEvents: state.schoolEvents.filter((e) => e.id !== eventId),
      auditLogs: existing
        ? appendAudit(state, {
            actorId: actor?.actorId ?? 'usr_admin',
            actorName: actor?.actorName ?? 'Portal Admin',
            actorRole: actor?.actorRole ?? 'admin',
            action: 'Deleted Calendar Event',
            entityType: 'school_event',
            entityId: eventId,
            targetLabel: `${existing.date} · ${existing.title}`,
            detail: 'Removed from school calendar',
          })
        : state.auditLogs,
    },
  };
}

export function getActiveAcademicTerm(
  state: SchoolECSState
): AcademicTermEntity | undefined {
  const terms = state.academicTerms ?? [];
  return (
    terms.find((t) => t.id === state.activeTermId) ??
    terms.find((t) => t.isActive) ??
    terms[0]
  );
}

export function upsertAcademicTerm(
  state: SchoolECSState,
  input: {
    id?: string;
    name: string;
    startDate: string;
    endDate: string;
    isActive?: boolean;
  },
  actor?: AuditActor
): { state: SchoolECSState; term?: AcademicTermEntity; error?: string } {
  const name = input.name.trim();
  const startDate = input.startDate.trim();
  const endDate = input.endDate.trim();
  if (!name) return { state, error: 'Term name is required.' };
  if (
    !/^\d{4}-\d{2}-\d{2}$/.test(startDate) ||
    !/^\d{4}-\d{2}-\d{2}$/.test(endDate)
  ) {
    return {
      state,
      error: 'Start and end dates must use YYYY-MM-DD format.',
    };
  }
  if (endDate < startDate) {
    return { state, error: 'End date must be on or after the start date.' };
  }

  const currentTerms = state.academicTerms ?? [];
  const existing = input.id
    ? currentTerms.find((t) => t.id === input.id)
    : undefined;
  const term: AcademicTermEntity = {
    id: existing?.id ?? `term_${Date.now().toString(36)}`,
    name,
    startDate,
    endDate,
    isActive: input.isActive ?? existing?.isActive ?? currentTerms.length === 0,
  };

  let nextTerms = existing
    ? currentTerms.map((t) => (t.id === term.id ? term : t))
    : [...currentTerms, term];

  let nextActiveId = state.activeTermId;
  if (term.isActive) {
    nextTerms = nextTerms.map((t) => ({ ...t, isActive: t.id === term.id }));
    nextActiveId = term.id;
  }

  return {
    state: {
      ...state,
      academicTerms: nextTerms,
      activeTermId: nextActiveId,
      auditLogs: appendAudit(state, {
        actorId: actor?.actorId ?? 'usr_admin',
        actorName: actor?.actorName ?? 'Portal Admin',
        actorRole: actor?.actorRole ?? 'admin',
        action: existing ? 'Updated Academic Term' : 'Added Academic Term',
        entityType: 'school_event',
        entityId: term.id,
        targetLabel: term.name,
        detail: `${term.startDate} to ${term.endDate}${term.isActive ? ' (Active)' : ''}`,
      }),
    },
    term,
  };
}

export function setActiveAcademicTerm(
  state: SchoolECSState,
  termId: string,
  actor?: AuditActor
): SchoolECSState {
  const terms = state.academicTerms ?? [];
  const target = terms.find((t) => t.id === termId);
  if (!target) return state;
  return {
    ...state,
    activeTermId: termId,
    academicTerms: terms.map((t) => ({ ...t, isActive: t.id === termId })),
    auditLogs: appendAudit(state, {
      actorId: actor?.actorId ?? 'usr_admin',
      actorName: actor?.actorName ?? 'Portal Admin',
      actorRole: actor?.actorRole ?? 'admin',
      action: 'Switched Active Term',
      entityType: 'school_event',
      entityId: termId,
      targetLabel: target.name,
      detail: `${target.startDate} to ${target.endDate}`,
    }),
  };
}

export function computeAdminAttentionItems(
  state: SchoolECSState,
  todayYmd = '2026-11-25'
): AdminAttentionItem[] {
  const items: AdminAttentionItem[] = [];

  const unsignedDiary = state.diaryEntries.filter((d) => !d.parentAcknowledged);
  if (unsignedDiary.length > 0) {
    items.push({
      id: 'att_unsigned_diary',
      severity: 'medium',
      title: `${unsignedDiary.length} diary note${unsignedDiary.length === 1 ? '' : 's'} awaiting parent sign-off`,
      detail: 'Follow up with guardians or review pending homework acknowledgments.',
      count: unsignedDiary.length,
      actionLabel: 'Review Diary',
      targetModule: 'diary',
    });
  }

  const classroomsMissingRegister = state.classrooms.filter((cls) => {
    const classLearners = state.learners.filter((l) => l.classroomId === cls.id);
    if (classLearners.length === 0) return false;
    return !state.attendanceRecords.some(
      (r) => r.classroomId === cls.id && r.date === todayYmd
    );
  });
  if (classroomsMissingRegister.length > 0) {
    items.push({
      id: 'att_missing_register',
      severity: 'high',
      title: `${classroomsMissingRegister.length} class${classroomsMissingRegister.length === 1 ? '' : 'es'} missing today's register`,
      detail: classroomsMissingRegister.map((c) => c.name).join(', '),
      count: classroomsMissingRegister.length,
      actionLabel: 'Take Register',
      targetModule: 'register',
    });
  }

  const substrandCov = computeSubstrandCoverage(state);
  const behindSubstrands = substrandCov.filter((s) => s.coveragePercent < 50);
  if (behindSubstrands.length > 0) {
    items.push({
      id: 'att_behind_coverage',
      severity: 'medium',
      title: `${behindSubstrands.length} scheme topic${behindSubstrands.length === 1 ? '' : 's'} below 50% coverage`,
      detail: behindSubstrands
        .slice(0, 2)
        .map((b) => `${b.substrand.code} ${b.substrand.title}`)
        .join(' · '),
      count: behindSubstrands.length,
      actionLabel: 'Check Coverage',
      targetModule: 'coverage',
    });
  }

  const unassignedLessons = state.lessonPlans.filter((lp) => !lp.timetableSlotId);
  if (unassignedLessons.length > 0) {
    items.push({
      id: 'att_unassigned_lessons',
      severity: 'info',
      title: `${unassignedLessons.length} lesson plan${unassignedLessons.length === 1 ? '' : 's'} not assigned to a timetable slot`,
      detail: unassignedLessons.slice(0, 2).map((l) => l.title).join(' · '),
      count: unassignedLessons.length,
      actionLabel: 'Assign Lessons',
      targetModule: 'lessons',
    });
  }

  return items;
}

export function computeTeacherTodaySchedule(
  state: SchoolECSState,
  teacherId: string,
  dayCode = 'Wed'
): TeacherTodayPeriod[] {
  return state.timetableSlots
    .filter(
      (s) =>
        s.teacherId === teacherId &&
        s.day.toLowerCase() === dayCode.toLowerCase()
    )
    .sort((a, b) => a.period - b.period)
    .map((slot) => ({
      slot,
      classroom: state.classrooms.find((c) => c.id === slot.classroomId),
      subject: state.subjects.find((sub) => sub.id === slot.subjectId),
      lessonPlan: state.lessonPlans.find(
        (lp) => lp.id === slot.lessonPlanId || lp.timetableSlotId === slot.id
      ),
    }));
}

export function getTeacherPendingLessonPlans(
  state: SchoolECSState,
  teacherId: string
): LessonPlanEntity[] {
  return state.lessonPlans
    .filter((lp) => lp.teacherId === teacherId && lp.status !== 'taught')
    .sort((a, b) => a.scheduledDate.localeCompare(b.scheduledDate));
}

export function computeParentChildDigests(
  state: SchoolECSState,
  linkedLearnerIds?: string[],
  activeLearnerId?: string,
  todayYmd = '2026-11-25'
): ParentChildDigest[] {
  const children = state.learners.filter((l) =>
    linkedLearnerIds && linkedLearnerIds.length > 0
      ? linkedLearnerIds.includes(l.id)
      : activeLearnerId
        ? l.id === activeLearnerId
        : false
  );

  return children.map((learner) => {
    const classroom = state.classrooms.find((c) => c.id === learner.classroomId);
    const todayAttendance = state.attendanceRecords.find(
      (r) => r.learnerId === learner.id && r.date === todayYmd
    );
    const pendingDiaryEntries = state.diaryEntries
      .filter((d) => d.learnerId === learner.id && !d.parentAcknowledged)
      .sort((a, b) => b.date.localeCompare(a.date));
    const latestAssessment = state.assessments
      .filter((a) => a.learnerId === learner.id)
      .sort((a, b) => b.date.localeCompare(a.date))[0];

    return {
      learner,
      classroom,
      todayAttendance,
      pendingDiaryEntries,
      latestAssessment,
    };
  });
}

export function buildQuickJumpItems(
  state: SchoolECSState,
  role: Role,
  query: string,
  linkedLearnerIds?: string[]
): QuickJumpItem[] {
  const q = query.trim().toLowerCase();
  const isParent = role === 'parent';

  const moduleEntries: QuickJumpItem[] = isParent
    ? [
        {
          id: 'mod_home',
          category: 'module',
          title: 'School Events & Calendar',
          subtitle: 'Upcoming dates, child updates, and quick sign-offs',
          targetModule: 'home',
        },
        {
          id: 'mod_learners',
          category: 'module',
          title: "My Child's Details",
          subtitle: 'Attendance, homework diary, assessments, and term report',
          targetModule: 'learners',
        },
      ]
    : [
        {
          id: 'mod_home',
          category: 'module',
          title: 'Home & Calendar',
          subtitle: 'Daily priorities, events, and school overview',
          targetModule: 'home',
        },
        {
          id: 'mod_timetable',
          category: 'module',
          title: 'Timetable',
          subtitle: 'Weekly period schedule and lesson links',
          targetModule: 'timetable',
        },
        {
          id: 'mod_register',
          category: 'module',
          title: 'Class Register',
          subtitle: 'Daily roll call and attendance shortcuts',
          targetModule: 'register',
        },
        {
          id: 'mod_learners',
          category: 'module',
          title: 'Learners Directory',
          subtitle: 'Student profiles, enrollment, and bulk CSV import',
          targetModule: 'learners',
        },
        {
          id: 'mod_diary',
          category: 'module',
          title: 'School Diary',
          subtitle: 'Daily homework and guardian sign-offs',
          targetModule: 'diary',
        },
        {
          id: 'mod_assessments',
          category: 'module',
          title: 'Assessments',
          subtitle: 'Substrand mastery scores and teacher feedback',
          targetModule: 'assessments',
        },
        {
          id: 'mod_schemes',
          category: 'module',
          title: 'Schemes of Work',
          subtitle: 'Strands and substrands grouped by classroom',
          targetModule: 'schemes',
        },
        {
          id: 'mod_lessons',
          category: 'module',
          title: 'Lesson Plans',
          subtitle: 'Lesson registry, teaching status, and duplication',
          targetModule: 'lessons',
        },
        ...(role === 'admin'
          ? [
              {
                id: 'mod_coverage',
                category: 'module' as const,
                title: 'Coverage & Audit',
                subtitle: 'Syllabus delivery analytics and audit log',
                targetModule: 'coverage' as const,
              },
              {
                id: 'mod_classrooms',
                category: 'module' as const,
                title: 'Classrooms',
                subtitle: 'Streams, homeroom teachers, and score spread',
                targetModule: 'classrooms' as const,
              },
              {
                id: 'mod_parents',
                category: 'module' as const,
                title: 'Parents & Zones',
                subtitle: 'Families, siblings, and transport locations',
                targetModule: 'parents' as const,
              },
              {
                id: 'mod_schema',
                category: 'module' as const,
                title: 'Custom Fields & Terms',
                subtitle: 'Custom fields, page layout, users, and academic terms',
                targetModule: 'schema' as const,
              },
            ]
          : []),
      ];

  const scopedLearners = isParent
    ? state.learners.filter(
        (l) => !linkedLearnerIds || linkedLearnerIds.includes(l.id)
      )
    : state.learners;

  const learnerEntries: QuickJumpItem[] = scopedLearners.map((l) => {
    const cls = state.classrooms.find((c) => c.id === l.classroomId);
    return {
      id: `jmp_lrn_${l.id}`,
      category: 'learner',
      title: l.name,
      subtitle: `${l.admissionNo} · ${cls?.name ?? l.classroomId}`,
      targetModule: 'learners',
      learnerId: l.id,
    };
  });

  const classroomEntries: QuickJumpItem[] = isParent
    ? []
    : state.classrooms.map((c) => ({
        id: `jmp_cls_${c.id}`,
        category: 'classroom',
        title: `${c.name} Register`,
        subtitle: `Room ${c.roomCode} · ${c.gradeLevel}`,
        targetModule: 'register',
        classroomId: c.id,
      }));

  const lessonEntries: QuickJumpItem[] = isParent
    ? []
    : state.lessonPlans.map((lp) => {
        const cls = state.classrooms.find((c) => c.id === lp.classroomId);
        return {
          id: `jmp_lp_${lp.id}`,
          category: 'lesson',
          title: lp.title,
          subtitle: `${cls?.name ?? lp.classroomId} · ${lp.scheduledDate}`,
          targetModule: 'lessons',
        };
      });

  const all = [
    ...learnerEntries,
    ...classroomEntries,
    ...lessonEntries,
    ...moduleEntries,
  ];
  if (!q) {
    return all.slice(0, 12);
  }
  return all
    .filter(
      (item) =>
        item.title.toLowerCase().includes(q) ||
        item.subtitle.toLowerCase().includes(q)
    )
    .slice(0, 14);
}

export function copyClassroomAttendanceFromDate(
  state: SchoolECSState,
  input: {
    classroomId: string;
    teacherId: string;
    toDate: string;
    fromDate?: string;
  },
  actor?: AuditActor
): { state: SchoolECSState; count: number; sourceDate?: string; error?: string } {
  const learners = state.learners.filter(
    (l) => l.classroomId === input.classroomId
  );
  if (learners.length === 0) {
    return {
      state,
      count: 0,
      error: 'No learners enrolled in the selected classroom.',
    };
  }

  let sourceDate = input.fromDate?.trim();
  if (!sourceDate) {
    const priorDates = Array.from(
      new Set(
        state.attendanceRecords
          .filter(
            (r) => r.classroomId === input.classroomId && r.date < input.toDate
          )
          .map((r) => r.date)
      )
    ).sort((a, b) => b.localeCompare(a));
    sourceDate = priorDates[0];
  }

  if (!sourceDate) {
    return {
      state,
      count: 0,
      error: `No earlier register exists for this classroom before ${input.toDate}.`,
    };
  }

  const sourceRecords = state.attendanceRecords.filter(
    (r) => r.classroomId === input.classroomId && r.date === sourceDate
  );
  if (sourceRecords.length === 0) {
    return {
      state,
      count: 0,
      error: `No attendance records found on ${sourceDate} for this classroom.`,
    };
  }

  let nextState = state;
  let copiedCount = 0;
  for (const learner of learners) {
    const prev = sourceRecords.find((r) => r.learnerId === learner.id);
    if (!prev) continue;
    const res = upsertAttendanceRecord(
      nextState,
      {
        learnerId: learner.id,
        teacherId: input.teacherId,
        date: input.toDate,
        status: prev.status,
        remark: prev.remark || `Copied from ${sourceDate}.`,
        customFields: { ...(prev.customFields ?? {}) },
      },
      actor
    );
    if (!res.error) {
      nextState = res.state;
      copiedCount += 1;
    }
  }

  if (copiedCount === 0) {
    return {
      state,
      count: 0,
      error: `No matching learner attendance records found on ${sourceDate}.`,
    };
  }

  return { state: nextState, count: copiedCount, sourceDate };
}

function splitCsvRow(line: string): string[] {
  const cells: string[] = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i += 1;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === ',' && !inQuotes) {
      cells.push(current.trim());
      current = '';
    } else {
      current += ch;
    }
  }
  cells.push(current.trim());
  return cells;
}

export function parseAndImportLearnersCsv(
  state: SchoolECSState,
  csvText: string,
  defaultClassroomId: string,
  actor?: AuditActor
): {
  state: SchoolECSState;
  importedCount: number;
  errors: string[];
} {
  const lines = csvText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  if (lines.length === 0) {
    return { state, importedCount: 0, errors: ['CSV input is empty.'] };
  }

  const headerCells = splitCsvRow(lines[0]).map((h) => h.toLowerCase());
  const looksLikeHeader =
    headerCells.some((h) => h.includes('name')) &&
    headerCells.some((h) => h.includes('adm') || h.includes('email'));
  const dataLines = looksLikeHeader ? lines.slice(1) : lines;

  if (dataLines.length === 0) {
    return {
      state,
      importedCount: 0,
      errors: ['No learner rows found below the header.'],
    };
  }

  let nextState = state;
  let importedCount = 0;
  const errors: string[] = [];

  for (let i = 0; i < dataLines.length; i += 1) {
    const rowNum = looksLikeHeader ? i + 2 : i + 1;
    const cols = splitCsvRow(dataLines[i]);
    const [
      rawName = '',
      rawAdm = '',
      rawClass = '',
      rawLocation = '',
      rawParent = '',
      rawEmail = '',
      rawPhone = '',
      rawNote = '',
    ] = cols;

    const matchedClass = nextState.classrooms.find(
      (c) =>
        c.id.toLowerCase() === rawClass.toLowerCase() ||
        c.name.toLowerCase() === rawClass.toLowerCase()
    );
    const resolvedClassroomId = matchedClass?.id || defaultClassroomId;

    const matchedLoc = rawLocation
      ? (nextState.locations ?? []).find(
          (loc) =>
            loc.id.toLowerCase() === rawLocation.toLowerCase() ||
            loc.name.toLowerCase() === rawLocation.toLowerCase()
        )
      : undefined;

    const res = createLearner(
      nextState,
      {
        name: rawName,
        admissionNo: rawAdm,
        classroomId: resolvedClassroomId,
        locationId: matchedLoc?.id,
        parentName: rawParent,
        parentEmail: rawEmail,
        guardianPhone: rawPhone,
        internalHealthNote: rawNote,
      },
      actor
    );

    if (res.error) {
      errors.push(`Row ${rowNum}: ${res.error}`);
    } else {
      nextState = res.state;
      importedCount += 1;
    }
  }

  return { state: nextState, importedCount, errors };
}

export function duplicateLessonPlan(
  state: SchoolECSState,
  lessonPlanId: string,
  input?: { scheduledDate?: string; titleSuffix?: string },
  actor?: AuditActor
): { state: SchoolECSState; plan?: LessonPlanEntity; error?: string } {
  const source = state.lessonPlans.find((lp) => lp.id === lessonPlanId);
  if (!source) {
    return { state, error: 'Source lesson plan not found.' };
  }
  const suffix = input?.titleSuffix ?? ' (Copy)';
  return createLessonPlan(
    state,
    {
      teacherId: source.teacherId,
      classroomId: source.classroomId,
      substrandId: source.substrandId,
      title: `${source.title}${suffix}`,
      scheduledDate: input?.scheduledDate ?? source.scheduledDate,
      lessonsDelivered: 0,
      status: 'planned',
      reflectionNote: source.reflectionNote,
      customFields: { ...(source.customFields ?? {}) },
    },
    actor
  );
}

export function computeOnboardingChecklist(
  state: SchoolECSState
): OnboardingChecklistItem[] {
  const hasAssignedClassTeacher = state.classrooms.some((c) =>
    Boolean(c.classTeacherId)
  );
  const hasLearners = state.learners.length > 0;
  const hasLinkedParent = state.users.some(
    (u) => u.role === 'parent' && u.linkedLearnerIds.length > 0
  );
  const hasLocations = (state.locations ?? []).length > 0;
  const hasSchemes = state.strands.length > 0 && state.substrands.length > 0;

  return [
    {
      id: 'chk_classrooms',
      label: 'Set up classrooms & lead teachers',
      description: `${state.classrooms.length} stream${state.classrooms.length === 1 ? '' : 's'} ready.`,
      completed: state.classrooms.length > 0 && hasAssignedClassTeacher,
      targetModule: 'classrooms',
    },
    {
      id: 'chk_schemes',
      label: 'Review Schemes of Work & active term',
      description: `${state.strands.length} strands · ${state.substrands.length} substrands configured.`,
      completed: hasSchemes,
      targetModule: 'schemes',
    },
    {
      id: 'chk_learners',
      label: 'Enroll or CSV-import learners',
      description: `${state.learners.length} enrolled learner${state.learners.length === 1 ? '' : 's'}.`,
      completed: hasLearners,
      targetModule: 'learners',
    },
    {
      id: 'chk_parents',
      label: 'Configure home locations & link parents',
      description: `${(state.locations ?? []).length} transport locations · guardian portal access.`,
      completed: hasLocations && hasLinkedParent,
      targetModule: 'parents',
    },
  ];
}

export function clearSampleData(
  state: SchoolECSState,
  actor?: AuditActor
): SchoolECSState {
  const keptUsers = state.users.filter((u) => u.role !== 'parent');
  return {
    ...state,
    users: keptUsers,
    learners: [],
    diaryEntries: [],
    assessments: [],
    lessonPlans: [],
    attendanceRecords: [],
    timetableSlots: [],
    auditLogs: [
      {
        id: `aud_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        timestamp: formatAuditTimestamp(),
        actorId: actor?.actorId ?? 'usr_admin',
        actorName: actor?.actorName ?? 'Portal Admin',
        actorRole: actor?.actorRole ?? 'admin',
        action: 'Cleared Sample Data',
        entityType: 'learner',
        entityId: 'sample_reset',
        targetLabel: 'School Workspace',
        detail:
          'Cleared demo learners, diary logs, assessments, lesson plans, and register history',
      },
    ],
  };
}




