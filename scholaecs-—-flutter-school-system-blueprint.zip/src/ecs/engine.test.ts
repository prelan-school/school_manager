import test from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_WEB_ADMIN_EMAIL,
  DEFAULT_WEB_SEED_PASSWORD,
  INITIAL_ECS_STATE,
  INITIAL_PORTAL_ACCOUNTS,
} from './initialData';
import {
  archiveDynamicField,
  assignClassTeacher,
  assignLessonToTimetableSlot,
  authenticatePortalAccount,
  broadcastClassroomDiary,
  buildLearnerLongitudinalReport,
  buildLearnerPrintableReportHtml,
  buildQuickJumpItems,
  buildScoreCandlesticks,
  clearSampleData,
  computeAdminAttentionItems,
  computeClassroomMatrix,
  computeLocationSummaries,
  computeOnboardingChecklist,
  computeParentChildDigests,
  computeParentSummaries,
  computeSubjectMasteryProgression,
  computeSubstrandCoverage,
  computeTeacherClassMatrix,
  computeTeacherCoverageSummaries,
  computeTeacherTodaySchedule,
  copyClassroomAttendanceFromDate,
  createAssessmentEntry,
  createDiaryEntry,
  createLearner,
  createLessonPlan,
  deleteLessonPlan,
  deleteLocation,
  deleteScheduleDay,
  deleteSchoolEvent,
  deleteTimetableSlot,
  duplicateLessonPlan,
  getActiveAcademicTerm,
  getFieldsForEntity,
  getPageWidgetsForRole,
  getScheduleDaysForClassroom,
  getTeacherPendingLessonPlans,
  invitePortalUserAccount,
  markClassroomAllPresent,
  parseAndImportLearnersCsv,
  registerDynamicField,
  registerPortalAccount,
  registerSchemeStrand,
  registerSchemeSubstrand,
  removeDynamicField,
  resetPortalAccountPassword,
  restoreDynamicField,
  setActiveAcademicTerm,
  toggleDayClassroomMapping,
  togglePageWidgetEnabled,
  togglePageWidgetRole,
  updateDynamicField,
  updateLearnerProfile,
  updateLessonPlan,
  updateLessonStatus,
  updatePortalUserAccount,
  updateSchemeStrand,
  updateSchemeSubstrand,
  upsertAcademicTerm,
  upsertClassroom,
  upsertLocation,
  upsertScheduleDay,
  upsertSchoolEvent,
  upsertTimetableSlot,
  validateWebAuthInputs,
} from './engine';
import { buildAdminAiSnapshot } from './aiSummaryPayload';

test('dynamic field added to diary_entry is immediately queryable and persists in new entries', () => {
  const resField = registerDynamicField(INITIAL_ECS_STATE, {
    label: 'Leadership Points',
    targetEntityType: 'diary_entry',
    fieldType: 'number',
    required: true,
    visibleTo: ['admin', 'teacher', 'parent'],
    editableBy: ['admin', 'teacher'],
    description: 'Points awarded for peer leadership.',
  });
  assert.ok(resField.field);
  assert.equal(resField.field.key, 'leadership_points');

  const parentFields = getFieldsForEntity(resField.state, 'diary_entry', 'parent');
  assert.ok(parentFields.some((f) => f.key === 'leadership_points'));

  const invalidDiary = createDiaryEntry(resField.state, {
    learnerId: 'lrn_zuri',
    teacherId: 'tch_amara',
    date: '2026-11-25',
    homeworkSummary: 'Read chapter 4',
    teacherNote: 'Great focus',
    customFields: {},
    actorRole: 'teacher',
  });
  assert.ok(invalidDiary.error);

  const validDiary = createDiaryEntry(resField.state, {
    learnerId: 'lrn_zuri',
    teacherId: 'tch_amara',
    date: '2026-11-25',
    homeworkSummary: 'Read chapter 4',
    teacherNote: 'Great focus',
    customFields: { leadership_points: 5, awards: 'Peer Mentor' },
    actorRole: 'teacher',
  });
  assert.ok(validDiary.entry);
  assert.equal(validDiary.entry.customFields.leadership_points, 5);
});

test('scheme strand -> substrand registers once and pulls directly into assessments and lesson coverage', () => {
  const s1 = registerSchemeStrand(INITIAL_ECS_STATE, {
    subjectId: 'sub_math5',
    code: 'STR-M3',
    title: 'Data Handling & Probability',
    term: 'Term 2',
    createdByTeacherId: 'tch_amara',
  });
  assert.ok(s1.strand);

  const s2 = registerSchemeSubstrand(s1.state, {
    strandId: s1.strand.id,
    code: '3.1',
    title: 'Bar Graphs & Line Plots',
    learningOutcome: 'Construct scaled bar graphs from survey data.',
    targetLessons: 4,
  });
  assert.ok(s2.substrand);

  const asm = createAssessmentEntry(s2.state, {
    learnerId: 'lrn_zuri',
    substrandId: s2.substrand.id,
    teacherId: 'tch_amara',
    date: '2026-11-25',
    mastery: 'Exceeding',
    scorePercent: 95,
    performanceComment: 'Scaled axes accurately without prompts.',
    customFields: {},
    actorRole: 'teacher',
  });
  assert.ok(asm.entry);
  assert.equal(asm.entry.strandId, s1.strand.id);
  assert.equal(asm.entry.subjectId, 'sub_math5');

  const lp = createLessonPlan(asm.state, {
    teacherId: 'tch_amara',
    classroomId: 'cls_5a',
    substrandId: s2.substrand.id,
    title: 'Class Survey Bar Charts',
    scheduledDate: '2026-11-25',
    lessonsDelivered: 2,
    status: 'taught',
    reflectionNote: 'All learners plotted class heights.',
  });
  assert.ok(lp.plan);

  const coverage = computeSubstrandCoverage(lp.state).find(
    (c) => c.substrand.id === s2.substrand!.id
  );
  assert.ok(coverage);
  assert.equal(coverage.deliveredLessons, 2);
  assert.equal(coverage.coveragePercent, 50);

  const updated = updateLessonStatus(lp.state, lp.plan.id, 'taught', 4);
  const coverageAfter = computeSubstrandCoverage(updated).find(
    (c) => c.substrand.id === s2.substrand!.id
  );
  assert.equal(coverageAfter?.coveragePercent, 100);

  const teacherSummary = computeTeacherCoverageSummaries(updated).find(
    (t) => t.teacher.id === 'tch_amara'
  );
  assert.ok(teacherSummary && teacherSummary.taughtPlans >= 3);
});

test('role projection hides internal teacher/admin fields from parent portal', () => {
  const teacherFields = getFieldsForEntity(
    INITIAL_ECS_STATE,
    'attendance_record',
    'teacher'
  );
  const parentFields = getFieldsForEntity(
    INITIAL_ECS_STATE,
    'attendance_record',
    'parent'
  );
  assert.ok(teacherFields.some((f) => f.key === 'uniform_compliant'));
  assert.ok(!parentFields.some((f) => f.key === 'uniform_compliant'));
});

test('loosely coupled page widgets align per role and respond to live schema composition', () => {
  const adminWidgets = getPageWidgetsForRole(
    INITIAL_ECS_STATE,
    'learner_profile',
    'admin'
  );
  const parentWidgets = getPageWidgetsForRole(
    INITIAL_ECS_STATE,
    'learner_profile',
    'parent'
  );
  assert.ok(adminWidgets.some((w) => w.id === 'learner_enrollment'));
  assert.ok(!parentWidgets.some((w) => w.id === 'learner_enrollment'));

  const toggled = togglePageWidgetEnabled(INITIAL_ECS_STATE, 'learner_timetable');
  const afterDisable = getPageWidgetsForRole(toggled, 'learner_profile', 'teacher');
  assert.ok(!afterDisable.some((w) => w.id === 'learner_timetable'));

  const granted = togglePageWidgetRole(INITIAL_ECS_STATE, 'learner_enrollment', 'parent');
  const parentAfterGrant = getPageWidgetsForRole(granted, 'learner_profile', 'parent');
  assert.ok(parentAfterGrant.some((w) => w.id === 'learner_enrollment'));
});

test('longitudinal learner report filters from registration date vs last 30 days and strips staff uniform flags for parents', () => {
  const sinceReg = buildLearnerLongitudinalReport(
    INITIAL_ECS_STATE,
    'lrn_zuri',
    'admin',
    { preset: 'since_registration' }
  );
  const last30 = buildLearnerLongitudinalReport(
    INITIAL_ECS_STATE,
    'lrn_zuri',
    'parent',
    { preset: 'last_30_days' }
  );
  assert.ok(sinceReg && last30);
  assert.ok(sinceReg.assessments.length > last30.assessments.length);
  assert.ok(sinceReg.timeline.some((e) => e.category === 'registration'));
  assert.ok(!last30.timeline.some((e) => e.category === 'registration'));
  assert.ok(
    sinceReg.timeline.some(
      (e) => e.category === 'attendance' && e.detail.includes('Uniform:')
    )
  );
  assert.ok(
    !last30.timeline.some(
      (e) => e.category === 'attendance' && e.detail.includes('Uniform:')
    )
  );
});

test('admin can perform full CRUD on component fields across learner and module entities', () => {
  const created = registerDynamicField(INITIAL_ECS_STATE, {
    label: 'Transport Bus Route',
    targetEntityType: 'learner',
    fieldType: 'text',
    required: false,
    visibleTo: ['admin', 'teacher', 'parent'],
    editableBy: ['admin'],
    description: 'Assigned afternoon school bus route.',
  });
  assert.ok(created.field);

  const updated = updateDynamicField(created.state, created.field.id, {
    label: 'School Bus Route',
    fieldType: 'select',
    options: ['Route A', 'Route B'],
    required: true,
    visibleTo: ['admin', 'parent'],
  });
  assert.ok(updated.field);
  assert.equal(updated.field.key, 'school_bus_route');
  assert.equal(updated.field.fieldType, 'select');
  assert.deepEqual(updated.field.options, ['Route A', 'Route B']);

  const savedLearner = updateLearnerProfile(updated.state, 'lrn_zuri', {
    customFields: { school_bus_route: 'Route A' },
  });
  assert.equal(savedLearner.error, undefined);
  assert.equal(
    savedLearner.state.learners.find((l) => l.id === 'lrn_zuri')?.customFields
      .school_bus_route,
    'Route A'
  );

  const afterDelete = removeDynamicField(savedLearner.state, updated.field.id);
  assert.ok(!afterDelete.dynamicFields.some((f) => f.id === updated.field!.id));
});

test('archiving a component schema hides it from active inputs while preserving historical readout labels', () => {
  const archived = archiveDynamicField(INITIAL_ECS_STATE, 'df_diary_awards');
  const activeDiaryFields = getFieldsForEntity(archived, 'diary_entry', 'teacher', false);
  const readoutDiaryFields = getFieldsForEntity(archived, 'diary_entry', 'teacher', true);

  assert.ok(!activeDiaryFields.some((f) => f.id === 'df_diary_awards'));
  assert.ok(readoutDiaryFields.some((f) => f.id === 'df_diary_awards'));

  const restored = restoreDynamicField(archived, 'df_diary_awards');
  const afterRestore = getFieldsForEntity(restored, 'diary_entry', 'teacher', false);
  assert.ok(afterRestore.some((f) => f.id === 'df_diary_awards'));
});

test('batch diary broadcast and mark-all-present register apply across classroom learners', () => {
  const cls5aLearners = INITIAL_ECS_STATE.learners.filter(
    (l) => l.classroomId === 'cls_5a'
  );
  const broadcast = broadcastClassroomDiary(INITIAL_ECS_STATE, {
    classroomId: 'cls_5a',
    teacherId: 'tch_amara',
    date: '2026-11-26',
    homeworkSummary: 'Review ratios worksheet',
    teacherNote: 'Quiz tomorrow',
    customFields: { awards: 'Teamwork Week' },
    actorRole: 'teacher',
  });
  assert.equal(broadcast.error, undefined);
  assert.equal(broadcast.entries.length, cls5aLearners.length);

  const register = markClassroomAllPresent(broadcast.state, {
    classroomId: 'cls_5a',
    teacherId: 'tch_amara',
    date: '2026-11-26',
  });
  assert.equal(register.error, undefined);
  assert.equal(register.count, cls5aLearners.length);
  for (const lrn of cls5aLearners) {
    const rec = register.state.attendanceRecords.find(
      (r) => r.learnerId === lrn.id && r.date === '2026-11-26'
    );
    assert.equal(rec?.status, 'present');
  }
});

test('timetable slot validation blocks classroom, teacher, and room conflicts on the same day/period', () => {
  // Classroom cls_5a already has Mon P1
  const clsConflict = upsertTimetableSlot(INITIAL_ECS_STATE, {
    classroomId: 'cls_5a',
    subjectId: 'sub_eng5',
    teacherId: 'tch_david',
    day: 'Mon',
    period: 1,
    timeRange: '08:00 - 08:45',
    room: 'B2-99',
  });
  assert.ok(clsConflict.error?.includes('Classroom'));

  // Teacher tch_amara already teaches Mon P1
  const teacherConflict = upsertTimetableSlot(INITIAL_ECS_STATE, {
    classroomId: 'cls_6b',
    subjectId: 'sub_math5',
    teacherId: 'tch_amara',
    day: 'Mon',
    period: 1,
    timeRange: '08:00 - 08:45',
    room: 'B2-08',
  });
  assert.ok(teacherConflict.error?.includes('Teacher'));

  // Room B2-04 already booked Mon P1
  const roomConflict = upsertTimetableSlot(INITIAL_ECS_STATE, {
    classroomId: 'cls_6b',
    subjectId: 'sub_eng5',
    teacherId: 'tch_david',
    day: 'Mon',
    period: 1,
    timeRange: '08:00 - 08:45',
    room: 'b2-04',
  });
  assert.ok(roomConflict.error?.includes('Room'));

  // Non-conflicting slot succeeds
  const valid = upsertTimetableSlot(INITIAL_ECS_STATE, {
    classroomId: 'cls_6b',
    subjectId: 'sub_eng5',
    teacherId: 'tch_david',
    day: 'Mon',
    period: 1,
    timeRange: '08:00 - 08:45',
    room: 'B2-08',
  });
  assert.equal(valid.error, undefined);
  assert.ok(valid.slot);
});

test('admin can invite staff/guardians and manage multi-child linkedLearnerIds', () => {
  const invited = invitePortalUserAccount(INITIAL_ECS_STATE, {
    email: 'kwame.mensah@family.org',
    displayName: 'Kwame Mensah',
    role: 'parent',
    linkedLearnerIds: ['lrn_liam', 'lrn_nadia'],
  });
  assert.equal(invited.error, undefined);
  assert.ok(invited.user);
  assert.deepEqual(invited.user.linkedLearnerIds, ['lrn_liam', 'lrn_nadia']);

  const promoted = updatePortalUserAccount(invited.state, invited.user.id, {
    role: 'teacher',
    teacherId: 'tch_david',
    linkedLearnerIds: ['lrn_liam'],
  });
  assert.equal(promoted.error, undefined);
  assert.equal(promoted.user?.role, 'teacher');
  assert.equal(promoted.user?.teacherId, 'tch_david');
  assert.deepEqual(promoted.user?.linkedLearnerIds, ['lrn_liam']);
});

test('subject mastery progression and printable HTML report escape special characters safely', () => {
  const progression = computeSubjectMasteryProgression(
    INITIAL_ECS_STATE,
    'lrn_zuri'
  );
  const mathSeries = progression.find((s) => s.subject.id === 'sub_math5');
  assert.ok(mathSeries);
  assert.equal(mathSeries.points.length, 2);
  assert.equal(mathSeries.latestScore, 92);
  assert.equal(mathSeries.deltaFromFirst, 18);

  const injected = updateLearnerProfile(INITIAL_ECS_STATE, 'lrn_zuri', {
    name: 'Zuri <script>alert(1)</script>',
  });
  const html = buildLearnerPrintableReportHtml(
    injected.state,
    'lrn_zuri',
    'parent',
    { preset: 'since_registration' }
  );
  assert.ok(html);
  assert.ok(!html.includes('<script>'));
  assert.ok(html.includes('&lt;script&gt;'));
});

test('admin can CRUD schedule days mapped to classrooms, add classrooms, and clean up slots on day delete', () => {
  const addedDay = upsertScheduleDay(INITIAL_ECS_STATE, {
    code: 'Sat',
    label: 'Saturday Clinic',
    order: 6,
    classroomIds: ['cls_5a'],
    defaultTimeRange: '09:00 - 10:30',
  });
  assert.equal(addedDay.error, undefined);
  assert.ok(addedDay.day);

  const days5a = getScheduleDaysForClassroom(addedDay.state, 'cls_5a');
  const days6b = getScheduleDaysForClassroom(addedDay.state, 'cls_6b');
  assert.ok(days5a.some((d) => d.code === 'Sat'));
  assert.ok(!days6b.some((d) => d.code === 'Sat'));

  const toggled = toggleDayClassroomMapping(addedDay.state, addedDay.day.id, 'cls_6b');
  assert.ok(getScheduleDaysForClassroom(toggled, 'cls_6b').some((d) => d.code === 'Sat'));

  const newCls = upsertClassroom(toggled, {
    name: 'Grade 7A — Cedar',
    gradeLevel: 'Grade 7',
    roomCode: 'C1-02',
    defaultDayIds: ['day_mon', addedDay.day.id],
  });
  assert.equal(newCls.error, undefined);
  assert.ok(newCls.classroom);
  assert.equal(getScheduleDaysForClassroom(newCls.state, newCls.classroom.id).length, 2);

  // Schedule an unassigned lesson onto Sat, then delete Sat and verify clean detachment
  const satSlot = upsertTimetableSlot(newCls.state, {
    classroomId: 'cls_5a',
    subjectId: 'sub_math5',
    teacherId: 'tch_david',
    day: 'Sat',
    period: 1,
    timeRange: '09:00 - 10:30',
    room: 'B2-04',
    lessonPlanId: 'lsn_5',
  });
  assert.equal(satSlot.error, undefined);
  assert.equal(
    satSlot.state.lessonPlans.find((lp) => lp.id === 'lsn_5')?.timetableSlotId,
    satSlot.slot!.id
  );

  const afterDayDelete = deleteScheduleDay(satSlot.state, addedDay.day.id);
  assert.ok(!afterDayDelete.timetableSlots.some((s) => s.id === satSlot.slot!.id));
  assert.equal(
    afterDayDelete.lessonPlans.find((lp) => lp.id === 'lsn_5')?.timetableSlotId,
    undefined
  );
});

test('admin lesson registry supports full CRUD and bidirectional timetable slot binding', () => {
  const created = createLessonPlan(INITIAL_ECS_STATE, {
    teacherId: 'tch_amara',
    classroomId: 'cls_5a',
    substrandId: 'sub_m1_ratio',
    title: 'Algebraic Patterns Lab',
    scheduledDate: '2026-11-28',
    lessonsDelivered: 0,
    status: 'planned',
    reflectionNote: 'Initial draft',
  });
  assert.ok(created.plan);
  assert.equal(created.plan.timetableSlotId, undefined);

  const assigned = assignLessonToTimetableSlot(created.state, {
    lessonPlanId: created.plan.id,
    timetableSlotId: 'tt_thu_2',
    syncSlotSubjectAndTeacher: true,
  });
  assert.equal(assigned.error, undefined);
  assert.equal(
    assigned.state.lessonPlans.find((lp) => lp.id === created.plan!.id)?.timetableSlotId,
    'tt_thu_2'
  );
  assert.equal(
    assigned.state.timetableSlots.find((sl) => sl.id === 'tt_thu_2')?.lessonPlanId,
    created.plan.id
  );

  const edited = updateLessonPlan(assigned.state, created.plan.id, {
    title: 'Algebraic Patterns Workshop',
    status: 'taught',
    lessonsDelivered: 2,
  });
  assert.equal(edited.error, undefined);
  assert.equal(edited.plan?.title, 'Algebraic Patterns Workshop');
  assert.equal(edited.plan?.lessonsDelivered, 2);

  const deleted = deleteLessonPlan(edited.state, created.plan.id);
  assert.ok(!deleted.lessonPlans.some((lp) => lp.id === created.plan!.id));
  assert.equal(
    deleted.timetableSlots.find((sl) => sl.id === 'tt_thu_2')?.lessonPlanId,
    undefined
  );
});

test('timetable CRUD updates/deletes slots and rejects HH:MM overlapping intervals across periods', () => {
  // tt_mon_1 is Mon P1 08:00 - 08:45 with tch_amara in B2-04.
  // Try adding Mon P2 08:30 - 09:15 for tch_amara — overlaps 08:30-08:45!
  const overlap = upsertTimetableSlot(INITIAL_ECS_STATE, {
    classroomId: 'cls_6b',
    subjectId: 'sub_math5',
    teacherId: 'tch_amara',
    day: 'Mon',
    period: 2,
    timeRange: '08:30 - 09:15',
    room: 'B2-99',
  });
  assert.ok(overlap.error?.includes('Teacher'));

  // Edit existing slot tt_fri_1 cleanly
  const edited = upsertTimetableSlot(INITIAL_ECS_STATE, {
    id: 'tt_fri_1',
    classroomId: 'cls_5a',
    subjectId: 'sub_math5',
    teacherId: 'tch_david',
    day: 'Fri',
    period: 2,
    timeRange: '09:00 - 09:45',
    room: 'B2-04',
  });
  assert.equal(edited.error, undefined);
  assert.equal(edited.slot?.period, 2);

  // Delete slot cleanly
  const afterDelete = deleteTimetableSlot(edited.state, 'tt_fri_1');
  assert.ok(!afterDelete.timetableSlots.some((s) => s.id === 'tt_fri_1'));
});

test('school calendar events CRUD enforces admin role, validates date/title, and updates state', () => {
  const denied = upsertSchoolEvent(INITIAL_ECS_STATE, {
    date: '2026-12-25',
    title: 'Christmas Day',
    description: 'National holiday',
    kind: 'holiday',
    actorRole: 'teacher',
  });
  assert.ok(denied.error?.includes('administrators'));

  const badDate = upsertSchoolEvent(INITIAL_ECS_STATE, {
    date: '25-12-2026',
    title: 'Christmas Day',
    description: 'National holiday',
    kind: 'holiday',
    actorRole: 'admin',
  });
  assert.ok(badDate.error?.includes('YYYY-MM-DD'));

  const created = upsertSchoolEvent(INITIAL_ECS_STATE, {
    date: '2026-12-25',
    title: 'Christmas Day',
    description: 'National holiday',
    kind: 'holiday',
    actorRole: 'admin',
  });
  assert.equal(created.error, undefined);
  assert.ok(created.event);
  assert.ok(created.state.schoolEvents.some((e) => e.id === created.event!.id));

  const deleted = deleteSchoolEvent(created.state, created.event!.id, 'admin');
  assert.equal(deleted.error, undefined);
  assert.ok(!deleted.state.schoolEvents.some((e) => e.id === created.event!.id));
});

test('buildAdminAiSnapshot produces accurate counts, alerts, and highlights context', () => {
  const snapshot = buildAdminAiSnapshot(INITIAL_ECS_STATE);
  assert.equal(snapshot.counts.learners, INITIAL_ECS_STATE.learners.length);
  assert.equal(snapshot.upcomingCalendarEvents.length, INITIAL_ECS_STATE.schoolEvents.length);
  assert.ok(snapshot.alertsContext.pendingParentDiarySignoffs.length >= 1);
  assert.ok(snapshot.highlightsContext.strongAssessments.length >= 1);
  assert.ok(snapshot.teacherRollups.length >= 2);
});

test('portal auth validation, sign in, role sign up with child auto-linking, and password reset work', () => {
  assert.ok(
    validateWebAuthInputs({
      email: 'invalid-email',
      password: '123',
      isSignUp: false,
    })
  );

  const okSignIn = authenticatePortalAccount(
    INITIAL_PORTAL_ACCOUNTS,
    DEFAULT_WEB_ADMIN_EMAIL,
    DEFAULT_WEB_SEED_PASSWORD
  );
  assert.equal(okSignIn.error, undefined);
  assert.equal(okSignIn.account?.role, 'admin');

  const wrongPw = authenticatePortalAccount(
    INITIAL_PORTAL_ACCOUNTS,
    DEFAULT_WEB_ADMIN_EMAIL,
    'wrongpw'
  );
  assert.ok(wrongPw.error?.includes('Incorrect password'));

  const dup = registerPortalAccount(INITIAL_PORTAL_ACCOUNTS, INITIAL_ECS_STATE, {
    email: DEFAULT_WEB_ADMIN_EMAIL,
    password: 'Password1!',
    confirmPassword: 'Password1!',
    displayName: 'Duplicate User',
    role: 'teacher',
  });
  assert.ok(dup.error?.includes('already exists'));

  const parentSignUp = registerPortalAccount(
    INITIAL_PORTAL_ACCOUNTS,
    INITIAL_ECS_STATE,
    {
      email: 'liam.father@family.org',
      password: 'Password1!',
      confirmPassword: 'Password1!',
      displayName: 'John Otieno',
      role: 'parent',
      linkedLearnerIds: ['lrn_liam'],
    }
  );
  assert.equal(parentSignUp.error, undefined);
  assert.equal(parentSignUp.account?.role, 'parent');
  assert.deepEqual(parentSignUp.account?.linkedLearnerIds, ['lrn_liam']);
  assert.ok(
    parentSignUp.state.auditLogs.some(
      (a) => a.action === 'Registered Portal Account' && a.actorName === 'John Otieno'
    )
  );

  const reset = resetPortalAccountPassword(
    parentSignUp.accounts,
    'liam.father@family.org',
    'NewPass99'
  );
  assert.equal(reset.error, undefined);
  const signInAfterReset = authenticatePortalAccount(
    reset.accounts,
    'liam.father@family.org',
    'NewPass99'
  );
  assert.equal(signInAfterReset.account?.displayName, 'John Otieno');
});

test('schemes are classroom-scoped and isolate lesson coverage per classroom', () => {
  const s6b = registerSchemeStrand(INITIAL_ECS_STATE, {
    classroomId: 'cls_6b',
    subjectId: 'sub_math5',
    code: 'STR-6B-ALGEBRA',
    title: 'Grade 6B Expressions',
    term: 'Term 2',
    createdByTeacherId: 'tch_david',
  });
  assert.equal(s6b.strand?.classroomId, 'cls_6b');

  const sub6b = registerSchemeSubstrand(s6b.state, {
    strandId: s6b.strand!.id,
    code: '6B.1',
    title: 'Linear Equations',
    learningOutcome: 'Solve one-step linear equations.',
    targetLessons: 4,
  });
  assert.ok(sub6b.substrand);

  // Teach 2 periods in cls_5a under that substrandId -> must NOT credit cls_6b scheme!
  const wrongClassPlan = createLessonPlan(sub6b.state, {
    teacherId: 'tch_amara',
    classroomId: 'cls_5a',
    substrandId: sub6b.substrand!.id,
    title: 'Cross-class spillover guard',
    scheduledDate: '2026-11-27',
    lessonsDelivered: 2,
    status: 'taught',
    reflectionNote: 'Spillover test',
  });
  const covZero = computeSubstrandCoverage(wrongClassPlan.state).find(
    (c) => c.substrand.id === sub6b.substrand!.id
  );
  assert.equal(covZero?.deliveredLessons, 0);

  // Teach 2 periods in cls_6b -> credits 50%
  const rightClassPlan = createLessonPlan(wrongClassPlan.state, {
    teacherId: 'tch_david',
    classroomId: 'cls_6b',
    substrandId: sub6b.substrand!.id,
    title: 'Grade 6B Linear Equations',
    scheduledDate: '2026-11-27',
    lessonsDelivered: 2,
    status: 'taught',
    reflectionNote: 'Delivered in 6B',
  });
  const covHalf = computeSubstrandCoverage(rightClassPlan.state).find(
    (c) => c.substrand.id === sub6b.substrand!.id
  );
  assert.equal(covHalf?.deliveredLessons, 2);
  assert.equal(covHalf?.coveragePercent, 50);
});

test('class teacher assignment, classroom/teacher matrices, candlesticks, parent summaries, and Who & When audit logs', () => {
  const actor = {
    actorId: 'usr_admin',
    actorName: 'Principal Admin',
    actorRole: 'admin' as const,
  };
  const reassigned = assignClassTeacher(
    INITIAL_ECS_STATE,
    'cls_6b',
    'tch_amara',
    actor
  );
  assert.equal(
    reassigned.classrooms.find((c) => c.id === 'cls_6b')?.classTeacherId,
    'tch_amara'
  );
  assert.equal(reassigned.auditLogs[0]?.action, 'Assigned Class Teacher');
  assert.equal(reassigned.auditLogs[0]?.actorName, 'Principal Admin');

  const classMatrix = computeClassroomMatrix(reassigned);
  assert.ok(classMatrix.length >= 2);
  const teacherMatrix = computeTeacherClassMatrix(reassigned);
  const amara = teacherMatrix.find((r) => r.teacher.id === 'tch_amara');
  assert.ok(amara && amara.homeroomClassrooms.length >= 2);

  const parentSummaries = computeParentSummaries(reassigned);
  const grace = parentSummaries.find((p) => p.parentEmail === 'grace.mwangi@family.org');
  assert.ok(grace);
  assert.equal(grace.children.length, 2);
  assert.equal(grace.classrooms.length, 2);

  const candles = buildScoreCandlesticks(reassigned.assessments, {
    bucketBy: 'subject',
    state: reassigned,
  });
  assert.ok(candles.length >= 1);
  for (const pt of candles) {
    assert.ok(pt.high >= pt.low);
    assert.ok(pt.high >= pt.open && pt.high >= pt.close);
    assert.ok(pt.low <= pt.open && pt.low <= pt.close);
  }
});

test('createLearner, updateSchemeStrand, updateSchemeSubstrand, and explicit AuditActor attribution', () => {
  const actor = {
    actorId: 'usr_admin',
    actorName: 'Principal Prelan',
    actorRole: 'admin' as const,
  };

  const enrolled = createLearner(
    INITIAL_ECS_STATE,
    {
      name: 'Kofi Boateng',
      admissionNo: 'SCH-2026-099',
      classroomId: 'cls_5a',
      parentName: 'Abena Boateng',
      parentEmail: 'abena.boateng@family.org',
      guardianPhone: '+254 712 889 100',
    },
    actor
  );
  assert.equal(enrolled.error, undefined);
  assert.ok(enrolled.learner);
  assert.equal(enrolled.state.auditLogs[0]?.action, 'Enrolled New Learner');
  assert.equal(enrolled.state.auditLogs[0]?.actorName, 'Principal Prelan');

  // Duplicate admission no blocked
  const dup = createLearner(enrolled.state, {
    name: 'Duplicate Learner',
    admissionNo: 'sch-2026-099',
    classroomId: 'cls_5a',
    parentName: 'Test Parent',
    parentEmail: 'test@family.org',
    guardianPhone: '+254 700 111 222',
  });
  assert.ok(dup.error?.includes('already assigned'));

  // Update scheme strand & substrand
  const targetStrand = INITIAL_ECS_STATE.strands[0];
  const editedStrand = updateSchemeStrand(
    enrolled.state,
    targetStrand.id,
    { title: 'Number Sense & Operations', term: 'Term 2' },
    actor
  );
  assert.equal(editedStrand.error, undefined);
  assert.equal(editedStrand.strand?.title, 'Number Sense & Operations');
  assert.equal(editedStrand.state.auditLogs[0]?.actorName, 'Principal Prelan');

  const targetSub = INITIAL_ECS_STATE.substrands[0];
  const editedSub = updateSchemeSubstrand(
    editedStrand.state,
    targetSub.id,
    { targetLessons: 6, learningOutcome: 'Updated target mastery.' },
    actor
  );
  assert.equal(editedSub.error, undefined);
  assert.equal(editedSub.substrand?.targetLessons, 6);
  assert.equal(editedSub.state.auditLogs[0]?.action, 'Updated Scheme Substrand');
});

test('Location CRUD, summaries, learner location linking, and verified-email parent guard', () => {
  const actor = {
    actorId: 'usr_admin',
    actorName: 'Principal Admin',
    actorRole: 'admin' as const,
  };

  // Seeded locations exist and parent summaries include locations
  assert.ok(INITIAL_ECS_STATE.locations.length >= 4);
  const initialLocSummaries = computeLocationSummaries(INITIAL_ECS_STATE);
  const kilimani = initialLocSummaries.find((s) => s.location.id === 'loc_kilimani');
  assert.equal(kilimani?.learnerCount, 2);
  const parentSummaries = computeParentSummaries(INITIAL_ECS_STATE);
  const grace = parentSummaries.find((p) => p.parentEmail === 'grace.mwangi@family.org');
  assert.equal(grace?.locations[0]?.id, 'loc_kilimani');

  // Create new location & block duplicate name case-insensitively
  const created = upsertLocation(
    INITIAL_ECS_STATE,
    {
      name: 'Lavington',
      zone: 'West Shuttle Route E',
      notes: 'Pickup 06:55',
    },
    actor
  );
  assert.equal(created.error, undefined);
  assert.ok(created.location);
  assert.equal(created.state.auditLogs[0]?.action, 'Created Location');

  const dup = upsertLocation(created.state, { name: 'lavington' }, actor);
  assert.ok(dup.error?.includes('already exists'));

  // Enroll learner assigned to Lavington and verify updateLearnerProfile clears/updates location
  const enrolled = createLearner(
    created.state,
    {
      name: 'Sanaa Njeri',
      admissionNo: 'SCH-2026-888',
      classroomId: 'cls_5a',
      locationId: created.location!.id,
      parentName: 'Esther Njeri',
      parentEmail: 'esther.njeri@family.org',
      guardianPhone: '+254 711 222 333',
    },
    actor
  );
  assert.equal(enrolled.error, undefined);
  assert.equal(enrolled.learner?.locationId, created.location!.id);

  // Unverified parent registration must NOT auto-link learners by email
  const unverified = registerPortalAccount(INITIAL_PORTAL_ACCOUNTS, enrolled.state, {
    email: 'esther.njeri@family.org',
    password: DEFAULT_WEB_SEED_PASSWORD,
    confirmPassword: DEFAULT_WEB_SEED_PASSWORD,
    displayName: 'Esther Unverified',
    role: 'parent',
    emailVerified: false,
  });
  assert.equal(unverified.error, undefined);
  assert.equal(unverified.account?.linkedLearnerIds.length, 0);

  // Verified parent registration auto-links matching child by parentEmail
  const verified = registerPortalAccount(INITIAL_PORTAL_ACCOUNTS, enrolled.state, {
    email: 'esther.njeri@family.org',
    password: DEFAULT_WEB_SEED_PASSWORD,
    confirmPassword: DEFAULT_WEB_SEED_PASSWORD,
    displayName: 'Esther Verified',
    role: 'parent',
    emailVerified: true,
  });
  assert.equal(verified.error, undefined);
  assert.deepEqual(verified.account?.linkedLearnerIds, [enrolled.learner!.id]);

  // Deleting location clears locationId on learners and logs deletion
  const afterDelete = deleteLocation(enrolled.state, created.location!.id, actor);
  assert.equal(
    afterDelete.learners.find((l) => l.id === enrolled.learner!.id)?.locationId,
    undefined
  );
  assert.equal(afterDelete.auditLogs[0]?.action, 'Deleted Location');
});

test('academic terms CRUD switches active term bounds and resolves this_term report range', () => {
  const actor = {
    actorId: 'usr_admin',
    actorName: 'Principal Admin',
    actorRole: 'admin' as const,
  };
  const initialActive = getActiveAcademicTerm(INITIAL_ECS_STATE);
  assert.equal(initialActive?.id, 'term_1_2026');

  const created = upsertAcademicTerm(
    INITIAL_ECS_STATE,
    {
      name: 'Midterm Intensive (2026)',
      startDate: '2026-10-15',
      endDate: '2026-11-20',
      isActive: true,
    },
    actor
  );
  assert.equal(created.error, undefined);
  assert.ok(created.term);
  assert.equal(getActiveAcademicTerm(created.state)?.id, created.term.id);

  const report = buildLearnerLongitudinalReport(
    created.state,
    'lrn_zuri',
    'admin',
    { preset: 'this_term' },
    '2026-11-25'
  );
  assert.equal(report?.bounds.from, '2026-10-15');
  assert.equal(report?.bounds.to, '2026-11-20');

  const switchedBack = setActiveAcademicTerm(created.state, 'term_1_2026', actor);
  assert.equal(getActiveAcademicTerm(switchedBack)?.id, 'term_1_2026');
});

test('role-specific home task helpers & quick jump search respect role scope', () => {
  const adminQueue = computeAdminAttentionItems(INITIAL_ECS_STATE, '2026-11-25');
  assert.ok(adminQueue.some((item) => item.id === 'att_unsigned_diary'));

  const wedSchedule = computeTeacherTodaySchedule(
    INITIAL_ECS_STATE,
    'tch_amara',
    'Wed'
  );
  assert.ok(Array.isArray(wedSchedule));

  const pendingPlans = getTeacherPendingLessonPlans(INITIAL_ECS_STATE, 'tch_amara');
  assert.ok(pendingPlans.every((p) => p.status !== 'taught'));

  const parentDigests = computeParentChildDigests(
    INITIAL_ECS_STATE,
    ['lrn_zuri', 'lrn_maya'],
    'lrn_zuri',
    '2026-11-25'
  );
  assert.equal(parentDigests.length, 2);
  assert.ok(parentDigests.some((d) => d.pendingDiaryEntries.length >= 1));

  // Quick Jump hides staff classrooms/modules from parents
  const parentJump = buildQuickJumpItems(
    INITIAL_ECS_STATE,
    'parent',
    '',
    ['lrn_zuri']
  );
  assert.ok(parentJump.every((j) => j.category !== 'classroom' && j.category !== 'lesson'));
  assert.ok(parentJump.some((j) => j.learnerId === 'lrn_zuri'));

  const adminRegisterJump = buildQuickJumpItems(
    INITIAL_ECS_STATE,
    'admin',
    'register'
  );
  assert.ok(adminRegisterJump.some((j) => j.targetModule === 'register'));
});

test('register copy-yesterday, CSV learner import, duplicate lesson plan, onboarding checklist & sample reset work', () => {
  const actor = {
    actorId: 'usr_admin',
    actorName: 'Principal Admin',
    actorRole: 'admin' as const,
  };

  // Copy attendance from previous recorded date into 2026-11-29
  const copied = copyClassroomAttendanceFromDate(
    INITIAL_ECS_STATE,
    {
      classroomId: 'cls_5a',
      teacherId: 'tch_amara',
      toDate: '2026-11-29',
    },
    actor
  );
  assert.equal(copied.error, undefined);
  assert.ok(copied.count >= 2);
  assert.ok(copied.sourceDate);

  // Bulk CSV import with 2 valid rows and 1 duplicate admission row
  const csv = [
    'Name,AdmissionNo,Classroom,Location,ParentName,ParentEmail,Phone,Note',
    'Amina Yusuf,SCH-2026-901,Grade 5A — Acacia,Kilimani,Hassan Yusuf,hassan@family.org,+254700111222,No allergies',
    `Duplicate Learner,${INITIAL_ECS_STATE.learners[0].admissionNo},cls_5a,Kilimani,Test,test@family.org,+254700333444,`,
    'Daniel Kiprop,SCH-2026-902,cls_6b,,Sarah Kiprop,sarah.kiprop@family.org,+254700555666,',
  ].join('\n');

  const imported = parseAndImportLearnersCsv(copied.state, csv, 'cls_5a', actor);
  assert.equal(imported.importedCount, 2);
  assert.equal(imported.errors.length, 1);
  assert.ok(imported.state.learners.some((l) => l.admissionNo === 'SCH-2026-901'));

  // Duplicate lesson plan creates a fresh planned copy
  const sourcePlan = INITIAL_ECS_STATE.lessonPlans[0];
  const dupPlan = duplicateLessonPlan(
    imported.state,
    sourcePlan.id,
    { scheduledDate: '2026-12-01' },
    actor
  );
  assert.equal(dupPlan.error, undefined);
  assert.ok(dupPlan.plan);
  assert.equal(dupPlan.plan.status, 'planned');
  assert.equal(dupPlan.plan.lessonsDelivered, 0);
  assert.equal(dupPlan.plan.title, `${sourcePlan.title} (Copy)`);

  // Onboarding checklist reflects active school state
  const checklistBefore = computeOnboardingChecklist(dupPlan.state);
  assert.equal(checklistBefore.length, 4);
  assert.ok(checklistBefore.every((item) => item.completed));

  // Clear sample data wipes demo records while retaining classrooms/schemes/staff
  const cleared = clearSampleData(dupPlan.state, actor);
  assert.equal(cleared.learners.length, 0);
  assert.equal(cleared.lessonPlans.length, 0);
  assert.ok(cleared.classrooms.length > 0);
  assert.ok(cleared.strands.length > 0);
  const checklistAfter = computeOnboardingChecklist(cleared);
  assert.equal(
    checklistAfter.find((i) => i.id === 'chk_learners')?.completed,
    false
  );
});



